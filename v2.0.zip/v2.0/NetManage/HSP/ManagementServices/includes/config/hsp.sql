#
# Table structure for table `hsp_admin_users`
#

DROP TABLE IF EXISTS `hsp_admin_users`;
CREATE TABLE `hsp_admin_users` (
  `uid` int(50) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  `roll` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `username` (`username`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_directories`
#

DROP TABLE IF EXISTS `hsp_directories`;
CREATE TABLE `hsp_directories` (
  `id` int(10) NOT NULL auto_increment,
  `display_name` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `type_dir` int(10) NOT NULL default '0',
  `port` int(10) default '0',
  `base_dn` varchar(255) default NULL,
  `host` varchar(255) default NULL,
  `group_dn` varchar(255) default NULL,
  `user_dn` varchar(255) default NULL,
  `ldap_user_identifier` varchar(255) default NULL,
  `customDirId` int(11) default NULL,
  PRIMARY KEY  (`id`,`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_groups`
#

DROP TABLE IF EXISTS `hsp_groups`;
CREATE TABLE `hsp_groups` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `dirID` int(10) NOT NULL default '0',
  `style` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_apps_links`
#

DROP TABLE IF EXISTS `hsp_apps_links`;
CREATE TABLE `hsp_apps_links` (
  `appID` int(10) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL,
  `protected` tinyint(1) NOT NULL default '0',
	`parameterized` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`appID`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_apps_onweb`
#

DROP TABLE IF EXISTS `hsp_apps_onweb`;
CREATE TABLE `hsp_apps_onweb` (
  `appID` int(10) NOT NULL auto_increment,
  `display_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `hostURL` varchar(255) NOT NULL,
  `appURL` varchar(255) NOT NULL,
  PRIMARY KEY  (`appID`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_apps_w2h`
#

DROP TABLE IF EXISTS `hsp_apps_w2h`;
CREATE TABLE `hsp_apps_w2h` (
  `appID` int(10) NOT NULL auto_increment,
  `paramStr` text NOT NULL,
  `hostURL` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `subType` tinyint(4) NOT NULL default '0',
  `fileName` varchar(255) NOT NULL,
  PRIMARY KEY  (`appID`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_gat_uat`
#

DROP TABLE IF EXISTS `hsp_gat_uat`;
CREATE TABLE `hsp_gat_uat` (
  `id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `nodeList` text NOT NULL,
  `type_entity` varchar(20) NOT NULL
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_tree`
#

DROP TABLE IF EXISTS `hsp_tree`;
CREATE TABLE `hsp_tree` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '1',
  `appID` int(10) unsigned default NULL,
  `application` varchar(255),
  `text` varchar(255),
  `href` varchar(255),
  `title` varchar(255),
  `icon` varchar(255),
  `target` varchar(255),
  `orderfield` int(11) default '0',
  `expanded` tinyint(4) default '0',
	`status` tinyint(4) default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

INSERT INTO `hsp_tree` (`id`, `parent_id`, `appID`, `application`, `text`, `href`, `title`, `icon`, `target`, `orderfield`, `expanded`) VALUES ('', '1', NULL, NULL, 'top level', 'navigate(2)', NULL, NULL, NULL, '0', '1');

# --------------------------------------------------------

#
# Table structure for table `hsp_service_config`
#
DROP TABLE IF EXISTS `hsp_service_config`;
CREATE TABLE `hsp_service_config` (
  `maint_interval` int(255) NOT NULL default '0',
  `server_address` varchar(255) default NULL
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_client_config`
#
DROP TABLE IF EXISTS `hsp_client_config`;
CREATE TABLE `hsp_client_config` (
  `enable_mon` smallint(6) NOT NULL default '0',
  `server_address` varchar(255) default NULL,
  `heartbeat_interval` int(255) NOT NULL default '0'
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_reports`
#

DROP TABLE IF EXISTS `hsp_reports`;
CREATE TABLE `hsp_reports` (
  `dir_name` varchar(255) NOT NULL default '',
  `display_name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`dir_name`)
) TYPE=MyISAM;

#
# Dumping data for table `hsp_reports`
#

INSERT INTO `hsp_reports` VALUES ('report1', 'Connected Sessions');
INSERT INTO `hsp_reports` VALUES ('report2', 'Logged-on Users');
INSERT INTO `hsp_reports` VALUES ('report3', 'Registered Applications');


# --------------------------------------------------------

#
# Table structure for table `hsp_users`
#

DROP TABLE IF EXISTS `hsp_users`;
CREATE TABLE `hsp_users` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `dirID` int(10) NOT NULL default '0',
  `style` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

INSERT INTO `hsp_users` (`id`, `name`) VALUES ('1', 'anonymous');

# --------------------------------------------------------

#
# Table structure for table `hsp_connection_info`
#

DROP TABLE IF EXISTS `hsp_connection_info`;
CREATE TABLE `hsp_connection_info` (
  `CONNECTION_ID` bigint(20) NOT NULL default '0',
  `SESSION_ID` bigint(20) default NULL,
  `VERSION` int(11) default NULL,
  `CONNECTED` int(11) default NULL,
  `ADDITIONAL_INFO` varchar(255) default NULL,
  `HOST_IP_ADDRESS` varchar(255) default NULL,
  `HOST_PORT` int(11) default NULL,
  `HOST_LOGGED_ON_USER` varchar(64) default NULL,
  `SECURITY_PROTOCOL` varchar(64) default NULL,
  `START` datetime default NULL,
  `HEARTBEAT_INTERVAL` int(11) default NULL,
  `END_TIME` datetime default NULL,
  `RESERVED` varchar(255) default NULL,
  PRIMARY KEY  (`CONNECTION_ID`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_registration_info`
#

DROP TABLE IF EXISTS `hsp_registration_info`;
CREATE TABLE `hsp_registration_info` (
  `SESSION_ID` bigint(20) NOT NULL default '0',
  `VERSION` int(11) default NULL,
  `REGISTER_STATUS` int(11) default NULL,
  `APPLICATION_TYPE` varchar(64) default NULL,
  `EMULATION_TYPE` varchar(64) default NULL,
  `SESSION_NAME` varchar(255) default NULL,
  `SESSION_TYPE` varchar(32) default NULL,
  `LOGGED_ON_USER` varchar(255) default NULL,
  `CLIENT_IP_ADDRESS` varchar(255) default NULL,
  `CLIENT_PLATFORM` varchar(128) default NULL,
  `START` datetime default NULL,
  `HEARTBEAT_INTERVAL` int(11) default NULL,
  `END_TIME` datetime default NULL,
  `RESERVED` varchar(255) default NULL,
  PRIMARY KEY  (`SESSION_ID`)
) TYPE=MyISAM;


# --------------------------------------------------------

#
# Table structure for table `hsp_custom_users`
#

DROP TABLE IF EXISTS `hsp_custom_users`;
CREATE TABLE `hsp_custom_users` (
  `id` int(11) NOT NULL auto_increment,
  `dirID` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `fullName` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  `changePassword` tinyint(1) NOT NULL default '0',
  `disabled` tinyint(1) NOT NULL default '0',
  `cannotChangePassword` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `dirID` (`dirID`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_custom_groups`
#

DROP TABLE IF EXISTS `hsp_custom_groups`;
CREATE TABLE `hsp_custom_groups` (
  `id` int(11) NOT NULL auto_increment,
  `dirID` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `dirID` (`dirID`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_custom_directories`
#

DROP TABLE IF EXISTS `hsp_custom_directories`;
CREATE TABLE `hsp_custom_directories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_custom_cross`
#

DROP TABLE IF EXISTS `hsp_custom_cross`;
CREATE TABLE `hsp_custom_cross` (
  `userId` int(11) NOT NULL default '0',
  `groupId` int(11) NOT NULL default '0'
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `hsp_whos_online`
#

DROP TABLE IF EXISTS `hsp_whos_online`;
CREATE TABLE `hsp_whos_online` (
  `sessionId` varchar(128) NOT NULL default '',
  `userId` int(10) default NULL,
  `username` varchar(128) NOT NULL default '',
  `directory` varchar(128) NOT NULL default '',
  `fullName` varchar(64) NOT NULL default '',
  `ipAddress` varchar(15) NOT NULL default '',
  `timeEntry` varchar(14) NOT NULL default '',
  `lastHeartbeat` varchar(14) NOT NULL default '',
  `timeLastClick` varchar(14) NOT NULL default '',
  `lastUrl` varchar(64) NOT NULL default '',
  `lastNodeId` int(10) default NULL,
  KEY `directory` (`directory`)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `version`
#

DROP TABLE IF EXISTS `hsp_general`;
  CREATE TABLE `hsp_general` (
  `version` varchar(10) NOT NULL default '',
  `lastGc` varchar(14) NOT NULL default ''  
) TYPE=MyISAM;


#
# Dumping data for table `version`
#

INSERT INTO `hsp_general` VALUES ('1.2', '');

# --------------------------------------------------------
 
#
# Table structure for table `hsp_user_parameters`
#
 
CREATE TABLE `hsp_user_parameters` (
  `userId` int(10) NOT NULL default '0',
  `paramName` varchar(255) default NULL,
  `paramValue` varchar(255) default NULL
) TYPE=MyISAM;

