<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created: Mars 2004
  Title: global_defines.php
  Purpose: Global string definitions for HSP general use.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/

	$lingua = (isset($_GET['l']) && trim($_GET['l'] != "" ))? $_GET['l']: "portuguese";
	
	if(isset($_POST['lingua'])){
		$lingua = $_POST['lingua'];
	}
	
	define('GLOBAL_CLASSES_DIR' , 'includes/classes/');
	define('STYLE_DIR' , '/includes/stylesheets/');	
	define('PHP_SESSION_SAVE_PATH', 'c:/temp');
	define('CURRENT_LANG' , $lingua);
	define('INCLUDES_DIR' , 'includes/');
	define('CONFIG_CALCULATE_IMAGE_SIZE','true');
	define('IMAGE_REQUIRED','true');
	define('MARGIN_WIDTH' , '100');
	define('LMENU_DIR','includes/LMenu/');
	define('LMENU_IMAGES_DIR','includes/LMenu/images');
	define('PORTAL_STYLE_DIR','Portal/style');
	define('CONFIG_XML_NAME','config.xml');
	define('PERMISSION_XML_NAME', 'permission.xml');
	define('CONFIG_XML_PATH','includes/config/');
	
	if(isset($_GET['username'])){define('LOGIN_USER', $_GET['username']);} 
	
	
// DLL
	define('PHP_AUTH_DLL', 'php_PhPAuthModule.dll');
	define('PHP_AUTH_MODULE', 'PhPAuthModule');
	
// tables
	define('TABLE_ADMIN_USERS','hsp_admin_users');
	define('TABLE_DIRECTORIES','hsp_directories');
	define('TABLE_GROUPS','hsp_groups');	
	define('TABLE_APPS_LINKS','hsp_apps_links');
	define('TABLE_APPS_ONWEB','hsp_apps_onweb');
	define('TABLE_APPS_W2H','hsp_apps_w2h');
	define('TABLE_GAT_UAT','hsp_gat_uat');
	define('TABLE_TREE','hsp_tree');
	
	define('TABLE_REPORTS','hsp_reports');
	define('TABLE_USERS','hsp_users');
	define('TABLE_CLIENT_CONFIG','hsp_client_config');
	define('TABLE_SERVICE_CONFIG','hsp_service_config');
	
	define('TABLE_CONNECTION_INFO','hsp_connection_info');
	define('TABLE_REGISTRATION_INFO','hsp_registration_info');
	define('TABLE_CUSTOM_DIRECTORY','hsp_custom_directories');
	define('TABLE_CUSTOM_USERS','hsp_custom_users');
	define('TABLE_CUSTOM_GROUPS','hsp_custom_groups');
	define('TABLE_CUSTOM_CROSS','hsp_custom_cross');	
	define('TABLE_WHOS_ONLINE','hsp_whos_online');
	
	define('TABLE_GENERAL','hsp_general');
	define('TABLE_USER_PARAMETER','hsp_user_parameters');
	define('TABLE_USER_DURATION','hsp_user_duration');
	define('TABLE_EMULACAO_SIMPLES','hsp_emulacao_simples');
?>