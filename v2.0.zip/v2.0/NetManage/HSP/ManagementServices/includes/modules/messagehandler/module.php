<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     Mars 2004

  Title:            module.php (messageHandler)
  Purpose:          A general module for providing messages that can be displayed to the user.
  Limitations:		Requires PHP 4+

 ============================================================================*/
require_once('includes/classes/ModuleBase.php');
require_once('HTML/Table.php');

class messageHandler extends ModuleBase
{
	var $m_tableOut = null;
	
	function messageHandler($globalobjects)
	{
		$session = $globalobjects->GetSession();
		
		// Make sure that the message is buffer is empty:
		$this->m_tableOut = null;
		
		// Get the messages from the session itself:
		$arrMsgCode = &$session->value(SESSION_MESSAGES);
		
		$boxContents = array();
		
		if(is_array($arrMsgCode))
		{
			// Collect all errors:
			foreach($arrMsgCode as $msgCode)
			{
				// Translate to the correct language:
				$this->outputBuilder($msgCode); 	
			}
		}
		/*
		$boxContents[] = array('text' => $this->m_tableOut->toHtml());
		$box = new infoBox($boxContents);
	    	$this->SetContent($box->getInfoBox());
	    	*/
	    $this->SetContent($this->m_tableOut->toHtml());
	    	
	}

	// Create am HTML table and insert the error code and message to it:
	function outputBuilder($msg)
	{
		// Building a table for presenting the msg stack:
		
		if(is_null($this->m_tableOut))
		{
			$this->m_tableOut  = new HTML_Table("id=tblSessionMesseges");
			$this->m_tableOut-> setAutoGrow(true);
		}
			
		$strOut[0] = '<h6 id="strSessionMessege" class="HomeHeader">'.$msg.'</h6>';
		
		$this->m_tableOut ->addRow($strOut);
	}
}
?>