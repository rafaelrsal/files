<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     Mars 2004

  Title:            module.php (messageHandler)
  Purpose:          A general module for providing error messages that can be displayed 
  					to the user.
  Limitations:		Requires PHP 4+

 ============================================================================*/
require_once('includes/global_errorCodes.php');
require_once('includes/classes/ModuleBase.php');
require_once('HTML/Table.php');

class errorHandler extends ModuleBase
{
	var $m_tableOut = null;
	var $m_Language;
	function errorHandler($globalobjects)
	{
		$moduleName = 'errorHandler';	
		$this->m_Language = $globalobjects->GetLanguage();
		$session = $globalobjects->GetSession();		
		$this->m_Language->GlobalRequireLangFile( 'module.php' , $moduleName);
		
		//$session->set(SESSION_MODULE, $moduleName);
		
		// Make sure that the error table is empty:
		$this->m_tableOut = null;
		
		// Get the error messages from the session itself:		
		$arrErrCodes = &$session->value(SESSION_ERRORS);
		
		// Get rid of the error codes for now.
		$session->remove(SESSION_ERRORS);
		$boxContents = array();
		
		if(is_array($arrErrCodes))
		{
			// Collect all errors:
			foreach($arrErrCodes as $errCode)
			{
				// Translate to the correct language:
				$this->outputBuilder($errCode, ($this->translateError($errCode))); 	
			}
		}
		
		// Allow a single integer code:
		if(is_int($arrErrCodes))
		{
			// Translate to the correct language:
			$this->outputBuilder($arrErrCodes, ($this->translateError($arrErrCodes))); 		
		}				

		$this->SetContent($this->m_tableOut->toHtml());
	}

	// Get the error code, load the right message in the right language:
	function translateError($errorNumber)
	{
		require('includes/modules/errorhandler/includes/languages/'.$this->m_Language->GetLanguage().'/errormessages.php');
		
		$errMsg = $GLOBAL_ERROR_TRANSLATOR[$errorNumber];
		if(is_null($errMsg))
			// Unexpected error - take care of it:
			$errMsg = $GLOBAL_ERROR_TRANSLATOR[HSP_ERR_UNKNOWN_FAILURE];
			
		return $errMsg;
	}								
	
	// Create am HTML table and insert the error code and message to it:
	function outputBuilder($errCode, $errString)
	{
		// Building a table for presenting the error stack:
		
		if(is_null($this->m_tableOut))
		{
			$this->m_tableOut  = new HTML_Table();
			$this->m_tableOut-> setAutoGrow(true);
		}
			
		$strOut[0] = '<font color="Red" size="1">'.ERROR.$errCode.' - '.$errString.'.'.'</font>';
	
		$this->m_tableOut ->addRow($strOut);
	}
}
?>

<font color="Red"> </font>