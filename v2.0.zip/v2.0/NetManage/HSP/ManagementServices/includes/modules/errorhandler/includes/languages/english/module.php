<?PHP
define('ERROR' , 'Error ');
?>