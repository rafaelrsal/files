<?PHP
define('ERROR' , 'Erro ');
?>