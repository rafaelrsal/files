<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     Mars 2004

  Title:            errorMessages.php 
  Purpose:          Translations of error codes to english.
  Limitations:		Requires PHP 4+

 ============================================================================*/
require_once('includes/global_errorCodes.php');

$GLOBAL_ERROR_TRANSLATOR = array(
		HSP_SUCCESS=>'Successo',
		HSP_ERR_UNKNOWN_FAILURE=>'Erro desconhecido',
		HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS=>'Sem permiss�o de acesso. O sistema n�o tem as permiss�es de acesso corretas para abrir o arquivo ou pasta',
		HSP_ERR_FILE_NOT_FOUND=>'Arquivo n�o encontrado',
		HSP_ERR_INVALID_CREDENTIALS=>'Credencial inv�lida. Verifique se voc� informou corretamente o usu�rio e a senha',
		HSP_ERR_DB_ERROR=>'Erro de base de dados',
		HSP_ERR_DB_CONNECT_ERROR=>'Falha na conex�o com a base de dados',
		HSP_ERR_DB_SQL_ERROR=>'Erro ao executar o comando SQL',
		HSP_ERR_GROUPS_SELECT_ONE_ERROR=>'Selecione somente um grupo de cada lista',
		HSP_ERR_GROUPS_MUST_SELECT_ERROR=>'Voc� deve selecionar um grupo de cada lista',
		HSP_ERR_GROUPS_ASSOC_MISMATCHED_ERROR=>'Associa��o de grupos incompat�veis',
		HSP_ERR_USERS_SELECT_ONE_ERROR=>'Selecione apenas um usu�rio de cada lista',
		HSP_ERR_USERS_MUST_SELECT_ERROR=>'Voc� deve selecionar um usu�rio de cada lista',
		HSP_ERR_USERS_ASSOC_MISMATCHED_ERROR=>'Associa��o de usu�rios incompat�veis',
		HSP_ERR_DIRECTORY_LIST_ERROR=> 'Erro ao obter a lista, diret�rio n�o foi encontrado',
		HSP_ERR_DIRECTORY_NAME_ERROR=> 'Erro ao obter o nome do diret�rio',
		HSP_ERR_USER_LIST_ERROR=> 'Erro ao obter a lista de usu�rios, diret�rio n�o encontrado',
		HSP_ERR_AUTHENTICATION_ERROR=> 'Erro de autentica��o. Verifique se voc� informou um usu�rio e senha v�lidos',		
		HSP_ERR_INCONGRUENT_FILE=>'O arquivo selecionado n�o corresponde ao tipo de aplica��o',
		HSP_ERR_MISSING_APP_SETTINGS=>'Falta configura��o de aplicativo. Informe os dados faltantes',
		HSP_ERR_MISSING_NODE_SELECTION=>'Voc� deve selecionar um n� antes de executar a opera��o requisitada',
		HSP_ERR_ILLEGAL_OPERATION=>'Opera��o ilegal',
		HSP_ERR_NO_USER_GROUP_SELECTION=>'Voc� deve selecionar um grupo antes de executar a opera��o requisitada',
		HSP_ERR_EMPTY_DIR_LIST=>'A lista selecionada est� vazia',
		HSP_ERR_NOT_IMPLEMENTED_YET=>'Ainda n�o implementado',
		HSP_ERR_ACTIVATE_MON_SERVER=>'N�o � poss�vel ativar / desativar o Servi�o de Monitoramento',
		HSP_ERR_SET_MON_CFG=>'Falha ao configurar o Servi�o de Monitoramento',
		HSP_ERR_SET_EXTENSION_CFG=>'Falha ao atualizar a configura��o',
		HSP_ERR_PARSING_XML=>'N�o foi poss�vel analisar o arquivo XML',
		HSP_ERR_INVALID_URL=>'Voc� informou uma URL inv�lida',
		HSP_ERR_NO_DIRECTORY_SELECTED=>'O Diret�rio n�o foi definido',
		HSP_ERR_GET_SERVER_STATUS=>'Erro ao obter o status do servidor',
		HSP_ERR_MAINTENENCE_INTERVAL_NOT_POSITIVE=>'O intervalo de manuten��o deve ser maior que zero',
		HSP_ERR_HEARTBEAT_NOT_POSITIVE=>'O intervalo de Keep Alive deve ser maior que zero',
		HSP_ERR_MAINTENENCE_INTERVAL_NUMERIC=>'O intervalo de manuten��o deve ser num�rico',
		HSP_ERR_HEARTBEAT_INTERVAL_NUMERIC=>'O intervalo de Keep Alive deve ser num�rico',
		HSP_ERR_DB_PORT_NUMERIC=>'A Porta deve ser num�rica',
		HSP_ERR_DB_PORT_RANGE=>'A Porta deve estar entre 0 and 65536',
		HSP_ERR_MISSING_SERVER_ADDRESS=>'Est� faltando o endere�o do servidor',
		HSP_ERR_DB_DOES_NOT_EXISTS=>'Base de Dados n�o existe',
		HSP_CUSTOMDIR_USER_EXISTS=>'O usu�rio que voc� est� definindo j� existe neste diret�rio',
		HSP_CUSTOMDIR_GROUP_EXISTS=>'O grupo que voc� est� definindo j� existe neste diret�rio',
		HSP_ERR_ANON_DISABLED=>'Usu�rio Anonymous est� desabilitado',
		HSP_ERR_DIRNAME_ALREADY_DEFINED=>'O nome do diret�rio informado j� foi anteriormente definido',
		HSP_ERR_NAME_ALREADY_EXISTS=>'O nome do n� informado j� foi anteriormente definido',
		HSP_ERR_USER_ALREADY_LOGGEDIN=>'O usu�rio Anonymous j� est� conectado neste computador',
		HSP_ERR_COULDNOT_RETRIEVE_FILE=>'N�o foi poss�vel recuperar o arquivo. Use Pesquisar para localizar o arquivo',
		HSP_ERR_USER_PARAM_ALREADY_DEFINED=>'Par�metro j� definido',
		HSP_ERR_NOT_W2H_SERVER=>'N�o foi poss�vel recuperar os dados necess�rios. Certifique-se que a URL � de um servidor OnWeb Web-to-Host v�lido',
		HSP_ERR_HTTPS_ABNORMALITY=>'Quando utilizar \'https://\' no campo URL, desabilite a op��o "Verify URL and the Run as protected URL"',
		HSP_ERR_NO_ONWEB_APPS=>'N�o existem aplica��es definidas no servidor OnWeb',
		HSP_ERR_NO_EXPRESS_FTP_SUPPORT=>'Os clientes OnWeb Web-to-Host Express e FTP n�o s�o suportados, somente Java e Pro',
		HSP_ERR_SSONAME_EXISTS=>'Um SSO j� est� definido para este dom�nio'
		);
?>