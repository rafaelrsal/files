<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     Mars 2004

  Title:            errorMessages.php 
  Purpose:          Translations of error codes to english.
  Limitations:		Requires PHP 4+

 ============================================================================*/
require_once('includes/global_errorCodes.php');

$GLOBAL_ERROR_TRANSLATOR = array(
		HSP_SUCCESS=>'Success',
		HSP_ERR_UNKNOWN_FAILURE=>'Unknown error occurred',
		HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS=>'Access denied. The system does not have the access rights needed to open the file or folder',
		HSP_ERR_FILE_NOT_FOUND=>'File not found',
		HSP_ERR_INVALID_CREDENTIALS=>'Invalid credentials. Check that you have entered a valid user name and password',
		HSP_ERR_DB_ERROR=>'General database error',
		HSP_ERR_DB_CONNECT_ERROR=>'Connection to database failed',
		HSP_ERR_DB_SQL_ERROR=>'Error executing SQL statement',
		HSP_ERR_GROUPS_SELECT_ONE_ERROR=>'Select only one group from each list',
		HSP_ERR_GROUPS_MUST_SELECT_ERROR=>'You must select a group from each list',
		HSP_ERR_GROUPS_ASSOC_MISMATCHED_ERROR=>'Associate only mismatched groups',
		HSP_ERR_USERS_SELECT_ONE_ERROR=>'Select only one user from each list',
		HSP_ERR_USERS_MUST_SELECT_ERROR=>'You must select a user from each list',
		HSP_ERR_USERS_ASSOC_MISMATCHED_ERROR=>'Associate only mismatched users',
		HSP_ERR_DIRECTORY_LIST_ERROR=> 'Error getting list, directory could not be found',
		HSP_ERR_DIRECTORY_NAME_ERROR=> 'Error getting directory name',
		HSP_ERR_USER_LIST_ERROR=> 'Error getting user list, directory could not be found',
		HSP_ERR_AUTHENTICATION_ERROR=> 'Authentication error. Check that you have entered a valid user name and password',		
		HSP_ERR_INCONGRUENT_FILE=>'The file selected does not correspond to the requested application type',
		HSP_ERR_MISSING_APP_SETTINGS=>'Missing application settings. Enter the missing data',
		HSP_ERR_MISSING_NODE_SELECTION=>'You must select a node before the requested operation can be performed',
		HSP_ERR_ILLEGAL_OPERATION=>'Illegal operation',
		HSP_ERR_NO_USER_GROUP_SELECTION=>'You must select a user or group before the requested operation can be performed',
		HSP_ERR_EMPTY_DIR_LIST=>'The selected list is empty',
		HSP_ERR_NOT_IMPLEMENTED_YET=>'Not implemented yet',
		HSP_ERR_ACTIVATE_MON_SERVER=>'Unable to activate / deactivate Monitoring Services',
		HSP_ERR_SET_MON_CFG=>'Failed to configure Monitoring Services',
		HSP_ERR_SET_EXTENSION_CFG=>'Failed to update configuration',
		HSP_ERR_PARSING_XML=>'Could not parse XML file',
		HSP_ERR_INVALID_URL=>'You have entered an invalid URL',
		HSP_ERR_NO_DIRECTORY_SELECTED=>'No Directory has been defined',
		HSP_ERR_GET_SERVER_STATUS=>'Error getting server status',
		HSP_ERR_MAINTENENCE_INTERVAL_NOT_POSITIVE=>'Maintenance interval must be greater than zero',
		HSP_ERR_HEARTBEAT_NOT_POSITIVE=>'Keep Alive interval must be greater than zero',
		HSP_ERR_MAINTENENCE_INTERVAL_NUMERIC=>'Maintenance interval must be numeric',
		HSP_ERR_HEARTBEAT_INTERVAL_NUMERIC=>'Keep Alive interval must be numeric',
		HSP_ERR_DB_PORT_NUMERIC=>'Port number must be numeric',
		HSP_ERR_DB_PORT_RANGE=>'Port number should be between 0 and 65536',
		HSP_ERR_MISSING_SERVER_ADDRESS=>'Server address is missing',
		HSP_ERR_DB_DOES_NOT_EXISTS=>'Database does not exist',
		HSP_CUSTOMDIR_USER_EXISTS=>'The user you defined already exists in this directory',
		HSP_CUSTOMDIR_GROUP_EXISTS=>'The group you defined  already exists in this directory',
		HSP_ERR_ANON_DISABLED=>'Anonymous user logon is disabled',
		HSP_ERR_DIRNAME_ALREADY_DEFINED=>'The directory name you entered has been previously defined',
		HSP_ERR_NAME_ALREADY_EXISTS=>'The node name you entered has been previously defined',
		HSP_ERR_USER_ALREADY_LOGGEDIN=>'Anonymous user is already logged on from this computer',
		HSP_ERR_COULDNOT_RETRIEVE_FILE=>'Could not retrieve file. Use Browse to locate the file',
		HSP_ERR_USER_PARAM_ALREADY_DEFINED=>'Parameter already defined',
		HSP_ERR_NOT_W2H_SERVER=>'Could not retrieve needed data. Make sure that the server URL is a valid OnWeb Web-to-Host server',
		HSP_ERR_HTTPS_ABNORMALITY=>'When using \'https://\' in the URL field, uncheck the Verify URL and the Run as protected URL checkboxes',
		HSP_ERR_NO_ONWEB_APPS=>'The OnWeb server has no applications defined on it',
		HSP_ERR_NO_EXPRESS_FTP_SUPPORT=>'OnWeb Web-to-Host Express and FTP clients are not supported, only Java and Pro',
		HSP_ERR_SSONAME_EXISTS=>'An SSO is already defined for this domain'
		);
?>