var on_line = true;

function runServerScript(url)
{	//alert(url);
    if (window.XMLHttpRequest) 
    {// branch for native XMLHttpRequest object
		req = new XMLHttpRequest();
		req.onreadystatechange = processReqChange;
		req.open("GET", url, true);	    
    }
    else if (window.ActiveXObject) 
    {// branch for IE/Windows ActiveX version
        req = new ActiveXObject("Microsoft.XMLHTTP");
        if (req) 
        {
            req.open("GET", url, true);
            req.send();
        }
    }	
} 