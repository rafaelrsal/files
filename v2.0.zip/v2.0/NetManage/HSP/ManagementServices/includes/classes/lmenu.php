<?PHP
class LMenuItem
{
	var $dots;
	var $text;
	var $link;
	var $title;
	var $icon;
	var $target;
	var$expanded;
	function LMenuItem($dots,$text,$link='',$title='',$icon='',$target='',$expanded='')
	{
		for ($i=0;$i<$dots;$i++)
		{
			$this->dots.='.';
		}		
		$this->text = $text;
		$this->link = $link;
		$this->title = $title;
		$this->icon = $icon;
		$this->target = $target;
		$this->expanded = $expanded;
	}
	function toString()
	{
		return 	$this->dots	 .'|'.
			$this->text	 .'|'.
			$this->link	 .'|'.
			$this->title	 .'|'.
			$this->icon	 .'|'.
			$this->target	 .'|'.
			$this->expanded."\n";
	}
}
class LMenu
{
	var $lmmenu = array();
	function LMenu()
	{
	
	}
	
	function addItem($dots,$text,$link='',$title='',$icon='',$target='',$expanded='')
	{
		$item = new LMenuItem($dots,$text,$link,$title,$icon,$target,$expanded);
		$this->lmmenu[] = $item;
	}
	function addItemAt($index,$dots,$text,$link='',$title='',$icon='',$target='',$expanded='')
	{
		$item = new LMenuItem($dots,$text,$link,$title,$icon,$target,$expanded);
		$this->lmmenu[$index] = $item;
	}
	function addLMenItem($item)
	{		
		$this->lmmenu[] = $item;
	}
	function addLMenItemAt($index)
	{		
		$this->lmmenu[$index] = $item;
	}
	function toString()
	{
		$menuContent='';
		foreach ($this->lmmenu as $item)
		{
			$menuContent.=$item->toString();
		}
		return $menuContent;
	}
	
}
?>