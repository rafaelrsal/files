<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser

  Date Created:     Mars 2004

  Title:            frame.php
  Purpose:          A frame, hadling all frame elements that contain deifferent UI HSP
  					modules.
  Limitations:		Requires PHP 4+

 ============================================================================*/
require_once('frameElement.php');
require_once('includes/classes/ModuleBase.php');
require_once('HTML/Table.php');
require_once('admin/includes/images.php');
class Frame
{
	var $m_ArrElements = array(	'header' =>"",
					'left' =>"",
					'center' =>"",
					'right' =>"",
					'footer' =>"");

	function Frame($globalobjects,$centermodules,$leftmodules=null,$rightmodules=null,$header=true,$left=true,$right=true,$footer=true)
	{
		$language = $globalobjects->GetLanguage();
		$language->RequireLangFile( 'header.php' );
		$language->RequireLangFile( 'footer.php' );

		// we need to make sure we have a module.
		if (is_null($centermodules))
			$centermodules = array('login');

		if (is_null($leftmodules))
			$left = false;

		if (is_null($rightmodules))
			$right = false;

		// Start loading all frame elements into elements array
		if(true==$header)
		{
			$this->m_ArrElements['header']=  'header';
		}

		if(true==$left)
		{
			require_once('left_column.php');
			$this->m_ArrElements['left']=  new Left_Column($globalobjects,$leftmodules);
			$this->m_ArrElements['left']->setContent();
		}

		// center	 (module) - start
		require_once('center.php');
		$this->m_ArrElements['center']=  new Center($globalobjects,$centermodules);
		$this->m_ArrElements['center']->setContent();
		// center	 (module) - end

		if(true==$right)
		{
			require_once('right_column.php');
			$this->m_ArrElements['right']=  new Right_Column($globalobjects,$rightmodules);
			$this->m_ArrElements['right']->setContent();
		}
		if(true==$footer)
		{
			$this->m_ArrElements['footer'] = 'footer';
		}
	}

	function GetModule()
	{
		return $this->m_ModuleName;
	}

	function show()
	{
		$row = array();
		
		if ($this->m_ArrElements['header'] != '')
			include('admin/includes/html/header.html');

// left column table - start
		if ($this->m_ArrElements['left'] != '')
		{
        	// Aman 01/07/2004
			$leftTable = new HTML_Table('height="100%" bgcolor="#f57921" border="0" width="200px" cellspacing="0" cellpadding="0"');
			$leftTable->addCol($this->m_ArrElements['left']->GetContent());
			$row[] = $leftTable->toHTML();
		}
		else $row[] = '';

// left column table - end
// center table - start
		if ($this->m_ArrElements['center'] != '')
		{
        	// Aman 01/07/2004
			$centerTable = new HTML_Table('border="0" width="100%" cellspacing="0" cellpadding="0" id="tblMainCenter"');
			$centerTable->addCol($this->m_ArrElements['center']->GetContent(),'valign="top"');
			$row[] = $centerTable->toHTML();
		}
		else $row[] = '';
// center table - end
// right column table - start
		if ($this->m_ArrElements['right'] != '')
		{
        	// Aman 01/07/2004
			$rightTable = new HTML_Table('border="0" width="0" cellspacing="0" cellpadding="0"');
			$rightTable->addCol($this->m_ArrElements['right']->GetContent());
			$row[] = $rightTable->toHTML();
		}
		//else $row[] = '';
// right column table - end

         // Aman 01/07/2004
		$table = new HTML_Table('border="0" width="100%" height="100%" cellspacing="0" cellpadding="0"');
		if ( count($row) )
		{
			$table->addRow($row);

	         // Aman 01/07/2004
			$centerAtrib = ' bgcolor="#C6D3EF" width="197px" valign="top" id="tdLeftColumn"';
			$table->setCellAttributes(0,0,$centerAtrib);

			if ($this->m_ArrElements['left'] != '') //support flow zero
			{
				//regular flow
				$centerAtrib = ' bgcolor="#FFFFFF" width="100%" valign="top" id="tdCenterColumn"';
			}
			else
			{
				//flow zero
				$centerAtrib = ' bgcolor="#FFFFFF" width="75%" valign="top" id="tdCenterColumn"';
			}
			
			$table->setCellAttributes(0,1,$centerAtrib);
			if ($this->m_ArrElements['right'] != '')
			{
				$centerAtrib = ' bgcolor="#EFF3FF" width="0px" valign="top" id="tdRightColumn"';
				$table->setCellAttributes(0,2,$centerAtrib);
			}

			echo $table->toHTML();
		}

		if ($this->m_ArrElements['footer'] != '')
			include('admin/includes/html/footer.html');

		// Flushing buffered output that was initialized at the very beginning of admin.php
		// This was done in order to avoid header collisions problems:
		ob_end_flush();
	}

}
?>