<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     Mars 2004

  Title:            PearDB.php
  Purpose:          Wrapper functions for using PEAR DB for DB connectivity.
  Limitations:		Requires PHP 4+

 ============================================================================*/
require_once('DB.php');
class PearDB
{
	var $m_DSN = null;	
	var $m_DB=null;
	var $m_LastQuery=null;	
	
	function SetODBC( $dsn , $username, $password, $dbsyntax )
	{		
		$this->SetDSN('odbc',$username,$password,$dsn,false,false,$dbsyntax);
	}
	
	
	function SetDSN($phptype,$username,$password,$hostspec,$database,$port=false,$dbsyntax=false,$protocol=false,$socket=false)
	{
		
		$this->m_DSN = array(
					    'phptype'  => $phptype,
					    'dbsyntax' => $dbsyntax,
					    'username' => $username,
					    'password' => $password,
					    'protocol' => $protocol,
					    'hostspec' => $hostspec,
					    'port'     => $port,
					    'socket'   => $socket,
					    'database' => $database
					    );
	}
	
	function SetDSNArray($dsn)
	{
		if (is_array($dsn))
		{
			$this->m_DSN = $dsn;
			return true;
		}
		return false;
	}
	
	
	function SetDSNString($dsnstring)
	{	if ($dsnstring!=null && $dsnstring!='')
		{
			$this->m_DSN = &DB::parseDSN($dsnstring);
			return true;
		}
		
		return false;
	}
	
	function GetDSNasString()
	{
		$strDsn = null;
		
		if(is_array($this->m_DSN))
		{
			$strDsn = $this->m_DSN['phptype'];
			$strDsn.='://';
			$strDsn.= ($this->m_DSN['username'].':'.$this->m_DSN['password']);
			$strDsn.= ('@'.$this->m_DSN['hostspec'].'/'.$this->m_DSN['database']);
		}
		
		return  $strDsn;
	}
	
	function GetDSN()
	{
		return $this->m_DSN;
	}
	
	function GetDSNField($field)
	{
		return $this->m_DSN[$field];
	}
	
	function Connect()
	{
		if (count( $this->m_DSN) > 0)
		{		
			$this->m_DB =DB::connect($this->m_DSN,true);			
		}
		if ($this->m_DB == null || DB::isError($this->m_DB)) 
			return HSP_ERR_DB_CONNECT_ERROR;

		return HSP_SUCCESS;
	}
	
	function Disconnect()
	{
		$this->m_DB->disconnect();
	}
	
	function Query($sql)
	{
		$this->m_LastQuery = $this->m_DB->query($sql);
		if (DB::isError($this->m_LastQuery))
		 {
		 	//return $this->m_LastQuery->getMessage();
		 	return HSP_ERR_DB_SQL_ERROR;
		}


		return $this->m_LastQuery;
	}
	
	function FreeResults()
	{
		if (!is_null($this->$m_LastQuery))
			$this->$m_LastQuery->free();
	}
	
	function Fetch($mode)
	{
		if (!is_null($this->m_LastQuery))
		{
			if (is_null($mode)) 
			{
				return $this->m_LastQuery->fetchRow();
			}
			else
			{
				return  $this->m_LastQuery->fetchRow($mode);
			}			
		}
	}

	function AutoExecute($table_name,$fields_values,$autotype = DB_AUTOQUERY_INSERT, $whereCondition = false)
	{
		if ( !is_null($this->m_DB) )
		{		
			$res = $this->m_DB->autoExecute($table_name, $fields_values, $autotype, $whereCondition);
		}
				
		if ( is_null($this->m_DB) || DB::isError($this->m_DB) || (is_object($res))) 
			return HSP_ERR_DB_ERROR;
		
		return HSP_SUCCESS;
	}
	
	function GetNextID($sequence)
	{
		return $this->m_DB->nextId($sequence);
	}
	
	function NumRows()
	{
		return $this->m_LastQuery->numRows();
	}
	
	function GetAll($tablename)
	{
		return $this->m_DB->getAll('SELECT * FROM ' . $tablename . ';');
	}
	
	function GetAllEx($query,$params=null,$fetchmode=DB_FETCHMODE_DEFAULT)
	{
		return $this->m_DB->getAll($query,$params,$fetchmode);
	}
	
	function GetAllAssoc($tablename, $orderBy=null)
	{
		if (is_null($orderBy))
		{
			return $this->m_DB->getAssoc('SELECT * FROM ' . $tablename . ';');
		}
		else
		{
			return $this->m_DB->getAssoc('SELECT * FROM ' . $tablename . ' ORDER BY '. $orderBy .';');
		}
	}
	
	// Going through a table and getting the max ID field (mhoter)
	function GetMaxID($tablename, $id_text, &$arrRes)
	{
		$arrRes = $this->m_DB->getRow('SELECT MAX('.$id_text.') FROM ' . $tablename . ';');
		if(is_array($arrRes))
			return HSP_SUCCESS;
		else
			// TODO::We should translate DB error codes, and not only return the following
			// error code - mhoter
			return HSP_ERR_DB_ERROR;

	}

	// Getting a table and a row ID and returning the row data (mhoter)
	function GetRowForID($tablename, $id, &$arrRes)
	{
		$arrRes = $this->m_DB->getRow('SELECT * FROM ' . $tablename . ' WHERE ID='.$id.';');
		if(is_array($arrRes))
			return HSP_SUCCESS;
		else
			// TODO::We should translate DB error codes, and not only return the following
			// error code - mhoter
			return HSP_ERR_DB_ERROR;
	}

	// Get the row(s) for a certain field:
	function GetRowForField($tablename, $fieldname, $value, &$arrRes)
	{
		$arrRes = $this->m_DB->getRow('SELECT * FROM ' . $tablename . ' WHERE '.$fieldname.' = "'.$value.'";');
		if(is_array($arrRes))
			return HSP_SUCCESS;
		else
			// TODO::We should translate DB error codes, and not only return the following
			// error code - mhoter
			return HSP_ERR_DB_ERROR;
	}

	// from docs: DB_common::getOne() -- Runs a query and returns the first column of the first row
	function getOne($sql,&$result)
	{
		$result = $this->m_DB->getOne($sql);
		if ($this->m_DB == null || DB::isError($this->m_DB)) 
			return HSP_ERR_DB_ERROR;

		return HSP_SUCCESS;
	}
	
	function tableInfo($tableName)
	{
		return $this->m_DB->tableInfo($tableName);
	}
	
	function GetDBObj()
	{
		return $this->m_DB;
	}
	
	function getDBSyntax()
	{
		return $this->m_DB->dbsyntax;
	}
}
?>