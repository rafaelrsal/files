<?PHP
require_once(GLOBAL_CLASSES_DIR . 'HAPSession.php' );
require_once(GLOBAL_CLASSES_DIR . 'language.php' );
require_once(GLOBAL_CLASSES_DIR . 'DBConfig.php');
require_once(GLOBAL_CLASSES_DIR . 'PearDB.php');

//require_once('db/mssql.php');

@include_once "DB/mysql.php";

class GlobalObjects
{
	var $m_Session ;
	var $m_Language;
	var $m_Database;	
	var $m_username;
	
	function GlobalObjects()
	{
		
		$this->m_Session = new HAPSession();
		$this->m_Session->start();
		
		//Guilherme Lima 19/03/2013
		// verifica��o de usu�rio logado
		if ($this->m_Session->exists(USUARIO_LOGADO))
		{
			$this->m_username = $this->m_Session->value(USUARIO_LOGADO);
		}
		else
		{
			$this->m_username = LOGIN_USER;
			if($this->m_username != "LOGIN_USER")
			{
				$this->m_Session->set(USUARIO_LOGADO, $this->m_username);
			}
		}
		// fim
		
		if ($this->m_Session->exists(SESSION_LANGUAGE)) 
		{
			
	    	$this->m_Language = &$this->m_Session->value(SESSION_LANGUAGE);
		} 
		else
		{
			$this->m_Language = new Language(CURRENT_LANG); // set language as admin
			$this->m_Session->set(SESSION_LANGUAGE, $this->m_Language);
	  	}
	  	
  	  	/*
		database connection details (DSN) are saved to a configuration file on the server.
		database module is responsible to update the details and create that file.
		
		database module will save the database object as session variable 'SESSION_DATABASE'.
		if this var exists we retrive it from the session object if not we nead to create the database object and set it.
		
		we also need to be aware of the init state where the config file does not exist.
		another issue is if the file exists but the connection fails due to corrupted data or other connection problems.
		*/
		
		if ($this->m_Session->exists(SESSION_DATABASE))
		{
			$this->m_Database =& $this->m_Session->value(SESSION_DATABASE);
		} 
		else 
		{
			$bisInit = false;
			$dbconfig = new DBConfig();
			$errCode = $dbconfig->init();
			if ( $errCode != HSP_ERR_FILE_NOT_FOUND )
			{
	    			$dbconfig->DBDeserialize();
	    			$bisInit = $dbconfig->isInit();

				$this->m_Database = new PearDB();
				$this->m_Database->SetDSNArray($dbconfig->getDBData());
				
				if (!$bisInit)
				{
					$ret = $this->m_Database->Connect();
					if ($ret != HSP_SUCCESS )
					{ 
						$errorCode = array($ret);			
						$this->m_Session->set(SESSION_ERRORS, $errorCode);
					}
					else
					{
						// successful connection
						$this->m_Session->set(SESSION_DATABASE, $this->m_Database);	
					}
				}
			}
			else
			{
				$this->m_Session->set(SESSION_ERRORS, $errCode);
			}
			
			if (!$this->m_Session->value(SESSION_INIT_CONFIG) )
			{
				$this->m_Session->set(SESSION_INIT_CONFIG, $bisInit );
			}
		}

	}
	
	function &GetSession()
	{
		return $this->m_Session;
	}
	
	function &GetLanguage()
	{
		return $this->m_Language;
	}
	
	function &GetDatabase()
	{
		return $this->m_Database;
	}
	
	// Guilherme Chiozzini de Lima 19/03/2013
	// fun��o de retorno de username
	function GetUsername()
	{
		return $this->m_username;
	}
	
  	
}
?>