<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Guy (Dude) Schetrit, Hoter Mickey , Udi Zisser
  Date Created: Mars 2004
  Title:  DBConfig.php
  Purpose:          To allow setting and getting the initial HSP DB configuration, using serialization.
  Limitations:		Requires PHP 4.3.x (<5.0)
 ============================================================================*/

require_once('includes/classes/xmlWrapper.php');
require_once('includes/classes/dbmethods.php');

define('STORAGE_TYPE_ODBC',3 );
define('STORAGE_TYPE_RDBMS',2 );

class DBConfig
{
	var $m_arrDBData=null; // Holding data for database connection. (dsn)		
	var $m_wrapper = null;
	var $m_storageType;
	var $m_dbmethod = null;
	
	function DBConfig()
	{
		$this->m_wrapper = new xmlWrapper();
		$this->m_dbmethod = new DBMethod();
	}
	
	function init()
	{
		if (!$this->m_wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME))
		{
			return HSP_ERR_FILE_NOT_FOUND;
		}
		
		$this->m_storageType = $this->m_wrapper->getStorageType();
		
		return HSP_SUCCESS;
	}
	
	function setDBData($phptype,$username,$password,$hostspec,$database=false,$port=false,$dbsyntax=false,$protocol=false,$socket=false)	
	{
		$this->m_arrDBData = array(
					    'phptype'  => $phptype,
					    'dbsyntax' => $dbsyntax,
					    'username' => $username,
					    'password' => $password,
					    'protocol' => $protocol,
					    'hostspec' => $hostspec,
					    'port'     => $port,
					    'socket'   => $socket,
					    'database' => $database					  
					    );
	}
	
	function setDBDataArray($dbarr)
	{
		if (is_array($dbarr))
		{
			$this->m_arrDBData = $dbarr;
			return true; // ok
		}
		return false; // fail
	}
	
	function setDsnString($dsn)
	{
		if (is_array($this->m_arrDBData))
		{
			$this->m_arrDBData['dsn'] = $dsn;
		}
	}
	
	function getDBData()
	{
		return $this->m_arrDBData; 
	}
		
	function getDBConfigItem($item)
	{
		if (is_array($this->m_arrDBData))
		{
			if (array_key_exists($item,$this->m_arrDBData))
				return $this->m_arrDBData[$item];
			return false;
		}
		
		return '';
	}
	
	function DBDeserialize()
	{
		if ( STORAGE_TYPE_ODBC == $this->m_storageType )
		{
			$dbParams = $this->m_wrapper->getODBCParams();
			$this->setDBData(	'odbc',								
								$dbParams['user_name'],
								$dbParams['password'],
								$dbParams['dsn'],
								false,
								false,
								$dbParams['type'] );
		}
		elseif(STORAGE_TYPE_RDBMS == $this->m_storageType )
		{
			$dbParams = $this->m_wrapper->getRDBMSParams();
			$this->setDBData(	$dbParams['rdbms_type'],
								$dbParams['rdbms_username'],
								$dbParams['rdbms_password'],
								$dbParams['rdbms_address'],
								$dbParams['rdbms_name'],
								$dbParams['rdbms_port'] );	
		}
	}
	
	function DBSerialize()
	{		
		if ( false != $this->m_arrDBData['dbsyntax'] )
		{
			$this->m_storageType = STORAGE_TYPE_ODBC;
		}
		else
		{
			$this->m_storageType = STORAGE_TYPE_RDBMS;
		}
		
		if ( STORAGE_TYPE_ODBC == $this->m_storageType )
		{
			$arr['type'] 		= $this->m_arrDBData['dbsyntax'];
			$arr['dsn'] 		= $this->m_arrDBData['hostspec'];
			$arr['user_name'] 	= $this->m_arrDBData['username'];
			$arr['password'] 	= $this->m_arrDBData['password'];
			$this->m_wrapper->setODBCParams($arr);
		}
		elseif(STORAGE_TYPE_RDBMS == $this->m_storageType )
		{
			$arr['rdbms_type']	= $this->m_arrDBData['phptype'];
			$arr['rdbms_address'] 	= $this->m_arrDBData['hostspec'];
			$arr['rdbms_port'] 	= $this->m_arrDBData['port'];
			$arr['rdbms_name'] 	= $this->m_arrDBData['database'];
			$arr['rdbms_username']= $this->m_arrDBData['username'];
			$arr['rdbms_password']	= $this->m_arrDBData['password'];
			$arr['version']		= '0';
			$this->m_wrapper->setRDBMSParams($arr);
		}

		$this->m_wrapper->setStorageType($this->m_storageType);
		
		$fp = @fopen( CONFIG_XML_PATH . CONFIG_XML_NAME, "wb");
		if(true == $fp)
		{
			if(fputs($fp, $this->m_wrapper->toString()))
			{
				fclose($fp);				
				return HSP_SUCCESS;
			}
		}

		return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;		
	}
	
	function isInit()
	{
		$umConfigInfo = $this->m_wrapper->getUMConfigInfo();
		
		if ('all the dude ever wanted was his rag back' == $umConfigInfo['ft_config'])
		{
			return true;
		}
		return false;
	}
	
	function setUMftConfig($umftConfig)
	{
		$this->m_wrapper->setUMftConfig($umftConfig);
	}
	
	function getInitParams()
	{
		$umConfigInfo = $this->m_wrapper->getUMConfigInfo();
		$arr = array();
		$arr['username'] = $umConfigInfo['user_name'];
		$arr['password'] = $umConfigInfo['password'];
		
		return $arr;
	}
	//********* Guilhemre Lima 05/03/2013 *********************
	function UserVerify($user, $pass){
		return $this->m_dbmethod->verfAdminUsers($user, $pass);
	}
	//************** 09/04/2013 *******************************
	function ChangeAdminPassword($user, $oldpass, $newpass){
		return $this->m_dbmethod->ChangePasswordAdminUser($user, $oldpass, $newpass);
	}
	//************** 10/04/2013 *******************************
	function CreateNewAdminUser($user, $pass, $roll){
		return $this->m_dbmethod->CreateNewAdminUser($user, $pass, $roll);
	}
	function RemoveAdminUser($user){
		return $this->m_dbmethod->RemoveAdminUser($user);
	}
	//************** 16/04/2013 ******************************
	function ResetPassaword($id){
		return $this->m_dbmethod->ResetPassaword($id);
	}
}

?>