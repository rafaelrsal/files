<?php
class tableBox
{
	var $table_border = '0';
	var $table_width = '100%';
	var $table_cellspacing = '0';
	var $table_cellpadding = '2';
	var $table_parameters = '';
	var $table_row_parameters = '';
	var $table_data_parameters = '';
	
	function tableBox($contents, $direct_output = false) 
	{
  		$tableBox_string = '<table border="' . OutputString($this->table_border) . '" width="' . OutputString($this->table_width) . '" cellspacing="' . OutputString($this->table_cellspacing) . '" cellpadding="' . OutputString($this->table_cellpadding) . '"';
  		if (NotNull($this->table_parameters)) $tableBox_string .= ' ' . $this->table_parameters;
		$tableBox_string .= '>' . "\n";

		for ($i=0, $n=sizeof($contents); $i<$n; $i++)
		{
			if (isset($contents[$i]['form']) && NotNull($contents[$i]['form'])) $tableBox_string .= $contents[$i]['form'] . "\n";
			
			$tableBox_string .= '  <tr';
			
			if (NotNull($this->table_row_parameters)) $tableBox_string .= ' ' . $this->table_row_parameters;
			if (isset($contents[$i]['params']) && NotNull($contents[$i]['params'])) $tableBox_string .= ' ' . $contents[$i]['params'];
			
			$tableBox_string .= '>' . "\n";

			if (isset($contents[$i][0]) && is_array($contents[$i][0])) 
			{
				for ($x=0, $n2=sizeof($contents[$i]); $x<$n2; $x++) 
				{
					if (isset($contents[$i][$x]['text']) && NotNull($contents[$i][$x]['text'])) 
					{
						$tableBox_string .= '<td';
						if (isset($contents[$i][$x]['align']) && NotNull($contents[$i][$x]['align'])) 
							$tableBox_string .= ' align="' . OutputString($contents[$i][$x]['align']) . '"';
						if (isset($contents[$i][$x]['params']) && NotNull($contents[$i][$x]['params']))
						{
							$tableBox_string .= ' ' . $contents[$i][$x]['params'];
						}
						elseif (NotNull($this->table_data_parameters))
						{
							$tableBox_string .= ' ' . $this->table_data_parameters;
						}
						
						$tableBox_string .= '>';
						if (isset($contents[$i][$x]['form']) && NotNull($contents[$i][$x]['form']))
							$tableBox_string .= $contents[$i][$x]['form'];
						$tableBox_string .= $contents[$i][$x]['text'];
						if (isset($contents[$i][$x]['form']) && NotNull($contents[$i][$x]['form'])) 
							$tableBox_string .= '</form>';
						
						$tableBox_string .= '</td>' . "\n";
					}
				}
			}
			else 
			{
				$tableBox_string .= '<td';
  				if (isset($contents[$i]['align']) && NotNull($contents[$i]['align'])) 
  					$tableBox_string .= ' align="' . OutputString($contents[$i]['align']) . '"';
				if (isset($contents[$i]['params']) && NotNull($contents[$i]['params'])) 
				{
					$tableBox_string .= ' ' . $contents[$i]['params'];
				} 
				elseif (NotNull($this->table_data_parameters)) 
				{
					$tableBox_string .= ' ' . $this->table_data_parameters;
				}
				
				$tableBox_string .= '>' . $contents[$i]['text'] . '</td>' . "\n";
			}

			$tableBox_string .= '  </tr>' . "\n";
			if (isset($contents[$i]['form']) && NotNull($contents[$i]['form'])) 
				$tableBox_string .= '</form>' . "\n";
		
		}
		
		$tableBox_string .= '</table>' . "\n";
		if ($direct_output == true) 
			echo $tableBox_string;
		
		return $tableBox_string;
	}
}

class infoBox extends tableBox 
{
	var $m_Box;
	function infoBox($contents)
	{
		$info_box_contents = array();
		$info_box_contents[] = array('text' => $this->infoBoxContents($contents));
		$this->table_cellpadding = '1';
		$this->table_parameters = 'class="infoBox"';
		$this->m_Box = $this->tableBox($info_box_contents);
	}

	function infoBoxContents($contents) 
	{
		$this->table_cellpadding = '3';
		$this->table_parameters = 'class="infoBoxContents"';
		$info_box_contents = array();
		$info_box_contents[] = array(array('text' =>DrawSeparator('pixel_trans.gif', '100%', '1')));
		
		for ($i=0, $n=sizeof($contents); $i<$n; $i++)
		{
			$info_box_contents[] = array(array('align' => (isset($contents[$i]['align']) ? $contents[$i]['align'] : ''),
			'form' => (isset($contents[$i]['form']) ? $contents[$i]['form'] : ''),
			'params' => 'class="boxText"',
			'text' => (isset($contents[$i]['text']) ? $contents[$i]['text'] : '')));
		}
		
		$info_box_contents[] = array(array('text' => DrawSeparator('pixel_trans.gif', '100%', '1')));
		return $this->tableBox($info_box_contents);
	}
	function getInfoBox()
	{
		return $this->m_Box;
	}
}

class infoBoxHeading extends tableBox 
{
	function infoBoxHeading($contents, $left_corner = true, $right_corner = true, $right_arrow = false) 
	{
		$this->table_cellpadding = '0';
		if ($left_corner == true) 
		{
			$left_corner = Image(IMAGES_DIR . 'infobox/corner_left.gif');
		} 
		else
		{
			$left_corner = Image(IMAGES_DIR . 'infobox/corner_right_left.gif');
		}
		
		if ($right_arrow == true) 
		{
			$right_arrow = '<a href="' . $right_arrow . '">' . Image(IMAGES_DIR . 'infobox/arrow_right.gif', ICON_ARROW_RIGHT) . '</a>';
		}
		else 
		{
			$right_arrow = '';
		}
		
		if ($right_corner == true) 
		{
			$right_corner = $right_arrow . Image(IMAGES_DIR . 'infobox/corner_right.gif');
		}
		else
		{
			$right_corner = $right_arrow . DrawSeparator('pixel_trans.gif', '11', '14');
		}
		
		$info_box_contents = array();
		$info_box_contents[] = array(array('params' => 'height="14" class="infoBoxHeading"',
						    'text' => $left_corner),
						    array('params' => 'width="100%" height="14" class="infoBoxHeading"',
						    'text' => $contents[0]['text']),
						    array('params' => 'height="14" class="infoBoxHeading" nowrap',
						    'text' => $right_corner));
						    
		return $this->tableBox($info_box_contents);
	}
}

class contentBox extends tableBox 
{
	function contentBox($contents) 
	{
		$info_box_contents = array();
		$info_box_contents[] = array('text' => $this->contentBoxContents($contents));
		$this->table_cellpadding = '1';
		$this->table_parameters = 'class="infoBox"';
		$this->tableBox($info_box_contents);
	}

	function contentBoxContents($contents) 
	{
		$this->table_cellpadding = '4';
		$this->table_parameters = 'class="infoBoxContents"';
		return $this->tableBox($contents);
	}
}

class contentBoxHeading extends tableBox 
{
	function contentBoxHeading($contents) 
	{
  		$this->table_width = '100%';
  		$this->table_cellpadding = '0';
  		$info_box_contents = array();
  		$info_box_contents[] = array(array('params' => 'height="14" class="infoBoxHeading"',
  						'text' => Image(IMAGES_DIR . 'infobox/corner_left.gif')), 
  						array('params' => 'height="14" class="infoBoxHeading" width="100%"',
  							'text' => $contents[0]['text']),
  							array('params' => 'height="14" class="infoBoxHeading"',
  							'text' => Image(IMAGES_DIR . 'infobox/corner_right_left.gif')));
  		$this->tableBox($info_box_contents);
	}
}


function ParseInputFieldData($data, $parse) 
{
	return strtr(trim($data), $parse);
}

function DrawSeparator($image = 'pixel_black.gif', $width = '100%', $height = '1') 
{
	return Image(IMAGES_DIR . $image, '', $width, $height);
}

function OutputString($string, $translate = false, $protected = false) 
{
	if ($protected == true)
	{
		return htmlspecialchars($string);
    	} 
    	else
    	{
      		if ($translate == false)
      		{
        			return ParseInputFieldData($string, array('"' => '&quot;'));
      		} else 
      		{
        			return ParseInputFieldData($string, $translate);
      		}
    	}
}

function NotNull($value) 
{
	if (is_array($value))
	{
      		if (sizeof($value) > 0) 
      		{
        			return true;
      		}
      		else 
      		{
      			return false;
      		}
    	} 
    	else
    	{
      		if (($value != '') && (strtolower($value) != 'null') && (strlen(trim($value)) > 0))
      		{
        			return true;
      		} 
      		else 
      		{
      			return false;
      		}
    	}
}

function Image($src, $alt = '', $width = '', $height = '', $parameters = '') 
{
	if ( (empty($src) || ($src == IMAGES_DIR)) && (IMAGE_REQUIRED == 'false') ) 
    	{
    		return false;
    	}
	// alt is added to the img tag even if it is null to prevent browsers from outputting
	// the image filename as default
    	$image = '<img src="' . OutputString($src) . '" border="0" alt="' . OutputString($alt) . '"';

    	if (NotNull($alt)) 
    	{
      		$image .= ' title=" ' . OutputString($alt) . ' "';
    	}
    	
    	if ( (CONFIG_CALCULATE_IMAGE_SIZE == 'true') && (empty($width) || empty($height)) ) 
    	{
      		if ($image_size = @getimagesize($src)) 
      		{
        			if (empty($width) && NotNull($height)) 
        			{
          				$ratio = $height / $image_size[1];
          				$width = (int)$image_size[0] * $ratio;
        			} 
        			elseif (NotNull($width) && empty($height)) 
        			{
          				$ratio = $width / $image_size[0];
          				$height = (int)$image_size[1] * $ratio;
        			} 
        			elseif (empty($width) && empty($height)) 
        			{
          				$width = (int)$image_size[0];
          				$height = (int)$image_size[1];
        			}
      		} 
      		elseif (IMAGE_REQUIRED == 'false') 
      		{
        			return false;
      		}
    	}
    	
    	if (NotNull($width) && NotNull($height))
    	{
    		$image .= ' width="' . OutputString($width) . '" height="' . OutputString($height) . '"';
    	}

    	if (NotNull($parameters))
    		$image .= ' ' . $parameters;
    	$image .= '>';
    	
    	return $image;
} 

?>