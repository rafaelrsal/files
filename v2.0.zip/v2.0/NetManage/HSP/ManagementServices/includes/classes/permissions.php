<?php 
/*===========================================================================

        Copyright (c) 2013, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Guilherme Lima
  Date Created: April 2013
  Title:            database methods
  Purpose:          methods for db access
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
include_once( "lib/ezxml/classes/ezxml.php" );

class Permission{

	var $m_ezxml = null; // variável para uso da classe ezxml
	var $m_domTree = null; // variável para o xml já carregado
	var $m_xmlString = null; // variável para o xml com formato de string
	
	function Permission(){
		$this->m_ezXml = new eZXML();
	}
	
	// função para inicializar o xml
	function initFromFile($fileName)
	{		
		$fd = @fopen($fileName, "r");
		
		if ( $fd )
		{
			$this->m_xmlString = @fread($fd, filesize($fileName)); // transforma o texto em xml
			@fclose($fd);		
			$this->m_domTree = $this->m_ezXml->domTree($this->m_xmlString); // recupera o xml como obejto
			return true;
		}
		return false;
	}
	
	// funcao para parear js com xml
	function updateJSFile(){
		$xmlini = $this->m_domTree->elementsByName('roll');// elemntos roll do xml - retorna todos como array
		$sPerJs = 'var permission = [';
		$aux; // auxiliar para acesso aos nós do xml
		$cont = 0; // contador
		$contPrinc = 1; // contador dos objetos roll
		// loop para rodar todo xml nos nós roll
		foreach($xmlini as $value){
			$sPerJs .= '{"nome":"'.$value->elementTextContentByName('nome').'","permission":{"menu":[';
			$aux = $value->elementByName('permission'); // seta permission para poder rodar nós internos a ele
			$cont = 1;
			// loop para rodar os nós de menu
			foreach($aux->elementsByName('menu') as $perm){
				if($cont < count($aux->elementsByName('menu')) && count($aux->elementsByName('menu')) > 1){
					$sPerJs .= $perm->textContent() . ',';
					$cont = $cont + 1;
				}
				else{
					$sPerJs .= $perm->textContent();
					$cont = 1;
				}
			}
			$sPerJs .= '],"submenu":[';
			// loop para rodar os nós de submenu
			foreach($aux->elementsByName('submenu') as $subperm){
				if($cont < count($aux->elementsByName('submenu')) && count($aux->elementsByName('submenu')) > 1 ){
					$sPerJs .= $subperm->textContent() .',';
					$cont = $cont + 1;
				}
				else{
					$sPerJs .= $subperm->textContent();
				}
			}
			if($contPrinc < count($xmlini) && count($xmlini) > 1){ // Existe mais algum ainda?
				$sPerJs .= ']}},';
			}
			else{ // senão
				$sPerJs .= ']}}';
			}
			$contPrinc = $contPrinc+1;
		}
		
		$sPerJs .= '];';
		$pjs = @fopen("includes/config/permission.js", 'w');
		if($pjs){// abriu arquivo?
			// @fwrite($pjs, 'var permission = [{"nome":"admin", "permission":{"menu":[],"submenu":[]}},{"nome":"gmi", "permission":{"menu":[2],"submenu":[1,14]}},{"nome":"stso", "permission":{"menu":[4],"submenu":[]}}];');
			if(@fwrite($pjs, $sPerJs) != false){ // gravou?
				return true;
			}
			else{
				return false;
			}
			@fclose($pjs);
			
		}
		else{
			return false;
		}
	}
	
	//******************** GUILHERME LIMA *****************************
	/*
		Função para inserção de um novo roll
		Verifica se já existe, insere no xml, e atualiza o JS
		Recebe nome e permissions(se existir)
		Retorna -> true => inseriu
				   false => não inseriu
	*/
	function InsertNewRoll($nome, $menu=null, $submenu=null){
		$xmlini = $this->m_domTree->elementsByName('permissions'); // xml setado a partir do nó permissions
		// loop para validação de roll já existente
		foreach($xmlini[0]->elementsByName('roll') as $rolls){
			if($rolls->elementTextContentByName('nome') == $nome){ // Nome já existente?
				return false;
			}
		}
		$xmlnoderoll =& $this->m_domTree->createElementNode('roll'); // cria o nó roll
		$xmlnode =& $this->m_domTree->createElementNode('nome'); // cria o nó nome
		$xmlnode->appendChild( $this->m_domTree->createTextNode($nome) ); // coloca o conteudo nele 
		$xmlnodepermission =& $this->m_domTree->createElementNode('permission'); // cria o nó permission
		$xmlnoderoll->appendChild($xmlnode); // coloca o conteudo nele
		if($menu && is_array($menu)){
			foreach($menu as $value){
				$xmlnode =& $this->m_domTree->createElementNode('menu'); // cria nó menu
				$xmlnode->appendChild( $this->m_domTree->createTextNode($value) ); // popula com conteudo
				$xmlnodepermission->appendChild($xmlnode);// insere menu no nó permission
			}
		}
		if($submenu && is_array($submenu)){
			foreach($submenu as $subvalue){
				$xmlnode =& $this->m_domTree->createElementNode('submenu'); // cria nó menu
				$xmlnode->appendChild( $this->m_domTree->createTextNode($subvalue) ); // popula com conteudo
				$xmlnodepermission->appendChild($xmlnode); // insere submenu no nó permission
			}
		}
		$xmlnoderoll->appendChild($xmlnodepermission); // insere nó permission no nó roll	
		$xmlini[0]->appendChild($xmlnoderoll);
		
		if($this->UpdateXml()){
			return true;
		}
		else{
			return false;
		}
	}
	//*****************************************************************
	
	//************GUILHERME CHIOZZINI DE LIMA 16/04/2013***************
	/*
		Função para atualização de permissions
		insere no XML e atualiza js
		Recebe nome da roll, menu e submenu
	*/
	function UpdateOldRows($nome, $menu=null, $submenu=null){
		$xmlini = $this->m_domTree->elementsByName('roll'); // array vindo xml dos roll
		$xmlnodepermission =& $this->m_domTree->createElementNode('permission'); // cria o nó permission
		$flagEditouAlgum = false;
		$cont= 0;
		// loop para rodar todo xml nos nós roll
		foreach($xmlini as $value){
			if($value->elementTextContentByName('nome') == $nome){ // nome passado é igual algum roll
				$flagEditouAlgum = true;
				$xmlini[$cont]->removeNamedChildren('permission');// remove o nó permission para o novas permissões
				if($menu && is_array($menu)){ // existem permissões de menu em quantidade?
					foreach($menu as $value){// loop para rodar os menus
						$xmlnode =& $this->m_domTree->createElementNode('menu'); // cria nó menu
						$xmlnode->appendChild( $this->m_domTree->createTextNode($value) ); // popula com conteudo
						$xmlnodepermission->appendChild($xmlnode);// insere menu no nó permission
					}
				}
				if($submenu && is_array($submenu)){// existem permissões de submenu em quantidade?
					foreach($submenu as $subvalue){ // loop para rodar os submenus
						$xmlnode =& $this->m_domTree->createElementNode('submenu'); // cria nó menu
						$xmlnode->appendChild( $this->m_domTree->createTextNode($subvalue) ); // popula com conteudo
						$xmlnodepermission->appendChild($xmlnode); // insere submenu no nó permission
					}
				}
				
				break; // temrina, já preparou novas permissões
			}
			$cont = $cont + 1; // não achou ainda
		}
		if($flagEditouAlgum){ // existiu alguma edição de roll
			$xmlini[$cont]->appendChild($xmlnodepermission); // appenda o nó de permission 
			
			if($this->UpdateXml()){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
	//*****************************************************************
	
	//*********************GUILHERME CHIOZZINI DE LIMA 24/04/2013******
	/*
		Função para remoção de um roll
		Remove um roll via nome
		Recebe -> $nome => nome do roll a ser removido
		Retorna -> true => removido
				   false => não removido
	*/
	function RemoveOldRoll($nome){
		$xmlini = $this->m_domTree->elementsByName('roll'); // array vindo do xml dos roll
		$xmlPerm = $this->m_domTree->elementsByName('permissions');
		$cont = 0;
		// loop para rodar todo xml nos nós roll
		foreach($xmlini as $value){
			if ($value->elementTextContentByName('nome') == $nome){ // achou roll?
				$xmlini[$cont]->setName($nome."remover");
				$xmlPerm[0]->removeNamedChildren($nome."remover");
				if($this->UpdateXml()){
					return true;
				}
				else{
					return false;
				}
			}
			$cont = $cont + 1;
		}
		return false;
	}
	
	/*
		Função para atualizar xml		
	*/
	function UpdateXml(){
		$fp = @fopen('includes/config/permission.xml', 'w');   // arquivo xml
		if($fp){ //abriu arquivo?
			if(@fwrite($fp, $this->m_domTree->toString())== false){// não escreveu no arquivo?
				return false;
			}
			@fclose($fp);
			clearstatcache();
			$this->initFromFile(CONFIG_XML_PATH . PERMISSION_XML_NAME); // restarta com novo xml
			if($this->updateJSFile()){ // atualizou js?
				return true; // sim
			}
			else{
				return false; // não
			}
		}
		else{
			return false;
		}
	}
	
	/*
		Função para retornar todos os roll com suas devidas permissoes
		Retorna -> ARRAY[index][nome]
				   ARRAY[index][menu]
				   ARRAY[index][submenu]
	*/
	function SelectAllRolls(){
		$xmlini = $this->m_domTree->elementsByName('roll'); // array vindo xml dos roll
		$xmlPermission; // auxiliar para percorrer premissões
		$selecionados = array(array()); // array bidimensional, para armazenar index+tipo de info
		$cont = 0; // contador
		
		//loop para percorrer todos os nós roll
		foreach($xmlini as $key=>$value){
			if($value->elementTextContentByName('nome') != "admin")
			{
				$selecionados[$key-1]["nome"] = $value->elementTextContentByName('nome');
				$selecionados[$key-1]["menu"] = "";
				$selecionados[$key-1]["submenu"] = "";
				$xmlPermission = $value->elementByName('permission');
				foreach($xmlPermission->elementsByName('menu') as $menu){// loop para rodar os menus
					$selecionados[$key-1]["menu"] .= $menu->textContent() . ";";
				}
				foreach($xmlPermission->elementsByName('submenu') as $submenu){ // loop para rodar os submenus
					$selecionados[$key-1]["submenu"] .= $submenu->textContent() . ";";
				}			
			}
		}
		return $selecionados;
	}
	//*****************************************************************
	
	//************GUILHERME LIMA 30/04/2013****************************
	/*
		Função para selecionar apenas um roll
		Recebe -> $name => nome do roll a ser selecionado
		Retorno -> retorna um array com nome, menus e submenus do roll
	*/
	function selectOneRoll($name){
		$xmlini = $this->m_domTree->elementsByName('roll'); // array vindo xml dos roll
		$xmlPermission; // auxiliar para percorrer premissões
		$selecionado = array(); // array bidimensional, para armazenar index+tipo de info
		
		//loop para percorrer todos os nós roll
		foreach($xmlini as $key=>$value){
			if($name == $value->elementTextContentByName('nome')){
				$selecionado["nome"] = $value->elementTextContentByName('nome');
				$selecionado["menu"] = "";
				$selecionado["submenu"] = "";
				$xmlPermission = $value->elementByName('permission');
				foreach($xmlPermission->elementsByName('menu') as $menu){// loop para rodar os menus
					$selecionado["menu"] .= $menu->textContent() . ";";
				}
				foreach($xmlPermission->elementsByName('submenu') as $submenu){ // loop para rodar os submenus
					$selecionado["submenu"] .= $submenu->textContent() . ";";
				}
				
				return $selecionado;
			}
		}
		return "err";
	}
	//*****************************************************************
}
?>