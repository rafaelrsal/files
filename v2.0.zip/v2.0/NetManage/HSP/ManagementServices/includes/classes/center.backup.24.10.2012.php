<?PHP
require_once('frameElement.php');

class Center extends frameElement 
{
	var $m_ModulesArr = array();
	function Center($globalobjects,$modules)
	{
		foreach ($modules as $module)
		{
			if (!include_once( GLOBAL_CONTEXT.'/modules/'.$module.'/module.php'))
			{
				include_once( 'includes/modules/'.$module.'/module.php');
			}
			
			$newModule = new $module($globalobjects);	
			$newModule->init();
			$newModule->process();
			$newModule->finalize();
			
			$this->m_ModulesArr[] = $newModule;
			
			$session = $globalobjects->GetSession();

			if ($session->exists(SESSION_ERRORS)) 
			{
				// insert the errorHandler module at the top of the center pane
				include_once( 'includes/modules/errorHandler/module.php');
				array_unshift($this->m_ModulesArr , new errorHandler($globalobjects));
				$session->remove(SESSION_ERRORS);				
			}

			if ($session->exists(SESSION_MESSAGES)) 
			{
				// insert the messageHandler module at the top of the center pane
				include_once( 'includes/modules/messageHandler/module.php');
				array_unshift($this->m_ModulesArr , new messageHandler($globalobjects));
				$session->remove(SESSION_MESSAGES);
			}
		}
	}
	
	function setContent()
	{
		foreach ($this->m_ModulesArr as $module)
		{
			$this->m_Content[] = $module->GetContent();
		}
	}	
}
?>