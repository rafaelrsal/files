<?PHP
/*===========================================================================

        Copyright (c) 2013, Slice TI.  All Rights Reserved.  
 ============================================================================

  Author: Guilherme Lima
  Date Created: Mars 2013
  Title:            database methods
  Purpose:          methods for db access
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('includes/classes/xmlWrapper.php'); // inclus�o da classe para recupera��o de dados do banco (ip, senha, usu�rio, nome banco)
 
define('STORAGE_TYPE_ODBC',3 );
define('STORAGE_TYPE_RDBMS',2 );

class DBMethod{
	
	var $m_arrDBData=null; // Holding data for database connection. (dsn)		
	var $m_wrapper = null; // vari�vel para uso da classe xmlWrapper
	var $m_storageType; // vari�vel para uso do tipo de storage
	
	// construtor da classe
	function DBMethod(){
		$this->m_wrapper = new xmlWrapper();
		if (!$this->m_wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME))
		{
			return HSP_ERR_FILE_NOT_FOUND;
		}
	}
	
	//*********************GUILHERME CHIOZZINI DE LIMA **************************
	// fun��o para validar usu�rios do admin do HSP
	function verfAdminUsers($user, $pass){
		$dbConfigInfo = $this->m_wrapper->getRDBMSParams(); // repera dados do xml
		
		//*******************13/03/2013*************************************
		$arruserinfo = array();
		
		// conex�o com o banco
		$conn = mssql_connect($dbConfigInfo['rdbms_address'], $dbConfigInfo['rdbms_username'], $dbConfigInfo['rdbms_password']);
		mssql_select_db($dbConfigInfo['rdbms_name'], $conn);
		// query
		$sql = "SELECT roll FROM hsp_admin_users WHERE username = '" . $user . "' AND password = '" . encrypt_str($pass) . "'";
		
		//execu��o
		$query = mssql_query($sql, $conn);
		if (!mssql_num_rows($query)){
			mssql_close($conn);
			return 'vazio'; // retorna nenhuma linha, usu�rio n�o existe
		}
		else{
			$row = mssql_fetch_array($query, MSSQL_BOTH);
			$arruserinfo['roll'] = $row['roll'];
			$arruserinfo['user'] = $user;
			mssql_close($conn);
			return $arruserinfo;
		}
	}
	
	//Fun��o para altera��o de senha de usu�rios do admin
	function ChangePasswordAdminUser($user, $oldpass, $newpass)
	{
		$dbConfigInfo = $this->m_wrapper->getRDBMSParams(); // repera dados do xml
		// conex�o com o banco
		$conn = mssql_connect($dbConfigInfo['rdbms_address'], $dbConfigInfo['rdbms_username'], $dbConfigInfo['rdbms_password']);
		mssql_select_db($dbConfigInfo['rdbms_name'], $conn);
		// query
		$sql = "SELECT uid FROM hsp_admin_users WHERE username = '" . $user . "' AND password = '" . encrypt_str($oldpass) . "'";
		$updatesql = "UPDATE hsp_admin_users set password = '". encrypt_str($newpass) ."'  where uid =";
		//execu��o
		$query = mssql_query($sql, $conn);
		if (!mssql_num_rows($query)){ // senha antiga incorreta
			mssql_close($conn);
			return 'vazio'; // Senha incorreta
		}
		else{ // senha antiga correta
			$row = mssql_fetch_array($query, MSSQL_BOTH);
			$updatesql = $updatesql . $row['uid'];
			$query = mssql_query($updatesql, $conn);
			mssql_close($conn);
			if(!$query){ // n�o atualizou?
				return 'err';
			}
			else{ // atualizou?
				return 'ok';
			}
		}
		
	}
	
	// Fun��o para cria��o de um novo usu�rio para o Admin
	function CreateNewAdminUser($user, $pass, $roll)
	{
		$dbConfigInfo = $this->m_wrapper->getRDBMSParams(); // repera dados do xml
		// conex�o com o banco
		$conn = mssql_connect($dbConfigInfo['rdbms_address'], $dbConfigInfo['rdbms_username'], $dbConfigInfo['rdbms_password']);
		mssql_select_db($dbConfigInfo['rdbms_name'], $conn);
		
		//query
		$sql = "SELECT uid FROM hsp_admin_users where username='". $user ."'";
		$insertsql = "INSERT INTO hsp_admin_users (username, password, roll) values ('".$user."','".encrypt_str($pass)."','".$roll."')";
		
		//execu��o
		$query = mssql_query($sql, $conn);
		if (mssql_num_rows($query)){ // usu�rio j� existente?
			mssql_close($conn);
			return 'existe'; // J� existe
		}
		else{
			$query = mssql_query($insertsql, $conn);
			mssql_close($conn);
			if(!$query){ // n�o inseriu?
				return "err"; // n�o inserido
			}
			else{
				return "ok";
			}
		}
		
	}
	
	// Fun��o para remover usu�rio existente
	function RemoveAdminUser($user)
	{
		$dbConfigInfo = $this->m_wrapper->getRDBMSParams(); // repera dados do xml
		// conex�o com o banco
		$conn = mssql_connect($dbConfigInfo['rdbms_address'], $dbConfigInfo['rdbms_username'], $dbConfigInfo['rdbms_password']);
		mssql_select_db($dbConfigInfo['rdbms_name'], $conn);
		
		//query
		$sql = "SELECT uid FROM hsp_admin_users where username='". $user ."'";
		$removesql = "DELETE FROM hsp_admin_users where uid=";
		
		//execu��o
		$query = mssql_query($sql, $conn);
		if (!mssql_num_rows($query)){ // usu�rio inexistente?
			mssql_close($conn);
			return 'vazio'; // usu�rio n�o existe
		}
		else{ // usu�rio existente?
			$row = mssql_fetch_array($query, MSSQL_BOTH); // recuperar elementos do usu�rio existente
			$removesql = $removesql . $row['uid']; // atualiza query de remo��o
			$query = mssql_query($removesql, $conn); // executa
			mssql_close($conn); // fecha conex�o
			if(!$query){ // n�o removeu?
				return 'err'; // erro
			}
			else{ // removeu?
				return 'ok'; // removido
			}
		}
	}
	//************************************************************************************************
	//******************************GUILHERME CHIOZZINI DE LIMA 16/04/2013****************************
	function ResetPassaword($id){
		$dbConfigInfo = $this->m_wrapper->getRDBMSParams(); // repera dados do xml
		// conex�o com o banco
		$conn = mssql_connect($dbConfigInfo['rdbms_address'], $dbConfigInfo['rdbms_username'], $dbConfigInfo['rdbms_password']);
		mssql_select_db($dbConfigInfo['rdbms_name'], $conn);
		// query
		$updatesql = "UPDATE hsp_admin_users set password = '". encrypt_str("password") ."'  where uid = " . $id;
		//execu��o
		$query = mssql_query($updatesql, $conn);
		mssql_close($conn);
		if(!$query){ // n�o atualizou?
			return 'err';
		}
		else{ // atualizou?
			return 'ok';
		}
	}
	//************************************************************************************************
}
 ?>