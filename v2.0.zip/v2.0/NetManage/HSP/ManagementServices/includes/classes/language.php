<?PHP
class Language
{
	var $m_Language; // The current language
	var $m_Context; // Admin or Portal	

	function Language($lang)
	{
		$this->m_Language = $lang;
		$this->m_Context = GLOBAL_CONTEXT;
	}
		
	function GetLanguage()
	{
		return $this->m_Language;
	}
	
	function SetLanguage($language)
	{
		$this->m_Language = $language;
	}
		
	function RequireLangFile($filename,$modulename='')
	{
		if ($modulename != '')
		{
			$modulename = '/modules/' . $modulename;
		}
		$path = $this->m_Context . $modulename .'/includes/languages/' . $this->m_Language .'/' . $filename;
		require_once( $path );
	}
	
	function GlobalRequireLangFile($filename, $modulename='')
	{
		$path = 'includes/';
		
		if ($modulename != '')
		{
			$path.= 'modules/' . $modulename .'/includes/languages/';
		}
		
		$path.= $this->m_Language .'/' . $filename;
		
		require_once( $path );
	}
}



?>