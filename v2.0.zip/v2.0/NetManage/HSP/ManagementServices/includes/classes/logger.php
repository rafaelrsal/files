<?php
define('LOG_PATH' , 'data/');
define('LOG_SUCCESS','success: ');
define('LOG_FAIL','fail: ');


class Logger
{	
	var $m_fileName;
	var $m_fd;
	var $m_mode;
	
	function Logger( $fileName='hsp_log.txt', $mode='a+' )
	{
		$this->m_mode = $mode;
		$this->m_fileName = $fileName;
	}	
	
	function open()
	{
		$this->m_fd = @fopen( LOG_PATH . $this->m_fileName , $this->m_mode );
		if ( $this->m_fd == false )
		{
			return false;
		}
		
		return true;
	}
	
	function close()
	{
		return @fclose( $this->m_fd );
	}
	
	function write( $text , $bTimeStamp=true )
	{		
		if( $bTimeStamp )
		{
			$text =  date("[F j, Y, H:i:s]: ") . $text;
		}
		@fwrite($this->m_fd, $text . "\r\n");
	}
	
	function flush()
	{	
		if ( $this->m_fd )	
		{
			@fclose($this->m_fd);
		}
		
		if( @unlink( LOG_PATH . $this->m_fileName ) )
		{
			$this->m_fd = @fopen( LOG_PATH . $this->m_fileName , $this->m_mode );
			return true;
		}
		
		return false;
	}
	
}
?>