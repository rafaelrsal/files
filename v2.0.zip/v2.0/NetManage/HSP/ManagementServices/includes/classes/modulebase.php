<?php
require_once 'HTML/QuickForm/Renderer/ITStatic.php';
require_once 'HTML/Template/Sigma.php';

class ModuleBase
{
	var $m_content;
	var $m_session ;
	var $m_language;
	var $m_database;
	var $m_form;
	var $m_moduleName;
	var $m_username;
	
	function ModuleBase($globalobjects)
	{
		$this->m_session = $globalobjects->GetSession();
		$this->m_language = $globalobjects->GetLanguage();
		$this->m_database = $globalobjects->GetDatabase();
		$this->m_username = $globalobjects->GetUsername();
	}
	
	function init($moduleName)
	{
	
		// The new structure  - mhoter:
		$this->m_moduleName = $moduleName;
		
		$this->m_session->set(SESSION_MODULE, $moduleName);

		$this->m_language->RequireLangFile( 'module.php' , $moduleName);

	}

	// Build the page of the module and display it:
	function finalize($arrVars)
	{
		$tpl =& new HTML_Template_Sigma('.');
		$tpl->loadTemplateFile("admin/modules/$this->m_moduleName/includes/$this->m_moduleName.tpl");

		$renderer =& new HTML_QuickForm_Renderer_ITStatic($tpl);
		$renderer->setRequiredTemplate('<font color="red" size="1">*</font>{label}');
		$renderer->setErrorTemplate('<font color="red" size="">{error}</font><br />{html}');

		if (null != $this->m_form)
		{
			$this->m_form->accept($renderer);
		}
		
		if(is_array($arrVars))
		{
			foreach($arrVars as $varName=>$varVal)
			{
				$tpl->setVariable($varName, $varVal);
			}
		}
		
		// Let the template build itself:
		$tpl->parse();

		// Get the result of the template build:
		$contents = $tpl->get();

		$this->SetContent($contents);
	}

	function Show()
	{
		echo $this->m_content;
	}

	// TOBE REMOVED WHEN ALL MODULES ACT IN THE NEW STRUCTURE:
	function GetContent()
	{
		return $this->m_content;
	}
	
	// TOBE REMOVED WHEN ALL MODULES ACT IN THE NEW STRUCTURE:
	function SetContent($content)	
	{
		$this->m_content = $content;
	}
	
	// TOBE REMOVED WHEN ALL MODULES ACT IN THE NEW STRUCTURE:
	function GetSession()
	{
		return $this->m_session;
	}
	
	// TOBE REMOVED WHEN ALL MODULES ACT IN THE NEW STRUCTURE:
	function GetLanguage()
	{
		return $this->m_language;
	}
	
	function GetDatabase()
	{
		return $this->m_database;
	}
	
	// Guilherme Chiozzini de Lima - 19/03/2013
	// function par retorno do usu�rio logado
	
	function GetUsername()
	{
		return $this->m_username;
	}
	
	// Guilherme Chiozzini de Lima - 19/03/2013
	// Function para cria��o de log
	// Entrada - $action - a��o efetuada
	// 			$description - extra infos
	function CriaLog($action, $description=null)
	{
		$strTextoHeader = "data\t\t\t;username\t\t\t;a��o\t\t\t;local\t\t\t;item do menu\t\t\t; descri��o\n"; // string contendo o texto do header
	
		if (is_null($description)) // variavel � null
		{
			$strTextoLog = date('H:i:s')."\t\t\t;".$this->m_username."\t\t\t;".$action."\t\t\t;".get_class($this)."\t\t\t;".$_SESSION['ItemTitle']."\n"; // string contendo conteudo do log
		}
		else
		{
			$strTextoLog = date('H:i:s')."\t\t\t;".$this->m_username."\t\t\t;".$action."\t\t\t;".get_class($this)."\t\t\t;".$_SESSION['ItemTitle']."\t\t\t;". $description ."\n"; // string contendo conteudo do log
		}
		
		if(!file_exists("log/admin/".date('Ymd').".csv"))
		{
			$log = fopen("log/admin/".date('Ymd').".csv", 'a');

			if($log == true)
			{
				fwrite($log, $strTextoHeader);
				fwrite($log, $strTextoLog);
				fclose($log);
			}
		}
		else
		{
			$log = fopen("log/admin/".date('Ymd').".csv", 'a');
			if($log == true)
			{
				fwrite($log, $strTextoLog);
				fclose($log);
			}
		}
	
	}
}
?>