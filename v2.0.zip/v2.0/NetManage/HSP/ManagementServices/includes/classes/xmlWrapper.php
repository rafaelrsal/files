<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title:            xml wrapper
  Purpose:          Entry point manipulating the config.xml file
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/

include_once( "lib/ezxml/classes/ezxml.php" );
define('EMPTY_PASSWORD','itreallytiedtheroomtogethernetmanage');
define('EMPTY_PORT','none');
class xmlWrapper
{
	var $m_ezXml;
	var $m_fileName;
	var $m_xmlString;
	var $m_domTree;
	
	function xmlWrapper()
	{		
		$this->m_ezXml = new eZXML();
		
		if(!extension_loaded('HSPSecurModule'))
		{
			dl('php_HSPSecurModule.dll');
		}
	}
	
	function initFromFile($fileName)
	{
		$this->m_fileName = $fileName;
		
		$fd = @fopen($this->m_fileName, "r");
		
		if ( $fd )
		{
			$this->m_xmlString = @fread($fd, filesize($this->m_fileName));
			@fclose($fd);		
			$this->m_domTree = $this->m_ezXml->domTree($this->m_xmlString);
			return true;
		}
		return false;
	}
	
	function initFromString($xmlString)
	{
		$this->m_xmlString = $xmlString;
		
		$this->m_domTree = $this->m_ezXml->domTree($this->m_xmlString); 
	}
	
	function getStorageType()
	{
		$storage_type    = $this->m_domTree->elementsByName('hap_storage_info');
		return $storage_type[0]->elementTextContentByName( 'storage_type' );		
	}
	
	function setStorageType($type)
	{
		$hap_storage_info  = $this->m_domTree->elementsByName('hap_storage_info');
		
		$storage_type  = &$hap_storage_info[0]->elementTextContentByName( 'storage_type' );
		$storage_type = $type;		
	}
	
	function getRDBMSParams()
	{
		$dbParams = array();
		$storage_rdbms    = $this->m_domTree->elementsByName('storage_rdbms');

		$dbParams['version'] 		= $storage_rdbms[0]->elementTextContentByName( 'version' );
		$dbParams['rdbms_address'] 	= $storage_rdbms[0]->elementTextContentByName( 'rdbms_address' );
		$dbParams['rdbms_port'] 	= $storage_rdbms[0]->elementTextContentByName( 'rdbms_port' );
		// Check the case when port is empty (mhoter -- mssql reason):		
		if("none" == $dbParams['rdbms_port'])
		{
			$dbParams['rdbms_port'] = "";
		}
		$dbParams['rdbms_name'] 	= $storage_rdbms[0]->elementTextContentByName( 'rdbms_name' );
		$dbParams['rdbms_username'] = $storage_rdbms[0]->elementTextContentByName( 'rdbms_username' );
		$dbParams['rdbms_password'] = decrypt_str($storage_rdbms[0]->elementTextContentByName( 'rdbms_password' ));
		if ( $dbParams['rdbms_password'] ==  EMPTY_PASSWORD )
		{
			$dbParams['rdbms_password'] = '';
		}
		
		$dbParams['rdbms_type'] 	= $storage_rdbms[0]->elementTextContentByName( 'rdbms_type' );
		
		return $dbParams;
	}
	
	function setRDBMSParams($dbParams)
	{
		$storage_rdbms    = $this->m_domTree->elementsByName('storage_rdbms');
		
		$version = &$storage_rdbms[0]->elementTextContentByName( 'version' );
		$version = $dbParams['version'];
		
		$rdbms_address 	= &$storage_rdbms[0]->elementTextContentByName( 'rdbms_address' );
		$rdbms_address = $dbParams['rdbms_address'];
		
		$rdbms_port	= &$storage_rdbms[0]->elementTextContentByName( 'rdbms_port' );
		// Check the case when port is empty (mhoter -- mssql reason):		
		if(empty($dbParams['rdbms_port']))
		{
			$dbParams['rdbms_port'] = EMPTY_PORT;
		}
		$rdbms_port = $dbParams['rdbms_port'];
		
		$rdbms_name	= &$storage_rdbms[0]->elementTextContentByName( 'rdbms_name' );
		$rdbms_name = $dbParams['rdbms_name'];
		
		$rdbms_username = &$storage_rdbms[0]->elementTextContentByName( 'rdbms_username' );
		$rdbms_username = $dbParams['rdbms_username'];
		
		$rdbms_password = &$storage_rdbms[0]->elementTextContentByName( 'rdbms_password' );
		if ( empty($dbParams['rdbms_password']) )
		{
			$dbParams['rdbms_password'] = EMPTY_PASSWORD;
		}
		
		$rdbms_password = encrypt_str($dbParams['rdbms_password']);
		
		$rdbms_type = &$storage_rdbms[0]->elementTextContentByName( 'rdbms_type' );
		$rdbms_type = $dbParams['rdbms_type'];
	}

	function getODBCParams()
	{
		$dbParams = array();
		$storage_odbc    = $this->m_domTree->elementsByName('storage_odbc');
	
		$dbParams['type'] 		= $storage_odbc[0]->elementTextContentByName( 'type' );
		$dbParams['dsn'] 		= $storage_odbc[0]->elementTextContentByName( 'dsn' );
		$dbParams['user_name'] 	= $storage_odbc[0]->elementTextContentByName( 'user_name' );
		$dbParams['password'] 	= decrypt_str($storage_odbc[0]->elementTextContentByName( 'password' ));
		
		if ( $dbParams['password'] ==  EMPTY_PASSWORD )
		{
			$dbParams['password'] = '';
		}
		return $dbParams;
	}

	function setODBCParams($dbParams)
	{
		$storage_rdbms    = $this->m_domTree->elementsByName('storage_odbc');
		
		$type = &$storage_rdbms[0]->elementTextContentByName( 'type' );
		$type = $dbParams['type'];
		
		$dsn = &$storage_rdbms[0]->elementTextContentByName( 'dsn' );
		$dsn = $dbParams['dsn'];
		
		$user_name 	= &$storage_rdbms[0]->elementTextContentByName( 'user_name' );
		$user_name 	= $dbParams['user_name'];
		
		$password	= &$storage_rdbms[0]->elementTextContentByName( 'password' );
		
		if(empty( $dbParams['password']))
		{
			$dbParams['password'] = EMPTY_PASSWORD;
		}

		$password = encrypt_str($dbParams['password']);
	}	

	function getDBDll()
	{
		$hap_storage_interface    = $this->m_domTree->elementsByName('hap_storage_interface');
		return $hap_storage_interface[0]->elementTextContentByName( 'storage_interface_module' );
	}
	
	function setDBDll($DBDllName)
	{
		$hap_storage_interface    = $this->m_domTree->elementsByName('hap_storage_interface');
		
		$storage_interface_module  = &$hap_storage_interface[0]->elementTextContentByName( 'storage_interface_module' );
		$storage_interface_module = $DBDllName;
	}
	
	function getMaintenanceInterval()
	{
		$hap_storage_maintenance    = $this->m_domTree->elementsByName('hap_storage_maintenance');
		return $hap_storage_maintenance[0]->elementTextContentByName( 'maintenance_interval' );
	}
	
	function setMaintenanceInterval($interval)
	{
		$hap_storage_maintenance    = $this->m_domTree->elementsByName('hap_storage_maintenance');
		
		$maintenance_interval  = &$hap_storage_maintenance[0]->elementTextContentByName( 'maintenance_interval' );
		$maintenance_interval = $interval;
	}
	
	function getUMConfigInfo()
	{
		$umConfigInfo = array();
		$um_config_info   = $this->m_domTree->elementsByName('um_config_info');

		$umConfigInfo['ft_config'] 	= decrypt_str($um_config_info[0]->elementTextContentByName( 'ft_config' ));
		$umConfigInfo['user_name'] 	= $um_config_info[0]->elementTextContentByName( 'user_name' );
		$umConfigInfo['password'] 	= decrypt_str($um_config_info[0]->elementTextContentByName( 'password' ));
		
		return $umConfigInfo;
	}
	
	function setUMftConfig($umftConfig)
	{
		$um_config_info   = $this->m_domTree->elementsByName('um_config_info');
		
		$ft_config = &$um_config_info[0]->elementTextContentByName( 'ft_config' );
		$ft_config = encrypt_str($umftConfig);
	}

	function setUMConfigInfo($nameAndPass)
	{		
		$um_config_info   = $this->m_domTree->elementsByName('um_config_info');
		
		$username = &$um_config_info[0]->elementTextContentByName( 'user_name' );
		$username = $nameAndPass['user_name'];

		$password = &$um_config_info[0]->elementTextContentByName( 'password' );
		$password = encrypt_str($nameAndPass['password']);
	}
	
	function toString()
	{
		return $this->m_domTree->toString();
	}
	
	function getAnonymousStatus()
	{
		$um_config_info   = $this->m_domTree->elementsByName('um_config_info');
		$anon_user =  $um_config_info[0]->elementTextContentByName( 'anon_user' );
	
		return  $anon_user;
	}
	
	function setAnonymousStatus($status)
	{
		$um_config_info   = $this->m_domTree->elementsByName('um_config_info');
		$anon_user =  &$um_config_info[0]->elementTextContentByName( 'anon_user' );
		$anon_user = $status;
	}
	
	function serialize($path)
	{
		$fp = @fopen($path, "wb");
		if(true == $fp)
		{
			if(fputs($fp, $this->toString()))
			{
				fclose($fp);				
				return HSP_SUCCESS;
			}
		}

		return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;		
	}
	
	function getConfigParams()
	{
		$configParams = array();
		$um_config_info   = $this->m_domTree->elementsByName('um_config_info');

		$configParams['enableNewWindow']		= $um_config_info[0]->elementTextContentByName( 'enableNewWindow' );
		$configParams['numberOfTabs'] 			= $um_config_info[0]->elementTextContentByName( 'numberOfTabs' );
		$configParams['serverTimeout'] 			= $um_config_info[0]->elementTextContentByName( 'serverTimeout' );
		$configParams['showRememberPassword'] 	= $um_config_info[0]->elementTextContentByName( 'showRememberPassword' );
		$configParams['globalSessionLimit'] 	= $um_config_info[0]->elementTextContentByName( 'globalSessionLimit' );
		$configParams['setOpenNewWindow'] 		= $um_config_info[0]->elementTextContentByName( 'setOpenNewWindow' );
		$configParams['enableLocalstart'] 		= $um_config_info[0]->elementTextContentByName( 'enableLocalstart' );
		
		return $configParams;
	}

	function getOnWebApps()
	{
		$appData = array();
		$appName = null;
		
		if(null != $this->m_domTree)
		{
			$entries = $this->m_domTree->elementsByName('entry');
			$tlrs = $this->m_domTree->elementsByName('TLR');
			for($i = 0; $i<count($entries); ++$i)
			{
				// Get the applicatione name:
				$appName = $entries[$i]->elementTextContentByName( 'name' );
				
				// Get the TLR url and display name, and attach it to the app name: 
				$appData[$appName]['displayname']= $tlrs[$i]->elementTextContentByName( 'displayname' );
				$appData[$appName]['url']= $tlrs[$i]->elementTextContentByName( 'url' );
			}
		}				
		return $appData;
	}

	function setConfigParams($configParams)
	{
		$um_config_info   = $this->m_domTree->elementsByName('um_config_info');
		
		$enableNewWindow = &$um_config_info[0]->elementTextContentByName( 'enableNewWindow' );
		$enableNewWindow = $configParams['enableNewWindow'];
		
		$numberOfTabs = &$um_config_info[0]->elementTextContentByName( 'numberOfTabs' );
		$numberOfTabs = $configParams['numberOfTabs'];
		
		$serverTimeout = &$um_config_info[0]->elementTextContentByName( 'serverTimeout' );
		$serverTimeout = $configParams['serverTimeout'];		
		
		$showRememberPassword = &$um_config_info[0]->elementTextContentByName( 'showRememberPassword' );
		$showRememberPassword = $configParams['showRememberPassword'];
		
		$globalSessionLimit = &$um_config_info[0]->elementTextContentByName( 'globalSessionLimit' );
		$globalSessionLimit = $configParams['globalSessionLimit'];
		
		$setOpenNewWindow = &$um_config_info[0]->elementTextContentByName( 'setOpenNewWindow' );
		$setOpenNewWindow = $configParams['setOpenNewWindow'];
		
		$enableLocalstart = &$um_config_info[0]->elementTextContentByName( 'enableLocalstart' );
		$enableLocalstart = $configParams['enableLocalstart'];
	}
}

?>