<?php
// these includes are necessary for the reconstruction of the session's vars
// it would be best not to put them here but we cannot think of a better place
// and no one will notice this anyways...


require_once('admin/modules/groups/includes/group.php');
require_once('admin/modules/users/includes/user.php');
require_once('admin/includes/classes/DirAuthInfo.php');
require_once('upgrade/upgrade.php');

class HAPSession 
  {
  	function start()
  	{
  		if (!isset($_SESSION) || is_null($_SESSION))
  		{
  			session_start();	
  			header("Cache-control: private"); // IE6 Fix
  		}
  	}
  	
  	function exists($variable) 
  	{
  		if (isset($_SESSION[$variable])) 
  		{
        			return true;
  		}
  		return false;
    	}

    function set($variable, $value) 
    {  	
    	$_SESSION[$variable] = $value;
    	
    }

    function remove($variable)
    {
    	if ($this->exists($variable)) 
    	{
        	unset($_SESSION[$variable]);
        	return true;
    	}
    	return false;
    }

    function &value($variable)
    {
    	if (isset($_SESSION[$variable]))
    	{
        		return $_SESSION[$variable];
    	}
    	return false;
    }
    
    function close()
    {
    	if (isset($_SESSION))
    	{
		return session_write_close();
	}
    }

	function destroy() 
	{
		if (isset($_SESSION))
		{
      			return session_destroy();
		}
    	}
    	
    	function session_unset()
    	{
    		if (isset($_SESSION))
    		{
    			return session_unset();
    		}
    	}
  }
?>