<?PHP
require_once('frameElement.php');

class Left_Column extends frameElement 
{
	
	var $m_ModulesArr = array();
	function Left_Column($globalobjects,$modules)
	{
		foreach ($modules as $module)
		{
			if(!include_once( GLOBAL_CONTEXT.'/modules/'.$module.'/module.php'))
			{
				include_once( 'includes/modules/'.$module.'/module.php');
			}
			
			$newModule = new $module($globalobjects);	
			$newModule->init();
			$newModule->process();
			$newModule->finalize();
			
			$this->m_ModulesArr[] = $newModule;
		}
	}
	
	function setContent()
	{
		foreach ($this->m_ModulesArr as $module)
		{
			$this->m_Content[] = $module->GetContent();
		}	 
	}
	
	
}
?>