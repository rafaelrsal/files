<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: whosOnline.php
  Purpose: recored and handle portal users login events
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/

require_once('includes/classes/DBConfig.php');
require_once('includes/classes/PearDB.php');

class whosOnline
{
	var $m_sessionId;
	var $m_ipAddress;
	var $m_lastPage;
	var $m_userId;
	var $m_username;
	var $m_fullName;
	var $m_db;
	var $m_timeout;
	var $m_directory;
	var $m_timeEntry;
	var $m_gcTimeout;
	function whosOnline( $db = null ) 
	{	
		if ( $db == null )
		{
			$db = $this->DBConnection();
		}
	    $this->m_db = $db;
	    $this->m_ipAddress = $this->getClientIP();
	    $this->m_timeout = 60*60; // 1 Hour
	    $this->m_gcTimeout = 60*10; // 10 min
	}
	
	function init( $sessionId=null )
	{
		if ( $sessionId == null )
		{
			$this->m_sessionId = session_id();
		}
		else
		{
			$this->m_sessionId = $sessionId;
		}
		
	    $this->m_lastPage = $_SERVER['SCRIPT_NAME'];
	    
	    if ( isset($_SESSION['userObject']) )
	    {
	    	$userObj = $_SESSION['userObject'];
	    	
	    	$this->m_userId = $userObj->getUserId();
	    	$this->m_username = $userObj->getUsername();
	    	
	    	$this->m_fullName = $userObj->getFullName();
	    	if ( empty($this->m_fullName) )
	    	{
	    		$this->m_fullName = $this->m_username;
	    	}
	    	
	    	$dirDetails = $userObj->getDirectoryDetails();
	    	if ( isset($dirDetails['display_name']) )
	    	{
	    		$this->m_directory = $dirDetails['display_name'];
	    	}
	    	else
	    	{
	    		$this->m_directory = '';
	    	}
	    }
	    
	    if ( isset( $_SESSION['timeEntry'] ) )
	    {
			$this->m_timeEntry = $_SESSION['timeEntry'];
	    }
	    else
	    {
	    	$this->m_timeEntry = time();
	    	$_SESSION['timeEntry'] = $this->m_timeEntry;
	    }
	    
		
	}
	
	function getClientIP()
	{
		$ip = '';
		if (getenv('HTTP_CLIENT_IP'))
		{ 
			$ip = getenv('HTTP_CLIENT_IP');
		} 
		elseif (getenv('HTTP_X_FORWARDED_FOR'))
		{ 
			$ip = getenv('HTTP_X_FORWARDED_FOR');
		} 
		elseif (getenv('HTTP_X_FORWARDED'))
		{ 
			$ip = getenv('HTTP_X_FORWARDED');
		} 
		elseif (getenv('HTTP_FORWARDED_FOR'))
		{ 
			$ip = getenv('HTTP_FORWARDED_FOR');
		} 
		elseif (getenv('HTTP_FORWARDED'))
		{ 
			$ip = getenv('HTTP_FORWARDED');
		} 
		else 
		{ 
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
	
	function register( $nodeId = null )
	{
		$this->init();
		$current_time = time();
	    $this->deleteExpiredEntries();	    
		
	    $fields_values = array(	'sessionId'=>		$this->m_sessionId,
	    						'userId'=> 			$this->m_userId,
	    						'username'=> 		stripslashes($this->m_username),
	    						'directory'=> 		$this->m_directory,
								'fullName'=>		stripslashes($this->m_fullName),
								'ipAddress'=>		$this->m_ipAddress,
								'lastUrl'=>			$this->m_lastPage
								);
		if ( $nodeId != null )
		{
			$fields_values['lastNodeId'] = $nodeId;
			$fields_values['timeLastClick'] = $current_time;
		}
		
		$fields_values['lastHeartbeat'] = $current_time;
		
	    	
		$this->m_db->getOne("select count(*) as count from " . TABLE_WHOS_ONLINE . " where sessionId=\"$this->m_sessionId\";", $queryRes);

		if ( $queryRes > 0 )
	    {
	    	$ret = $this->m_db->AutoExecute( TABLE_WHOS_ONLINE, $fields_values, DB_AUTOQUERY_UPDATE,"sessionId=\"$this->m_sessionId\";");		      
	    } 
	    else
	    {	
	    	$fields_values['timeLastClick'] = $current_time;
	    	$fields_values['timeEntry'] = $this->m_timeEntry;
	    	$ret = $this->m_db->AutoExecute( TABLE_WHOS_ONLINE, $fields_values );		      
	    }
	}
	
	function unregister( $sessionId=null )
	{
		if ( $sessionId == null )
		{
			$sessionId = $this->m_sessionId;			
		}
		
		$this->m_db->Query("delete from " . TABLE_WHOS_ONLINE . " where sessionId=\"$sessionId\";");
	}
	
	function deleteExpiredEntries()
	{
		// we would like to run clean up at least once every 10min ($this->m_gcTimeout)
		// also every call to this function will have a chance of 1/100 to do it
		$runGc = false;
		$current_time = time();
		$this->m_db->getOne("select lastGc from " . TABLE_GENERAL. ";" ,$lastGc );
		
		if ( $lastGc == '' || $lastGc == null || $lastGc == false )
		{
			$runGc = true;
		}
		else 
		{		
			srand() ;
			$random  = rand(1, 100);				
				
			if ( ($current_time - $lastGc) >= $this->m_gcTimeout || $random == 42 )
			{
				$runGc = true;
			}
		}
		
		if ( $runGc )
		{
			$fields_values = array(	'lastGc'=>$current_time);
			$this->m_db->AutoExecute( TABLE_GENERAL, $fields_values, DB_AUTOQUERY_UPDATE );
			
			$xx_mins_ago = ($current_time - $this->m_timeout);
			$this->m_db->Query("delete from " . TABLE_WHOS_ONLINE . " where lastHeartbeat < \"$xx_mins_ago\";");			
		}
		
		
	}
	
	function setTimeout( $timeout )
	{
		$this->m_timeout = $timeout;
	}
	
	function count()
	{
		$this->m_db->getOne("select count(*) as count from " . TABLE_WHOS_ONLINE . ";",$queryRes);
		return $queryRes;
	}
	
	function DBConnection()
	{
		$database = null;
		$dbconfig = new DBConfig();
		$dbconfig->init();
		$errCode = $dbconfig->DBDeserialize();
		
		if($errCode != 0)
		{
			return null;
		}			
		else
		{
			$database = new PearDB();
			$database->SetDSNArray($dbconfig->getDBData());			
			$ret = $database->Connect();
			if ( $ret != 0 )
			{ 
				return null;
			}			
		}
		
		return $database;
	} 
	
	function checkUserLogged( $username, $directory = null )
	{
		if ( null == $directory ) //anonymous user
		{
			$this->m_db->getOne("select count(*) as count from " . TABLE_WHOS_ONLINE . " where username = \"" . ANON_USER_NAME . "\" AND ipAddress=\"" . $this->m_ipAddress . "\" AND directory=\"\";",$queryRes);
		}
		else
		{
			$this->m_db->getOne("select count(*) as count from " . TABLE_WHOS_ONLINE . " where username=\"" . $username . "\" AND directory=\"". $directory . "\";",$queryRes);
		}
		
		return $queryRes;
	}
}
?>