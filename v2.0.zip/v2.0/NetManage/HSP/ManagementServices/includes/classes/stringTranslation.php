<?php
class stringTranslation
{	
	var $translationArrayClass;
	
	function stringTranslation()
	{		
		$this->translationArrayClass = new translationArrayClass();
	}
	
	function translate( $str )
	{
		if ( isset($this->translationArrayClass->translationArray[$str]) )
		{
			return $this->translationArrayClass->translationArray[$str];
		}
		
		return $str;
	}
}
?>