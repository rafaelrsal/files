<?php
	
	require_once(GLOBAL_CONTEXT . '/includes/require.php');
    require_once('includes/global_defines.php');
	require_once('includes/global_errorCodes.php');
	require_once('includes/classes/global_objects.php');
	require_once(LANG_DIR . CURRENT_LANG . '.php');
	
	if ( !@include_once( 'data/defines.php') )
	{
		ini_set("max_execution_time", "120" );
	}
	else
	{
		ini_set("max_execution_time", MAX_EXECUTEION_TIME );
	}
?>