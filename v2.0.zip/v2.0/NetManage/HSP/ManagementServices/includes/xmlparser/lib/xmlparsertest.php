<?PHP
include_once( "ezxml/classes/ezxml.php" );


$file = "data.xml";

$handle = fopen($file, "r");
$contents = fread($handle, filesize($file));
fclose($handle);

$ezXml = new eZXML();
$domObj = $ezXml->domTree($contents);

$hap_storage_info = $domObj->elementsByName('hap_storage_info');
$storage_rdbms    = $domObj->elementsByName('storage_rdbms');
$rdbms_address	  = $domObj->elementsByName('rdbms_address');

/*$element = &$storage_rdbms[0]->elementByName( 'rdbms_address' );
$chil = &$element->firstChild();
$chil->setContent('127.0.0.1');
*/
$kkk = &$storage_rdbms[0]->elementTextContentByName( 'rdbms_address' );
$kkk = '127.0.0.1';

//$rdbms_address[0]->setContent( '127.0.0.1' );


//$storage_rdbms[0]->Name = 'AAAA';

/*$clone = $storage_rdbms[0]->clone();



$clone->Name = 'AAAA';
//$clone->removeChildren();

$hap_storage_info[0]->removeNamedChildren( 'storage_rdbms' );
$hap_storage_info[0]->appendChild($clone);
*/

echo $domObj->toString();

//echo $rdbmsnameNode[0]->toString(2);
//echo '<br>';

/*echo $rdbmsnameNode[0]->elementTextContentByName('rdbms_address');
echo '<br>';
echo $rdbmsnameNode[0]->elementTextContentByName('rdbms_port');
echo '<br>';
echo $rdbmsnameNode[0]->elementTextContentByName('rdbms_name');
echo '<br>';
*/

//$arr = $rdbms_name[0];
//$chil = $arr->Children;
//$con = $chil[0]->Content;
//echo $con;
?>