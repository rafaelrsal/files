<?PHP
define('HSP_ERROR_PAGETITLE','HSP Error');

class translationArrayClass
{
	var $translationArray = array(	
	0=>'O Portal HSP j� est� ativo.',
	1=>'O Logon do usu�rio An�nimo est� desabilitado.',
	2=>'N�o foi poss�vel encontrar a aplica��o',
	3=>'Voc� n�o est� autorizado a visualizar esta p�gina!',
	4=>'A p�gina expirou.<br>Pressione o bot�o Voltar para retornar ao Portal do Usu�rio',
	5=>'P�gina expirada.',
	6=>'Voc� j� est� logado neste diret�rio.',
	7=>'Erro de base de dados.',
	8=>'Erro de sistema.',
	9=>'N�o foi poss�vel completar a execu��o do Single Sign On.'
	);
}
?>