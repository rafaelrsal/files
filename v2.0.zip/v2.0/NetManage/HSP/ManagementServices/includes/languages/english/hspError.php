<?PHP
define('HSP_ERROR_PAGETITLE','HSP Error');

class translationArrayClass
{
	var $translationArray = array(	
	0=>'HSP Portal is already active.',
	1=>'Anonymous user logon is disabled.',
	2=>'Application cannot be found',
	3=>'You are not authorized to view this page!',
	4=>'Page expired.<br>Press the Back button to return to the HSP user portal',
	5=>'Page expired.',
	6=>'You are already logged on to this directory.',
	7=>'General database error.',
	8=>'General system error.',
	9=>'Could not complete Single Sign On execution.'
	);
}
?>