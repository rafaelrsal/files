<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: print.php
  Purpose: print preview
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
?>

<html>
<head>
<TITLE>Host Application Tree Print Preview</TITLE>
<link rel="stylesheet" type="text/css" href="includes/stylesheets/hsp.css">
<script language="JavaScript" src="admin/includes/js/Misc.js"></script>
<script language="javascript">

	document.onkeydown = checkKP;
		
	function checkKP(e) 
	{			
	
		if (event.keyCode == 27) //check ESC key press
		{
			window.close();
		}
	}
	
	var win = window.dialogArguments;

	function DoDefaultEnterKey(e)
	{
		if(CheckEnter(e))
	   {
			parent.document.getElementsByName('btnClose').item(0).click();
	   }

	}

	function CloseMe()
	{
		if ( null != win.document.getElementsByName('new').item(0) ) 
		{
			 win.document.getElementsByName('new').item(0).focus();
		}
		else if(null != win.document.getElementsByName('save').item(0))
		{
			win.document.getElementsByName('save').item(0).focus();
		}
		self.close()
	}
</script>

</head>
<body onunload="CloseMe();">
<FORM name="previewForm" >
<IFRAME SRC="treeprint.php" name="tree" FRAMEBORDER="0" height="87%" width="100%">
</IFRAME>

<TABLE width="100%">	
	<tr>
		<td colspan=5>		
			<hr>
		</td>
	</tr>
	<tr><td colspan="3" align="right">
		<INPUT type="button" value="Print"  onclick="tree.focus();window.print();" class="NewButton">
		<INPUT type="submit" value="Close"  onclick="CloseMe();return false;" class="NewButton" name=btnClose>
	</td></tr>
	<tr><td>&nbsp</td></tr>
</TABLE>
</FORM>
<script language="javascript" for="window" event="onload">
	document.getElementsByName('btnClose').item(0).focus();
</script>
</body>
</html>