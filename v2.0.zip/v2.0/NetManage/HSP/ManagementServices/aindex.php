<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  	           Udi Zisser
  	           Guy Schetrit
  					
  Date Created:     April 2004

  Title:            	aindex.php
  Purpose:          Entry point for using the HSP administration console options.
  Limitations:	Requires PHP 4.3.4

 ============================================================================*/

 
session_start();
header("Cache-control: private"); // IE6 Fix
 // NOTICE --Using ob_start(), enables us to navigate between our pages, without getting header 
  	// warnings. This means we buffer output until we call frame->show(), and there
  	// we call ob_end_flush()! - mhoter
 	ob_start();
 	///////////////

 	// NOTICE --The following is required in order to include the path to the pear:
 	//			in unix it should be like this ->
 	//			ini_set("include_path", ".:includes/pear" );
	ini_set("include_path", ".;includes/pear;includes/xmlparser" );
	//////////////
 	
 	define('GLOBAL_CONTEXT','admin');
	require_once('includes/global_require.php');
	require_once('includes/classes/whosOnline.php');
	require_once(GLOBAL_CLASSES_DIR . 'frame.php');
	
	if ( !isset($_SESSION[SESSION_ADMIN_AUTH_FLAG]) && ( isset($_SESSION['authenticatedUserType'])))
	{
		$whosOnline = new whosOnline();
		$whosOnline->unregister(session_id());
		
		if ( isset($_SESSION) )
		{
			$_SESSION = array();
		}
	}
	
	//**********29/10/2012******* Guilherme Lima - Slice -> destrui��o de sess�o para mudan�a de idiomas *******************
	session_destroy();
?>

<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>"/>
<title><?php echo TXT_TITLE; ?></title>
</head> 
<FRAMESET>
    <FRAME src="admin.php?l=<?PHP echo CURRENT_LANG;?>" name="admin">
</FRAMESET>
</HTML>
