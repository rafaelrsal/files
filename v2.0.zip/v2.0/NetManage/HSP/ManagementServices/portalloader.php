<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created: Mars 2004
  Title: portalLoader.php
  Purpose: load the correct portal style
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
/**
This file will load the correct home.php according to the selected style.
We had to make this file so all path will be relative to the root of the project  (web site).
/*******************************************************/

	$userObj = $_SESSION['userObject'];
	if ( empty($userObj) || !$userObj->isAuthenticated() )
	{
		$_SESSION['errorCode'] = 3;
		include_once('hspError.php');
		exit();
	}
	
	$details = $userObj->getCustomUserDetails();
	if ( !isset($_SESSION['refresh']) )
	{
		if ( $userObj->getUserType() == USER_TYPE_USER )
		{	
			setcookie('hspVersion','1.2xx');
			if ( isset($_POST['rememberPassword']) )
			{
				setcookie('password',$userObj->getPassword(),time()+3600*24*30);// expire after 1 month			
				setcookie('rememberPassword','checked',time()+3600*24*30);// expire after 1 month
			}
			else
			{
				setcookie('password',false,time()-3600);// delete the cookie
				setcookie('rememberPassword',false,time()-3600);// expire after 1 month
			}
			
			if ( isset($_POST['directories']))
			{
				 setcookie('directories',$_POST['directories'],time()+3600*24*30);// expire after 1 month
			}
			
			setcookie('username',$userObj->getUsername(),time()+3600*24*30); // expire after 1 month
			
		}		
	}
	else 
	{
		 unset($_SESSION['refresh']);
	}
	// load the home page
	require_once('Portal/style/' .  $userObj->getUserStyle() .'/home.php');
?>

<script type="text/javascript" src="includes/js/keyHandlers.js"></script>
<script type="text/javascript" src="includes/js/server.js"></script>
<script language="javascript">
	document.onkeydown = checkKP;
	document.oncontextmenu = disableContextMenu;
	window.setInterval("register()",1500000); // send heartbeat every 25 min
	window.onbeforeunload = unload;

	function unload()
	{		
		runServerScript('unregister.php');	
		if ( logoutPressed != true )
		{			
			event.returnValue  = '<?PHP echo LOGOUT_REFRESH_MESSAGE; ?>';
		}
	}
	
	function register()
	{
		runServerScript('register.php');
	}
	
	function disableContextMenu()
	{
		return false;
	}
</script>