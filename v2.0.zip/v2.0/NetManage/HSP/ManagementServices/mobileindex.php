<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: login.php
  Purpose: user portal login page.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
define('GLOBAL_CONTEXT','portal');

ini_set("include_path", ".;includes/pear;includes/xmlparser" );

require_once('includes/classes/whosOnline.php');
require_once('Portal/includes/dbConnection.php');
require_once('Portal/includes/applicationProcess.php');
require_once('Portal/includes/portalUser.php');
require_once('includes/classes/PearDB.php');
		
session_start();

require_once('Portal/includes/Languages/english/login.php');

	$errorMsg = '';
	$invokeChangePasswordPopup = 0;
	$accountIsDisabled = 0;
	
	$defaultUsername = '';
	$defaultPassword = '';
	$defaultDirectory = '';
	$rememberPassword = '';
	
	$displayRememberPassword = false;
	
	$portalConfiguration = file_get_contents('data/portalConfiguration.js');
	$startPos = strpos( $portalConfiguration , 'rememberPassword' );
	$endPos = strpos( $portalConfiguration , ';' , $startPos );
	$displayRememberPassword = strpos( substr($portalConfiguration,$startPos,$endPos - $startPos) , 'true' )?true:false;	
	
	if ( $_SERVER['REQUEST_METHOD'] == 'POST' )
	{	
		require_once('Portal/includes/loginProcess.php');
	}
	else 
	{		
		
		if ( $_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['logout']) )
		{		
			require_once('logout.php');
			exit();
		}
				
		if ( count($_SESSION) )
		{	// refresh		
			require_once('Portal/includes/loginProcess.php');
		}
		
		getHSPCookies( $defaultUsername , $defaultPassword, $defaultDirectory ,$rememberPassword );	
	}

	function getHSPCookies( &$username , &$password, &$directory , &$rememberPass )
	{
		if ( isset($_COOKIE['username']))
		{
			$username = $_COOKIE['username'];
		}
		else 
		{
			$username = '';
		}
		
		if ( isset($_COOKIE['password']))
		{
			$password = $_COOKIE['password'];
		}
		else 
		{
			$password = '';
		}
		
		if ( isset($_COOKIE['directories']))
		{
			$directory = $_COOKIE['directories'];
		}
		else 
		{
			$directory = '';
		}
		
		if ( isset($_COOKIE['rememberPassword']))
		{
			$rememberPass = $_COOKIE['rememberPassword'];
		}
		else 
		{
			$rememberPass = '';			
		}
	}

?>



<html>
<head>
<link rel="stylesheet" type="text/css" href="portal/style/default/hsp.css">
<script type="text/javascript" src="data/portalConfiguration.js"></script>
<script type="text/javascript" src="includes/js/keyHandlers.js"></script>
<script type="text/javascript" src="Portal/includes/js/cookies.js"></script>
<script type="text/javascript" src="Portal/includes/js/loginPage.js"></script>
<title>
<?PHP echo INDEX_TITLE;?>
</title>
</head>
<body>

<!-- HEADER - START -->
<?PHP
	@include_once('Portal/includes/html/header.php');
?>
<!-- HEADER - END -->

<!-- LOGIN FORM - START -->
<FORM action="mobileindex.php" method="POST" name="loginForm" id="loginForm">
	<TABLE>
 		<TR valign="top">
			<TD>
				<TABLE border="0" cellspacing="3" cellpadding="3" align="center">
					<?PHP
					 	echo '<tr><td colspan="2"><font color=red>'.$errorMsg.'</font></td></tr>';
					?>
                    <tr>
                    	<td colspan="2" align=center>
                    		<?PHP echo LOGIN_INSTRUCTIONS_LABEL;?>
                        </td>
                    </tr>
					<TR>
						<TD>
							<?PHP echo USERNAME_LABEL;?></td><td><input class="FixedWidthObjects" onkeypress="DoDefaultEnterKey(event)" size="15" maxlength="255" name="loginUsername" type="text" value="<?PHP echo stripslashes($defaultUsername);?>"/>
						</TD>
					</TR>
				 	<TR>
				 		<TD>
				 			<?PHP echo PASSWORD_LABEL;?>
				 		</TD>
				 		<TD>
				 			<input class="FixedWidthObjects" onkeypress="DoDefaultEnterKey(event)" size="15" maxlength="255" name="password" type="password" value="<?PHP echo stripslashes($defaultPassword);?>"/>
				 		</TD>
				 	</TR>
				 	<TR>
				 		<TD>
				 			<?PHP echo DIRECTORY_LABEL;?>
				 		</TD>
				 		<TD>
				 			<select name="directories" class="FixedWidthObjects" onkeypress="DoDefaultEnterKey(event)" value="<?PHP echo $defaultDirectory;?>">
				 			<?PHP
								@include_once('data/directoylist');
							?>
							</select>
						</TD>
					</TR>
                    <tr>
                    	<td colspan=2>
                        	<hr>
                        </td>
                    </tr>
                    <tr>
	            		<td colspan="2">
	            		<?php	            		
	            		if ( $displayRememberPassword )
	            		{
	            		?>	            			
	                		<input name='rememberPassword' onkeypress="DoDefaultEnterKey(event)" type="checkbox" <?php echo $rememberPassword; ?>><?php echo REMEMBER_PASSWORD_LBL;?></input>
                		<?php } ?>
	           			</td>
            		</tr>
				 	<TR>
				 		<td>
				 		</td>
					 	<TD>
					 		<INPUT  class="NewButton FixedWidthObjects" align=right name="submitLogon" value="<?PHP echo LOGIN_LABEL_BTN;?>" type="submit" />
					 	</TD>
				 	</TR>
				</TABLE>
			</TD>
		</TR>
	</TABLE>
	<!-- -------------------- Change Password Popup -------------------------- -->
<?php
require_once('Portal/includes/changePassPopup.php');
?>	

<input name="buttonClicked" type="hidden" />

<!-- // used by portal\includes\js\login.js -->
<input name="password_req_msg" type="hidden" value='<?PHP echo PASSWORD_REQ_MSG; ?>' />
<input name="passwordMatch_req_msg" type="hidden" value='<?PHP echo PASSWOR_DO_NOT_MATCH ?>'/>
<input name="wrong_password_msg" type="hidden" value='<?PHP echo WRONG_PASSWORD ?>'/>

</FORM>
	<!-- -------------------- Change Password Popup -------------------------- -->
	
<!-- LOGIN FORM - END -->
<!-- FOOTER - START -->
<!-- FOOTER - END -->
</body>
</html>
<script language="javascript" for="window" event="onload">
// from loginPage.js
loginOnload(<?php echo $invokeChangePasswordPopup;?>);
</script>