<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created:     Mars 2004

  Title: treeAssoicationTbl.php
  Purpose: Controlling all DB connectivity for the treeAssoication module.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('admin/modules/applicationsTree/includes/applicationsTreeTbl.php');
 
class anonymousTbl extends applicationsTreeTbl 
{
	
	function anonymousTbl($peardb)	
	{
		parent::applicationsTreeTbl($peardb);
	}

	function insertToGatUat($id, $name, $nodeList, $type)
	{
		$fields_values = array(	'id' => $id,
								'name' => $name,
								'nodeList' => $nodeList,
								'type_entity' => $type,
								);
		
		return $this->m_pearDB->AutoExecute(TABLE_GAT_UAT, $fields_values);
	}
	
	function updateUserStyle( $uid , $style )
	{
		$fields_values = array( 'style'  => $style );
		return $this->m_pearDB->AutoExecute(TABLE_USERS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$uid.';');
	}
	
	function updateGroupStyle( $gid , $style )
	{
		$fields_values = array( 'style'  => $style );
		return $this->m_pearDB->AutoExecute(TABLE_GROUPS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$gid . ';');
	}
	
	function getStyle( $id , $isGroup = false)
	{
		$sql = null;
		if ( $isGroup )
		{
			$sql = "SELECT style FROM ".TABLE_GROUPS." WHERE id=$id;";
		}
		else
		{
			$sql = "SELECT style FROM ".TABLE_USERS." WHERE id=$id;";
		}
		
		$this->m_pearDB->getOne( $sql , $style );
		return $style;
	}
}
?>