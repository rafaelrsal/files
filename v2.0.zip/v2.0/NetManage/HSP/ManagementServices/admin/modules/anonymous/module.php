<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: module.php
  Purpose: anonymous module - association the HSP applications to a user anonymous
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
?>

<script language="JavaScript" type="text/javascript">
<!--
<?php include ("includes/LMenu/libjs/layersmenu-browser_detection.js"); ?>
// -->
</script>
<script language="JavaScript" type="text/javascript" src="includes/LMenu/libjs/layerstreemenu-cookies.js"></script>

<?PHP
require_once('HTML/QuickForm.php');

include_once ("includes/LMenu/lib/PHPLIB.php");
include_once ("includes/LMenu/lib/layersmenu-common.inc.php");
include_once ("includes/LMenu/lib/treemenu.inc.php");
require_once ("includes/classes/LMenu.php");

require_once('admin/modules/anonymous/includes/anonymousTbl.php');
require_once('includes/classes/xmlWrapper.php');

define('SESSION_SET_USER_PARAMETERS_DETAILS', 'setUserParametersDetails');
define('SESSION_ENABLE_ANON', 'enable_anon');
define('SESSION_STYLE_ANON', 'style_anon');

class anonymous extends ModuleBase
{
	var $m_entityID;
	var $m_entityName;
	var $m_selectedNode;
	var $m_arrSelectedNodesList;
	var $m_treeView;
	var $m_anonStatus;
	var $m_wrapper;
	var $m_style;
	
	function anonymous($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$db  = &parent::GetDatabase();
		$this->m_treeAnonTbl = new anonymousTbl($db);
		
		$this->m_session->remove(SESSION_MESSAGES);
	}
	
	function init()
	{
		parent::init("anonymous");

		$this->m_selectedNode = 0;
		$this->m_arrSelectedNodesList = null;
		
		$this->m_entityID = 1; // Anonymous is always the first user in the list
		$this->m_entityName = "anonymous";

		// for print preview. see print.php
		$_SESSION['print_preview_header'] = "Anonymous";

		$this->m_wrapper = new xmlWrapper();
		$this->m_wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME);
		
		$this->m_anonStatus = $this->m_session->value(SESSION_ANONYMOUS_STATUS);
		if(false == $this->m_anonStatus)
		{
			$this->m_anonStatus = $this->getAnonymousStatus();
		}

		$this->m_style = $this->m_session->value(SESSION_STYLE_ANON);
		if(false == $this->m_style)
		{
			$this->m_style = $this->m_treeAnonTbl->getStyle($this->m_entityID);
		}
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm("anonymousForm"); //default is post
		
		$this->m_form->addElement('text', 'name',  ANON_NAME_LBL, array('size' => 20, 'maxlength' => 255));
		$this->m_form->addElement('text', 'icon', ANON_ICON_LBL);
		$this->m_form->addElement('text', 'description', ANON_DESC_LBL);
		$this->m_form->addElement('text', 'apptype', ANON_APP_TYPE_LBL);
		$this->m_form->addElement('text', 'platform', ANON_PLATFORM_LBL);
		
		$this->m_form->addElement('header', 'header', ANON_TBL_HEADER);
		$this->m_form->addElement('text', 'header2',ANON_HEADER_DETAILS_TXT);
		$this->m_form->addElement('submit', 'save', ANON_SAVE_BTN,"class='NewButton'");
		$this->m_form->addElement('button', 'preview', ANON_PREVIEW_BTN,"onclick=loadApplicationTreePreview() class='NewButton'");
		$this->m_form->addElement('button', 'setparam', ANON_SETPARAM_BTN,"onclick=onSetParam(); class='NewButton' style=width:120px");
		$this->m_form->addElement('select', 'style', ANON_USER_STYLE_LBL,$this->getStyleList(), "onchange=isChanged=true");
		$this->m_form->addElement('hidden', 'button_pressed', 'none');
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);

		// Present the data of a node as read only:
		$temp = &$this->m_form->getElement("name");
		$temp->freeze();
		$temp = &$this->m_form->getElement("icon");
		$temp->freeze();
		$temp = &$this->m_form->getElement("description");
		$temp->freeze();
		$temp = &$this->m_form->getElement("apptype");
		$temp->freeze();
		$temp = &$this->m_form->getElement("platform");
		$temp->freeze();
	}
	
	function process()
	{
		$anon_status_string = "";
		$bNodeUnmarked = false;

		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$selectElement = &$this->m_form->getElement("style");

			if (isset($_GET['prev']) && 'setparam' == $_GET['prev'])
			{
				// Coming back from setPramters module - we have all data we need from last time:
				$this->m_arrSelectedNodesList = $this->m_session->value(SESSION_SELECTED_NODES_LIST);
				$anon_status_string = $this->m_session->value(SESSION_ENABLE_ANON);
				$this->m_style = $this->m_session->value(SESSION_STYLE_ANON);
				// Don't need that any more:
				$this->m_session->remove(SESSION_ENABLE_ANON);	
			}
			else 
			{
				if(isset($_GET['nodeID']))
				{
					$this->m_selectedNode = $_GET['nodeID'];
					$this->m_arrSelectedNodesList = $this->m_session->value(SESSION_SELECTED_NODES_LIST);
					if((is_array($this->m_arrSelectedNodesList)) && 
										(in_array($this->m_selectedNode, $this->m_arrSelectedNodesList)))
					{
						// If the selected node already appears in the list it means it 
						// actually needs to be dis-selected. Thus we later on don't present it's
						// details:
						$bNodeUnmarked = true;
					}
					
					// User marked a node thus changed the gat/uat:
					$isUpdated = "true";
					$this->m_session->set(SESSION_PAGECHANGED, $isUpdated);	
	
					if(isset($_GET['checked']) && ("true" == $_GET['checked']))
					{
						$anon_status_string = "CHECKED";
					}
	
					if(isset($_GET['treeIndex']))
					{
						$treeIndex = $_GET['treeIndex'];
						$this->m_session->set(SESSION_NODE_TREE_POSITION, $treeIndex);
					}
				}
				else
				{
					$this->m_session->remove(SESSION_SELECTED_NODES_LIST);	
					$this->m_session->remove(SESSION_NODE_TREE_POSITION);
					$this->m_session->remove(SESSION_PAGECHANGED);
					$this->m_session->remove(SESSION_ENABLE_ANON);		
					
					// Get the user subtree nodes, and update the $this->m_arrSelectedNodesList,
					// so it can be presented on the HAT itself.
					$res = $this->GetExistingTree();
					if(HSP_SUCCESS != $res)
					{
						$errorCode = array($res);
						$this->m_session->set(SESSION_ERRORS, $errorCode);
					}
					if("enabled" == $this->m_anonStatus)
					{
						// Anonymous is enabled. Make the check box checked (a little confusing but correct)
						$anon_status_string = "CHECKED";
					}
				}
			}

			$selectElement->setSelected($this->m_style);
		}
		else
		{
			/////////// POST //////////////
			if(isset($_POST['button_pressed']) && 'setparam' ==  $_POST['button_pressed'])
			{
				$this->onSetParam();
			}
			///////////  SAVE /////////////////////////////
			if(isset($_POST['save']) )
			{
				$res = $this->onSave();
				if(HSP_SUCCESS != $res)
				{
					$errorCode = array($res);
					$this->m_session->set(SESSION_ERRORS, $errorCode);
				}
				else
				{
					// Saving succeeded - remove the 'updated' flaf:
					$this->m_session->remove(SESSION_PAGECHANGED);	
					// Cria evento no log
					parent::CriaLog(ANON_SAVE_BTN);
				}
			}
		}
		
		$this->m_form->removeElement('enable_anon');
		$this->m_form->addElement('checkbox', 'enable_anon', ANON_ENABLE_LBL, "",$anon_status_string." onclick=isChanged=true");
		
		if((0 != intval($this->m_selectedNode)) && (false == $bNodeUnmarked))
		{
			$res = $this->getNodeData($this->m_selectedNode);
		}
	}
	
	function finalize()
	{
		$arrVars = array();

		// Build the menu:
		$treeViewMenu = new TreeMenu();
		$treeViewMenu->setImgwww("includes/LMenu/images/"); // allowing different icons.
		$treeViewMenu->setImgdir("includes/LMenu/images/");
		$treeViewMenu->setLibjsdir("includes/LMenu/libjs/");
		$db = $this->m_treeAnonTbl->getDB(); 
		$treeViewMenu->setDBConnParms($db->getDSNasString());
		$treeViewMenu->setTableName(TABLE_TREE);
		
		if(0 != $this->m_selectedNode)
		{
			if(is_array($this->m_arrSelectedNodesList))
			{
				// Search the already selected nodes. If new node ID already exists it
				// must be removed from the list. Else, inserted to the list and presented
				// as selected as a result.
				if(false === ($key = array_search($this->m_selectedNode, $this->m_arrSelectedNodesList)))
				{
					array_push($this->m_arrSelectedNodesList, $this->m_selectedNode);
				}
				else
				{
					unset($this->m_arrSelectedNodesList[$key]);
				}
			}
			else
			{
				// The first selected node:
				$this->m_arrSelectedNodesList = array();
				array_push($this->m_arrSelectedNodesList, $this->m_selectedNode);
			}
		}
				
		$isUpdated = $this->m_session->value(SESSION_PAGECHANGED);
		if("" == $isUpdated)
		{
			$isUpdated = "false";
		}

		$arrVars["setupdated"] = $isUpdated;		
		
		if( is_array($this->m_arrSelectedNodesList) && count($this->m_arrSelectedNodesList) )
		{
			$arrVars['bPreview'] = 1;
			// Create a temp file that will hold the GAT/UAT and present it
			$res = $this->prepareSubTreeFile($this->m_arrSelectedNodesList);
			if(HSP_SUCCESS != $res)
			{
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);
			}
		}
		else
		{
			//disable the print preview button
			$arrVars['bPreview'] = 0;
		}		

		$arrVars['strMesg'] = ANON_CHANGES;
			
		// Let the tree menu build the tree and mark the selected paths:
		$treeViewMenu->scanTableForMenu("HSPTree1", "" , "", $this->m_arrSelectedNodesList);
		
		if(is_array($this->m_arrSelectedNodesList))
		{	// keep the list of selected nodes:
			$this->m_session->set(SESSION_SELECTED_NODES_LIST, $this->m_arrSelectedNodesList);
		}
		
		$arrVars['appsTree'] = $treeViewMenu->newTreeMenu("HSPTree1");
		
		$treeNodePosition = $this->m_session->value(SESSION_NODE_TREE_POSITION);
		$arrVars["treeIndex"] = $treeNodePosition;
		$arrVars["roll"] = $_SESSION['roll'];
		parent::finalize($arrVars);
	}
	
	function onSave()
	{
		$res = HSP_SUCCESS;
		$emptyTree = true;
		
		$this->m_arrSelectedNodesList = $this->m_session->value(SESSION_SELECTED_NODES_LIST);
		
		if(is_array($this->m_arrSelectedNodesList) && count($this->m_arrSelectedNodesList))
		{
			$emptyTree = false;
			
			// First remove the old tree:
			$res = $this->m_treeAnonTbl->removeGatUat($this->m_entityID, $this->m_entityName);
			if(HSP_SUCCESS == $res)
			{
				// udi zisser, add style to user table
				if ( isset($_POST['style']) )
				{
					$styleName = htmlspecialchars($_POST['style']);
					$res = $this->m_treeAnonTbl->updateUserStyle( $this->m_entityID , $styleName);
				}
				
				// Transform array to string:
				$nodeList = implode(",", $this->m_arrSelectedNodesList);
			
				$res = $this->m_treeAnonTbl->insertToGatUat($this->m_entityID, $this->m_entityName, $nodeList, "user");
			}
		}

		if(isset($_POST['enable_anon']) && ("1" == $_POST['enable_anon']))
		{
			if(false == $emptyTree)
			{
				// The checkbox is checked,
				// See if it is different from the config status:
				if("disabled" == $this->m_anonStatus)
				{
					// Change the status in the config.xml and session paramter:
					$res = $this->setAnonymousSatatus("enabled", "CHECKED");
				}
				// Else do nothing, the status of the checkbox wasn't changed.
			}
			else
			{
				if("disabled" == $this->m_anonStatus)
				{
					// The user changed something on the page:
					$isUpdated = "true";
					$this->m_session->set(SESSION_PAGECHANGED, $isUpdated);	
				}

				// Trying to save anonymous enabled when actually there is no node selected - forbidden:
				$res = HSP_ERR_MISSING_NODE_SELECTION;
			}
		}
		else
		{
			if(true == $emptyTree)
			{
				// The user is disabling with no node selection - OK, remove the old uat:
				$res = $this->m_treeAnonTbl->removeGatUat($this->m_entityID, $this->m_entityName);
			}
			// The checkbox is not checked -- (in HTML unchecked box is not submitted)
			// See if it is different from the config status:
			if("enabled" == $this->m_anonStatus)
			{
				// Change the status in the config.xml and session paramter:
				$res = $this->setAnonymousSatatus("disabled");
			}
			// Else do nothing, the status of the checkbox wasn't changed.
		}
		
		if(isset($_POST['style']))
		{
			
			if($this->m_style != $_POST['style'])
			{
				// The style was changed but not saved:
				$isUpdated = "true";				
				$this->m_session->set(SESSION_PAGECHANGED, $isUpdated);	
			}
		}

		return $res;
	}
	
	function onSetParam()
	{
		// Set the genaral details:
		$itemDetails = array( 'name'=>'Anonymous', 'id'=>1, 'dirID'=>0);
		$this->m_session->set(SESSION_SET_USER_PARAMETERS_DETAILS, $itemDetails);
		
		// Save the disable/enable checkbox:
		$isUpdated = $this->m_session->value(SESSION_PAGECHANGED);
		if(isset($_POST['enable_anon']) && ("1" == $_POST['enable_anon']))
		{
			if("disabled" == $this->m_anonStatus)
			{
				// The state was changed but not saved:
				$isUpdated = "true";
			}
			$this->m_session->set(SESSION_ENABLE_ANON, "CHECKED");
		}
		elseif("enabled" == $this->m_anonStatus)
		{
			// The state was changed but not saved:
			$isUpdated = "true";
		}
		
		// Save the style:
		if(isset($_POST['style']))
		{
			
			if($this->m_style != $_POST['style'])
			{
				// The style was changed but not saved:
				$isUpdated = "true";
			}
			$this->m_session->set(SESSION_STYLE_ANON, $_POST['style']);
		}

		
		$this->m_session->set(SESSION_PAGECHANGED, $isUpdated);	
		
		Header('Location: admin.php?module=userParameters&roll='.$_POST['roll']);
		exit();
	}
	
	/**
	* The method to get the a selected node data from the database
	* @param int $nodeID the id of the selected node
	* @access public
	* @return void
	*/
	function getNodeData($nodeID)
	{
		$arrTreeRes = null;

		// Get the id of the application:
		$res = $this->m_treeAnonTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);

		$icon = $arrTreeRes[7];

		// If the icon file is the application default, there is no need to show it explicitly:
		if((W2H_ICON == $icon) || (ONWEB_ICON == $icon) || (LINK_ICON == $icon) || (PROTECTED_LINK_ICON == $icon))// do the same check for each application type
		{
			$icon = "default";
		}


		if(HSP_SUCCESS == $res)
		{
			if((null == $arrTreeRes[3]) || ("" == $arrTreeRes[3]))
			{
				$arrTreeRes[3] = ANON_APP_TYPE_TXT;
			}
			elseif ( $arrTreeRes[3] == 'w2h')
			{
				$arrTreeRes[3] = ANON_W2H_TXT;
			}
			elseif ( $arrTreeRes[3] == 'onWeb')
			{
				$arrTreeRes[3] = ANON_ONWEB_TXT;
			}
			elseif ( $arrTreeRes[3] == 'url')
			{
				// Check if this is a protected url
				$res = $this->m_treeAnonTbl->GetRowForField(TABLE_APPS_LINKS, 'appID', $arrTreeRes[2], $arrAppRes);
				if(HSP_SUCCESS == $res)
				{
					if("0" == $arrAppRes[2])
					{
						// usuall link
						$arrTreeRes[3] = ANON_LINK_TXT;
					}
					else
					{
						// protected:
						$arrTreeRes[3] = ANON_PROTECTED_LINK_TXT;
					}
				}
				else
				{
					return $res;
				}
			}
			
			$platform = $arrTreeRes[13]?ANON_MOBILE_LBL:ANON_DESKTOP_LBL;		
			
			$arrTreeRes[4] = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $arrTreeRes[4]);
			$arrTreeRes[6] = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $arrTreeRes[6]);
			$this->m_form->setDefaults(array(	'name'			=>$arrTreeRes[4],
												'icon'			=>$icon,
												'description'	=>$arrTreeRes[6],
												'apptype'		=>$arrTreeRes[3],
												'platform'		=>$platform));
			return $res;

		}

		$errorCode = array($res);
		$this->m_session->set(SESSION_ERRORS, $errorCode);

		return $res;
	}

	function prepareSubTreeFile($nodeList = null)
 	{
 		include_once("includes/LMenu/lib/layersmenu-process.inc.php");
 		$this->m_treeView = new ProcessLayersMenu();
 		$db = $this->m_treeAnonTbl->getDB();
 		$this->m_treeView->setDBConnParms($db->getDSNasString());
 		$this->m_treeView->setTableName(TABLE_TREE);
			
		if((is_null($nodeList)) || (!is_array($nodeList)))
		{
			// Running preview from Application Tree. The user wants to see
			// the whole tree, so the selected node is 2 (the ID of the top level node):
			$nodeList = array("2");
		}

		// Scan table will take care that the href of each node points to nothing:
		$this->m_treeView->scanTableForMenu("stam1","","previewNoTop", $nodeList);
		$strFile = $this->m_treeView->getMenuStructure("stam1");

		// This file is used for testing preview purposes only:
		$fileName = "tree.preview";

		// Save file:
		$path = "data/apptrees/"; // TODO: the path should be a general define.

		if(file_exists($path.$fileName))
		{
			// Avoid php warnings:
			if(is_writable($path.$fileName) == false)
				return 	HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
		}

		// Running over the old file whether exists or not:
		$handle = @fopen($path.$fileName, "w");
		if($handle)
		{
			$res = fwrite($handle, $strFile);
			fclose($handle);
			if(false === $res)
			{
				return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
			}
			return HSP_SUCCESS;

		}

		return 	HSP_ERR_FILE_NOT_FOUND;
 	}
	function GetExistingTree()
	{
		$res = HSP_ERR_DB_ERROR;
		$arrRes = null;
		
		// Get the user data:
		$arrRes = $this->m_treeAnonTbl->GetAllEx("SELECT nodeList FROM ".TABLE_GAT_UAT." WHERE id=$this->m_entityID AND name=\"$this->m_entityName\";");
 		//$res = $this->m_treeAnonTbl->GetRowForField(	TABLE_hsp_gat_uat,"id", $this->m_entityID, $arrRes);
 		if(is_array($arrRes))
 		{
			$res = HSP_SUCCESS;
 			if(count($arrRes) > 0)
 			{
 				// Extract the nodeList string to an array:
 				$this->m_arrSelectedNodesList = explode(",", $arrRes[0][0]);
 			}
 		}

 		return $res;
 	}

 	function getStyleList()
 	{
 		$list = array();
 		$dirpath = PORTAL_STYLE_DIR;

 		$dh = opendir($dirpath);

   		while (false !== ($file = readdir($dh)))
   		{
			//Don't list subdirectories
   			if (is_dir("$dirpath/$file") && $file != '.' && $file != '..')
   			{
				//Truncate the file extension and capitalize the first letter
       			$list[$file] = $file;
			}
		}

		closedir($dh);
		
     	return $list;
 	}

	function getAnonymousStatus()
	{
		// Get anonymous status from the config.xml:
		$anonStatus = $this->m_wrapper->getAnonymousStatus();
			
		// Set session param:
		$this->m_session->set(SESSION_ANONYMOUS_STATUS, $anonStatus);
			
		return $anonStatus;
	}
	
	function setAnonymousSatatus($status, $checked="")
	{
		// Update config.xml
		$this->m_wrapper->setAnonymousStatus($status);
		
		// Update session:
		$this->m_session->set(SESSION_ANONYMOUS_STATUS, $status);
		
		// Update the UI:
		$this->m_form->removeElement("enable_anon");		
		$this->m_form->addElement('checkbox', 'enable_anon', ANON_ENABLE_LBL, "",$checked);
		
		return $this->m_wrapper->serialize(CONFIG_XML_PATH . CONFIG_XML_NAME);
	} 	
}
?>