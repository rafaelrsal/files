<?PHP
define('ANON_USER_STYLE_LBL','Choose template style:');
define('ANON_NAME_LBL','Node name:');
define('ANON_ICON_LBL','Icon file:');
define('ANON_DESC_LBL','Description:');
define('ANON_APP_TYPE_LBL','Application type:');
define('ANON_PREVIEW_BTN','Preview');
define('ANON_SAVE_BTN','Save');
define('ANON_EMPTY_APP_TYPE_TXT','None');
define('ANON_CHANGES','There are unsaved changes on this page. OK to ignore changes?');
define('ANON_HEADER_DETAILS_TXT','Details');
define('ANON_APP_TYPE_TXT','None');
define('ANON_W2H_TXT','OnWeb Web-to-Host');
define('ANON_ONWEB_TXT','OnWeb application');
define('ANON_LINK_TXT','URL');
define('ANON_PROTECTED_LINK_TXT','URL, protected');
define('ANON_TBL_HEADER','Applications for Anonymous User');
define('ANON_ENABLE_LBL','Enable Anonymous User');
define('ANON_SETPARAM_BTN','Set Parameters...');
define('ANON_PLATFORM_LBL','Platform:');
define('ANON_MOBILE_LBL','Mobile');
define('ANON_DESKTOP_LBL','Desktop');
?>