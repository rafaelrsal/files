<?PHP
define('ANON_USER_STYLE_LBL','Selecione o Estilo do Template:');
define('ANON_NAME_LBL','Nome do N�:');
define('ANON_ICON_LBL','Arquivo de �cone:');
define('ANON_DESC_LBL','Descri��o:');
define('ANON_APP_TYPE_LBL','Tipo de Aplica��o:');
define('ANON_PREVIEW_BTN','Preview');
define('ANON_SAVE_BTN','Salvar');
define('ANON_EMPTY_APP_TYPE_TXT','Nenhum');
define('ANON_CHANGES','Existem altera��es n�o salvas nesta p�gina. OK para ignorar as altera��es?');
define('ANON_HEADER_DETAILS_TXT','Detalhes');
define('ANON_APP_TYPE_TXT','Nenhum');
define('ANON_W2H_TXT','OnWeb Web-to-Host');
define('ANON_ONWEB_TXT','Aplica��o OnWeb');
define('ANON_LINK_TXT','URL');
define('ANON_PROTECTED_LINK_TXT','URL Protegida');
define('ANON_TBL_HEADER','Aplica��es para o Usu�rio An�nimo');
define('ANON_ENABLE_LBL','Habilitar Usu�rio An�nimo');
define('ANON_SETPARAM_BTN','Configura��es...');
define('ANON_PLATFORM_LBL','Plataforma:');
define('ANON_MOBILE_LBL','Mobile');
define('ANON_DESKTOP_LBL','Desktop');
?>