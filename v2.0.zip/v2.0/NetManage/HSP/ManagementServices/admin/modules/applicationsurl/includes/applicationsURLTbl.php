<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     May 2004

  Title:            applicationsURLTbl.php
  Purpose:          Controlling all DB connectivity for the applicationsURL module.
  Limitations:		Requires PHP 4+

 ============================================================================*/
require_once('admin/modules/applicationsData/includes/applicationsDataTbl.php');

class applicationsURLTbl extends applicationsDataTbl 
{
	
	function applicationsURLTbl($peardb)	
	{
		parent::applicationsDataTbl($peardb);
	}

	function insertToAppList($url,$protected, $mobileApplication, $parameterized)
	{
		$fields_values = array('url'=>$url,"protected"=>$protected, "mobileApp"=>$mobileApplication, "parameterized"=>$parameterized);

		return  $this->m_pearDB->AutoExecute(TABLE_APPS_LINKS, $fields_values);									
	}

	function updateAppList($appID, $url,$protected, $mobileApplication, $parameterized)
	{
		$fields_values = array(	'url'=>$url,"protected"=>$protected, "mobileApp"=>$mobileApplication, "parameterized" =>$parameterized);
				
		return $this->m_pearDB->AutoExecute(TABLE_APPS_LINKS , $fields_values, DB_AUTOQUERY_UPDATE,'appID="'.$appID.'";');				
	}
	
}
?>