<?PHP
define('APPSURL_MAIN_TXT','HSP - URL ');
define('APPSURL_URL_TXT','URL: ');
define('APPSURL_PROTECTED_URL_TXT','Executar como uma URL protegida');
define('APPSURL_MOBILE_APPLICATION_INSTALL_TXT','Aplica��es Mobile instal�veis');
define('APPSURL_VERIFY_URL_TXT','Verificar URL');
define('APPSURL_BACK_BTN','< Voltar');
define('APPSURL_FINISH_BTN','Salvar');
define('APPSURL_CANCEL_BTN','Cancelar');
define('APPSURL_HELP_LNK','Ajuda');
define('APPSURL_REQUIRED_TXT','Verificar campos obrigat�rios');
define('APPSURL_URL_REQ_MSG','Informe a URL.');
define('APPSURL_URL_PARM_NOVALIDATION','Se voc� est� tentando salvar a URL com par�metros de usu�rio customizados, ent�o desabilite a op��o \'Verificar URL\'.');
?>