<?PHP
define('APPSURL_MAIN_TXT','HSP URL - ');
define('APPSURL_URL_TXT','URL: ');
define('APPSURL_PROTECTED_URL_TXT','Run as protected URL');
define('APPSURL_MOBILE_APPLICATION_INSTALL_TXT','Installable mobile application');
define('APPSURL_VERIFY_URL_TXT','Verify URL');
define('APPSURL_BACK_BTN','< Back');
define('APPSURL_FINISH_BTN','Save');
define('APPSURL_CANCEL_BTN','Cancel');
define('APPSURL_HELP_LNK','Help');
define('APPSURL_REQUIRED_TXT','denotes required field');
define('APPSURL_URL_REQ_MSG','Enter a URL.');
define('APPSURL_URL_PARM_NOVALIDATION','If you are trying to save a URL with custom user parameters, uncheck the \'Verify URL\' checkbox.');
?>