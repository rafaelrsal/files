<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser

  Date Created:     Mars 2004

  Title:            applicationsURL.php
  Purpose:          ApplicationsURL module - building the HSP tree of applications.
  Limitations:		Requires PHP 4+

 ============================================================================*/
?>

<?PHP
require_once('HTML/QuickForm.php');
require_once('admin/modules/applicationsURL/includes/applicationsURLTbl.php');

class applicationsURL extends ModuleBase
{
	var $m_appURLTbl;
	var $m_requestMode;
	var $m_protectedUrl;
	var $m_mobileApplication;
	var $m_verifyUrl;
	var $m_isupdated;
	
	function applicationsURL($globalobjects)
	{
		parent::ModuleBase($globalobjects);		
		
		$db  = &parent::GetDatabase();
		$this->m_appURLTbl = new applicationsURLTbl($db);
		$this->m_protectedUrl = false;
		$this->m_mobileApplication = false;
		$this->m_verifyUrl = true;
	}


	// Initialize the form which is the skeleton of the page:
	function init()
	{
		parent::init("applicationsURL");
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('appsURLForm','post','','','onsubmit="onSave();return false;"'); //default is post

		$this->m_form->addElement('text', 'url',  APPSURL_URL_TXT, array('size' => 40,'maxlength' => 255, 'onchange' => "updated();"));
		$this->m_form->addElement('button', 'back', APPSURL_BACK_BTN,"onclick=onReturn('back') class='NewButton'");
		$this->m_form->addElement('button', 'cancel', APPSURL_CANCEL_BTN,"onclick=onReturn('cancel') class='NewButton'");
		$this->m_form->addElement('submit', 'finish', APPSURL_FINISH_BTN,"onclick='onSave();return false;' class='NewButton'");
		$this->m_form->addElement('hidden', 'button_clicked', "none");
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);

		$this->m_form->applyFilter('url', 'trim');

		$this->m_form->setRequiredNote(APPSURL_REQUIRED_TXT);
	}
	
	// Process the submition requests:
	function process()
	{
		$res = HSP_SUCCESS;
		$arrRes = null;
		$this->m_isupdated = "false";
		
		$this->m_requestMode = 	$this->m_session->value(SESSION_NEW_NODE);

		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$this->m_form->setDefaults(array("url" => "http://"));
			
			if(("edit" == $this->m_requestMode) &&
				("url" == $this->m_session->value(SESSION_NODE_PREV_APPTYPE)))
			{
				// Get the url from the data base:
				$nodeID = $this->m_session->value(SESSION_NODE_ID);
				$res = $this->m_appURLTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);
				
				// Make sure we are editing the same application type:
				if((HSP_SUCCESS == $res) && ("url" == $arrTreeRes[3]))
				{
					$res = $this->m_appURLTbl->GetRowForField(TABLE_APPS_LINKS, 'appID', $arrTreeRes[2], $arrAppRes);
					if(HSP_SUCCESS == $res)
					{
						$url = rawurldecode($arrAppRes[1]);
						$this->m_form->setDefaults(array("url" => $url));
						
						if ( $arrAppRes[2] == '1' )
						{
							$this->m_protectedUrl = true;
						}
						if ( $arrAppRes[4] == '1' )
						{
							$this->m_mobileApplication = true;
						}
					}
				}
			}
		}

		if((isset($_POST['button_clicked'])) && ("back" == $_POST['button_clicked']))
		{
			// Go back to 'applicationsData' page:
			// Update the app type:
			$url = 'url';
			$this->m_session->set(SESSION_NODE_APPTYPE, $url);
			// Let the next screen know who called it:
			$module = 'applicationsURL';
			$this->m_session->set(SESSION_PREV_MODULE, $module);
			Header('Location: admin.php?module=applicationsData&roll='.$_POST['roll']);
			exit();
		}

		if((isset($_POST['button_clicked'])) && ("cancel" == $_POST['button_clicked']))
		{
			// Go back to 'applicationsTree' page:

			$module = 'applicationsURL';
			$this->m_session->set(SESSION_PREV_MODULE, $module);
			Header('Location: admin.php?module=applicationsTree&roll='.$_POST['roll']);
			exit();
		}

		if((isset($_POST['button_clicked'])) && ("finish" == $_POST['button_clicked']))
		{
			$finish = "";
			$bHTTP = false;
			$this->m_isupdated = "true";

			$arrParms = array();

			// Get all the POST and SESSION values:
			$url = $this->m_form->exportValue('url');

			// Find out if that's https -- we can't handle it now:
			if(false === stristr($url, "https:"))
			{
				$bHTTP = true;
			}		

			// Get verify url status:
			if (false == isset($_POST['verifyUrl']))
			{
				// No need to verify url:
				$this->m_verifyUrl = false;
			}

			// get protected url settings.
			$this->m_protectedUrl = false;		
			if (isset($_POST['protectedUrl']) && 'on' == $_POST['protectedUrl'])
			{
				$this->m_protectedUrl = true;
			}

			$this->m_mobileApplication = false;		
			if (isset($_POST['mobileApplication']) && 'on' == $_POST['mobileApplication'])
			{
				$this->m_mobileApplication = true;
			}
			
			if(true === $bHTTP)
			{
				// Encode URL string in order to run it easily on portal side:
				$this->linkencode($url);
				
				if( true == $this->m_verifyUrl)
				{
					// Check to see if the server URL is valid:
					$res = $this->testURL($url);
				}
			}
			else 
			{
				// https - cannot validate and protect
				if(($this->m_protectedUrl) || ($this->m_verifyUrl))
				{
					$res = HSP_ERR_HTTPS_ABNORMALITY;
				}
			}
			if(HSP_SUCCESS == $res)
			{
				$parameterized = 0;
				$name = $this->m_session->value(SESSION_NODE_NAME);
				$description = $this->m_session->value(SESSION_NODE_DESC);
				$icon = $this->m_session->value(SESSION_NODE_ICON);
				$appWindow = $this->m_session->value(SESSION_APP_BEHAVIOR);
				$appMobileGeneral = $this->m_session->value(SESSION_APP_MOBILE);
								
				if(($icon == null) || ($icon == "default"))
				{
					if(true == $this->m_protectedUrl)
					{
						$icon = PROTECTED_LINK_ICON;
					}
					else
					{
						$icon = LINK_ICON;
					}
				}
				
				if(strstr($url, '<hsp_') && strchr($url, '>')) //TODO:: improve check?? 
				{
					// This is probably a paramterized URL:
					$parameterized = 1;
				}
				
				if('edit' == $this->m_requestMode)
					$res = $this->updateNode(	$name, 
												$icon, 
												$description, 
												$url,
												$appWindow,
												$appMobileGeneral,
												$this->m_protectedUrl,
												$this->m_mobileApplication,
												$parameterized);
				else
				{
					$res = $this->saveNode(	$name, 
											$icon, 
											$description, 
											$url, 
											$this->m_appURLTbl, 
											$this->m_session->value(SESSION_NODE_ID),
											true,
											$appWindow,
											$appMobileGeneral,
											$this->m_protectedUrl,
											$this->m_mobileApplication,
											$parameterized);
					$finish = "&clicked=finish";
				}
				if(HSP_SUCCESS == $res)
				{
					// Let the next screen know who called it:
					$module = 'applicationsURL';
					$this->m_session->set(SESSION_PREV_MODULE, $module);
					parent::CriaLog($this->m_requestMode ."_". trim(APPSURL_FINISH_BTN));
					Header("Location: admin.php?module=applicationsTree$finish&roll=".$_POST['roll']);
					exit();
				}
			}
		}

		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}

	}
	
	// Build the page and send it to display:
	function finalize()
	{
		
		$nodeName = $this->m_session->value(SESSION_NODE_NAME);
		if ( $this->m_session->value(SESSION_APP_MOBILE) == 1 )
		{
			$mobileDisabledState = 'false';
		}
		else 
		{
			$mobileDisabledState = 'true';
		}
		
		$verifyUrlState = $this->m_verifyUrl?'checked':0;
		$protectedUrlState = $this->m_protectedUrl?'checked':0;
		$mobileApplication = $this->m_mobileApplication?'checked':0; // installable app
		$generalMobile = $this->m_session->value(SESSION_APP_MOBILE)?'true':'false';
		
		$arrVars = array(	"strNodeName"=>$nodeName,
							"isupdated"=>$this->m_isupdated,
							"verifyUrlState"=>$verifyUrlState,
							"verifyUrlLbl"=>APPSURL_VERIFY_URL_TXT,
							"protectedUrlState"=>$protectedUrlState,
							"protectedUrlLbl"=>APPSURL_PROTECTED_URL_TXT,
							"mobileApplicationState"=>$mobileApplication,
							"mobileApplicationLbl"=>APPSURL_MOBILE_APPLICATION_INSTALL_TXT,
        					"enterURL" =>APPSURL_URL_REQ_MSG,
        					"noValidation" =>APPSURL_URL_PARM_NOVALIDATION,
        					"appsURLForm_required_note" => APPSURL_REQUIRED_TXT,
        					"mobileDisabledState"=>$mobileDisabledState,
        					"mobileGeneral"=>$generalMobile
        					);
		parent::finalize($arrVars);
	}

	function saveNode($name, $icon, $description, $url, $db, & $parentID, $insideCall, $appWindow, $appMobileGeneral, $protected=false, $mobileApplication=false, $parameterized=0 )
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$arrRes = null;

		if(false == $insideCall)
		{
			// Called from outside:
			$db = new applicationsURLTbl($db);
		}
		
		// First insert application data to application table in the DB:
		$res = $db->insertToAppList($url,$protected, $mobileApplication, $parameterized);
		if(HSP_SUCCESS == $res)
		{
			// Now enter the application as a node in the tree.

			// Get the application id (of the recentley application that was
			// inserted to the application table). This id is to be kept as a link
			// between the node and its application:
			$appID = 0;
			$res = $db->getMaxEntryID(TABLE_APPS_LINKS, 'appID',  $arrRes);
			if(HSP_SUCCESS == $res)
			{

				$appID = $arrRes[0];
				unset($arrRes);

				// Build the link of the new node
				if(HSP_SUCCESS == $res)
					{
					// Insert node below the selected node. Notice we send the application id also
					// (Later on we will get the real Node URL and update the Node entry
					// with the right url):
					$res = $db->insertToHSPTree($parentID, $appID, "url", $name, $icon, $description, $appWindow, $appMobileGeneral);
					if(HSP_SUCCESS == $res)
					{
						// Get the id of the recently entered node:
						$res = $db->getMaxEntryID(TABLE_TREE, 'id', $arrRes);
						// Update the url(==href) field of the recently inserted node in hsp_tree:
						$params = array("href" => "navigate($arrRes[0])");
						$res = $db->updateTree($arrRes[0], $params);
						
						if(HSP_SUCCESS == $res)
						{
							// Update the father the he has a new baby born: he is no longer a "leaf":
							$paramArr2 = array("status" => "1");
							$res = $db->updateTree( $parentID, $paramArr2 );
						}

						if(true == $insideCall)
						{
							// Update the node id:
							$this->m_session->set(SESSION_NODE_ID, $arrRes[0]);
						}
						else
						{
							// Update the parentID:
							$parentID = $arrRes[0];
						}
					}
					else
					{
						// Could not insert a new node to the tree, so we need to remove the application
						// entery that was inserted prior to this action:
						$db->remove(TABLE_APPS_LINKS, "appID", $appID);

					}
				}
			}

			if(true == $insideCall)
			{
				$this->m_session->remove(SESSION_NEW_NODE);
			}
		}

		return $res;
	}

	function updateNode($name,$icon,$description,$url,$appBehavior,$appMobileGeneral,$protected=false, $mobileApplication=false, $parameterized=0)
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$nodeID = $this->m_session->value(SESSION_NODE_ID);
		$appID = 0;

		$res = $this->m_appURLTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);
		if(HSP_SUCCESS == $res)
		{
			$appID = $arrTreeRes[2];

			// Check first if the previous application wasn't this one
			// e.g. it was a W2H session and now it was asked to be a link:
			$prevApp = $this->m_session->value(SESSION_NODE_PREV_APPTYPE);
			if('url' == $prevApp)
			{
				// The application type remained the same, just update the application list
				// and the tree:
				$res = $this->m_appURLTbl->updateAppList($appID, $url ,$protected, $mobileApplication, $parameterized);
				if(HSP_SUCCESS == $res)
				{
					$params = array("text"=>$name, "icon"=> $icon, "title"=>$description, "newWindow"=>$appBehavior,"mobile"=>$appMobileGeneral );
					$res = $this->m_appURLTbl->updateTree($nodeID, $params);
				}
			}
			else
			{
				if('onWeb' == $prevApp)
					// Remove the OnWeb application from it's list:
					$res = $this->m_appURLTbl->remove(TABLE_APPS_ONWEB, "appID", $appID);
				elseif('w2h' == $prevApp)
					// Remove the w2h application from it's list:
					$res = $this->m_appURLTbl->remove(TABLE_APPS_W2H, "appID", $appID);
				//elseif some other appplication

				if((HSP_SUCCESS == $res) || ('' == $prevApp /*previosly folder*/))
				{
					// Add the new application:
					$res = $this->addAppAndUpdateTree($nodeID, $name, $icon, $description, $url, $protected, $appBehavior, $appMobileGeneral, $mobileApplication, $parameterized);
				}
			}
		}

		return  $res;
	}

	function addAppAndUpdateTree($nodeID, $name, $icon, $description, $url, $protected, $appBehavior, $appMobileGeneral, $mobileApplication, $parameterized=0)
	{
		$res = $this->m_appURLTbl->insertToAppList($url, $protected, $mobileApplication, $parameterized);
		if(HSP_SUCCESS == $res)
		{
			// Get the appID of the recently inserted application:
			$res = $this->m_appURLTbl->getMaxEntryID(TABLE_APPS_LINKS, 'appID',  $arrRes);
			if(HSP_SUCCESS == $res)
			{
				// Update the node tree table with the new application:
				$params = array("appID"=>$arrRes[0], "application"=>"url", "text"=>$name, "icon"=> $icon, "title"=>$description, "newWindow"=>$appBehavior,"mobile"=>$appMobileGeneral );
				$res = $this->m_appURLTbl->updateTree($nodeID, $params);
			}
		}
		return $res;
	}

	function testURL(& $url)
	{
		if((null == $url) || ("" == $url) || ("http://" == $url))
			return HSP_ERR_INVALID_URL;
		
		// Validate the URL (by trying to open it for reading):	
		$handle = @fopen($url, "r");
		if(false != $handle)
		{
			return HSP_SUCCESS;
		}
			
		return HSP_ERR_INVALID_URL;
	}

	function linkencode (& $p_url) {
	   $ta = @parse_url($p_url);
	   if (!empty($ta['scheme']))
	   {
	 		$ta['scheme'].='://'; 
	   }
	   else
	   {
	   		// NO SCHEMA-Leave as is, don't bother encoding since it ain't URL:
	   		return;
	   }
	   
	   if (!empty($ta['pass']) && !empty($ta['user'])) {
	           $ta['user'].=':';
	           $ta['pass']=rawurlencode($ta['pass']).'@';
	   } elseif (!empty($ta['user'])) {
	       $ta['user'].='@';
	   }
	   
	   if (!empty($ta['port']) && !empty($ta['host'])) {
	       $ta['host']=''.$ta['host'].':';
	   } elseif    (!empty($ta['host'])) {
	       $ta['host']=$ta['host'];
	   }
	   else
	   {
	   		// NO HOST-Leave as is, don't bother encoding since it ain't URL:
	   		return;
	   }
	   
	   if (!empty($ta['path'])) {
	       $tu='';
	       $tok=strtok($ta['path'], "\\/");
	       while (strlen($tok)) {
	           $tu.=rawurlencode($tok).'/';
	           $tok=strtok("\\/");
	       }
	       $ta['path']='/'.trim($tu, '/');
	   }
	   if (!empty($ta['query'])) { $ta['query']='?'.$ta['query']; }
	   if (!empty($ta['fragment'])) { $ta['fragment']='#'.$ta['fragment']; }
	   $p_url =  @implode('', array($ta['scheme'], $ta['user'], $ta['pass'], $ta['host'], $ta['port'], $ta['path'], $ta['query'], $ta['fragment']));
	} 
}
?>