<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     May 2004

  Title:            applicationsW2HTbl.php
  Purpose:          Controlling all DB connectivity for the applicationsW2H module.
  Limitations:		Requires PHP 4+

 ============================================================================*/
require_once('admin/modules/applicationsData/includes/applicationsDataTbl.php');

class applicationsW2HTbl extends applicationsDataTbl 
{
	
	function applicationsW2HTbl($peardb)	
	{
		parent::applicationsDataTbl($peardb);
	}

	function insertToAppList($arrParams)
	{
		return  $this->m_pearDB->AutoExecute(TABLE_APPS_W2H, $arrParams);									
	}

	function updateAppList($appID,$arrParams)
	{
		return $this->m_pearDB->AutoExecute(TABLE_APPS_W2H , $arrParams, DB_AUTOQUERY_UPDATE,'appID="'.$appID.'";');				
	}
	
}
?>