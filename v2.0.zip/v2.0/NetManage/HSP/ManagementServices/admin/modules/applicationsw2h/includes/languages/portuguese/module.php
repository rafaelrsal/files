<?PHP
define('APPSW2H_OLD_FILE_LBL','Arquivos Web-to-Host pr�vios:');
define('APPSW2H_FILE_LBL','Novo arquivo Web-to-Host:');
define('APPSW2H_W2HSERVER_LBL','URL do Servidor Web-to-Host:');
define('APPSW2H_BACK_BTN','< Voltar');
define('APPSW2H_CANCEL_BTN','Cancelar');
define('APPSW2H_FINISH_BTN','Salvar');
define('APPSW2H_REQUIRED_TXT','verifique os campos obrigat�rios');
define('APPSW2H_W2H_FILE_REQ_MSG','Selecione um arquivo Web-to-Host');
define('APPSW2H_W2H_SERVER_REQ_MSG','Informe a URL do servidor Web-to-Host');
?>

