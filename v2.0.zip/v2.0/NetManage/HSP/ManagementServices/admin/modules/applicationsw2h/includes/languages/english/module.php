<?PHP
define('APPSW2H_OLD_FILE_LBL','Previous Web-to-Host file:');
define('APPSW2H_FILE_LBL','New Web-to-Host file:');
define('APPSW2H_W2HSERVER_LBL','Web-to-Host server URL:');
define('APPSW2H_BACK_BTN','< Back');
define('APPSW2H_CANCEL_BTN','Cancel');
define('APPSW2H_FINISH_BTN','Save');
define('APPSW2H_REQUIRED_TXT','denotes required field');
define('APPSW2H_W2H_FILE_REQ_MSG','Select a Web-to-Host file');
define('APPSW2H_W2H_SERVER_REQ_MSG','Enter a Web-to-Host server URL');
?>

