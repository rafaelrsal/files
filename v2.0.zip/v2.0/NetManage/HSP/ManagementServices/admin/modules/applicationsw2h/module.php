<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     Mars 2004

  Title:            applicationsW2H.php
  Purpose:          ApplicationsW2H module - building the HSP tree of applications.
  Limitations:		Requires PHP 4+

 ============================================================================*/
?>

<?PHP
require_once('HTML/QuickForm.php');
require_once('admin/modules/applicationsW2H/includes/applicationsW2HTbl.php');
define('APPSW2H_VERSION','appw2h_version');
define('APPSW2H_TYPE','appw2h_version');
class applicationsW2H extends ModuleBase
{
	var $m_appW2HTbl;
	var $m_requestMode;
	var $m_isupdated;
		
	function applicationsW2H($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$db  = &parent::GetDatabase();
		$this->m_appW2HTbl = new applicationsW2HTbl($db);
	}	
	
	// Initialize the form which is the skeleton of the page:
	function init()
	{
		parent::init("applicationsW2H");

		$this->m_requestMode = 	$this->m_session->value(SESSION_NEW_NODE);

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('appsW2HForm','post','','','onsubmit="onSave();return false;"'); //default is post

		$w2hfile =& $this->m_form->addElement('file', 'w2h_file', APPSW2H_FILE_LBL, array('size' => 40, 'onchange' => "updated();"));
		if('edit' != $this->m_requestMode)
			$this->m_form->addRule('w2h_file', APPSW2H_W2H_FILE_REQ_MSG, 'uploadedfile');
		$this->m_form->applyFilter('w2h_file', 'trim');
		$this->m_form->addElement('text', 'w2h_server', APPSW2H_W2HSERVER_LBL, array( 'onchange' => "updated();"));
		$this->m_form->addRule('w2h_server', APPSW2H_W2H_SERVER_REQ_MSG, 'required');
		$this->m_form->applyFilter('w2h_server', 'trim');
		$this->m_form->addElement('button', 'back', APPSW2H_BACK_BTN,"onclick=onReturn('back') class='NewButton'");
		$this->m_form->addElement('button', 'cancel', APPSW2H_CANCEL_BTN,"onclick=onReturn('cancel') class='NewButton'");
		$this->m_form->addElement('submit', 'finish', APPSW2H_FINISH_BTN, "onclick = 'onSave();return false;' class='NewButton'");
		
		$this->m_form->addElement('hidden', 'file_path');
		$this->m_form->addElement('hidden', 'version');
		$this->m_form->addElement('hidden', 'subType');
		$this->m_form->addElement('hidden', 'button_clicked', "none");
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->setRequiredNote(APPSW2H_REQUIRED_TXT);
	}
		
	// Process the submition requests:
	function process()
	{
		$res = HSP_SUCCESS;
		$this->m_isupdated = "false";
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			if((isset($_POST['button_clicked'])) && ("back" == $_POST['button_clicked']))
			{
				// Go back to 'applicationsData' page:
				// Update the app type:
				$w2h = 'w2h';
				$this->m_session->set(SESSION_NODE_APPTYPE, $w2h);
				// Let the next screen know who called it:
				$module = 'applicationsW2H';
				$this->m_session->set(SESSION_PREV_MODULE, $module);
				Header('Location: admin.php?module=applicationsData&roll='.$_POST['roll']);
				exit();
			}
			elseif((isset($_POST['button_clicked'])) && ("cancel" == $_POST['button_clicked']))
			{
				// Go back to 'applicationsTree' page:
	
				$module = 'applicationsW2H';
				$this->m_session->set(SESSION_PREV_MODULE, $module);
				Header('Location: admin.php?module=applicationsTree&roll='.$_POST['roll']);
				exit();
			} 
			else 
			{
				// Save button clicked. Validate only when saving data:
				if ($this->m_form->validate())
				{
					$finish = "";
					$arrParms = array();
					$this->m_isupdated = "true";
					
					// Get all the POST and SESSION values:
					$name = $this->m_session->value(SESSION_NODE_NAME);
					$description = $this->m_session->value(SESSION_NODE_DESC);
					$icon = $this->m_session->value(SESSION_NODE_ICON);
					$appWindow = $this->m_session->value(SESSION_APP_BEHAVIOR);
					
					if($icon == null)
					{
						// Make a default -- TEMPORARY!
						$icon = W2H_ICON;
					}
					// Find the w2hlegacy URL location:
					$arrParms["hostURL"] = htmlspecialchars($this->m_form->exportValue('w2h_server'));
					
					$res = $this->getW2HParams($arrParms);

					if(HSP_SUCCESS == $res)
					{
						// Check to see if the server URL is valid:
						$res = $this->testURL($arrParms["hostURL"]);

						if(HSP_SUCCESS == $res)
						{
							$res = $this->downloadHTPL( $arrParms );
						
							if( HSP_SUCCESS == $res ) 
							{
								
								if('edit' == $this->m_requestMode)
								{
									$res = $this->updateNode( $name, $icon, $description, $arrParms, $appWindow );
								}
								else
								{
									// new node:
									$res = $this->saveNode(	$name, $icon, $description, $arrParms,
														  	$this->m_appW2HTbl,
															$this->m_session->value(SESSION_NODE_ID),
															$appWindow);
									$finish = "&clicked=finish";
								}
								if(HSP_SUCCESS == $res)
								{
									// Let the next screen know who called it:
									$module = 'applicationsW2H';
									$this->m_session->set(SESSION_PREV_MODULE, $module);
									parent::CriaLog($this->m_requestMode ."_". trim(APPSW2H_FINISH_BTN));
									Header("Location: admin.php?module=applicationsTree$finish&roll=".$_POST['roll']);
									exit();
								}
							}							
						}
					}
				}

				// Return to previous details:
				if(isset($_POST['old_path']))
				{
					$oldName = $_POST['old_path'];
					// we are in edit mode:
					$this->m_form->addElement('text', 'old_path', APPSW2H_OLD_FILE_LBL, array('size' => 40));
					$temp = &$this->m_form->getElement("old_path");
					$temp->freeze();

					$this->m_form->setDefaults(array("old_path" => $oldName));
				}
				else
				{
					$server = htmlspecialchars($this->m_form->exportValue('w2h_server'));					
					$this->m_form->setDefaults(array("w2h_server" => $server));
				}
			}
		}
		else
		{
			$this->m_form->setDefaults(array("w2h_server" => "http://"));									
			
			// A GET request:
			if(('edit' == $this->m_requestMode) &&
							("w2h" == $this->m_session->value(SESSION_NODE_PREV_APPTYPE)))
			{
				// Get old paramters:
				$nodeID = $this->m_session->value(SESSION_NODE_ID);
				$res = $this->m_appW2HTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);	
				// Make sure we are editing the same application type:
				if((HSP_SUCCESS == $res) && ("w2h" == $arrTreeRes[3]))
				{
					$this->m_form->addElement('text', 'old_path', APPSW2H_OLD_FILE_LBL, array('size' => 40));
					
					$res = $this->m_appW2HTbl->GetRowForField(TABLE_APPS_W2H, 'appID', $arrTreeRes[2], $arrAppRes);
					if(HSP_SUCCESS == $res)	
					{	
						$temp = &$this->m_form->getElement("old_path");
						$temp->freeze();
	
						$this->m_form->setDefaults(array("w2h_server" => $arrAppRes[2], 
														"old_path" => $arrAppRes[5]));
						// save version and type for later use.
						$verElement = &$this->m_form->getElement("version");
						$verElement->setValue($arrAppRes[3]);
						$subElement = &$this->m_form->getElement("subType");
						$subElement->setValue($arrAppRes[4]);
					}
				}
			}
		}

		if(HSP_SUCCESS != $res)
		{	// If we reached here, action failed:
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}

	// Build the page and send it to display:
	function finalize()
	{
		$nodeName = $this->m_session->value(SESSION_NODE_NAME);
		
		$arrVars = array("strNodeName"=>$nodeName,
						"isupdated"=>$this->m_isupdated);
		
		parent::finalize($arrVars);
	}

	function saveNode($name, $icon, $description, $arrParms, $db, & $parentID, $appWindow, $mobileGeneral, $insideCall = true)
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$arrRes = null;

		if(false == $insideCall)
		{
			// Called from outside:
			$db = new applicationsW2HTbl($db);
		}

		// First insert application data to application table in the DB:
		$res = $db->insertToAppList($arrParms);
		if(HSP_SUCCESS == $res)
		{
			// Now enter the application as a node in the tree.
				
			// Get the application id (of the recentley application that was
			// inserted to the application table). This id is to be kept as a link
			// between the node and its application:
			$appID = 0;
			$res = $db->getMaxEntryID(TABLE_APPS_W2H, 'appID',  $arrRes);
			if(HSP_SUCCESS == $res)
			{
					
				$appID = $arrRes[0];
				unset($arrRes);
					
				// Build the link of the new node
				if(HSP_SUCCESS == $res)
					{
					// Insert node below the selected node. Notice we send the application id also
					// (Later on we will get the real Node URL and update the Node entry
					// with the right url):
					$res = $db->insertToHSPTree($parentID, $appID, "w2h", $name, $icon, $description, $appWindow , $mobileGeneral );
					if(HSP_SUCCESS == $res)
					{
						// Get the id of the recently entered node:
						$res = $db->getMaxEntryID(TABLE_TREE, 'id', $arrRes);							
						// Update the url(==href) field of the recently inserted node in hsp_tree:
						$params = array("href" => "navigate($arrRes[0])");
						$res = $db->updateTree($arrRes[0], $params); 
						
						if(HSP_SUCCESS == $res)
						{
							// Update the father the he has a new baby born: he is no longer a "leaf":
							$paramArr2 = array("status" => "1");
							$res = $db->updateTree( $parentID, $paramArr2 );
						}

						if(true == $insideCall)
						{
							// Update the node id:
							$this->m_session->set(SESSION_NODE_ID, $arrRes[0]);
						}
						else
						{
							// Update the parentID:
							$parentID = $arrRes[0];
						}
						
					} 
					else
					{
						// Could not insert a new node to the tree, so we need to remove the application
						// entery that was inserted prior to this action:
						$db->remove(TABLE_APPS_W2H, "appID", $appID);
					}

				}
			}
			
			if(true == $insideCall)
			{
				$this->m_session->remove(SESSION_NEW_NODE);
			}
		}
		
		return $res;
	}
	
	function updateNode($name, $icon, $description, $arrParms, $appBehavior)
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$nodeID = $this->m_session->value(SESSION_NODE_ID);
		$appID = 0;

		$res = $this->m_appW2HTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);
		if(HSP_SUCCESS == $res)
		{
			$appID = $arrTreeRes[2];
			// Check first if the previous application wasn't this one
			// e.g. it was a link and now it was asked to be a w2h session:
			$prevApp = $this->m_session->value(SESSION_NODE_PREV_APPTYPE);
			if('w2h' == $prevApp)
			{
				// The application type remained the same, just update the application list 
				// and the tree:
				$res = $this->m_appW2HTbl->updateAppList($appID, $arrParms);				
				if(HSP_SUCCESS == $res)
				{
					$params = array("text"=>$name, "icon"=> $icon, "title"=>$description, "newWindow"=>$appBehavior);
					$res = $this->m_appW2HTbl->updateTree($nodeID, $params); 
				}
			}
			else 
			{
				if('url' == $prevApp)
					// Remove the link application from it's list:
					$res = $this->m_appW2HTbl->remove(TABLE_APPS_LINKS, "appID", $appID);
				elseif('onWeb' == $prevApp)
					// Remove the onweb application from it's list:
					$res = $this->m_appW2HTbl->remove(TABLE_APPS_ONWEB, "appID", $appID);
				//elseif some other appplication
				
				if((HSP_SUCCESS == $res) || ('' == $prevApp /*previosly folder*/))
					// Add the new application:
					$res = $this->addAppAndUpdateTree($nodeID, $name, $icon, $description, $arrParms);
			}
		}
	
		return  $res;
	}


	function getW2HParams(& $arrParms)
	{
		$res = HSP_ERR_FILE_NOT_FOUND;
		
		$fileName = false;
		if(isset($_POST['old_path']))
		{
			$fileName = htmlspecialchars($_POST['old_path']);
			$fileName = stripslashes($fileName);
		}
		
		if(is_uploaded_file($_FILES['w2h_file']['tmp_name'])) 
		{
			
			if(0 == $_FILES['w2h_file']['size'])
			{
				return HSP_ERR_COULDNOT_RETRIEVE_FILE;
			}

			$fileName = $_FILES['w2h_file']['tmp_name'];
		}
		else
		{
			// No file loaded, look for old path:
			if(false == $fileName)
			{
				//Error - Don't know where the file is
				return $res; 
			}
		}
		
		$strFile = @file_get_contents($fileName);
		if(false === $strFile)
		{
			return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
		}

		$iPos = 0;
		$iEndPos = 0;
		
		// Find the paramter string:
		$iPos = strpos($strFile, "<!-- ConfigWizardSettings");
		$iEndPos = strpos($strFile, "-->",$iPos);
		if(false == $iPos)
		{
			return HSP_ERR_INCONGRUENT_FILE;
		}
		
		$paramStr = substr($strFile, $iPos, $iEndPos-$iPos + 3 );
		$paramStr=str_replace("\r","",$paramStr); 
		$paramStr=str_replace("\n","",$paramStr);
		$arrParms["paramStr"] = $paramStr;
		// Find the w2h version:
		$iPos = 0;
// Celso - 04.10 --> Trocado a palavra META em maiscula para minuscula
		$iPos = strpos($strFile, "<meta name=\"Version\" content=\"");
		if(false == $iPos)
		{
			// Probably an old html without that <META> tag.
			// Give it a default version:
			$arrParms["version"] = "4,2,1,4";
		}
		else
		{
			$iPos += 30; //length of the string above
		
			$iEndPos = strpos($strFile, "\">", $iPos);
			if(false === $iEndPos) // '===' so the '0' location will not be considered false!
				return HSP_ERR_INCONGRUENT_FILE;
			$arrParms["version"] = substr($strFile, $iPos, $iEndPos - $iPos);
		}

		// Find the emulation type (java/pro...)
		$iPos = 0;
		$iEndPos = 0;
// Celso - 04.10 --> Trocado a palavra META em maiuscula para minuscula
		$iPos = strpos($strFile, "<meta name=\"Product\" content=\"");
		if(false == $iPos)
			return HSP_ERR_INCONGRUENT_FILE;
		$iPos += 30; //End of the above string
		$iEndPos = strpos($strFile, "\">", $iPos);
		if(false === $iEndPos) // '===' so the '0' location will not be considered false!
			return HSP_ERR_INCONGRUENT_FILE;
		$strTmp = substr($strFile, $iPos, $iEndPos - $iPos);
		
		if(($strTmp == "Express Client") || ($strTmp == "FTP Manager Client"))
		{
			return HSP_ERR_NO_EXPRESS_FTP_SUPPORT;
		}
		else if($strTmp == "Java Client")
			$arrParms["subType"] = 1;
		else if($strTmp == "Pro Client")
			$arrParms["subType"] = 2;
		elseif($strTmp == "CPM")								
			return HSP_ERR_INCONGRUENT_FILE;
		
		// Get the file name:
		$arrParms["fileName"] = htmlspecialchars($this->m_form->exportValue('file_path'));

		return HSP_SUCCESS;
	}

	function addAppAndUpdateTree($nodeID, $name, $icon, $description, $arrParms)
	{
		$res = $this->m_appW2HTbl->insertToAppList($arrParms);
		if(HSP_SUCCESS == $res)
		{
			// Get the appID of the recently inserted application:
			$res = $this->m_appW2HTbl->getMaxEntryID(TABLE_APPS_W2H, 'appID',  $arrRes);					
			if(HSP_SUCCESS == $res)
			{
				// Update the node tree table with the new application:
				$params = array("appID"=>$arrRes[0], "application"=>"w2h", "text"=>$name, "icon"=> $icon, "title"=>$description);
				$res = $this->m_appW2HTbl->updateTree($nodeID, $params); 
			}
		}		
		return $res;
	}
	
	
	function testURL($url)
	{
		if((null == $url) || ("" == $url) || ("http://" == $url))
			return HSP_ERR_INVALID_URL;

		$url_stuff = parse_url($url);

		// For now allow only http requests verification.
		if("http" == $url_stuff["scheme"])
		{
			$port = 80; //default http
					
			if (!isset($url_stuff["path"]))
			   $url_stuff["path"] = "/";
	
			// The default is 80, but we can get a different port in url:		   
			if(isset($url_stuff["port"])) 
				$port = $url_stuff["port"];
			
			$fp = @fsockopen ($url_stuff['host'], $port, $errno, $errstr, 30);
				
			if("" == $fp)
				return HSP_ERR_INVALID_URL;
		}
		else
			return HSP_ERR_INVALID_URL;

		return HSP_SUCCESS;
	}

	function downloadHTPL( $arrParms )
	{
		$hostUrl = $arrParms["hostURL"];
		
		if (!isset($arrParms["version"]))
		{
			$version = $_POST['version'];
		}
		else 
		{
			$version = $arrParms["version"];
		}
		
		if (!isset($arrParms["subType"]))
		{
			$subType = $_POST['subType'];
		}
		else
		{
			$subType = $arrParms["subType"];
		}
		
		$htplFileName = '';
		if ( $subType == 0 )
		{
			$htplFileName = 'express.htpl';
		}
		elseif ( $subType == 1 )
		{
			$htplFileName = 'javaclient.htpl';
		}
		elseif ( $subType == 2 )
		{
			$htplFileName = 'hostproclient.htpl';
		}
		elseif ( $subType == 3 )
		{
			$htplFileName = 'hostftpclient.htpl';
		}
		
		if (!strpos($hostUrl,'/',strlen($hostUrl)-1))
		{
			$hostUrl .= '/';
		}		
		
		if ( $subType == 1 ) //javaclient
		{
			// get download url path (DistributionBase)			
			$startPos = strpos( $arrParms["paramStr"] , 'DistributionBase=' ) + 17;
			$endPos = strpos( $arrParms["paramStr"] , '&' ,$startPos);
			$downloadURL = substr($arrParms["paramStr"] , $startPos, $endPos - $startPos );
			$downloadURL .= '/w2hlegacy';
		}
		else
		{
			// get download url path (DownloadURL)			
			$startPos = strpos( $arrParms["paramStr"] , 'DownloadURL=' ) + 13;
			$endPos = strpos( $arrParms["paramStr"] , '&' ,$startPos);
			$downloadURL = substr($arrParms["paramStr"] , $startPos, $endPos - $startPos );
		}		
		
		$htplUrl = $hostUrl . $downloadURL . '/config/' . $htplFileName;				
		$htplLocalPath = 'data/w2h/htpl/' . $version . '/' . $htplFileName;
		$versionDir = 'data/w2h/htpl/' . $version;

		// By trying to get file contenets we verify that the server URL is not only valid
		// but contains w2h on it:
		$strFileBuffer = @file_get_contents($htplUrl);
		if ( $strFileBuffer )
		{
			if (!@is_readable($htplLocalPath))
			{
				if (!@opendir($versionDir))
				{
					$res = @mkdir($versionDir);
					if ( $res == false )
					{
						return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
					}
				}
				
				if (!$handle = @fopen($htplLocalPath, 'w')) 
				{
					return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
				}		
				
				if ( @fwrite($handle, $strFileBuffer) === FALSE ) 
				{
					return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
				}
				
				fclose($handle);				
			}
				
			return HSP_SUCCESS;
		}
		
		return HSP_ERR_NOT_W2H_SERVER;
	}
	
}
?>