<?PHP
define('EDITCUSTOMDIR_EDIT_BTN','Editar');
define('EDITCUSTOMDIR_ADD_GROUP_BTN','Adicionar Grupo');
define('EDITCUSTOMDIR_ADD_USER_BTN','Adicionar Usu�rio');
define('EDITCUSTOMDIR_DELETE_BTN','Remover');
define('EDITCUSTOMDIR_BACK_BTN','< Voltar para a lista de Diret�rios');

define('EDITCUSTOMDIR_NAME_LBL','Nome');
define('EDITCUSTOMDIR_DIRTYPE_LBL','Tipo');
define('EDITCUSTOMDIR_DESCRIPTION_LBL','Descri��o');

define('EDITCUSTOMDIR_CONFIRM_DELETE_MSG','Voc� tem certeza que deseja remover este');
define('EDITCUSTOMDIR_USER_TXT','Usu�rio');
define('EDITCUSTOMDIR_GROUP_TXT','Grupo');

define('EDITCUSTOMDIR_TABLE_TITLE_TXT','Usu�rios e Grupos');
define('EDITCUSTOMDIR_TITLE_TXT','Detalhes do Diret�rio Customizado');

define('DB_DIRNAME_REQ_MSG', 'Informar o nome do diret�rio');
?>