<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

define('INTERNALDIR_ID', 'internalDirId');
define('INTERNALDIRUSER_ID', 'internalDirUserId');
define('INTERNALDIRGROUP_ID', 'internalDirGroupId');
define('SESSION_CUSTOMDIR_MODE', 'customDirectoryMode');

define('CUSTOM_GROUP_AVAILABLE_USERS', 'customAvailableUsers');
define('CUSTOM_GROUP_MEMBER_USERS', 'customMemberUsers');

define('CUSTOM_USER_AVAILABLE_GROUPS', 'customAvailableGroups');
define('CUSTOM_USER_MEMBER_OF_GROUPS', 'customMemberOfGroups');

define('CUSTOM_GROUP_DETAILS', 'customGroupDetails');
define('CUSTOM_USER_DETAILS', 'customUserDetails');

class editCustomDir extends ModuleBase
{
	var $m_db;
	var $m_dirItemsArr;	
	var $m_internalDirId;

	function editCustomDir($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		$this->m_dirItemsArr = array();
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
		$this->m_form = new HTML_QuickForm('editCustomDirForm'); //default is post
	}
	
	function init()
	{		
		parent::init("editCustomDir");
		// buttons
		$this->m_form->addElement('button', 'editDir', 	EDITCUSTOMDIR_EDIT_BTN,  		"onclick=onEdit() class='NewButton'");
		$this->m_form->addElement('button', 'addGroup',	EDITCUSTOMDIR_ADD_GROUP_BTN,	"onclick=onAddGroup() class='NewButton' style='width:100px'");
		$this->m_form->addElement('button', 'addUser',	EDITCUSTOMDIR_ADD_USER_BTN, 	"onclick=onAddUser() class='NewButton' style='width:120px'");
		$this->m_form->addElement('button', 'deleteItem',EDITCUSTOMDIR_DELETE_BTN,   	"onclick=onDelete() class='NewButton'");
		$this->m_form->addElement('button', 'back',	EDITCUSTOMDIR_BACK_BTN,   		"onclick=onBack() class='NewButton' style='width:200px'");
		// text		
		$this->m_form->addElement('text', 'dirName', 		EDITCUSTOMDIR_NAME_LBL, array('size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'description', 	EDITCUSTOMDIR_DESCRIPTION_LBL, array('size' => 40, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects', 'style' => 'width:300px'));
		// hiddens
		$this->m_form->addElement('hidden', 'buttonClicked','');	
		$this->m_form->addElement('hidden', 'selectedRow', 1);
		$this->m_form->addElement('hidden', 'mode', 'new');
		
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			if ( isset($_GET['dirId'] ) )
			{	// edit mode
				$this->m_internalDirId = $_GET['dirId'];
			}
			elseif ( $this->m_session->value(INTERNALDIR_ID) )
			{
				$this->m_internalDirId = $this->m_session->value(INTERNALDIR_ID);
			}

			if ( null != $this->m_internalDirId )
			{
				$this->m_session->set(INTERNALDIR_ID, $this->m_internalDirId );
				$this->m_form->addElement('hidden', 'mode', 'edit');
			}
		}
		else
		{ // we are in post -> we can use the saved dir id
			$this->m_internalDirId = $this->m_session->value(INTERNALDIR_ID);
		}
		
		$this->m_session->remove(CUSTOM_GROUP_MEMBER_USERS);
		$this->m_session->remove(CUSTOM_GROUP_AVAILABLE_USERS);	
		$this->m_session->remove(CUSTOM_GROUP_DETAILS);
		
		$this->m_session->remove(CUSTOM_USER_MEMBER_OF_GROUPS);
		$this->m_session->remove(CUSTOM_USER_AVAILABLE_GROUPS);		
		$this->m_session->remove(CUSTOM_USER_DETAILS);		
	}

	function process()
	{
		$res = HSP_SUCCESS;	
		
		if ( null != $this->m_internalDirId )
		{
			$this->populateDirItemsArr();
		}
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$formValuesArray = $this->m_form->exportValues();
			
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));			
			
			if ( "back" == $formValuesArray['buttonClicked'])
			{
				$this->onBack();
			}
			elseif ( "edit" == $formValuesArray['buttonClicked'])
			{
				$this->onEdit($selectedRow);
			}
			elseif ( "addGroup" == $formValuesArray['buttonClicked'])
			{
				$this->onAddGroup();
			}
			elseif ( "addUser" == $formValuesArray['buttonClicked'])
			{
				$this->onAddUser();
			}
			elseif ( "delete" == $formValuesArray['buttonClicked'])
			{
				$this->onDelete($selectedRow);
			}
		}
		
		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
		
		if ( null != $this->m_internalDirId )
		{
			// we call populate on success in order to reflect the new state
			$this->populateDirItemsArr();
		}
	}
	
	function finalize()
	{
		$arrVars = array(	"tblItems"=>$this->generateTable(),
					        "confirm_delete"=>EDITCUSTOMDIR_CONFIRM_DELETE_MSG,
					        "strTitle"=>EDITCUSTOMDIR_TITLE_TXT,
					        "strTableTitle"=>EDITCUSTOMDIR_TABLE_TITLE_TXT,
					        "editCustomDirForm_error1_html"=>DB_DIRNAME_REQ_MSG,
					        "msgPageChanged"=> MENUITEM_CHANGES,
					        "selectedRow"=>$this->getSelectedIndex(),
					        "directoryName"=>$this->getDirName());
        
		parent::finalize($arrVars, 'editCustomDir');
	}
	
	function getSelectedIndex()
	{
		$userId = $this->m_session->value(INTERNALDIRUSER_ID);
		$groupId = $this->m_session->value(INTERNALDIRGROUP_ID);

		$this->m_session->remove(INTERNALDIRUSER_ID);		
		$this->m_session->remove(INTERNALDIRGROUP_ID);
		
		if ( false == $userId &&  false == $groupId )
		{
			return 1;
		}
		
		if ( null != $userId )
		{
			foreach ( $this->m_dirItemsArr as $index=>$item )
			{
				if ( $item['id'] == $userId && $item['type'] == EDITCUSTOMDIR_USER_TXT )
				{
					return $index+1;
				}
			}
		}
		elseif ( null != $groupId )
		{
			foreach ( $this->m_dirItemsArr as $index=>$item )
			{
				if ( $item['id'] == $groupId && $item['type'] == EDITCUSTOMDIR_GROUP_TXT )
				{
					return $index+1;
				}
			}

		}
		
		return 1; // we never get here.
	}
	
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tblItems" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(EDITCUSTOMDIR_NAME_LBL , EDITCUSTOMDIR_DIRTYPE_LBL, EDITCUSTOMDIR_DESCRIPTION_LBL);
		$headerAttribArr = array("class='TableHeader' width=200px","class='TableHeader' width=100px","class='TableHeader' width=200px");
		$tblBackups->addRow($headerArr , $headerAttribArr );
		
		foreach ( $this->m_dirItemsArr as $key=>$fileRow )
		{
			$rownum = $key + 1 ;
			
			$shortName = $fileRow['name'];
			
			if ( strlen($shortName) > 23 )
			{
				$shortName = substr($fileRow['name'], 0, 23) . '...';
			}
			
			$shortDesc = $fileRow['desc'];
			
			if ( strlen($shortDesc) > 47 )
			{
				$shortDesc = substr($fileRow['desc'], 0, 47) . '...';
			}
			
			$row = array ($shortName , $fileRow['type'], $shortDesc );			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
			
			$name = $fileRow['name'];
			$type = $fileRow['type'];
			$description = $fileRow['desc'];
			$attib = array("class='DataCell' title='$name'","class='DataCell' title='$type'","class='DataCell' title='$description'");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}

		return $tblBackups->toHtml();
		
	}
	
	function populateDirItemsArr()
	{	
		$this->m_dirItemsArr = array();
		
		$users = $this->m_db->GetAllEx("SELECT * FROM ".TABLE_CUSTOM_USERS . " WHERE dirID=$this->m_internalDirId;", null, DB_FETCHMODE_ASSOC);		
		$groups = $this->m_db->GetAllEx("SELECT * FROM ".TABLE_CUSTOM_GROUPS . " WHERE dirID=$this->m_internalDirId;", null, DB_FETCHMODE_ASSOC);		
		
		foreach ($users as $user)
		{
			$this->m_dirItemsArr[] = array('id'=>$user['id'] ,'name'=>$user['name'] , 'type'=>EDITCUSTOMDIR_USER_TXT , 'desc'=>$user['description'] );
		}
		
		foreach ($groups as $group)
		{
			$this->m_dirItemsArr[] = array('id'=>$group['id'] ,'name'=>$group['name'] , 'type'=>EDITCUSTOMDIR_GROUP_TXT , 'desc'=>$group['description'] );
		}
		
		$this->sortItemArr();
	}
	
	//sort the directory list by name
	function sortItemArr()
	{
		$tmpArr = array();
		foreach($this->m_dirItemsArr as $item)
		{
			$tmpArr[] = $item['name'];
		}
		
		natcasesort($tmpArr);
		
		$newFileListArray = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $this->m_dirItemsArr as $key=>$item )
			{
				if ($name == $item['name'])
				{
					$newFileListArray[] = $item;
					unset($this->m_dirItemsArr[ $key ]);
					break;
				}
			}			
		}
		
		$this->m_dirItemsArr = $newFileListArray;
	}
	
	function onEdit($selectedRow)
	{
		$this->m_session->set(SESSION_CUSTOMDIR_MODE, 'editMode');
		
		$type = $this->m_dirItemsArr[$selectedRow-1]['type'];
		$id = $this->m_dirItemsArr[$selectedRow-1]['id'];
		if ( EDITCUSTOMDIR_USER_TXT == $type )
		{
			Header("Location: admin.php?module=editCustomDirUser&id=$id&roll=".$_POST['roll']);
			exit();
		}
		elseif ( EDITCUSTOMDIR_GROUP_TXT == $type )
		{
			Header("Location: admin.php?module=editCustomDirGroup&id=$id&roll=".$_POST['roll']);
			exit();
		}
	}
	
	function onBack()
	{		
		Header('Location: admin.php?module=customDirectories&roll='.$_POST['roll']);
		exit();
	}
	
	function onDelete($selectedRow)
	{
		$type = $this->m_dirItemsArr[$selectedRow-1]['type'];
		$id = $this->m_dirItemsArr[$selectedRow-1]['id'];
		if ( EDITCUSTOMDIR_USER_TXT == $type )
		{
			$sql = "DELETE FROM ".TABLE_CUSTOM_USERS . " WHERE id={$id};";
			$ret = $this->m_db->Query($sql);
			if (HSP_ERR_DB_SQL_ERROR != $ret)
			{
				$sql = "DELETE FROM ".TABLE_CUSTOM_CROSS . " WHERE userId={$id};";
				$ret = $this->m_db->Query($sql);
			}
		}
		elseif ( EDITCUSTOMDIR_GROUP_TXT == $type )
		{
			$sql = "DELETE FROM ".TABLE_CUSTOM_GROUPS . " WHERE id={$id};";
			$ret = $this->m_db->Query($sql);
			if (HSP_ERR_DB_SQL_ERROR != $ret)
			{
				$sql = "DELETE FROM ".TABLE_CUSTOM_CROSS . " WHERE groupId={$id};";
				$ret = $this->m_db->Query($sql);
			}
		}
		
		if (HSP_ERR_DB_SQL_ERROR != $ret)
		{
			unset($this->m_dirItemsArr[$selectedRow - 1]);
			parent::CriaLog(EDITCUSTOMDIR_DELETE_BTN);
		}
		
		return $ret;
	}
	
	function onAddGroup()
	{	
		$this->m_session->set(SESSION_CUSTOMDIR_MODE, 'addMode');
		$this->m_session->remove(INTERNALDIRGROUP_ID);	
		Header('Location: admin.php?module=editCustomDirGroup&roll='.$_POST['roll']);
		exit();
	}
	
	function onAddUser()
	{
		$this->m_session->set(SESSION_CUSTOMDIR_MODE, 'addMode');
		$this->m_session->remove(INTERNALDIRUSER_ID);
		Header('Location: admin.php?module=editCustomDirUser&roll='.$_POST['roll']);
		exit();
	}
	
	function getDirName()
	{	
		$sql = "SELECT name FROM ".TABLE_CUSTOM_DIRECTORY . " WHERE id=$this->m_internalDirId;";
		$this->m_db->GetOne($sql, $name);
		
		return $name;
	}
}
?>