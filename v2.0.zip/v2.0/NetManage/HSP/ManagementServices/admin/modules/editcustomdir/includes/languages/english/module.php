<?PHP
define('EDITCUSTOMDIR_EDIT_BTN','Edit');
define('EDITCUSTOMDIR_ADD_GROUP_BTN','Add Group');
define('EDITCUSTOMDIR_ADD_USER_BTN','Add User');
define('EDITCUSTOMDIR_DELETE_BTN','Delete');
define('EDITCUSTOMDIR_BACK_BTN','< Back to Directories List');

define('EDITCUSTOMDIR_NAME_LBL','Name');
define('EDITCUSTOMDIR_DIRTYPE_LBL','Type');
define('EDITCUSTOMDIR_DESCRIPTION_LBL','Description');

define('EDITCUSTOMDIR_CONFIRM_DELETE_MSG','Are you sure you want to delete this');
define('EDITCUSTOMDIR_USER_TXT','User');
define('EDITCUSTOMDIR_GROUP_TXT','Group');

define('EDITCUSTOMDIR_TABLE_TITLE_TXT','Users and Groups');
define('EDITCUSTOMDIR_TITLE_TXT','Custom directory details');

define('DB_DIRNAME_REQ_MSG', 'Enter directory name');
?>