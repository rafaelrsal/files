function initPopup()
{
	document.getElementsByName('filename').item(0).focus();
}

function finalizePopup()
{
}

function TakePropertiesFromOpener()
{	        
	document.getElementsByName('filename').item(0).focus();
	document.getElementsByName('filename').item(0).value	= "";
	document.getElementsByName('description').item(0).value = "";
}

function SaveExport()
{
	win.document.getElementsByName('buttonClicked').item(0).value 	= 'backup';
	win.document.getElementsByName('filename').item(0).value 		= document.getElementsByName('filename').item(0).value;
	win.document.getElementsByName('description').item(0).value 	= document.getElementsByName('description').item(0).value;
	
	win.showWaitEx();
	win.document.getElementById('backupForm').submit();
	window.close();
}
