<?PHP
define('BACKUP_MAIN_TXT','<h1>Database export and import</h1>');
define('BACKUP_HEADER_TXT','Database Export');
define('BACKUP_DOBACKUP_BTN','Export...');
define('BACKUP_DOBACKUP_SAVE_BTN','Save');
define('BACKUP_DOBACKUP_CANCEL_BTN','Cancel');
define('BACKUP_DOBACKUPDOWNLOAD_BTN','Export and download');
define('BACKUP_FILELIST_LBL','Exported database files:');
define('BACKUP_FILENAME_LBL','File name:');
define('BACKUP_FILENAME_TITLE','File Name');
define('BACKUP_DATE_TIME_LBL','Date and Time');
define('BACKUP_TYPE_LBL','Database Type:');
define('BACKUP_DESCRIPTION_LBL','Description:');
define('BACKUP_RESTORE_BTN','Import');
define('BACKUP_DELETE_BTN','Delete');
define('BACKUP_CONFIRM_RESTORE_MSG','Importing the selected database will replace the existing one. Click OK to continue.');
define('BACKUP_CONFIRM_DELETE_MSG','Are you sure you want to delete this backup file?');
define('BACKUP_EXPORT_TITLE','Export Database');
?>