<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');
require_once('HTML/QuickForm.php');
require_once('Admin/includes/general.php'); // doBackup() , doRestore()
require_once('HTML/Table.php');
require_once('includes/classes/xmlWrapper.php');
require_once('upgrade/upgrade.php');

class backup extends ModuleBase
{
	var $m_db;
	var $m_dbType;
	
	var $m_fileListArr;	

	function backup($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();

		$this->m_form = new HTML_QuickForm('backupForm'); //default is post
	}
	
	function init()
	{		
		parent::init("backup");

		// Build the login form:
		$this->m_form->addElement('header', 'header', 		BACKUP_HEADER_TXT);
		$this->m_form->addElement('submit', 'backup', 		BACKUP_DOBACKUP_BTN, "class='NewButton' onclick='OpenPropertiesWindow();return false;'");
		$this->m_form->addElement('button', 'restore', 		BACKUP_RESTORE_BTN,  "onclick=onRestore() class='NewButton'");
		$this->m_form->addElement('button', 'deletefile', 	BACKUP_DELETE_BTN,   "onclick=onDelete() class='NewButton'");
		
		$this->m_form->addElement('submit', 'save', 		BACKUP_DOBACKUP_SAVE_BTN,  "class='NewButton' onclick='SaveExport();'");
		$this->m_form->addElement('button', 'cancel', 		BACKUP_DOBACKUP_CANCEL_BTN,  "class='NewButton' onclick='self.close();'");
		
		$this->m_form->addElement('text', 'filename', 		BACKUP_FILENAME_LBL, array('size' => 20, 'maxlength' => 255, 'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'description', 	BACKUP_DESCRIPTION_LBL, array('size' => 40, 'maxlength' => 255, 'class' => 'FixedWidthObjects', 'style' => 'width:300px'));

		$this->m_form->addElement('hidden',	'filename');
		$this->m_form->addElement('hidden', 'description');		
		$this->m_form->addElement('hidden', 'buttonClicked','');	
		$this->m_form->addElement('hidden', 'selectedRow', 1);
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$wrapper = new xmlWrapper();
		$wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME);
		
		$params = null;
		if ( STORAGE_TYPE_RDBMS == $wrapper->getStorageType() )
		{
			$params = $wrapper->getRDBMSParams();
			$this->m_dbType = $params['rdbms_type'];
		}
		elseif( STORAGE_TYPE_ODBC == $wrapper->getStorageType() )
		{
			$params = $wrapper->getODBCParams();
			$this->m_dbType = $params['type'];
		}
		
		$this->populateFileListArr();
	}

	function process()
	{
		$filename = null;
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$res = HSP_SUCCESS;		
			
			$formValuesArray = $this->m_form->exportValues();
			
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));			
			
			if ( "backup" == $formValuesArray['buttonClicked'])
			{
				$fileName = htmlspecialchars($this->m_form->exportValue('filename'));
				$description = htmlspecialchars($this->m_form->exportValue('description'));			
				$res = $this->doBackup($this->m_dbType,$fileName, $description);
				parent::CriaLog(BACKUP_DOBACKUP_BTN);
			}
			elseif ( "restore" == $formValuesArray['buttonClicked'] )
			{
				$fileName = $this->m_fileListArr[$selectedRow-1]['filename'];
				$res = $this->doRestore($fileName);
				
				if (HSP_SUCCESS == $res )
				{
					if ( $this->upgrade() == false )
					{
						$res = HSP_ERR_UPGRADE_FAILED;
					}
					
				}
			}
			elseif ( "delete" == $formValuesArray['buttonClicked'] )
			{	
				$fileName = $this->m_fileListArr[$selectedRow-1]['filename'];
				$res = $this->doDelete($fileName);
				parent::CriaLog(BACKUP_DELETE_BTN);
			}
			
			if(HSP_SUCCESS != $res)
			{
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);				
			}
			else
			{
				// we call populate on success in order to reflect the new state
				$this->populateFileListArr();
				$this->saveDirList();				
			}
			
			if ( isset( $_SESSION[SESSION_UPGRADE] ))
			{
				Header('Location: admin.php?module=maintenance');
				exit();
			}
		}
	}
	
	function finalize()
	{
		$language = parent::GetLanguage();
		
		$arrVars = array(	"tblBackups"=>$this->generateTable(),
					        "lblExport"=>BACKUP_EXPORT_TITLE,
					        "lblSave"=>BACKUP_DOBACKUP_SAVE_BTN,
					        "lblCancel"=>BACKUP_DOBACKUP_CANCEL_BTN,
					        "confirm_restore"=>BACKUP_CONFIRM_RESTORE_MSG,
					        "confirm_delete"=>BACKUP_CONFIRM_DELETE_MSG,
					        "backupForm_filename_label"=>BACKUP_FILENAME_LBL,
					        "backupForm_description_label"=>BACKUP_DESCRIPTION_LBL,
					        "moduleName"=>$this->m_moduleName,
					        "language"=>$language->m_Language);
        
		parent::finalize($arrVars);
	}
	
	function generateTable()
	{
		$tblBackups=new HTML_Table('id="tblBackups" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(BACKUP_DATE_TIME_LBL, BACKUP_FILENAME_TITLE , BACKUP_DESCRIPTION_LBL);
		$headerAttribArr = array("class='TableHeader' width=150px","class='TableHeader' width=225px","class='TableHeader' width=225px");
		$tblBackups->addRow($headerArr , $headerAttribArr );		
		
		foreach ( $this->m_fileListArr as $key=>$fileRow )
		{
			$rownum = $key + 1 ;
			
			$shortName = $fileRow['filename'];
			
			if ( strlen($shortName) > 27 )
			{
				$shortName = substr($fileRow['filename'], 0, 26) . '...';
			}
			
			$shortDesc = $fileRow['desc'];
			
			if ( strlen($shortDesc) > 27 )
			{
				$shortDesc = substr($fileRow['desc'], 0, 26) . '...';
			}
			
			
			$row = array ( $fileRow['formattedDatetime'], $shortName , $shortDesc );								
			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='BackupClick(this,$rownum)'", 'TD', true );
			
			$fileName = $fileRow['filename'];
			$description = $fileRow['desc'];
			
			$attib = array("class='DataCell'","class='DataCell' title='$fileName'","class='DataCell' title='$description'");
			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}
		
		return $tblBackups->toHtml();
		
	}
	
	
	function doBackup( $db_type, $filename, $description, $download=false )
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		
		$filename .= '.hql';
		if("mysql" == $db_type)
		{
			$res = doBackup($this->m_db , $filename, $description); // admin/includes/general.php
		}
		elseif("mssql" == $db_type)
		{
			if ( "db_odbc" == get_class($this->m_db->m_DB) )
			{
				$res = doBackup_MSSQLODBC($this->m_db, $filename, $description );
			}
			else
			{
				$res = doBackup_MSSQL($this->m_db, $filename, $description );
			}
		}
	
		return $res;
	}

	function doRestore($fileName)
	{
		return doRestore( $this->m_db , BACKUP_DIR. $fileName, $this->m_dbType, false);		
	}

	function doDelete($fileName)
	{
		$ret = @unlink(BACKUP_DIR.$fileName);
		if ($ret === true)
		{
			return HSP_SUCCESS;
		}
		
		return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
	}

	function populateFileListArr()
	{
		////////////////////////////////
		// this array will hold the data for each file as follows:
		// $this->m_fileListArr[0] = array('filename'=>'file1.ext' , 'desc'=>'file1 description' , 'formattedDatetime'=>'August 15 2004 10:27:31')
		// $this->m_fileListArr[1] = array('filename'=>'file2.ext' , 'desc'=>'file2 description' , 'formattedDatetime'=>'August 15 2004 10:27:31')
		///////////////////////////////
		
		$this->m_fileListArr = array();
		
		$dirpath = BACKUP_DIR;
		$dh = opendir($dirpath);
		
   		while (false !== ($file = readdir($dh)))
   		{
			//Don't list subdirectories
  			if (!is_dir("$dirpath/$file"))
  			{
   				// Get backup file details (type and description):
   				$handle = @fopen("$dirpath/$file", "rb");
				if($handle)
				{
					$strFile = fread($handle, filesize("$dirpath/$file"));
					fclose($handle);
				}
				else
				{
					return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
				}	

				list($type, $description, $extra) = split("&&", $strFile, 3);
				 
				if($type != $this->m_dbType)
				{
				 	// The current DB type id different than the file DB type.
				 	// TODO: later on we supply a migration tool for the different DBs.
				 	// Ignore this file:
					continue;
				}
				
				$this->m_fileListArr[] = array( 'filename'=> $file , 
												'desc'=>$description , 
												'formattedDatetime'=>date("F d Y H:i:s", filemtime(("$dirpath/$file"))),
												'filetime'=>filemtime(("$dirpath/$file")));
			}
		}
 		closedir($dh);
 		
 		$this->sortFileListArr();
	}
	
	//sort the file list by file modified date
	function sortFileListArr()
	{
		$tmpArr = array();
		foreach($this->m_fileListArr as $fileItem)
		{
			$tmpArr[$fileItem['filename']] = $fileItem['filetime'];
		}
		
		arsort($tmpArr);
		
		$newFileListArray = array();
		
		foreach($tmpArr as $name=>$time)
		{
			foreach( $this->m_fileListArr as $fileItem )
			{
				if ($name == $fileItem['filename'] )
				{
					$newFileListArray[] = $fileItem;
					break;
				}
			}			
		}
		
		$this->m_fileListArr = $newFileListArray;
	}
	
	function saveDirList()
	{
		$errorCode = HSP_SUCCESS;
		$fp = fopen('data/directoylist', 'w');
		
		$sql = 'select * from ' . TABLE_DIRECTORIES . ' order by display_name;';
		$dirArray = $this->m_db->GetAllEx( $sql , DB_FETCHMODE_ASSOC );
		
		if ( DB::isError($dirArray) ) 
		{
			$errorCode = HSP_ERR_DB_ERROR;
		}
		else 
		{
			foreach ( $dirArray as $dir )
			{
				fwrite($fp, '<option value="' .  $dir['id'] . '">'.$dir['display_name'].'</option>');
			}
		}
		
		fclose($fp);
		
		return $errorCode;
	}
	
	function upgrade()
	{
		$upgrade = new Upgrade( $this->m_db );
		if ( $upgrade->init() )
		{
			if ( $upgrade->getDoUpgrade() )
			{
				$_SESSION[SESSION_UPGRADE] = $upgrade;
			}
			else
			{
				unset($_SESSION[SESSION_UPGRADE]);
			}
			parent::CriaLog(BACKUP_RESTORE_BTN);
			return true;
			
		}
		
		return false;
	}	
}
?>