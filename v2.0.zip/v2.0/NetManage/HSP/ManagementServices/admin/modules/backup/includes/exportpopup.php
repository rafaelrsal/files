<?PHP
$language = $_GET['language'];
require_once("languages/$language/module.php");
?>

<html>
<head>
	<title><?php echo $_GET["Title"] ?></title>
	<script language=javascript>
		var win = window.dialogArguments;
	    function TakePropertiesFromOpener()
	    {	        
			document.getElementsByName('filename').item(0).focus();
			document.getElementsByName('filename').item(0).value	= "";
			document.getElementsByName('description').item(0).value = "";
	    }
	    
        function SaveExport()
        {
			win.document.getElementsByName('buttonClicked').item(0).value 	= 'backup';
			win.document.getElementsByName('filename').item(0).value 		= document.getElementsByName('filename').item(0).value;
			win.document.getElementsByName('description').item(0).value 	= document.getElementsByName('description').item(0).value;
			
			win.document.getElementById('backupForm').submit();
            window.close();
        }
	</script>
    <link rel="stylesheet" type="text/css" href="/hsp/includes/stylesheets/hsp.css">

</head>
<body id=bodProperties onload='javascript:TakePropertiesFromOpener();'>
	<center>
    	<br>
    	<br>
    	
	    <TABLE>
			<tr>
				<td><?php echo BACKUP_FILENAME_LBL; ?></td>
				<td><input size="20" maxlength="255" class="FixedWidthObjects" name="filename" type="text" /></td>
			</tr>
			<tr>
				<td><?php echo BACKUP_DESCRIPTION_LBL; ?></td>
				<td><input size="40" maxlength="255" class="FixedWidthObjects" name="description" type="text" style="width:300px"/></td> 
			</tr>
			<tr>
				<td colspan=3>
					<hr>
				</td>
			</tr>
			<tr>
				<td colspan=3 align=right>
					<input class="NewButton" type="submit" name="btnSave" value="<?php echo BACKUP_DOBACKUP_SAVE_BTN; ?>" onclick="SaveExport();">
					<input class="NewButton" type="button" value="<?php echo BACKUP_DOBACKUP_CANCEL_BTN; ?>" onclick="self.close();">&nbsp;
				</td>
			</tr>
		</TABLE>
	
    </center>
</body>
</html>