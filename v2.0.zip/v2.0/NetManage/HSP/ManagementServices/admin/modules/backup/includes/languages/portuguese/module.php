<?PHP
define('BACKUP_MAIN_TXT','<h1>Exporta��o e Importa��o do Database</h1>');
define('BACKUP_HEADER_TXT','Exportar Database');
define('BACKUP_DOBACKUP_BTN','Exportando');
define('BACKUP_DOBACKUP_SAVE_BTN','Salvar');
define('BACKUP_DOBACKUP_CANCEL_BTN','Cancelar');
define('BACKUP_DOBACKUPDOWNLOAD_BTN','Exportar e baixar');
define('BACKUP_FILELIST_LBL','Arquivos exportados do database:');
define('BACKUP_FILENAME_LBL','Nome do arquivo:');
define('BACKUP_FILENAME_TITLE','Nome do Arquivo');
define('BACKUP_DATE_TIME_LBL','Dia e Hora');
define('BACKUP_TYPE_LBL','Tipo do Database:');
define('BACKUP_DESCRIPTION_LBL','Descri��o:');
define('BACKUP_RESTORE_BTN','Importa��o');
define('BACKUP_DELETE_BTN','Remover');
define('BACKUP_CONFIRM_RESTORE_MSG','Importando o database selecionado voc� ir� substituir o database j� existente. Pressione OK para continuar.');
define('BACKUP_CONFIRM_DELETE_MSG','Voc� tem certeza que deseja remover estes arquivos de backup?');
define('BACKUP_EXPORT_TITLE','Exportando o Database');
?>