<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title:           	module.php (database)
  Purpose: Database configuration module.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('HTML/QuickForm.php');

require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');
require_once('Admin/includes/general.php'); // doBackup()-> upload hsp.sql
require_once('upgrade/upgrade.php');

class database extends ModuleBase
{
	var $m_bInit;
	var $m_dbConfig;
	var $m_bConfirmMsg;
	var $m_db;
	var $m_dbPortArr;
	
	function database($globalobjects)
	{	
		parent::ModuleBase($globalobjects);
		
		$this->m_db = null;		
		$this->m_bConfirmMsg = 'false';
		$this->m_dbPortArr = array(	'mysql'=>3306,
									'mssql'=>"");
	}
	
	function init()
	{
		parent::init("database");
		
		// Check if this is the first time HSP administration console is run.
		// This is done by checking error code - file not found, entered at the
		// admin.php.
		// If so we need to get DB and password information for on going use:
		
		$this->m_bInit = &$this->m_session->value(SESSION_INIT_CONFIG);
		if($this->m_bInit)
		{
			// Prepare an instruction message for the user,
			// running the database page for the first time:
			$msgCode = array(DB_CONFIG_MSG);			
			$this->m_session->set(SESSION_MESSAGES, $msgCode);
		}

		$this->m_dbConfig = new DBConfig();
		$errCode = $this->m_dbConfig->init();
		
		if ( !$this->m_bInit ) // do not deserialize if we are in flow 0.
		{
			if ( $errCode != HSP_ERR_FILE_NOT_FOUND )
			{
				$this->m_dbConfig->DBDeserialize();
			}
			else 
			{
				$this->m_session->set(SESSION_ERRORS, $errCode);
				exit;
			}
		}
		
		$databaseTypeArr = array(
					'mysql'=>DB_TYPE_MYSQL_TXT,
					'mssql'=>DB_TYPE_MSSQL_TXT,					
		);
		
		
		$databaseTypeArrOdbc = array(					
					'mssql'=>DB_TYPE_MSSQL_TXT,					
		);
		
		$this->m_form = new HTML_QuickForm('DatabaseForm'); //default is post
		
		$attr = array('onchange' => "updatePort();updated();",'class' => "FixedWidthObjects",'tabindex' => 0,'onkeypress' => 'DoDefaultEnterKey(event)');

		// Build the database form:		
		$this->m_form->addElement('radio', 'dsnradio', '',DB_ARRAY_RADIO_LBL,1,"onclick='SwitchDatabaseConfig(2)'");
		$this->m_form->addElement('radio', 'dsnradio', '',DB_DSN_RADIO_LBL,0,"onclick='SwitchDatabaseConfig(1)'");
		
		$this->m_form->addElement('text', 'dsn', DB_DSN_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()",'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'dsn_username', DB_USERNAME_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()",'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('password', 'dsn_password', DB_PASSWORD_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()",'class' => 'FixedWidthObjects'));
		
		
		$this->m_form->addElement('select', 'type_direct', DB_TYPE_LBL,$databaseTypeArr,$attr);
		$this->m_form->addElement('select', 'type_odbc', DB_TYPE_LBL,$databaseTypeArrOdbc,$attr);
		
		$this->m_form->addElement('text', 'dbname', DB_NAME_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()",'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'host', DB_HOST_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()", 'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'port', DB_PORT_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()",'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'name', DB_USERNAME_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()",'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('password', 'password', DB_PASSWORD_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()",'class' => 'FixedWidthObjects'));		
		
		$this->m_form->addElement('hidden', 'confirm','false');
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->addElement('submit', 'apply', DB_APPLY_BTN, 'class="NewButton" "onclick="validateForm();return false;" ');
		$this->m_form->addElement('button', 'clear', DB_CLEAR_BTN, 'class="NewButton" "onclick="clearForm();" ');
		if ( $this->m_dbConfig->getDBConfigItem('phptype') == 'odbc' )
		{
			$this->m_form->setDefaults(array(  'dsn'=>$this->m_dbConfig->getDBConfigItem('hostspec'), 
						     'dsn_username'=>$this->m_dbConfig->getDBConfigItem('username'),
						     'dsn_password'=>$this->m_dbConfig->getDBConfigItem('password'),
						     'type_odbc'=>$this->m_dbConfig->getDBConfigItem('dbsyntax'),
						     'dsnradio'=>0 ));
			
		}
		else 
		{	
			if(!is_null($this->m_dbConfig->getDBData()))		
			{
				$this->m_form->setDefaults(array(
						   'host'=>$this->m_dbConfig->getDBConfigItem('hostspec'),
						   'name'=>$this->m_dbConfig->getDBConfigItem('username'),
						   'password'=>$this->m_dbConfig->getDBConfigItem('password'),
						   'dbname'=>$this->m_dbConfig->getDBConfigItem('database'),
						   'type_direct'=>$this->m_dbConfig->getDBConfigItem('phptype'),
						   'port'=>$this->m_dbConfig->getDBConfigItem('port'),
						   'dsnradio'=>1 ));
			}
			else 
			{
				// The default is MySQL 3306 port:
				$this->m_form->setDefaults(array('port'=>$this->m_dbPortArr["mysql"], 'dsnradio'=>1));
			}
		}

	}
	
	function process()
	{
		$errorCode = HSP_SUCCESS;
		
		$bODBC = !(boolean)htmlspecialchars($this->m_form->exportValue('dsnradio'));			

		if ( 'POST' == $_SERVER['REQUEST_METHOD'])
		{
			$host = htmlspecialchars($this->m_form->exportValue('host'));
			$port = htmlspecialchars($this->m_form->exportValue('port'));
			$user = htmlspecialchars($this->m_form->exportValue('name'));
			$pass = htmlspecialchars($this->m_form->exportValue('password'));
			$name = htmlspecialchars($this->m_form->exportValue('dbname'));
			$typeDirect = htmlspecialchars($this->m_form->exportValue('type_direct'));
			$typeODBC = htmlspecialchars($this->m_form->exportValue('type_odbc'));
			$dsn = htmlspecialchars($this->m_form->exportValue('dsn'));
			$dsn_username = htmlspecialchars($this->m_form->exportValue('dsn_username'));
			$dsn_password = htmlspecialchars($this->m_form->exportValue('dsn_password'));				
				
			if ( $bODBC )
			{
				$type = $typeODBC;
			}
			else
			{
				$type = $typeDirect;
			}
			
					
			if ( 'true' == $this->m_form->exportValue('confirm') )
			{
				if ( $bODBC )
				{					
					$errorCode = $this->createDatabase( $type, $dsn_username, $dsn_password, $dsn, $name );
				}
				else 
				{					
					$errorCode = $this->createDatabase( $type, $user, $pass, $host, $name, $port );
				}
				
				$tmp = &$this->m_form->getElement('confirm');
				$tmp->setValue('false');
			}

			if ( HSP_SUCCESS == $errorCode )
			{
				if ($bODBC)
				{
					$errorCode = $this->isDatabaseExists( $dsn_username, $dsn_password, $host, $name, $port, $type,  $dsn);
				}
				else
				{
					$errorCode = $this->isDatabaseExists( $user, $pass, $host, $name, $port, $type);
				}
				
				if ( HSP_ERR_DB_DOES_NOT_EXISTS == $errorCode )
				{
					$this->m_bConfirmMsg = 'true';
					return;
				}
				
				if ( HSP_SUCCESS == $errorCode )
				{						
					$this->m_db  = new PearDB;
					
					if ( $bODBC )
					{							
						$this->m_db->SetODBC($dsn,$dsn_username,$dsn_password,$type);
					}
					else 
					{
						$this->m_db->SetDSN($type,$user,$pass,$host,$name,$port);
					}
					
					$errorCode = $this->m_db->Connect();
						
					if ( HSP_SUCCESS == $errorCode )
					{
						if ( $this->isDbEmpty() )
						{							
							$errorCode = $this->createDbTables( $type );
						}
						if (HSP_SUCCESS == $errorCode )
						{
							if ( $this->upgrade() == false )
							{
								$errorCode = HSP_ERR_UPGRADE_FAILED;
							}
						}
					}
					
					if ( HSP_SUCCESS == $errorCode )
					{ 
						if ( $bODBC )
						{
							$errorCode = $this->m_dbConfig ->setDBData('odbc',$dsn_username,$dsn_password,$dsn,false,false,$type);			
						}
						else
						{
							$errorCode = $this->m_dbConfig ->setDBData($type,$user,$pass,$host,$name,$port);
						}
						
						if ( HSP_SUCCESS == $errorCode )
						{
							$this->m_dbConfig->setUMftConfig('0');
							$errorCode = $this->m_dbConfig ->DBSerialize();

							if ( HSP_SUCCESS == $errorCode )
							{					
								$this->m_session->set(SESSION_DATABASE, $this->m_db );
								parent::CriaLog(DB_APPLY_BTN);
								$errorCode = $this->saveDirList();
								if( $this->m_bInit && HSP_SUCCESS == $errorCode )
								{
									// Redirect to change password
									// only when flow 0 and no error in the stack
									Header('Location: admin.php?module=userData');
									exit();
								}
							}
						}							
					}
				}					
			}
			else
			{
				$errorCode = HSP_ERR_DB_ERROR;
			}
	
			if ( HSP_SUCCESS != $errorCode )
			{
				$this->m_session->set( SESSION_ERRORS, $errorCode );
			}
			
			if ( isset( $_SESSION[SESSION_UPGRADE] ))
			{
				Header('Location: admin.php?module=maintenance');
				exit();
			}
		}
	}
	
	
	function finalize()
	{
		$displayState = 'inline';
		if( $this->m_dbConfig->getDBConfigItem('phptype') == "mssql")
		{
			$displayState='none';
		}
		
	    	$arrVars = array( "display_state"=>$displayState,
	    		 	 "DatabaseForm_confirmMsg1"=>DB_CONFIRM_CREATE_DB_TXT1,
	    		 	 "DatabaseForm_confirmMsg2"=>DB_CONFIRM_CREATE_DB_TXT2,
	    		 	 "lblApply"=>DB_APPLY_BTN,
	    		 	 "lblClear"=>DB_CLEAR_BTN,
	    		 	 "bConfirmMsg"=>$this->m_bConfirmMsg,
	    		 	 "requiredNote"=>DB_REQUIRED_TXT,
	    		 	 "msgPageChanged" => MENUITEM_CHANGES,
	    		 	 "DatabaseForm_error1_html"=>DB_DBNAME_REQ_MSG,
	    		 	 "DatabaseForm_error2_html"=>DB_HOST_REQ_MSG,
	    		 	 "DatabaseForm_error3_html"=>DB_PORT_ERR_MSG,
	    		 	 "DatabaseForm_error4_html"=>DB_NAME_REQ_MSG,
	    		 	 "DatabaseForm_error5_html"=>DB_DSN_REQ_MSG,
	    		 	 "DatabaseForm_error6_html"=>DB_DBNAME_ERR_MSG,);
	    		 	 
		parent::finalize($arrVars);
	    	
	    	
	}
	
	//we assume the DB exists if the hsp_directories table
	function isDbEmpty()
	{
		$ret = null;
		$sql = 'select * from ' .  TABLE_GENERAL .';';
		$this->m_db->GetOne($sql, $ret);

		//on error db_error object
		if ( DB::isError($ret) ) 
		{
			return true;
		}
		return false;
	}
	
	function createMySQLDB( $user, $pass, $host, $name, $port )
	{
		$errorCode = HSP_SUCCESS;				
		$pdb = new PearDB;		
		
		$pdb->SetDSN('mysql', $user, $pass, $host, 'mysql', $port );
		
		$errorCode = $pdb->Connect();
		
		if (  $errorCode == HSP_SUCCESS )
		{
			$sql = "CREATE DATABASE $name;" ;
			if ( $pdb->Query( $sql ) == HSP_ERR_DB_SQL_ERROR )
			{				
				$errorCode = HSP_ERR_DB_SQL_ERROR;
			}
				
			$pdb->Disconnect();
		}
		return $errorCode;
	}
	
	function createMSSQLDB( $user, $pass, $host, $name )
	{
		$errorCode = HSP_SUCCESS;
		
		$conn = @mssql_connect ($host, $user, $pass);
		if (true == $conn)
		{
			$succ = @mssql_query("CREATE DATABASE $name");
			if (true != $succ)
			{
				$errorCode =  HSP_ERR_DB_SQL_ERROR;
			}
			@mssql_close();
		}
		else
		{
			$errorCode =  HSP_ERR_DB_CONNECT_ERROR;
		}
		return $errorCode;
	}
	
	function createODBCDB( $dsn, $user, $pass ,$name )
	{
		$errorCode = HSP_SUCCESS;		
		
		$pdb = new PearDB;
		
		$pdb->SetODBC($dsn, $user, $pass, false);
		$errorCode = $pdb->Connect();
		
		if (  $errorCode == HSP_SUCCESS )
		{
			$sql = "CREATE DATABASE $name;" ;
			if ( $pdb->Query( $sql ) == HSP_ERR_DB_SQL_ERROR )
			{				
				$errorCode = HSP_ERR_DB_SQL_ERROR;
			}
				
			$pdb->Disconnect();
		}
		return $errorCode;
	}
	
	function isDatabaseExists( $user, $pass, $host, $name, $port, $type, $dsn=null )
	{
		$isConnected = HSP_ERR_DB_CONNECT_ERROR;
		$pdb = new PearDB;
		
		if (null != $dsn) // that means that we are in ODBC mode
		{
			$pdb->SetODBC($dsn,$user,$pass,false);
		}
		else
		{
			$pdb->SetDSN($type, $user, $pass, $host, $name, $port );
		}
		
		if ( $pdb->Connect() == HSP_SUCCESS )
		{ // db exists
			$isConnected = HSP_SUCCESS;
			$pdb->Disconnect();
		}
		elseif ($pdb->m_DB->code == -27 || $pdb->m_DB->code == -14)
		{ // no such db			
			$isConnected = HSP_ERR_DB_DOES_NOT_EXISTS;
		}
		
		return $isConnected;
	}
	
	function saveDirList()
	{
		$errorCode = HSP_SUCCESS;
		$fp = fopen('data/directoylist', 'w');
		
		$sql = 'select * from ' . TABLE_DIRECTORIES . ' order by display_name;';
		$dirArray = $this->m_db->GetAllEx( $sql , DB_FETCHMODE_ASSOC );
		
		if ( DB::isError($dirArray) ) 
		{
			$errorCode = HSP_ERR_DB_ERROR;
		}
		else 
		{
			foreach ( $dirArray as $dir )
			{
				fwrite($fp, '<option value="' .  $dir['id'] . '">'.$dir['display_name'].'</option>');
			}
		}
		
		fclose($fp);
		
		return $errorCode;
	}
	
	function createDbTables( $type )
	{
		$filename = 'includes/config/';
		
		if( 'mysql' == $type )
		{
			$filename .= 'hsp.sql';
		}
		elseif( 'mssql' == $type )
		{
			$filename .= 'hsp_mssql.sql';
		}
		
		return doRestore( $this->m_db , $filename, $type, true );
	}
	
	function createDatabase( $type, $user, $pass,  $host, $name, $port=null )
	{	
		if ( $type == 'mysql' )
		{
			$name = "`$name`"; // Added by mhoter - Sept04
			$createDBStatus = $this->createMySQLDB( $user, $pass, $host, $name, $port);
		}
		elseif ($type == 'mssql')
		{					
			$createDBStatus = $this->createMSSQLDB( $user, $pass, $host, $name);
		}						
		elseif ($type == 'odbc')
		{					
			$createDBStatus = $this->createODBCDB( $host, $user, $pass, $name);
		}	

		return $createDBStatus;	
	}
	
	function upgrade()
	{
		$upgrade = new Upgrade( $this->m_db );
		if ( $upgrade->init() )
		{
			if ( 'true' == $this->m_form->exportValue('confirm') && $upgrade->getDoUpgrade() )
			{
				unset($_SESSION[SESSION_UPGRADE]);
				$upgrade->run();
				$this->reloadDbConfig();
			}			
			elseif ( $upgrade->getDoUpgrade() )
			{
				$_SESSION[SESSION_UPGRADE] = $upgrade;
			}
			else
			{
				unset($_SESSION[SESSION_UPGRADE]);
			}
			return true;
		}
		
		return false;
	}
	
	function reloadDbConfig()
	{
		$errCode = $this->m_dbConfig->init();
		
		if ( $errCode != HSP_ERR_FILE_NOT_FOUND )
		{
			$this->m_dbConfig->DBDeserialize();
		}
		else 
		{
			$this->m_session->set(SESSION_ERRORS, $errCode);
			exit;
		}
	}	
}
?>