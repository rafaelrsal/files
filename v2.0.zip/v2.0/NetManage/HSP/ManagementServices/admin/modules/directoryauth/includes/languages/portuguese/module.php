<?PHP
define('DIRAUTH_MAIN_TXT','Diret�rio do Sistema de Autentica��o');
define('DIRAUTH_USERNAME_LBL','Nome do Usu�rio:');
define('DIRAUTH_PASSWORD_LBL','Senha:');
define('DIRAUTH_OK_BTN','  Ok  ');
define('DIRAUTH_CANCEL_BTN','Cancelar');
define('DIRAUTH_REQUIRED_TXT','verifique os campos obrigat�rios</td>');
define('DIRAUTH_USERNAME_REQ_MSG','Informe o nome do usu�rio');
define('DIRAUTH_AUTH_SUCCEEDED','Autentica��o feita com sucesso.');
define('DIRAUTH_DIRNAME_HEADER','Autentica��o para o diret�rio: ');
define('DIRAUTH_','Autentica��o para o diret�rio: ');
?>