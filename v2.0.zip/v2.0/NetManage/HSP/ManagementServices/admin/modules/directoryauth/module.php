<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: module.php
  Purpose: authenticate a directory user
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once 'HTML/QuickForm/Renderer/ITStatic.php';
require_once('HTML/QuickForm.php');
require_once 'HTML/Template/Sigma.php';
require_once('admin/modules/directories/includes/directoriesTbl.php');
require_once('admin/includes/classes/DirAuthInfo.php');

class directoryAuth extends ModuleBase
{
	var $m_callingModule;

	function directoryAuth($globalobjects, $callingModule)
	{
		parent::ModuleBase($globalobjects);

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('directoryAuthForm'); //default is post

		$this->m_callingModule = $callingModule;
	}
	
	function init()
	{
		parent::init("DirectoryAuth");

		$this->m_form->addElement('text', 'username', DIRAUTH_USERNAME_LBL, array('size' => 20, 'maxlength' => 255));
		$this->m_form->addElement('password', 'password', DIRAUTH_PASSWORD_LBL, array('size' => 20, 'maxlength' => 255));

		$this->m_form->addElement('submit', 'ok', DIRAUTH_OK_BTN, 'class="NewButton" onclick="onOk();return false;" style="width:73px;"');
		$this->m_form->addElement('button', 'cancel', DIRAUTH_CANCEL_BTN, 'class="NewButton" onclick="onCancel();" style="width:73px;"');
		$this->m_form->addElement('hidden', 'authError1', DIRAUTH_USERNAME_REQ_MSG);
		$this->m_form->addElement('hidden', 'buttonClickedAuth','');
		$this->m_form->addElement('hidden', 'callingModule', $this->m_callingModule);
		$this->m_form->addElement('hidden', 'showPleaseWait', 0);
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
	}
	
	function process()
	{
	}
	
	function  finalize()
	{
		$arrVars = array( "directoryAuthForm_required_note"=>DIRAUTH_REQUIRED_TXT);
		
		parent::finalize($arrVars);
	}
}
?>