
function initPopup()
{
	document.getElementById('popupErrors').innerHTML = "&nbsp;";
	document.getElementsByName('username').item(0).value = '';
	document.getElementsByName('username').item(0).focus();	
}

function finalizePopup()
{
	win.document.getElementById('newdir').focus();
}

function onOk()
{
	document.getElementById('popupErrors').innerHTML = "&nbsp;";
	win.document.getElementById('buttonClickedAuth').value = 'ok';
	win.document.getElementById('showPleaseWait').value = 0;
	
	if (validateForm())
	{		
		win.document.getElementById('username').value = document.getElementById('username').value;
		
		win.document.getElementById('password').value = document.getElementById('password').value;
		win.document.getElementById('showPleaseWait').value = 1;
		
		var callingModule = win.document.getElementById('callingModule').value;

      	win.document.getElementById(callingModule).submit();

		window.close();
	}
	else
	{
		document.getElementsByName('username').item(0).focus();
	}
}

function onCancel()
{
	win.document.getElementById('buttonClickedAuth').value = 'cancel';
	win.document.getElementById('showPleaseWait').value = 0;
	window.close();
}

function validateForm()
{
	if (isEmpty ( 'username' ))
	{
		document.getElementById('popupErrors').innerHTML = win.document.getElementById('authError1').value;
		return false;
	}
	else
	{
		return true;
	}
}