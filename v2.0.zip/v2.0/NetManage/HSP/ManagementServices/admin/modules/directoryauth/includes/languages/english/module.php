<?PHP
define('DIRAUTH_MAIN_TXT','System Directory Authentication');
define('DIRAUTH_USERNAME_LBL','User name:');
define('DIRAUTH_PASSWORD_LBL','Password:');
define('DIRAUTH_OK_BTN','  Ok  ');
define('DIRAUTH_CANCEL_BTN','Cancel');
define('DIRAUTH_REQUIRED_TXT','denotes required field</td>');
define('DIRAUTH_USERNAME_REQ_MSG','Enter user name');
define('DIRAUTH_AUTH_SUCCEEDED','Authentication successful.');
define('DIRAUTH_DIRNAME_HEADER','Authentication for directory: ');
define('DIRAUTH_','Authentication for directory: ');
?>