<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

define('SESSION_SET_PERMISSIONS_ITEMS', 	'setPermissionsItemDirItems');
define('SESSION_SET_PERMISSIONS_DETAILS', 	'setPermissionsItemDetails');

class setPermissions extends ModuleBase
{
	var $m_db;
	var $m_dirItemsArr;
	var $m_prevSelectedRow;	
	
	function setPermissions($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		$this->m_dirItemsArr = array();
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
		$this->m_form = new HTML_QuickForm('setPermissionsForm'); //default is post
	}
	
	function init()
	{		
		parent::init("setPermissions");
		$this->m_form->addElement('select', 'directories', SETPERMISSIONS_DIRECTORIES_LBL,$this->getDirectoriesNames(),'onchange="getUsersAndGroups();" onKeyPress="DoDefaultEnterKey(event)" style="width:200"');
		// buttons
		$this->m_form->addElement('button', 'editPermissions', 	SETPERMISSIONS_EDIT_BTN,  	'onclick=onEdit() class="NewButton" style="width:120px"');
		$this->m_form->addElement('button', 'clearPermissions',SETPERMISSIONS_CLEAR_BTN,   	'onclick=onClear() class="NewButton" style="width:120px"');
		// hiddens
		$this->m_form->addElement('hidden', 'buttonClicked','');	
		$this->m_form->addElement('hidden', 'selectedRow', 1);
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
				
		$this->m_dirItemsArr = $this->m_session->value( SESSION_SET_PERMISSIONS_ITEMS );
		$this->m_prevSelectedRow = false;
	}

	function process()
	{
		$res = HSP_SUCCESS;	
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$formValuesArray = $this->m_form->exportValues();
			
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));
			$dirID = htmlspecialchars($this->m_form->exportValue('directories'));
			
			if ( "selectChanged" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onSelectChanged($dirID);
			}
			elseif ( "editPermissions" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onEditPermissions( $dirID, $selectedRow );				
			}
			elseif( "clearPermissions" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onClearPermissions($selectedRow);
			}			
		}
		elseif ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$this->m_dirItemsArr = array();
			
			$itemDetails = $this->m_session->value(SESSION_SET_PERMISSIONS_DETAILS);

			$dirID = $itemDetails['dirID'];
			if ( $dirID )
			{
				$this->m_form->setDefaults(array('directories'=>$dirID));
				$res = $this->onSelectChanged($dirID);
				
				if(HSP_SUCCESS == $res)
				{
					$this->m_prevSelectedRow = 	$itemDetails['selectedrow'];		
					// Clean cached data of previous actions:
					$this->m_session->remove(SESSION_SET_PERMISSIONS_DETAILS);
				}
			}
		}
		
		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);			
		}
	}
	
	function finalize()
	{
		$selectedRow = $this->m_prevSelectedRow;
		if(false === $selectedRow)
		{
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));
			if ( !$selectedRow )
			{
				$selectedRow = 1;
			}
		}
				
		$arrVars = array(	"tblItems"=>$this->generateTable(),
					        "confirm_delete"=>SETPERMISSIONS_CONFIRM_DELETE_MSG,
					        "selectedRow"=>$selectedRow
					        );
        
		parent::finalize($arrVars, 'setPermissions');
	}
	
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tblItems" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(SETPERMISSIONS_TREE_LBL, SETPERMISSIONS_NAME_LBL , SETPERMISSIONS_TYPE_LBL);
		$headerAttribArr = array("class='TableHeader' width=20px","class='TableHeader' width=200px","class='TableHeader' width=100px");
		$tblBackups->addRow($headerArr , $headerAttribArr );
		
		foreach ( $this->m_dirItemsArr as $key=>$fileRow )
		{
			$rownum = $key + 1 ;
			
			$shortName = $fileRow['name'];
			
			if ( strlen($shortName) > 23 )
			{
				$shortName = substr($fileRow['name'], 0, 23) . '...';
			}
			
			$id = $fileRow['id'];
			$name = $fileRow['name'];
			$type = $fileRow['type'];

			$sql = "SELECT id FROM ".TABLE_GAT_UAT." WHERE id=$id AND name=\"$name\";";
			$recSet = $this->m_db->GetAllEx($sql);
			
			if ( count($recSet) )
			{
				$row = array ("<img src=".IMAGES_DIR."tree.gif>", $shortName , $fileRow['type'] );			
			}
			else
			{
				$row = array ("", $shortName , $fileRow['type'] );			
			}
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
			
			
			$attib = array("class='DataCell' title=''", "class='DataCell' title='$name'","class='DataCell' title=''");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}

		return $tblBackups->toHtml();
	}
	
	function getDirectoriesNames()
	{
		$dirArray = $this->m_db->GetAll(TABLE_DIRECTORIES);
		
		if ( DB::isError($dirArray) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		// retun an array with all the directories names
		$list = array(0=>SETPERMISSIONS_SELECT_DIRECTORY);
		
		foreach ($dirArray as $dir)
		{
			$list[$dir[0]] = $dir[1]; // $dir[1] name , $dir[0] dir id
		}
		natcasesort($list);
		return $list;
	}
	
	function onSelectChanged($dirID)
	{
		$this->m_dirItemsArr = array();
		
		if ( $dirID )
		{
			$recSet = $this->m_db->GetAllEx("SELECT id,name FROM ".TABLE_GROUPS." WHERE dirID=$dirID;", null, DB_FETCHMODE_ASSOC);
			if ( DB::isError($recSet) )
			{
				return HSP_ERR_DB_SQL_ERROR;
			}
			
			foreach ($recSet as $groupRecord)
			{
				$this->m_dirItemsArr[] = array('id'=>$groupRecord['id'] ,'name'=>$groupRecord['name'] , 'type'=>SETPERMISSIONS_GROUP_TXT  );
			}
			
			$recSet = $this->m_db->GetAllEx("SELECT id,name FROM ".TABLE_USERS." WHERE dirID=$dirID;", null, DB_FETCHMODE_ASSOC);
			foreach ($recSet as $userRecord)
			{
				$this->m_dirItemsArr[] = array('id'=>$userRecord['id'] ,'name'=>$userRecord['name'] , 'type'=>SETPERMISSIONS_USER_TXT );
			}
			if ( DB::isError($recSet) )
			{
				return HSP_ERR_DB_SQL_ERROR;
			}
		}
		
		$this->sortItemArr();
		
		$this->m_session->set(SESSION_SET_PERMISSIONS_ITEMS, $this->m_dirItemsArr);
		
		return HSP_SUCCESS;
	}
	
	//sort the directory list by name
	function sortItemArr()
	{
		$tmpArr = array();
		foreach($this->m_dirItemsArr as $item)
		{
			$tmpArr[] = $item['name'];
		}
		
		natcasesort($tmpArr);
		
		$newFileListArray = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $this->m_dirItemsArr as $key=>$item )
			{
				if ($name == $item['name'])
				{
					$newFileListArray[] = $item;
					unset($this->m_dirItemsArr[ $key ]);
					break;
				}
			}			
		}
		
		$this->m_dirItemsArr = $newFileListArray;
	}
	
	function onClearPermissions($selectedRow)
	{
		$name = $this->m_dirItemsArr[$selectedRow-1]['name'];
		$id = $this->m_dirItemsArr[$selectedRow-1]['id'];
		$entityType = $this->m_dirItemsArr[$selectedRow-1]['type'];
		$sql = "DELETE FROM ".TABLE_GAT_UAT. " WHERE id=$id AND name=\"$name\";";
		$ret = $this->m_db->Query($sql);		
		
		if ( DB::isError($ret) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		$fields_values = array( 'style'  => 'default', 'localstart'=>0 );
		if ( $entityType == 'User' )
		{
			$ret = $this->m_db->AutoExecute(TABLE_USERS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$id.';');
		}
		else
		{
			$ret = $this->m_db->AutoExecute(TABLE_GROUPS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$id.';');
		}
		
		if ( DB::isError($ret) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		parent::CriaLog(SETPERMISSIONS_CLEAR_BTN);
		return HSP_SUCCESS;				
	}
	
	function onEditPermissions( $dirID, $selectedRow)
	{
		$list = $this->getDirectoriesNames();

		if ( !is_array($list) )
		{
			return $list;
		}
		
		$itemDetails = array( 	'dirID'=>$dirID, 
								'displayName'=>$list[$dirID], 
								'name'=>$this->m_dirItemsArr[$selectedRow-1]['name'], 
								'id'=>$this->m_dirItemsArr[$selectedRow-1]['id'], 
								'type'=>$this->m_dirItemsArr[$selectedRow-1]['type'],
								'selectedrow'=>$selectedRow );
		
		$this->m_session->set(SESSION_SET_PERMISSIONS_DETAILS, $itemDetails);
		
		Header('Location: admin.php?module=treeAssociation&roll='.$_POST['roll']);
		exit();
	}
}
?>