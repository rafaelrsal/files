<?PHP
define('SETPERMISSIONS_EDIT_BTN','Edit Permissions');
define('SETPERMISSIONS_CLEAR_BTN','Clear Permissions');
define('SETPERMISSIONS_DIRECTORIES_LBL', 'Directories:');
define('SETPERMISSIONS_SELECT_DIRECTORY','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--- Select ---');

define('SETPERMISSIONS_TREE_LBL','');
define('SETPERMISSIONS_NAME_LBL','Name');
define('SETPERMISSIONS_TYPE_LBL','Type');


define('SETPERMISSIONS_CONFIRM_DELETE_MSG','Are you sure you want to clear the permissions for this');
define('SETPERMISSIONS_USER_TXT','User');
define('SETPERMISSIONS_GROUP_TXT','Group');

?>