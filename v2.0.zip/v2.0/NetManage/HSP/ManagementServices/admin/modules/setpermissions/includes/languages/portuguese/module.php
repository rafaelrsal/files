<?PHP
define('SETPERMISSIONS_EDIT_BTN','Editar Permiss�es');
define('SETPERMISSIONS_CLEAR_BTN','Limpar Permiss�es');
define('SETPERMISSIONS_DIRECTORIES_LBL', 'Diret�rios:');
define('SETPERMISSIONS_SELECT_DIRECTORY','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--- Selecionar ---');

define('SETPERMISSIONS_TREE_LBL','');
define('SETPERMISSIONS_NAME_LBL','Nome');
define('SETPERMISSIONS_TYPE_LBL','Tipo');


define('SETPERMISSIONS_CONFIRM_DELETE_MSG','Voc� tem certeza que deseja limpar as permiss�es para este');
define('SETPERMISSIONS_USER_TXT','Usu�rio');
define('SETPERMISSIONS_GROUP_TXT','Grupo');

?>