function initPopup()
{
	document.getElementById('popupErrors').innerHTML = '&nbsp;';
	document.getElementsByName('dirname').item(0).focus();
}

function finalizePopup()
{	
	if ( validateForm() )			
	{			    
		 saveDirectory()
	}
	else
	{
		document.getElementsByName('dirname').item(0).focus();
	}
}

function saveDirectory()
{
	if ( 'true' == win.document.getElementsByName('bEditMode').item(0).value)
	{
		win.document.getElementsByName('buttonClicked').item(0).value 	= 'edit';
	}
	else
	{
		win.document.getElementsByName('buttonClicked').item(0).value 	= 'new';
	}
	win.document.getElementsByName('dirname').item(0).value 			= document.getElementsByName('dirname').item(0).value;
	win.document.getElementsByName('description').item(0).value 	= document.getElementsByName('description').item(0).value;
	
	win.document.getElementById('customDirectoriesForm').submit();
	window.close();
}

function validateForm()
{	
	if (isEmpty ( 'dirname' ))
	{    
		document.getElementById('popupErrors').innerHTML = win.document.getElementById('error1').value;
		return false;
	}
	return true;
}
