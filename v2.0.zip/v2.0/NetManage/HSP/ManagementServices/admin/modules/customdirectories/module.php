<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

require_once('admin/modules/directories/module.php');

define('INTERNALDIR_ID', 'internalDirId');
define('SESSION_IMPORT_CONFIGURATION_DATA', 'importConfigurationData');

class customDirectories extends ModuleBase
{
	var $m_db;
	var $m_bEditMode;
	var $m_editDirDetails;
	
	var $m_internalDirArr;

	var $m_globalobjects;
	
	var $m_roll;
	
	function customDirectories($globalobjects)
	{
		$this->m_globalobjects = $globalobjects;
		parent::ModuleBase($globalobjects);
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();

		$this->m_form = new HTML_QuickForm('customDirectoriesForm'); //default is post
		
		$this->m_bEditMode = 'false'; //used only when the edit button is pressed		
		$this->m_editDirDetails = array();
	}
	
	function init()
	{		
		parent::init("customDirectories");
		
		$this->m_form->addElement('button', 'newDir', 			CUSTOMDIR_NEW_BTN, "class='NewButton' onclick='onNew();return false;'");
		$this->m_form->addElement('submit', 'editDir', 			CUSTOMDIR_EDIT_BTN,  "onclick=onBeforeEdit() class='NewButton'");
		$this->m_form->addElement('button', 'manageUsersGroups',CUSTOMDIR_MANAGE_USERS_GROUPS_BTN,  'onclick=onManageUsersGroups() class="NewButton" style=width:140px');		
		$this->m_form->addElement('button', 'deleteDir',		CUSTOMDIR_DELETE_BTN,   "onclick=onDelete() class='NewButton'");
		
		$this->m_form->addElement('submit', 'save', 			CUSTOMDIR_SAVE_BTN,  "class='NewButton' onclick='setContent();return false;'");
		$this->m_form->addElement('button', 'cancel', 			CUSTOMDIR_CANCEL_BTN,  "class='NewButton' onclick='self.close();'");		
		$this->m_form->addElement('button', 'import', 			CUSTOMDIR_IMPORT_BTN,  "class='NewButton' onclick='onImport();showWaitEx();'");
		
		$this->m_form->addElement('text', 'dirname', 			CUSTOMDIR_NAME_LBL, array('size' => 20, 'maxlength' => 255, 'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'description', 		CUSTOMDIR_DESCRIPTION_LBL, array('size' => 40, 'maxlength' => 255, 'class' => 'FixedWidthObjects', 'style' => 'width:300px'));
		
		$this->m_form->addElement('hidden',	'dirname');
		$this->m_form->addElement('hidden', 'description');		
		$this->m_form->addElement('hidden', 'buttonClicked','');
		$this->m_form->addElement('hidden', 'selectedRow', 1);

		$this->m_form->addElement('hidden', 'error1', CUSTOMDIR_NAME_REQ_MSG);
		$this->m_form->addElement('hidden', 'bEditMode', '');
		
		//*************GUILHERME LIMA 08/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->populateDirListArr();
	}

	function process()
	{
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$res = HSP_SUCCESS;		
			
			$formValuesArray = $this->m_form->exportValues();
			
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));			
			
			if ( "new" == $formValuesArray['buttonClicked'] )
			{
				$res = $this->onNew();
			}
			elseif ("edit" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onEdit($selectedRow);
			}
			elseif ( "delete" == $formValuesArray['buttonClicked'] )
			{	
				$this->onDelete($selectedRow);
			}
			elseif ( "beforeEdit" == $formValuesArray['buttonClicked'] )
			{					
				$this->onBeforeEdit($selectedRow);
			}
			elseif ( "onManageUsersGroups" == $formValuesArray['buttonClicked'] )
			{			
				$this->onManageUsersGroups($selectedRow);
			}
			elseif ( "import" == $formValuesArray['buttonClicked'] )
			{
				$this->m_session->remove(SESSION_IMPORT_CONFIGURATION_DATA);
				
				$this->onImport($selectedRow);
				Header("Location: admin.php?module=importDirectories&roll=".$_POST['roll']);
				exit();
			}
			
			if(HSP_SUCCESS != $res)
			{
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);				
			}
			else
			{
				// we call populate on success in order to reflect the new state
				$this->populateDirListArr();
			}
		}
	}
	
	function finalize()
	{
		$language = parent::GetLanguage();
		
		$arrVars = array(	"tbldir"=>$this->generateTable(),					        
					        "confirm_delete"=>CUSTOMDIR_CONFIRM_DELETE_MSG,
					        "selectedRow"=>$this->getSelectedDirIndex(),
					        "lblNew"=>rawurlencode(CUSTOMDIR_NEW_DIR),
					        "moduleName"=>$this->m_moduleName,
					        'editMode'=> $this->m_bEditMode,
					        'customDirForm_required_note'=>CUSTOMDIR_REQUIRED_TXT);
					        
		if ( $this->m_bEditMode == 'true')
		{
			$name = $this->m_editDirDetails[0]['name'];
			$name = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;", "'"), array(">", "<", "\"", "&", "\'"), $name);
			
			$description = $this->m_editDirDetails[0]['description'];
			$description = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;", "'"), array(">", "<", "\"", "&", "\'"), $description);
						
			$arrVarsEditMode = array(	'dirname'=>$name,
										'description'=> $description,
										'lblEdit'=>rawurlencode(CUSTOMDIR_EDIT_DIR));
						
			$arrVars = array_merge($arrVars, $arrVarsEditMode );
		}					        
        
		parent::finalize( $arrVars , 'customDirectories' );
	}
	
	function getSelectedDirIndex()
	{
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		if ( false == $dirId )
		{
			return 1;
		}
		
		foreach ( $this->m_internalDirArr as $index=>$dir )
		{
			if ( $dir['id'] == $dirId )
			{
				return $index+1;
			}
		}
		
		return 1; // we never get here.
	}
	
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tbldir" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(CUSTOMDIR_NAME_LBL , CUSTOMDIR_DESCRIPTION_LBL);
		$headerAttribArr = array("class='TableHeader' width=200px","class='TableHeader' width=400px");
		$tblBackups->addRow($headerArr , $headerAttribArr );
		
		foreach ( $this->m_internalDirArr as $key=>$dirRow )
		{
			$rownum = $key + 1 ;
			
			$shortName = $dirRow['name'];
			
			if ( strlen($shortName) > 23 )
			{
				$shortName = substr($dirRow['name'], 0, 23) . '...';
			}
			
			$shortDesc = $dirRow['description'];
			
			if ( strlen($shortDesc) > 47 )
			{
				$shortDesc = substr($dirRow['description'], 0, 47) . '...';
			}			
			
			$row = array ( $shortName , $shortDesc );			
			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
		
			$name = $dirRow['name'];
			$description = $dirRow['description'];
			$attib = array("class='DataCell' title='$name'","class='DataCell' title='$description'");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}
		
		return $tblBackups->toHtml();
	}
	
	function populateDirListArr()
	{
		$this->m_internalDirArr = $this->m_db->GetAllEx("SELECT * FROM ".TABLE_CUSTOM_DIRECTORY . ";", null, DB_FETCHMODE_ASSOC);
		
 		$this->sortDirArr();
	}
	
	//sort the directory list by name
	function sortDirArr()
	{
		$tmpArr = array();
		foreach($this->m_internalDirArr as $directoryItem)
		{
			$tmpArr[] = $directoryItem['name'];
		}
		
		natcasesort($tmpArr);
		
		$newFileListArray = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $this->m_internalDirArr as $directoryItem )
			{
				if ($name == $directoryItem['name'] )
				{
					$newFileListArray[] = $directoryItem;
					break;
				}
			}			
		}
		
		$this->m_internalDirArr = $newFileListArray;
	}
	
	function onNew()
	{	
		$name = htmlspecialchars($this->m_form->exportValue('dirname'));
		$name = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $name);
		$desc = htmlspecialchars($this->m_form->exportValue('description'));		
		$desc = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $desc);
		
		$fields_values = array(	'name'=>$name ,
								'description'=>$desc );
		
		$sql = "SELECT COUNT(name) FROM " . TABLE_CUSTOM_DIRECTORY ." WHERE name=\"$name\";";
		$this->m_db->GetOne($sql, $count);
		if ( DB::isError($count) )
		{
			return HSP_ERR_DB_ERROR;
		}
		if (!$count)
		{
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_DIRECTORY, $fields_values );
			if ( DB::isError($ret) )
			{
				return HSP_ERR_DB_ERROR;
			}
			$sql = "SELECT MAX( id ) FROM " . TABLE_CUSTOM_DIRECTORY .";";
			$this->m_db->GetOne($sql, $dirId);
			if ( DB::isError($dirId) )
			{
				return HSP_ERR_DB_ERROR;
			}
		}
		else
		{
			return HSP_ERR_DIRNAME_ALREADY_DEFINED;
		}

		$this->m_session->set(INTERNALDIR_ID, $dirId );
		parent::CriaLog(CUSTOMDIR_NEW_BTN); 
		return HSP_SUCCESS;
	}
	
	function onBeforeEdit($selectedRow)
	{
		$dirId = $this->m_internalDirArr[$selectedRow-1]['id'];
		
		$sql = "SELECT name, description FROM ".TABLE_CUSTOM_DIRECTORY." WHERE id=".$dirId.";";
		$ret = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		
		if ( DB::isError($ret) )
		{
			return HSP_ERR_DB_ERROR;
		}
		
		$this->m_session->set(INTERNALDIR_ID, $dirId );
		
		$this->m_editDirDetails = $ret;
		$this->m_bEditMode = 'true';
		return HSP_SUCCESS;
	}
	
	function onEdit($selectedRow)
	{
		$name = htmlspecialchars($this->m_form->exportValue('dirname'));
		$name = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $name);
		$desc = htmlspecialchars($this->m_form->exportValue('description'));		
		$desc = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $desc);

		$fields_values = array(	'name'=>$name ,
								'description'=>$desc );

		$dirId = $this->m_internalDirArr[$selectedRow-1]['id'];
		$sql = "SELECT COUNT(name) FROM " . TABLE_CUSTOM_DIRECTORY ." WHERE name=\"$name\" AND id!=$dirId;";
		$this->m_db->GetOne($sql, $count);
		if ( DB::isError($count) )
		{
			return HSP_ERR_DB_ERROR;
		}
		if (!$count)
		{
			$this->m_db->AutoExecute( TABLE_CUSTOM_DIRECTORY, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$dirId.';' );
			$directoryFieldsValues = array(	'host'=>$name );
			
			$ret = $this->m_db->AutoExecute( TABLE_DIRECTORIES, $directoryFieldsValues, DB_AUTOQUERY_UPDATE,'customDirId='.$dirId.';' );
			
			if ( HSP_SUCCESS != $ret ) 
			{
				return HSP_ERR_DB_ERROR;
			}
			
			$this->m_session->set(INTERNALDIR_ID, $dirId );
			parent::CriaLog(CUSTOMDIR_EDIT_BTN); 
			return HSP_SUCCESS;
		}
		else
		{
			return HSP_ERR_DIRNAME_ALREADY_DEFINED;
		}
				
	}
	
	function onManageUsersGroups($selectedRow)
	{
		$dirId = $this->m_internalDirArr[$selectedRow-1]['id'];		
		Header("Location: admin.php?module=editCustomDir&dirId=$dirId&roll=".$_POST['roll']); // roll--> parte para administra��o de menu
		exit();
	}

	function onDelete($selectedRow)
	{
		$retVal = HSP_SUCCESS;
		$id = $this->m_internalDirArr[$selectedRow-1]['id'];
		
		$sql = "DELETE FROM ".TABLE_CUSTOM_DIRECTORY . " WHERE id={$id};";
		$ret = $this->m_db->Query($sql);
		if ( !DB::isError($ret) )
		{
			unset($this->m_internalDirArr[$selectedRow - 1]);
		}
		else
		{
			$retVal = HSP_ERR_DB_SQL_ERROR;
		}
		
		$sql = "SELECT id FROM ".TABLE_DIRECTORIES . " WHERE customDirId={$id};";
		$this->m_db->GetOne( $sql, $dirId);
		if ( !DB::isError($dirId) )
		{
			$retVal = HSP_ERR_DB_SQL_ERROR;
		}
		
		// use the directories module to perform the deletion operations 
		// from Gat/Uat and from Groups/Users tables
		$directories = new directories($this->m_globalobjects);
		$ret = $directories->removeFromGatUat($dirId);
		if ( !DB::isError($ret) )
		{
			$retVal = HSP_ERR_DB_SQL_ERROR;
		}
		$ret = $directories->removeImportedGroupsAndUsers($dirId);
		if ( !DB::isError($ret) )
		{
			$retVal = HSP_ERR_DB_SQL_ERROR;
		}
		
		$sql = "DELETE FROM ".TABLE_DIRECTORIES . " WHERE customDirId={$id};";
		$ret = $this->m_db->Query($sql);
		if ( !DB::isError($ret) )
		{
			$retVal = HSP_ERR_DB_SQL_ERROR;
		}

		$sql = "SELECT id FROM " . TABLE_CUSTOM_USERS . " WHERE dirId={$id};";
		$customUsers = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC );
		if ( is_array($customUsers) )
		{
			foreach ($customUsers as $user )
			{
				$userId = $user['id'];
				$sql = "DELETE FROM ". TABLE_CUSTOM_CROSS . " WHERE userId={$userId};";
				$ret = $this->m_db->Query($sql);
			}
		}
		
		$sql = "SELECT id FROM " . TABLE_CUSTOM_GROUPS . " WHERE dirId={$id};";
		$customGroups = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC );
		if ( is_array($customGroups) )
		{
			foreach ($customGroups as $group )
			{
				$groupId = $group['id'];
				$sql = "DELETE FROM ". TABLE_CUSTOM_CROSS . " WHERE userId={$groupId};";
				$ret = $this->m_db->Query($sql);
			}
		}
		
		$sql = "DELETE FROM ". TABLE_CUSTOM_USERS . " WHERE dirId={$id};";
		$ret = $this->m_db->Query($sql);
		$sql = "DELETE FROM ".TABLE_CUSTOM_GROUPS . " WHERE dirId={$id};";
		$ret = $this->m_db->Query($sql);
		$this->m_session->remove(INTERNALDIR_ID);
		parent::CriaLog(CUSTOMDIR_DELETE_BTN);
		return $retVal;
	}
	
	function onImport($selectedRow)
	{
		$dirId = $this->m_internalDirArr[$selectedRow-1]['id'];
		$this->m_session->set(INTERNALDIR_ID, $dirId );	
	}
}
?>