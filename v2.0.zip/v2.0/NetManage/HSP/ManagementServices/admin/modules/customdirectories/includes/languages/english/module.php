<?PHP
define('CUSTOMDIR_NEW_BTN','New');
define('CUSTOMDIR_EDIT_BTN','Edit');
define('CUSTOMDIR_MANAGE_USERS_GROUPS_BTN','Users and Groups');

define('CUSTOMDIR_DELETE_BTN','Delete');
define('CUSTOMDIR_SAVE_BTN','Save');
define('CUSTOMDIR_CANCEL_BTN','Cancel');
define('CUSTOMDIR_IMPORT_BTN','Import');

define('CUSTOMDIR_NAME_LBL','Directory name');
define('CUSTOMDIR_DESCRIPTION_LBL','Description');

define('CUSTOMDIR_CONFIRM_DELETE_MSG','Are you sure you want to delete this directory?');
define('CUSTOMDIR_NEW_DIR','New Directory');
define('CUSTOMDIR_EDIT_DIR','Edit Directory');

define('CUSTOMDIR_NAME_REQ_MSG','Enter directory name.');
define('CUSTOMDIR_REQUIRED_TXT','denotes required field');
?>