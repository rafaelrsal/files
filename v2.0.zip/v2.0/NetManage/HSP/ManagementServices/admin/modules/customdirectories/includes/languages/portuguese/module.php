<?PHP
define('CUSTOMDIR_NEW_BTN','Novo');
define('CUSTOMDIR_EDIT_BTN','Editar');
define('CUSTOMDIR_MANAGE_USERS_GROUPS_BTN','Usu�rios e Grupos');

define('CUSTOMDIR_DELETE_BTN','Remover');
define('CUSTOMDIR_SAVE_BTN','Salvar');
define('CUSTOMDIR_CANCEL_BTN','Cancelar');
define('CUSTOMDIR_IMPORT_BTN','Importar');

define('CUSTOMDIR_NAME_LBL','Nome do Diret�rio');
define('CUSTOMDIR_DESCRIPTION_LBL','Descri��o');

define('CUSTOMDIR_CONFIRM_DELETE_MSG','Voc� tem certeza que deseja remover este diret�rio?');
define('CUSTOMDIR_NEW_DIR','Novo Diret�rio');
define('CUSTOMDIR_EDIT_DIR','Editar Diret�rio');

define('CUSTOMDIR_NAME_REQ_MSG','Informe o nome do diret�rio.');
define('CUSTOMDIR_REQUIRED_TXT','verifique ');
?>