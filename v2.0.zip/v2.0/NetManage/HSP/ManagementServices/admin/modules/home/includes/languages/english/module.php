<?PHP
define('HOME_MAIN_TXT','Welcome to Host Services Platform - Version ');
define('HOME_HSP_TXT','
<center>
<table>
<tr>
<td>
Host Services Platform (HSP), a single, unified platform to
consolidate host access, presentation and integration projects,
works smoothly and effortlessly across your entire host
environment.<br><br> 
It provides a common underlying framework that
integrates host systems, desktops, and wireless devices to new
Web-based solutions. The platform works seamlessly with .NET,
Web services and Java applications.<br><br>
Host Services Platform offers a modular, standards-based design
that connects NetManage RUMBA� and OnWeb� products to
create unified host access, presentation and integration services.
</td>
</tr>
</table>
</center>
');
define('HOME_STATISTICS','Statistics:');
define('HOME_MONITORED_USERS_LBL','Number of monitored users: ');
define('HOME_OPEN_SESSIONS_LBL','Number of open sessions: ');
?>