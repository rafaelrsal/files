<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: global_defines.php
  Purpose: 
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('HTML/QuickForm.php');

class Home extends ModuleBase
{
	var $m_version;
	function Home($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
		$this->m_db->getOne("select version from " . TABLE_GENERAL. ";" ,$this->m_version);
		
		if ( DB::isError($this->m_version) )
		{
			$this->m_version = "1.0";
		}
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('ConcurrencyForm'); //default is post
	}
	
	function init()
	{
		parent::init("home");

	}
	
	function process()
	{
		// do nothing
	}
	
	function finalize()
	{
		$arrVars = array(	'lblWelcomeText'=>HOME_HSP_TXT,							
							'lblWelcomeHead'=>HOME_MAIN_TXT . $this->m_version );
							
		parent::finalize($arrVars);
	}
}
?>