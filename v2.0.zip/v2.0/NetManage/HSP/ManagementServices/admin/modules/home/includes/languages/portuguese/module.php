<?PHP
define('HOME_MAIN_TXT','Bem vindo ao Portal de Administra��o dos Acessos aos Hosts - Version ');
define('HOME_HSP_TXT','
<center>
<table>
<tr>
<td>
O Host Services Platform (HSP), � uma plataforma unificada para 
consolidar o acesso aos hosts, aplica��es web e projetos de integra��o,
disponibilizando de forma f�cil e eficiente o acesso a todo os ambientes
legados.<br><br> 
Ele prov� uma estrutura comum que integra os sistemas legados,
desktops, e dispositivos sem fio eum uma nova solu��o baseada 
na plataforma web. A plataforma funciona perfeitamente com .NET,
Web services e aplica��es Java.<br><br>
O Host Services Platform oferece um design modular baseado em padr�es
que conectam os produtos Micro Focus RUMBA� e OnWeb� criando uma 
forma unificada de acesso �s aplica��es legados, apresenta��es, 
aplica��es web e servi�os de integra��o.
</td>
</tr>
</table>
</center>
');
define('HOME_STATISTICS','Estat�sticas:');
define('HOME_MONITORED_USERS_LBL','N�mero de usu�rios monitorados: ');
define('HOME_OPEN_SESSIONS_LBL','N�mero de sess�es abertas: ');
?>