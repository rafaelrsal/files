<?PHP
define('USERS_MAIN_TXT','Users');
define('USERS_HELP_LNK','Help');
define('USERS_REQUIRED_TXT','denotes required field');
define('USERS_DIRECTORIES_LBL','Directories:');
define('USERS_LIST_LBL','Available Users:');
define('USERS_IMPORTED_LBL','Selected Users:');
define('USERS_IMPORT_BTN','Show Users');
define('USERS_CLEAR_BTN', 'Clear');
define('USERS_ADD_BTN','   Add ->   ');
define('USERS_REMOVE_BTN','<- Remove');
define('USERS_SAVE_BTN','   Save   ');
define('USERS_ASSOCIATE_BTN','Associate  ');
define('USERS_CHOOSE_DIR_TXT','Select a directory...');
define('USERS_SELECT','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--- Select ---');
define('USERS_VERIFY_DLG','Verify Connection');
?>