<?PHP
define('USERS_MAIN_TXT','Usu�rios');
define('USERS_HELP_LNK','Ajuda');
define('USERS_REQUIRED_TXT','verifique os campos obrigat�rios');
define('USERS_DIRECTORIES_LBL','Diret�rios:');
define('USERS_LIST_LBL','Usu�rios Dispon�veis:');
define('USERS_IMPORTED_LBL','Usu�rios Selecionados:');
define('USERS_IMPORT_BTN','Exibir Usu�rios');
define('USERS_CLEAR_BTN', 'Limpar');
define('USERS_ADD_BTN','   Adicionar ->   ');
define('USERS_REMOVE_BTN','<- Remover');
define('USERS_SAVE_BTN','   Salvar   ');
define('USERS_ASSOCIATE_BTN','Associar  ');
define('USERS_CHOOSE_DIR_TXT','Selecione um diret�rio...');
define('USERS_SELECT','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--- Selecionar ---');
define('USERS_VERIFY_DLG','Verificar Conex�o');
?>