<?PHP

require_once('HTML/QuickForm.php');
require_once('admin/modules/users/includes/usersTbl.php');
require_once('admin/modules/users/includes/user.php');
require_once('admin/modules/DirectoryAuth/module.php');
require_once('admin/includes/classes/authentication.php');


define('SESSION_AVAILABLE_USERS','availableUsers');
define('SESSION_IMPORTED_USERS','importedUsers');
define('SESSION_DB_USERS','dbUsers');
define('PAGECHANGED', 'pageChanged');

class users extends ModuleBase
{
	var $m_dirArray;
	var $m_usersTbl;	
	var $m_availableUsers;
	var $m_importedUsers;
	var $m_usersObjArr;
	var $m_dirId;
	var $m_popup;

	function users($globalobjects)
	{
		///////////////////////////////////
		parent::ModuleBase($globalobjects);		
		$this->m_usersTbl = new usersTbl( $this->GetDatabase() );
		
		// initializations
		$this->m_dirArray = array();
		$this->m_usersObjArr = array();
		
		// Instantiate the HTML_QuickForm object
		$formName = 'UsersForm';
		$this->m_form = new HTML_QuickForm($formName); //default is post
		$this->m_dirAuthObj = new directoryAuth($globalobjects, $formName);
		$this->m_dirAuthObj->init();
		$this->m_dirAuthObj->process();
		$this->m_dirAuthObj->finalize();
		
		$this->m_popup = 'false';
	}
	
	function init()
	{
		parent::init("users");
		$this->getAllDirectories();

		// get all arrays from session variable
		if ( $this->m_session->exists(SESSION_AVAILABLE_USERS))
		{
			$this->m_availableUsers = $this->m_session->value(SESSION_AVAILABLE_USERS);
		}

		if ( $this->m_session->exists(SESSION_IMPORTED_USERS))
		{
			$this->m_importedUsers= $this->m_session->value(SESSION_IMPORTED_USERS);
		}

		if ( $this->m_session->exists(SESSION_DB_USERS))
		{
			$this->m_usersObjArr= $this->m_session->value(SESSION_DB_USERS);
		}


		$this->m_form->addElement('header', 'header', USERS_MAIN_TXT);
		$this->m_form->addElement('select', 'directories', USERS_DIRECTORIES_LBL,$this->getDirectoriesNames(),'onchange="GetUsers();" style="width:200" onKeyPress="DoDefaultEnterKey(event)"');
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$this->m_form->addElement('select', 'availableUsers', USERS_LIST_LBL,$this->m_availableUsers,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
			$this->m_form->addElement('select', 'importedUsers', USERS_IMPORTED_LBL,$this->m_importedUsers,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
		}
		else
		{
			$this->m_form->addElement('select', 'availableUsers', USERS_LIST_LBL,null,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
			$this->m_form->addElement('select', 'importedUsers', USERS_IMPORTED_LBL,null,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
		}
		$this->m_form->addElement('submit', 'import', USERS_IMPORT_BTN);
		$this->m_form->addElement('submit', 'clear', USERS_CLEAR_BTN);
		$this->m_form->addElement('submit', 'add', USERS_ADD_BTN,"class='NewButton ShortFixedWidthObjects'");
		$this->m_form->addElement('submit', 'remove', USERS_REMOVE_BTN,"class='NewButton ShortFixedWidthObjects'");
		$this->m_form->addElement('submit', 'save', USERS_SAVE_BTN,"class='NewButton ShortFixedWidthObjects'");
		$this->m_form->addElement('submit', 'associate', USERS_ASSOCIATE_BTN,"class='NewButton ShortFixedWidthObjects'");	
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);		
	}
	
	function process()
	{
		$res = HSP_SUCCESS;
		$errorCode = null;

		$this->m_formValuesArray = $this->m_form->exportValues();

		$dirID = htmlspecialchars($this->m_form->exportValue('directories'));
		if (strlen($dirID))
		{
			if (array_key_exists("add", $this->m_formValuesArray))
			{
				$this->addToImportedList($dirID);
				$this->populateImportedList();
				$this->populateAvailableList();
				$this->m_session->set(PAGECHANGED, 'changed');
			}
			elseif (array_key_exists("remove", $this->m_formValuesArray))
			{
				$this->removeFromImportedList();
				$this->populateImportedList();
				$this->populateAvailableList();
				$this->m_session->set(PAGECHANGED, 'changed');
			}
			elseif (array_key_exists("import", $this->m_formValuesArray))
			{
				$this->onShowUsers($dirID);
			}
			elseif (array_key_exists("save", $this->m_formValuesArray))
			{
				$res = $this->saveImportedList2DB($dirID);
			}
			elseif (array_key_exists("associate", $this->m_formValuesArray))
			{
				$this->associateUsers();
				$this->populateImportedList();
				$this->populateAvailableList();
			}
			elseif ( array_key_exists("clear", $this->m_formValuesArray) )
			{		
				$this->onClearUsers();
			}
			elseif (isset( $_POST['buttonClickedAuth'] ) && 'ok' == $_POST['buttonClickedAuth'])
			{
				$userName = $_POST['username'];
				$password = $_POST['password'];
				
				$res = $this->authenticate($userName, $password, $dirID);
				if ( HSP_SUCCESS != $res )
				{					
					$errorCode = $res;
					// javascript POPUP
					$this->m_popup = 'true';
				}
				else
				{
					$this->onShowUsers($dirID);
				}
			}
			
			if ( null != $errorCode )
			{
				$dirID = 0;
				$this->m_session->set(SESSION_ERRORS, $errorCode);
			}
		}
		else
		{
			$dirID = 0;
		}
		
		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
		
		$this->m_dirId = $dirID;
	}
	
	function finalize()
	{
		$isChangedVar = null;	
		if ($this->m_session->exists(PAGECHANGED) && $this->m_session->value(PAGECHANGED) == 'changed')
		{
			$isChangedVar = true;					
		}
		else
		{
			$isChangedVar = 0;			
		}
		
		$arrVars = array( 'isChangedVar'=> $isChangedVar,		
				'dirID'=> $this->m_dirId,
				'msgPageChanged'=> MENUITEM_CHANGES,
				'authenticatePopup'=> $this->m_popup,
				'moduleName'=>  $this->m_moduleName,		
				'authTitle'=> USERS_VERIFY_DLG,       
				'authenticationDiv'=>  $this->m_dirAuthObj->GetContent() );
		
		$this->m_session->remove(PAGECHANGED);
		parent::finalize($arrVars);
	}

	function getAllDirectories()
	{
		// get all domain names from db
		$this->m_dirArray = $this->m_usersTbl->getAllDirectories();
	}


	function getDirectoriesNames()
	{
		// retun an array with all the directories names
		$list = array(0=>USERS_SELECT);
		//$list[-1] = USERS_CHOOSE_DIR_TXT;
		foreach ($this->m_dirArray as $dir)
		{
			$list[$dir[0]] = $dir[1]; // $dir[1] name , $dir[0] dir id
		}
		natcasesort($list);
		return $list;
	}
	
	function getDirectoryUsers($dirID)
	{
		$retVal = false;
		
		// get all groups from the directory via gennady's dll
		$result = HSP_SUCCESS;
		$userName = '';
		$password = '';
		
		$isCustomDir = $this->m_usersTbl->isCustomDir($dirID);
		
		if ( !$isCustomDir )
		{
			if ($this->m_session->exists( SESSION_DIR_AUTH_CACHE ))
			{ // session var does exists...
				$dirAuthCache = $this->m_session->value( SESSION_DIR_AUTH_CACHE );
	
				if ( array_key_exists($dirID, $dirAuthCache))
				{
					$userName = $dirAuthCache[$dirID]->m_userName;
					$password = $dirAuthCache[$dirID]->m_Password;
					$result = $this->authenticate( $userName, $password , $dirID );
				}
				else
				{ 
					// javascript POPUP
					$this->m_popup = 'true';
				}			
			}
			else
			{ 
				// javascript POPUP
				$this->m_popup = 'true';
			}
		}
		
		if ( HSP_SUCCESS == $result && 'false' == $this->m_popup)
		{
			$this->m_availableUsers = array();
	
			if (!$isCustomDir)
			{
				if(!extension_loaded(PHP_AUTH_MODULE))
				{
					dl(PHP_AUTH_DLL);
				}
				
				$recSet = $this->m_usersTbl->getDirectoryDetails($dirID);
				
				if ( HSP_ERR_DB_SQL_ERROR != $recSet)
				{
					$users = getdirectoryusers(	$userName,
									$password,
									$recSet['host'],
									$recSet['host'],
									$recSet['type_dir'],
									$recSet['port'],
									$recSet['base_dn'],
									$recSet['group_dn'],
									$recSet['user_dn'],
									$recSet['ldap_user_identifier'] );
				}
				else
				{
					$this->m_session->set(SESSION_ERRORS, $recSet);
				}
			}
			else
			{
				$users = $this->m_usersTbl->getCustomDirUsers($dirID);
			}
	
			if ( is_array($users) && count($users)) //the groups variable is not an array when error code is returned.
			{
				unset($this->m_availableUsers);
				foreach($users as $dirName)
				{
					$this->m_availableUsers[] = $dirName;
				}
				natcasesort($this->m_availableUsers);
			}
			$retVal = true;
		}
		else if ( HSP_SUCCESS != $result)
		{
			$this->m_availableUsers = array();
			$this->m_importedUsers = array();
			
			// javascript POPUP
			$this->m_popup = 'true';
			
			//authenticaion error
			$this->m_session->set(SESSION_ERRORS, $result);
		}
		else if (HSP_SUCCESS == $result)
		{
			$this->onClearUsers();
		}
		
		return $retVal;
	}

	function getImportedListFromDB($dirID)
	{
		// get users from hsp database and populate the arrays for the list

		if (isset($this->m_usersObjArr))
		{
			// clear the users object array
			unset($this->m_usersObjArr);
			$this->m_usersObjArr = array();
		}

		// get all imported users from database
		$recordSet = $this->m_usersTbl->getAllUsersByDirID($dirID);
		foreach ($recordSet as $userRecord)
		{
			$this->m_usersObjArr[] = new user($dirID , $userRecord[1] , $userRecord[0]);
		}

		$this->m_session->set(SESSION_DB_USERS, $this->m_usersObjArr);

		if (isset($this->m_importedUsers))
		{
			unset($this->m_importedUsers);
		}
		$this->m_importedUsers = array();
		foreach ($this->m_usersObjArr as $userObj)
		{
			$this->m_importedUsers[] = $userObj->m_Name;
		}

		natcasesort($this->m_importedUsers);
	}

	function populateAvailableList()
	{
		// in order to repopulate the list we unfortunatly need to
		// remove the element from the form and add it again

		$this->m_form->removeElement('availableUsers');
		$this->m_form->addElement('select', 'availableUsers', USERS_LIST_LBL,$this->m_availableUsers,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
	}

	function populateImportedList()
	{
		// in order to repopulate the list we unfortunatly need to
		// remove the element from the form and add it again

		$this->m_form->removeElement('importedUsers');
		$this->m_form->addElement('select', 'importedUsers', USERS_IMPORTED_LBL,$this->m_importedUsers,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
	}

	function synchronizeList()
	{
		// initially we get a list of all users from the directory and a list of
		// already imported users from the hsp database.
		// we need to remove the users in the imported list from the list of users
		// from the directory (available users).



		foreach ($this->m_importedUsers as $importedKey=>$imported)
		{
			if( in_array($imported,$this->m_availableUsers) )
			{
				while(($gotcha = array_search($imported,$this->m_availableUsers)) > -1)
				{
					unset($this->m_availableUsers[$gotcha]);
				}
			}
			else
			{
				foreach ( $this->m_usersObjArr as $key=>$userObj)
	   			{
	   				if ( $userObj->m_Name == $imported )
	   				{
	   					// if a user exists in the imported list but not in the available list
						// we will change it's name to [name] both in the array and in the user's object
	   					$this->m_importedUsers[$importedKey] = '['.$this->m_usersObjArr[$key]->m_Name .']';

	   					$this->m_usersObjArr[$key]->m_isAssociated = false;
	   					$this->m_usersObjArr[$key]->m_Name = '['. $this->m_usersObjArr[$key]->m_Name .']';
	   				} // end if
	   			} // end foreach
	   			$this->m_session->set(SESSION_DB_USERS, $this->m_usersObjArr);
			}
		}
	}

	function removeFromImportedList()
	{
		// remove a user from imported user list (right)
		// first test if user selected any users
		if (isset( $_POST['importedUsers']))
		{
			// get selected users into array
			$selectedUsers = $_POST['importedUsers'];

			// loop through selected users
			foreach ($selectedUsers as $selected)
			{
				$tmpUser = $this->m_importedUsers[$selected]; // get selected user's name
				unset($this->m_importedUsers[$selected]); // remove selected user from imported user list (right)

				// loop through users object array
	   			foreach ( $this->m_usersObjArr as $key=>$userObj)
	   			{
	   				// when we find the selected user we check if it is
	   				// a new user or deleted user.
	   				// if this is a new user we remove it from the user object array
	   				// else we assume this is a deleted user and so we mark it as one.
	   				if ( $userObj->m_Name == $tmpUser)
	   				{
	   					// add only if associated gourp is removed
						if ($this->m_usersObjArr[$key]->m_isAssociated)
						{
	   						$this->m_availableUsers[] = $tmpUser;
						}

	   					if ($this->m_usersObjArr[$key]->m_State == NEW_USER)
	   					{
	   						unset($this->m_usersObjArr[$key]);
	   					}
	   					else
	   					{
	   						$this->m_usersObjArr[$key]->m_State = DELETED_USER;
	   					}
	   				}
	   			}

			}

			$this->sortAndUpdateSessions();
		}
	}

	function addToImportedList($dirID)
	{
		// add the selected users from left (available) list
		// to the right (imported) list

		// first test if any users are selected
		if (isset( $_POST['availableUsers']))
		{
			// get the selected users
			$selectedUsers = $_POST['availableUsers'];

			// loop through the selected users
			foreach ($selectedUsers as $selected)
			{
				$tmpUser = $this->m_availableUsers[$selected]; // get the selected user name
				unset($this->m_availableUsers[$selected]); // remove the selected user from the list (left)
	   			$this->m_importedUsers[] = $tmpUser; // add the user to the imported users list (right)

	   			$inUsersObjArr = false;

	   			// now we need to update the array of user objects
	   			// loop through the array of user objects
	   			foreach ( $this->m_usersObjArr as $key=>$userObj)
	   			{
	   				if ( $userObj->m_Name == $tmpUser)
	   				{
	   					// if this user originaly was in the list and was removed and
	   					// now she is back we just need to update the status.
	   					$this->m_usersObjArr[$key]->m_State = NOCHANGE_USER;
	   					$inUsersObjArr = true;
	   					break;
	   				}
	   			}

	   			if (!$inUsersObjArr)
	   			{	// if the is a new user we need to create a new user object
	   				$this->m_usersObjArr[] = new user($dirID,$tmpUser,null,NEW_USER);
	   			}

			}

			$this->sortAndUpdateSessions();
		}
	}

	function saveImportedList2DB($dirID)
	{
		$res = HSP_SUCCESS;
		$log = "";

		// loop through user objects array and invoke the propare database operation

		foreach ( $this->m_usersObjArr as $userObj)
		{
			if ($userObj->m_State == NEW_USER)
			{ // add to database
				$res = $this->m_usersTbl->addImportedUser($userObj->m_DirID,$userObj->m_Name);
				if(is_object($res))
				{
					//error object:
					return HSP_ERR_DB_ERROR;
				}
				$log = "New";
			}
			elseif ($userObj->m_State == DELETED_USER)
			{ // remove from database
				$res = $this->m_usersTbl->removeImportedUser($userObj->m_id);
				if(HSP_SUCCESS == $res)
				{
					// Remove from UAT table:
					$res = $this->m_usersTbl->removeGatUat($userObj->m_id, $userObj->m_Name);
					if(HSP_SUCCESS == $res)
					{
						$res = $this->m_usersTbl->removeUserParameters( $userObj->m_id );
					}
				}
				$log = "Delete";
			}
			elseif ($userObj->m_State == UPDATE_USER)
			{ // update database
				$res = $this->m_usersTbl->updateImportedUser($userObj->m_id,$userObj->m_Name);
				if(HSP_SUCCESS == $res)
				{
					// Update GAT table:
					$res = $this->m_usersTbl->updateGatUat($userObj->m_id, $userObj->m_oldName, $userObj->m_Name);
				}
				$log = "Update";
			}
		}

		$this->onShowUsers($dirID);
		parent::CriaLog($log ."_". trim(USERS_SAVE_BTN));
		return $res;
	}

	function associateUsers()
	{
		// when ever a user is renamed or removed from the directory
		// we need to give the user the ability to reconnect->associate the 'floating'
		// users.

		// first we test if the user selected any users from both lists
		// we need to make sure the user selects only one user from each list

		if (isset( $_POST['availableUsers']) && isset( $_POST['importedUsers']))
		{
			$selectedAvailableUsers = $_POST['availableUsers'];
			$selectedImportedUsers = $_POST['importedUsers'];

			if (count($selectedAvailableUsers) == 1 && count($selectedImportedUsers) == 1)
			{
				// get the selected users (which are in arrays)
				$availableIndex = $selectedAvailableUsers[0];
				$importedIndex = $selectedImportedUsers[0];

				// get the users names
				$tmpImportedUser = $this->m_importedUsers[$importedIndex];
				$tmpAvailableUser = $this->m_availableUsers[$availableIndex];

	   			$asocciated = false;
	   			// loop through user objects and set the state and name
	   			foreach ( $this->m_usersObjArr as $key=>$userObj)
	   			{
	   				if ( $userObj->m_Name == $tmpImportedUser && !$userObj->m_isAssociated)
	   				{
	   					$this->m_usersObjArr[$key]->m_State = UPDATE_USER;

	   					// Update the oldName field, get rid of square brackets:
	   					$this->m_usersObjArr[$key]->m_oldName = ltrim((rtrim($this->m_usersObjArr[$key]->m_Name, "]")), "[");

	   					$this->m_usersObjArr[$key]->m_Name = $tmpAvailableUser;
	   					$asocciated = true;
	   					$this->m_session->set(PAGECHANGED, 'changed');
	   					break;
	   				}
	   			}

	   			if (!$asocciated)
   				{
   					// error msg, user can associate only mismatched users.
   					$errorCode = array(HSP_ERR_USERS_ASSOC_MISMATCHED_ERROR);
					$this->m_session->set(SESSION_ERRORS, $errorCode);
   				}
   				else
   				{
					// remove the user from left (available) list and
					// add the the user to the right (imported) list
					unset($this->m_availableUsers[$availableIndex]);
		   			$this->m_importedUsers[$importedIndex] = $tmpAvailableUser;
   				}

	   			$this->sortAndUpdateSessions();


			}
			else
			{
				// error msg saying user must select only one item from each list
				$errorCode = array(HSP_ERR_USERS_SELECT_ONE_ERROR);
				$this->m_session->set(SESSION_ERRORS, $errorCode);
			}
		}
		else
		{
			// error msg saying user must select an item from each list
			$errorCode = array(HSP_ERR_USERS_MUST_SELECT_ERROR);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}

	}

	function sortAndUpdateSessions()
	{
		// sort the two lists and update the session variables
		natcasesort($this->m_importedUsers);
		natcasesort($this->m_availableUsers);

		// save variables to the Session so we can get them in later post's calls
		$this->m_session->set(SESSION_AVAILABLE_USERS, $this->m_availableUsers);
		$this->m_session->set(SESSION_IMPORTED_USERS, $this->m_importedUsers);
		$this->m_session->set(SESSION_DB_USERS, $this->m_usersObjArr);
	}

	function GetDirectoryName($dirID)
	{
		// get directory name by directory id
		$res = $this->m_usersTbl->GetDirectoryName($dirID);
		return $res;
	}

	function onShowUsers($dirID)
	{
		if ( $this->getDirectoryUsers($dirID) )
		{
			$this->getImportedListFromDB($dirID);
	
			$this->synchronizeList();	
		}
		
		$this->populateAvailableList();
		$this->populateImportedList();

		$this->m_session->set(SESSION_AVAILABLE_USERS, $this->m_availableUsers);
		$this->m_session->set(SESSION_IMPORTED_USERS, $this->m_importedUsers);
	}
	
	function onClearUsers()
	{
		$this->m_availableUsers = null;
		$this->m_importedUsers = null;
		
		$this->populateAvailableList();
		$this->populateImportedList();
	
		$this->m_session->set(SESSION_AVAILABLE_USERS, $this->m_availableUsers);
		$this->m_session->set(SESSION_IMPORTED_USERS, $this->m_importedUsers);	
	}
	
	function authenticate( $userName, $password, $dirID)
	{					
		$dirAuthObj = new authentication( $this->GetDatabase() ,$this->m_session );
		return $dirAuthObj->authenticate( $userName, $password, $dirID );
	}
}
?>