<?PHP
define('USER_PARAMETERS_EDIT_BTN','Editar Par�metros');
define('USER_PARAMETERS_CLEAR_BTN','Limpar Par�metros');
define('USER_PARAMETERS_DIRECTORIES_LBL', 'Diret�rios:');
define('USER_PARAMETERS_SELECT_DIRECTORY','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--- Selecionar ---');

define('USER_PARAMETERS_TREE_LBL','');
define('USER_PARAMETERS_NAME_LBL','Nome do Usu�rio');


define('USER_PARAMETERS_CONFIRM_DELETE_MSG','Voc� tem certeza que deseja limpar os par�metros deste usu�rio?');
define('USER_PARAMETERS_USER_TXT','Usu�rio');
?>