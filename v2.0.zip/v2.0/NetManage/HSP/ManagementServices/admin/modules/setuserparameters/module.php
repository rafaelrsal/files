<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

define('SESSION_SET_USER_PARAMETERES_ITEMS', 	'setUserParametersDirItems');
define('SESSION_SET_USER_PARAMETERS_DETAILS', 	'setUserParametersDetails');

class setUserParameters extends ModuleBase
{
	var $m_db;
	var $m_dirItemsArr;	
	var $m_prevSelectedRow;	
	
	function setUserParameters($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		$this->m_dirItemsArr = array();
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
		$this->m_form = new HTML_QuickForm('setUserParametersForm'); //default is post
	}
	
	function init()
	{		
		parent::init("setUserParameters");
		$this->m_form->addElement('select', 'directories', USER_PARAMETERS_DIRECTORIES_LBL,$this->getDirectoriesNames(),'onchange="getUsersAndGroups();" onKeyPress="DoDefaultEnterKey(event)" style="width:220"');
		// buttons
		$this->m_form->addElement('button', 'editPermissions', 	USER_PARAMETERS_EDIT_BTN,  	'onclick=onEdit() class="NewButton" style="width:140px"');
		$this->m_form->addElement('button', 'clearPermissions',USER_PARAMETERS_CLEAR_BTN,   'onclick=onClear() class="NewButton" style="width:140px"');
		// hiddens
		$this->m_form->addElement('hidden', 'buttonClicked','');	
		$this->m_form->addElement('hidden', 'selectedRow', 1);
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
				
		$this->m_dirItemsArr = $this->m_session->value( SESSION_SET_USER_PARAMETERES_ITEMS );
		$this->m_prevSelectedRow = false;
	}

	function process()
	{
		$res = HSP_SUCCESS;	
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$formValuesArray = $this->m_form->exportValues();
			
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));
			$dirID = htmlspecialchars($this->m_form->exportValue('directories'));
			
			if ( "selectChanged" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onSelectChanged($dirID);
			}
			elseif ( "editPermissions" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onEditPermissions( $dirID, $selectedRow );				
			}
			elseif( "clearPermissions" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onClearPermissions($selectedRow);
			}			
		}
		elseif ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$this->m_dirItemsArr = array();
			
			$itemDetails = $this->m_session->value(SESSION_SET_USER_PARAMETERS_DETAILS);
			$dirID = $itemDetails['dirID'];
			if ( $dirID )
			{
				$this->m_form->setDefaults(array('directories'=>$dirID));
				$res = $this->onSelectChanged($dirID);
				
				if(HSP_SUCCESS == $res)
				{
					$this->m_prevSelectedRow = 	$itemDetails['selectedrow'];		
					// Clean cached data of previous actions:
					$this->m_session->remove(SESSION_SET_USER_PARAMETERS_DETAILS);
				}
			}
		}
		
		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);			
		}
	}
	
	function finalize()
	{
		$selectedRow = $this->m_prevSelectedRow;
		if(false === $selectedRow)
		{
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));
			if ( !$selectedRow )
			{
				$selectedRow = 1;
			}
		}
		
		$arrVars = array(	"tblItems"=>$this->generateTable(),
					        "confirm_delete"=>USER_PARAMETERS_CONFIRM_DELETE_MSG,
					        "selectedRow"=>$selectedRow );
        
		parent::finalize($arrVars, 'setUserParameters');
	}
	
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tblItems" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(USER_PARAMETERS_TREE_LBL, USER_PARAMETERS_NAME_LBL);
		$headerAttribArr = array("class='TableHeader' width=20px","class='TableHeader' width=240px","class='TableHeader' width=100px");
		$tblBackups->addRow($headerArr , $headerAttribArr );
		
		foreach ( $this->m_dirItemsArr as $key=>$fileRow )
		{
			$rownum = $key + 1 ;
			
			$shortName = $fileRow['name'];
			
			if ( strlen($shortName) > 23 )
			{
				$shortName = substr($fileRow['name'], 0, 23) . '...';
			}
			
			$id = $fileRow['id'];
			

			$sql = "SELECT * FROM ".TABLE_USER_PARAMETER." WHERE userId=$id;";
			$recSet = $this->m_db->GetAllEx($sql);
			
			if ( count($recSet) )
			{
				$row = array ("<img src=".IMAGES_DIR."button_edit.png>", $shortName );			
			}
			else
			{
				$row = array ("", $shortName );			
			}
			
			$name = $fileRow['name'];
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
			
			$attib = array("class='DataCell' title=''", "class='DataCell' title='$name'");
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}

		return $tblBackups->toHtml();
	}
	
	function getDirectoriesNames()
	{
		$dirArray = $this->m_db->GetAll(TABLE_DIRECTORIES);
		
		if ( DB::isError($dirArray) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		// retun an array with all the directories names
		$list = array(0=>USER_PARAMETERS_SELECT_DIRECTORY);
		
		foreach ($dirArray as $dir)
		{
			$list[$dir[0]] = $dir[1]; // $dir[1] name , $dir[0] dir id
		}
		natcasesort($list);
		return $list;
	}
	
	function onSelectChanged($dirID)
	{
		$this->m_dirItemsArr = array();
		
		if ( $dirID )
		{
			$recSet = $this->m_db->GetAllEx("SELECT id,name FROM ".TABLE_USERS." WHERE dirID=$dirID;", null, DB_FETCHMODE_ASSOC);
			foreach ($recSet as $userRecord)
			{
				$this->m_dirItemsArr[] = array('id'=>$userRecord['id'] ,'name'=>$userRecord['name'] );
			}
			if ( DB::isError($recSet) )
			{
				return HSP_ERR_DB_SQL_ERROR;
			}
		}
		
		$this->sortItemArr();
		
		$this->m_session->set(SESSION_SET_USER_PARAMETERES_ITEMS, $this->m_dirItemsArr);
		
		return HSP_SUCCESS;
	}
	
	//sort the directory list by name
	function sortItemArr()
	{
		$tmpArr = array();
		foreach($this->m_dirItemsArr as $item)
		{
			$tmpArr[] = $item['name'];
		}
		
		natcasesort($tmpArr);
		
		$newFileListArray = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $this->m_dirItemsArr as $key=>$item )
			{
				if ($name == $item['name'])
				{
					$newFileListArray[] = $item;
					unset($this->m_dirItemsArr[ $key ]);
					break;
				}
			}			
		}
		
		$this->m_dirItemsArr = $newFileListArray;
	}
	
	function onClearPermissions($selectedRow)
	{
		$id = $this->m_dirItemsArr[$selectedRow-1]['id'];
		
		$sql = "DELETE FROM ".TABLE_USER_PARAMETER. " WHERE userId=$id;";
		$ret = $this->m_db->Query($sql);
		if ( DB::isError($ret) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		parent::CriaLog(USER_PARAMETERS_CLEAR_BTN);
		return HSP_SUCCESS;				
	}
	
	function onEditPermissions( $dirID, $selectedRow)
	{
		$list = $this->getDirectoriesNames();
		
		if ( !is_array($list) )
		{
			return $list;
		}
		
		$itemDetails = array( 	'dirID'=>$dirID, 
								'displayName'=>$list[$dirID], 
								'name'=>$this->m_dirItemsArr[$selectedRow-1]['name'], 
								'id'=>$this->m_dirItemsArr[$selectedRow-1]['id'],
								'selectedrow'=>$selectedRow);
		
		$this->m_session->set(SESSION_SET_USER_PARAMETERS_DETAILS, $itemDetails);
		
		Header('Location: admin.php?module=userParameters&roll='.$_POST['roll']);
		exit();
	}
}
?>