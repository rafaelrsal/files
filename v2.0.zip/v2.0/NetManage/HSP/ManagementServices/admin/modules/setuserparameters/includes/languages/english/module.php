<?PHP
define('USER_PARAMETERS_EDIT_BTN','Edit User Parameters');
define('USER_PARAMETERS_CLEAR_BTN','Clear User Parameters');
define('USER_PARAMETERS_DIRECTORIES_LBL', 'Directories:');
define('USER_PARAMETERS_SELECT_DIRECTORY','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--- Select ---');

define('USER_PARAMETERS_TREE_LBL','');
define('USER_PARAMETERS_NAME_LBL','User name');


define('USER_PARAMETERS_CONFIRM_DELETE_MSG','Are you sure you want to clear the parameters for this user?');
define('USER_PARAMETERS_USER_TXT','User');
?>