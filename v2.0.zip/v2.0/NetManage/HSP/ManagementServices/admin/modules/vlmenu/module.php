<?PHP
require_once('includes/LMenu/lib/PHPLIB.php');

class vlmenu extends ModuleBase
{
	function vlmenu($globalobjects)
	{
		parent::ModuleBase($globalobjects);
	}
	
	function  init()
	{
		parent::init("vlmenu");
	}
	
	function process()
	{
	}
	
	function finalize()
	{
	
		//******************* GUILHERME LIMA 06/03/2013 ****************
		if(isset($_GET['roll']))
		{
			$_SESSION['roll']=$_GET['roll'];
		}
		elseif ( isset($_POST['roll'])){
			$_SESSION['roll'] = $_POST['roll'];
		}
		else{
			//******************* GUILHERME LIMA 06/03/2013 ****************
			$_SESSION['roll']="restrito";
        }
        if (isset($_GET['MenuIndex'])) {
        	$_SESSION['MenuIndex']=$_GET['MenuIndex'];
			$_SESSION['ItemIndex']=$_GET['ItemIndex'];
			$_SESSION['ItemTitle']=$_GET['ItemTitle'];
        }

        if(!isset($_SESSION['MenuIndex']))
        {
	        $_SESSION['MenuIndex']="0";
            $_SESSION['ItemIndex']="0";
            $_SESSION['ItemTitle']=MENUITEM_HOME;
		};
		
		$arrVars = array(	"rand_tmsp"=>filemtime('includes/config/permission.js'),
							"lblHOME"=>MENUITEM_HOME,
	        				"lblSETTINGS"=>MENUITEM_SETTINGS,
	    					"lblDATABASE"=>MENUITEM_DATABASE,
			    			"lblIMPORTEXPORT"=>MENUITEM_IMPORTEXPORT,
	    					"lblADMIN_PASSWORD"=>MENUITEM_ADMIN_PASSWORD,
							"lblGENERAL_CONFIGURATION"=>MENUITEM_GENERAL_CONFIGURATION,
	    					"lblGENERAL_CONFIGURATION_URL"=>rawurlencode(MENUITEM_GENERAL_CONFIGURATION),
							"lblGENERAL_NEW_USER"=>MENUITEM_NEW_USER,
							"lblGENERAL_NEW_USER_URL"=>rawurlencode(MENUITEM_NEW_USER),
							"lblPERMISSIONS"=>MENUITEM_PERMISSIONS,
							"lblPERMISSIONS_URL"=>rawurlencode(MENUITEM_PERMISSIONS),
	    					"lblMONITORING"=>MENUITEM_MONITORING,
	    					"lblCONFIGURATION"=>MENUITEM_CONFIGURATION,
	    					"lblCLIENTCONFIGURATION"=>MENUITEM_CLIENTCONFIGURATION,
	    					"lblREPORTS"=>MENUITEM_REPORTS,
							"lblREPORTS_URL"=>rawurlencode(MENUITEM_REPORTS),
							"lblCONCURRENCY"=>MENUITEM_CONCURRENCY,
							"lblCONCURRENCY_URL"=>rawurlencode(MENUITEM_CONCURRENCY),
	    					"lblWHOSONLINE"=>MENUITEM_WHOS_ONLINE,
							"lblWHOSONLINE_URL"=>rawurlencode(MENUITEM_WHOS_ONLINE),
							"lblW2HADMIN"=>MENUITEM_W2H_ADMIN,
							"lblW2HADMIN_URL"=>rawurlencode(MENUITEM_W2H_ADMIN),
	    					"lblUSER_MANAGE"=>MENUITEM_USER_MANAGE,
	    					"lblCUSTOM_DIRECTORIES"=>MENUITEM_CUSTOM_DIRECTORIES,
							"lblCUSTOM_DIRECTORIES_URL"=>rawurlencode(MENUITEM_CUSTOM_DIRECTORIES),
	    					"lblSYSTEM_DIRECTORIES"=>MENUITEM_SYSTEM_DIRECTORIES,
							"lblSYSTEM_DIRECTORIES_URL"=>rawurlencode(MENUITEM_SYSTEM_DIRECTORIES),
	    					"lblGROUPS"=>MENUITEM_GROUPS,
	    					"lblUSERS"=>MENUITEM_USERS,
							"lblUSERS_URL"=>rawurlencode(MENUITEM_USERS),
	    					"lblPORTAL"=>MENUITEM_PORTAL,
	    					"lblAPPLICATION_MANAGMENT"=>MENUITEM_APPLICATION_MANAGMENT,
	    					"lblAPPLICATION_BUILD"=>MENUITEM_APPLICATION_BUILD,
							"lblAPPLICATION_BUILD_URL"=>rawurlencode(MENUITEM_APPLICATION_BUILD),
	    					"lblASSOC_APPLICATIONS"=>MENUITEM_ASSOC_APPLICATIONS,
							"lblASSOC_APPLICATIONS_URL"=>rawurlencode(MENUITEM_ASSOC_APPLICATIONS),
	    					"lblAPPLICATION_ANONYMOUS"=>MENUITEM_APPLICATION_ANONYMOUS,
							"lblAPPLICATION_ANONYMOUS_URL"=>rawurlencode(MENUITEM_APPLICATION_ANONYMOUS),
							"lblUSER_PARAMETERS"=>MENUITEM_USER_PARAMETERS,
	    					"lblUSER_PARAMETERS_URL"=>rawurlencode(MENUITEM_USER_PARAMETERS),
	    					"lblHELP"=>MENUITEM_HELP,
	    					"lblHELP_TOC"=>MENUITEM_HELP_TOC,
	    					"lblLOGOUT"=>MENUITEM_LOGOUT,
	    					"lblMenuHidePath"=> MENUITEM_HIDEPATH,
						    "msgPageChanged"=> MENUITEM_CHANGES,
        					"MenuIndex"=>$_SESSION['MenuIndex'],
        					"ItemIndex"=>$_SESSION['ItemIndex'],
        					"ItemTitle"=>$_SESSION['ItemTitle'],
        					"pleaseWait"=>TXT_TITLE,
							//******************* GUILHERME LIMA 06/03/2013 ****************
							"lblroll"=>$_SESSION['roll']);
        
        parent::finalize($arrVars, "vlmenu");
	}
}
?>