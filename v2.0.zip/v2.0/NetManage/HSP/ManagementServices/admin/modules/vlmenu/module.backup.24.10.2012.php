<?PHP
require_once('includes/LMenu/lib/PHPLIB.php');

class vlmenu extends ModuleBase
{
	function vlmenu($globalobjects)
	{
		parent::ModuleBase($globalobjects);
	}
	
	function  init()
	{
		parent::init("vlmenu");
	}
	
	function process()
	{
	}
	
	function finalize()
	{
        if (isset($_GET['MenuIndex'])) {

        	$_SESSION['MenuIndex']=$_GET['MenuIndex'];
			$_SESSION['ItemIndex']=$_GET['ItemIndex'];
			$_SESSION['ItemTitle']=$_GET['ItemTitle'];
        }

        if(!isset($_SESSION['MenuIndex']))
        {
	        $_SESSION['MenuIndex']="0";
            $_SESSION['ItemIndex']="0";
            $_SESSION['ItemTitle']=MENUITEM_HOME;
        };
		
		$arrVars = array(	"lblHOME"=>MENUITEM_HOME,
	        				"lblSETTINGS"=>MENUITEM_SETTINGS,
	    					"lblDATABASE"=>MENUITEM_DATABASE,
			    			"lblIMPORTEXPORT"=>MENUITEM_IMPORTEXPORT,
	    					"lblADMIN_PASSWORD"=>MENUITEM_ADMIN_PASSWORD,
	    					"lblGENERAL_CONFIGURATION"=>MENUITEM_GENERAL_CONFIGURATION,
	    					"lblMONITORING"=>MENUITEM_MONITORING,
	    					"lblCONFIGURATION"=>MENUITEM_CONFIGURATION,
	    					"lblCLIENTCONFIGURATION"=>MENUITEM_CLIENTCONFIGURATION,
	    					"lblREPORTS"=>MENUITEM_REPORTS,
	    					"lblCONCURRENCY"=>MENUITEM_CONCURRENCY,
	    					"lblWHOSONLINE"=>MENUITEM_WHOS_ONLINE,
	    					"lblUSER_MANAGE"=>MENUITEM_USER_MANAGE,
	    					"lblCUSTOM_DIRECTORIES"=>MENUITEM_CUSTOM_DIRECTORIES,
	    					"lblSYSTEM_DIRECTORIES"=>MENUITEM_SYSTEM_DIRECTORIES,
	    					"lblGROUPS"=>MENUITEM_GROUPS,
	    					"lblUSERS"=>MENUITEM_USERS,
	    					"lblPORTAL"=>MENUITEM_PORTAL,
	    					"lblAPPLICATION_MANAGMENT"=>MENUITEM_APPLICATION_MANAGMENT,
	    					"lblAPPLICATION_BUILD"=>MENUITEM_APPLICATION_BUILD,
	    					"lblASSOC_APPLICATIONS"=>MENUITEM_ASSOC_APPLICATIONS,
	    					"lblAPPLICATION_ANONYMOUS"=>MENUITEM_APPLICATION_ANONYMOUS,
	    					"lblUSER_PARAMETERS"=>MENUITEM_USER_PARAMETERS,
	    					"lblHELP"=>MENUITEM_HELP,
	    					"lblHELP_TOC"=>MENUITEM_HELP_TOC,
	    					"lblLOGOUT"=>MENUITEM_LOGOUT,
	    					"lblMenuHidePath"=> MENUITEM_HIDEPATH,
						    "msgPageChanged"=> MENUITEM_CHANGES,
        					"MenuIndex"=>$_SESSION['MenuIndex'],
        					"ItemIndex"=>$_SESSION['ItemIndex'],
        					"ItemTitle"=>$_SESSION['ItemTitle'],
        					"pleaseWait"=>TXT_TITLE);
        
        parent::finalize($arrVars, "vlmenu");
	}
}
?>