<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created: Mars 2004
  Title: groupsTbl.php
  Purpose: handle all database operations for groups module
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
class groupsTbl
{
	var $m_pearDB;
	
	function groupsTbl(&$peardb)
	{
		$this->m_pearDB = $peardb;
		$this->m_pearDB->connect();
	}
	
	function getAllDirectories()
	{
		return $this->m_pearDB->GetAll(TABLE_DIRECTORIES);
	}
	
	function getAllGroupsByDirID($dirID)
	{
		$recSet = $this->m_pearDB->GetAllEx("SELECT id,name FROM ".TABLE_GROUPS." WHERE dirID=$dirID");
		return $recSet;
	}
	
	function addImportedGroup($dirID,$name)
	{
		$fields_values = array( 'name'=>$name , 'dirID'=>$dirID);
		$ret = $this->m_pearDB->AutoExecute(TABLE_GROUPS, $fields_values);		
		return $ret;
		
	}
	
	function removeImportedGroup($id)
	{
		$sql = "DELETE FROM ".TABLE_GROUPS . " WHERE id='{$id}';";

		$ret = $this->m_pearDB->Query($sql);
		if (HSP_ERR_DB_SQL_ERROR != $ret)
		{
			return HSP_SUCCESS;
		}
		return $ret;
		
	}
	
	function updateImportedGroup($id, $name)
	{
		$sql = "UPDATE ".TABLE_GROUPS . " SET name=\"$name\" WHERE id=$id;";
		$ret = $this->m_pearDB->Query($sql);
		if (HSP_ERR_DB_SQL_ERROR != $ret)
		{
			return HSP_SUCCESS;
		}
		return $ret;

	}
	
	function GetDirectoryName($dirID)
	{
		$recSet = $this->m_pearDB->GetAllEx("SELECT name FROM ".TABLE_DIRECTORIES." WHERE id=$dirID");
		return $recSet;
	}
	
	function removeGatUat($id, $name)
	{
		$sql = "DELETE FROM ".TABLE_GAT_UAT. " WHERE id=$id AND name=\"$name\";";
		$ret = $this->m_pearDB->Query($sql);
		if (HSP_ERR_DB_SQL_ERROR != $ret)
		{
			return HSP_SUCCESS;
		}
		return $ret;
	}

	function updateGatUat($id, $oldName, $name)
	{
		$sql = "UPDATE ".TABLE_GAT_UAT . " SET name=\"$name\" WHERE id=$id AND name=\"$oldName\";";
		$ret = $this->m_pearDB->Query($sql);
		if (HSP_ERR_DB_SQL_ERROR != $ret)
		{
			return HSP_SUCCESS;
		}
		return $ret;
	}
	
	function getDirectoryDetails($id)
	{
		$sql = "SELECT type_dir,port,base_dn,host,group_dn,user_dn,ldap_user_identifier FROM ".TABLE_DIRECTORIES." WHERE id=$id;";
		$recSet = $this->m_pearDB->GetAllEx($sql,null,DB_FETCHMODE_ASSOC);
		
		if ( DB::isError($recSet) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		return $recSet[0];
	}
	
	function isCustomDir($id)
	{
		$isCustom = false;
		$sql = "SELECT customDirId FROM ".TABLE_DIRECTORIES . " WHERE id=$id;";
		$this->m_pearDB->GetOne( $sql, $customDirId);
		
		if ( $customDirId )
		{
			$isCustom = true;
		}
		
		return $isCustom;
	}
	
	function getCustomDirGroups($id)
	{
		$sql = "SELECT customDirId FROM ".TABLE_DIRECTORIES . " WHERE id=$id;";
		$this->m_pearDB->GetOne( $sql, $customDirId);
		
		$sql = "SELECT name FROM ".TABLE_CUSTOM_GROUPS." WHERE dirId=$customDirId";
		$recSet = $this->m_pearDB->GetAllEx($sql);
		
		$names = array();
		foreach ($recSet as $name)
		{
			$names[] = $name[0];			
		}
		
		return $names;
	}
}
?>