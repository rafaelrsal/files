<?PHP
define('GROUPS_MAIN_TXT','Grupos');
define('GROUPS_HELP_LNK','Ajuda');
define('GROUPS_REQUIRED_TXT','verifique os campos obrigat�rios');
define('GROUPS_DIRECTORIES_LBL','Diret�rios:');
define('GROUPS_LIST_LBL','Grupos Dispon�veis:');
define('GROUPS_IMPORTED_LBL','Grupos Selecionados:');
define('GROUPS_IMPORT_BTN','Exibir Grupos');
define('GROUPS_CLEAR_BTN', 'Limpar');
define('GROUPS_ADD_BTN','   Adicionar ->   ');
define('GROUPS_REMOVE_BTN','<- Remover');
define('GROUPS_SAVE_BTN','   Salvar   ');
define('GROUPS_ASSOCIATE_BTN','Associar  ');
define('GROUPS_CHOOSE_DIR_TXT','Selecione um diret�rio...');
define('GROUPS_SELECT','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--- Selecionar ---');
define('GROUPS_VERIFY_DLG','Verificar Conex�o');
?>