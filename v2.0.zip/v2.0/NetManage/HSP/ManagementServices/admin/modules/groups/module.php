<?PHP
require_once('HTML/QuickForm.php');
require_once('admin/modules/groups/includes/groupsTbl.php');
require_once('admin/modules/groups/includes/group.php');
require_once('admin/modules/DirectoryAuth/module.php');
require_once('admin/includes/classes/authentication.php');

define('SESSION_AVAILABLE_GROUPS','availableGroups');
define('SESSION_IMPORTED_GROUPS','importedGroups');
define('SESSION_DB_GROUPS','dbGroups');
define('PAGECHANGED', 'pageChanged');

class groups extends ModuleBase
{
	var $m_dirArray;
	var $m_groupsTbl;	
	var $m_availableGroups;
	var $m_importedGroups;
	var $m_groupsObjArr;
	var $m_dirId;
	var $m_popup;

	function groups($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		$this->m_groupsTbl = new groupsTbl( $this->GetDatabase() );
		
		// initializations
		$this->m_dirArray 		= array();
		$this->m_groupsObjArr 	= array();
		
		// Instantiate the HTML_QuickForm object
		$formName = 'GroupsForm';
		$this->m_form = new HTML_QuickForm($formName); //default is post
		$this->m_dirAuthObj = new directoryAuth($globalobjects, $formName);
		$this->m_dirAuthObj->init();
		$this->m_dirAuthObj->process();
		$this->m_dirAuthObj->finalize();
		
		$this->m_popup = 'false';
	}
	
	function init()
	{
		parent::init("groups");
		$this->getAllDirectories();

		// get all arrays from session variable
		if ( $this->m_session->exists(SESSION_AVAILABLE_GROUPS))
		{
			$this->m_availableGroups = $this->m_session->value(SESSION_AVAILABLE_GROUPS);
		}

		if ( $this->m_session->exists(SESSION_IMPORTED_GROUPS))
		{
			$this->m_importedGroups= $this->m_session->value(SESSION_IMPORTED_GROUPS);
		}

		if ( $this->m_session->exists(SESSION_DB_GROUPS))
		{
			$this->m_groupsObjArr= $this->m_session->value(SESSION_DB_GROUPS);
		}

		$this->m_form->addElement('header', 'header', GROUPS_MAIN_TXT);
		$this->m_form->addElement('select', 'directories', GROUPS_DIRECTORIES_LBL,$this->getDirectoriesNames(),'onchange="GetGroups();" onKeyPress="DoDefaultEnterKey(event)" style="width:200"');
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$this->m_form->addElement('select', 'availableGroups', GROUPS_LIST_LBL,$this->m_availableGroups,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
			$this->m_form->addElement('select', 'importedGroups', GROUPS_IMPORTED_LBL,$this->m_importedGroups,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
		}
		else
		{
			$this->m_form->addElement('select', 'availableGroups', GROUPS_LIST_LBL,null,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
			$this->m_form->addElement('select', 'importedGroups', GROUPS_IMPORTED_LBL,null,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');			
		}
		$this->m_form->addElement('submit', 'import', GROUPS_IMPORT_BTN);
		$this->m_form->addElement('submit', 'clear', GROUPS_CLEAR_BTN);
		$this->m_form->addElement('submit', 'add', GROUPS_ADD_BTN,"class='NewButton ShortFixedWidthObjects'");
		$this->m_form->addElement('submit', 'remove', GROUPS_REMOVE_BTN,"class='NewButton ShortFixedWidthObjects'");
		$this->m_form->addElement('submit', 'save', GROUPS_SAVE_BTN,"class='NewButton ShortFixedWidthObjects'");
		$this->m_form->addElement('submit', 'associate', GROUPS_ASSOCIATE_BTN,"class='NewButton ShortFixedWidthObjects'");		
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
	}
	
	function process()
	{
		$res = HSP_SUCCESS;
		$errorCode = null;

		$this->m_formValuesArray = $this->m_form->exportValues();

		$dirID = htmlspecialchars($this->m_form->exportValue('directories'));

		if ( strlen($dirID) )
		{
			if (array_key_exists("add", $this->m_formValuesArray))
			{
				$this->addToImportedList($dirID);
				$this->populateImportedList();
				$this->populateAvailableList();
				$this->m_session->set(PAGECHANGED, 'changed');
			}
			elseif (array_key_exists("remove", $this->m_formValuesArray))
			{
				$this->removeFromImportedList();
				$this->populateImportedList();
				$this->populateAvailableList();
				$this->m_session->set(PAGECHANGED, 'changed');
			}
			elseif (array_key_exists("import", $this->m_formValuesArray))
			{
				$this->onShowGroups($dirID);
			}
			elseif (array_key_exists("save", $this->m_formValuesArray))
			{
				$res = $this->saveImportedList2DB($dirID);
			}
			elseif (array_key_exists("associate", $this->m_formValuesArray))
			{
				$this->associateGroups();
				$this->populateImportedList();
				$this->populateAvailableList();					
			}
			elseif ( array_key_exists("clear", $this->m_formValuesArray) )
			{		
				$this->onClearGroups();
			}
			elseif (isset( $_POST['buttonClickedAuth'] ) && 'ok' == $_POST['buttonClickedAuth'])
			{
				$userName = $_POST['username'];
				$password = $_POST['password'];
				
				$res = $this->authenticate($userName, $password, $dirID);
				if ( HSP_SUCCESS != $res )
				{					
					$errorCode = $res;
					// javascript POPUP
					$this->m_popup = 'true';
				}
				else
				{
					$this->onShowGroups($dirID);
				}
			}
			
			if ( null != $errorCode )
			{
				$dirID = 0;
				$this->m_session->set(SESSION_ERRORS, $errorCode);
			}
		}
		else
		{
			$dirID = 0;
		}

		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
		
		$this->m_dirId = $dirID;
	}
	
	
	function  finalize()
	{		
		$isChangedVar = null;	
		if ($this->m_session->exists(PAGECHANGED) && $this->m_session->value(PAGECHANGED) == 'changed')
		{
			$isChangedVar = true;					
		}
		else
		{
			$isChangedVar = 0;			
		}
		
		$arrVars = array( 'isChangedVar'=> $isChangedVar,		
				'dirID'=> $this->m_dirId,
				'msgPageChanged'=> MENUITEM_CHANGES,
				'authenticatePopup'=> $this->m_popup,
				'moduleName'=>  $this->m_moduleName,		
				'authTitle'=> GROUPS_VERIFY_DLG,       
				'authenticationDiv'=>  $this->m_dirAuthObj->GetContent() );
		
		$this->m_session->remove(PAGECHANGED);
		parent::finalize($arrVars);
	}

	function getAllDirectories()
	{
		// get all domain names from db
		$this->m_dirArray = $this->m_groupsTbl->getAllDirectories();
	}

	function getDirectoriesNames()
	{
		// retun an array with all the directories names
		$list = array(0=>GROUPS_SELECT);
		//$list[-1] = GROUPS_CHOOSE_DIR_TXT;
		foreach ($this->m_dirArray as $dir)
		{
			$list[$dir[0]] = $dir[1]; // $dir[1] name , $dir[0] dir id
		}
		natcasesort($list);
		return $list;
	}

	function getDirectoryGroups($dirID)
	{
		$retVal = false;
		
		// get all groups from the directory via gennady's dll
		$result = HSP_SUCCESS;
		$userName = '';
		$password = '';
		
		$isCustomDir = $this->m_groupsTbl->isCustomDir($dirID);
		
		if ( !$isCustomDir )
		{
			if ($this->m_session->exists( SESSION_DIR_AUTH_CACHE ))
			{ // session var does exists...
				$dirAuthCache = $this->m_session->value( SESSION_DIR_AUTH_CACHE );
	
				if ( array_key_exists($dirID, $dirAuthCache))
				{
					$userName = $dirAuthCache[$dirID]->m_userName;
					$password = $dirAuthCache[$dirID]->m_Password;
					$result = $this->authenticate( $userName, $password , $dirID );
				}
				else
				{ 
					// javascript POPUP
					$this->m_popup = 'true';
				}			
			}
			else
			{ 
				// javascript POPUP
				$this->m_popup = 'true';
			}
		}		
		
		if ( HSP_SUCCESS == $result && 'false' == $this->m_popup)
		{
			$this->m_availableGroups = array();
			
			if (!$isCustomDir)
			{
				if(!extension_loaded(PHP_AUTH_MODULE))
				{
					dl(PHP_AUTH_DLL);
				}
				
				$recSet = $this->m_groupsTbl->getDirectoryDetails($dirID);
				
				if ( HSP_ERR_DB_SQL_ERROR != $recSet)
				{
					$groups = getdirectorygroups(	$userName,
								$password,
								$recSet['host'],
								$recSet['host'],
								$recSet['type_dir'],
								$recSet['port'],
								$recSet['base_dn'],
								$recSet['group_dn'],
								$recSet['user_dn'],
								$recSet['ldap_user_identifier'] );
				}
				else
				{
					$this->m_session->set(SESSION_ERRORS, $recSet);
				}
			}
			else
			{
				$groups = $this->m_groupsTbl->getCustomDirGroups($dirID);
			}
			
			if ( is_array($groups) && count($groups) ) //the groups variable is not an array when error code is returned.
			{
				unset($this->m_availableGroups);
				foreach($groups as $dirName)
				{
					$this->m_availableGroups[] = $dirName;
				}
				natcasesort($this->m_availableGroups);
			}
			$retVal = true;
		}
		else if ( HSP_SUCCESS != $result)
		{
			//authenticaion error
			$this->m_session->set(SESSION_ERRORS, $result);
		}
		else if (HSP_SUCCESS == $result)
		{
			$this->onClearGroups();
		}
		
		return $retVal;
	}

	function getImportedListFromDB($dirID)
	{
		// get groups from hsp database and populate the arrays for the list

		if (isset($this->m_groupsObjArr))
		{
			// clear the groups object array
			unset($this->m_groupsObjArr);
			$this->m_groupsObjArr = array();
		}

		// get all imported groups from database
		$recordSet = $this->m_groupsTbl->getAllGroupsByDirID($dirID);
		foreach ($recordSet as $groupRecord)
		{
			$this->m_groupsObjArr[] = new group($dirID , $groupRecord[1] , $groupRecord[0]);
		}

		$this->m_session->set(SESSION_DB_GROUPS, $this->m_groupsObjArr);

		if (isset($this->m_importedGroups))
		{
			unset($this->m_importedGroups);
		}
		$this->m_importedGroups = array();
		foreach ($this->m_groupsObjArr as $groupObj)
		{
			$this->m_importedGroups[] = $groupObj->m_Name;
		}

		natcasesort($this->m_importedGroups);
	}

	function populateAvailableList()
	{
		// in order to repopulate the list we unfortunatly need to
		// remove the element from the form and add it again

		$this->m_form->removeElement('availableGroups');
		$this->m_form->addElement('select', 'availableGroups', GROUPS_LIST_LBL,$this->m_availableGroups,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
	}

	function populateImportedList()
	{
		// in order to repopulate the list we unfortunatly need to
		// remove the element from the form and add it again

		$this->m_form->removeElement('importedGroups');
		$this->m_form->addElement('select', 'importedGroups', GROUPS_IMPORTED_LBL,$this->m_importedGroups,'multiple size=15 style="width:200" onchange="EnableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
	}

	function synchronizeList()
	{
		// initially we get a list of all groups from the directory and a list of
		// already imported groups from the hsp database.
		// we need to remove the groups in the imported list from the list of groups
		// from the directory (available groups).

		foreach ($this->m_importedGroups as $importedKey=>$imported)
		{
			if( in_array($imported,$this->m_availableGroups) )
			{
				while(($gotcha = array_search($imported,$this->m_availableGroups)) > -1)
				{
					unset($this->m_availableGroups[$gotcha]);
				}
			}
			else
			{
				foreach ( $this->m_groupsObjArr as $key=>$groupObj)
	   			{
	   				if ( $groupObj->m_Name == $imported )
	   				{
	   					// if a group exists in the imported list but not in the available list
						// we will change it's name to [name] both in the array and in the group's object
	   					$this->m_importedGroups[$importedKey] = '['.$this->m_groupsObjArr[$key]->m_Name .']';
	   					$this->m_groupsObjArr[$key]->m_isAssociated = false;
	   					$this->m_groupsObjArr[$key]->m_Name = '['. $this->m_groupsObjArr[$key]->m_Name .']';
	   				} // end if
	   			} // end foreach
	   			$this->m_session->set(SESSION_DB_GROUPS, $this->m_groupsObjArr);
			}
		}
	}

	function removeFromImportedList()
	{
		// remove a group from imported group list (right)
		// first test if user selected any groups
		if (isset( $_POST['importedGroups']))
		{
			// get selected groups into array
			$selectedGroups = $_POST['importedGroups'];

			// loop through selected groups
			foreach ($selectedGroups as $selected)
			{
				$tmpGroup = $this->m_importedGroups[$selected]; // get selected group's name
				unset($this->m_importedGroups[$selected]); // remove selected group from imported group list (right)

				// loop through groups object array
	   			foreach ( $this->m_groupsObjArr as $key=>$groupObj)
	   			{
	   				// when we find the selected group we check if it is
	   				// a new group or deleted group.
	   				// if this is a new group we remove it from the group object array
	   				// else we assume this is a deleted group and so we mark it as one.
	   				if ( $groupObj->m_Name == $tmpGroup)
	   				{
	   					// add only if associated gourp is removed
						if ($this->m_groupsObjArr[$key]->m_isAssociated)
						{
	   						$this->m_availableGroups[] = $tmpGroup;
						}

	   					if ($this->m_groupsObjArr[$key]->m_State == NEW_GROUP)
	   					{
	   						unset($this->m_groupsObjArr[$key]);
	   					}
	   					else
	   					{
	   						$this->m_groupsObjArr[$key]->m_State = DELETED_GROUP;
	   					}
	   				}
	   			}

			}
			$this->sortAndUpdateSessions();
		}
	}

	function addToImportedList($dirID)
	{
		// add the selected groups from left (available) list
		// to the right (imported) list

		// first test if any groups are selected
		if (isset( $_POST['availableGroups']))
		{
			// get the selected groups
			$selectedGroups = $_POST['availableGroups'];

			// loop through the selected groups
			foreach ($selectedGroups as $selected)
			{
				$tmpGroup = $this->m_availableGroups[$selected]; // get the selected group name
				unset($this->m_availableGroups[$selected]); // remove the selected group from the list (left)
	   			$this->m_importedGroups[] = $tmpGroup; // add the group to the imported groups list (right)

	   			$inGroupsObjArr = false;

	   			// now we need to update the array of group objects
	   			// loop through the array of group objects
	   			foreach ( $this->m_groupsObjArr as $key=>$groupObj)
	   			{
	   				if ( $groupObj->m_Name == $tmpGroup)
	   				{
	   					// if this group originaly was in the list and was removed and
	   					// now she is back we just need to update the status.
	   					$this->m_groupsObjArr[$key]->m_State = NOCHANGE_GROUP;
	   					$inGroupsObjArr = true;
	   					break;
	   				}
	   			}

	   			if (!$inGroupsObjArr)
	   			{	// if the is a new group we need to create a new group object
	   				$this->m_groupsObjArr[] = new group($dirID,$tmpGroup,null,NEW_GROUP);
	   			}

			}

			$this->sortAndUpdateSessions();
		}
	}

	function saveImportedList2DB($dirID)
	{
		$res = HSP_SUCCESS;
		$log = "";
		// loop through group objects array and invoke the propare database operation

		foreach ( $this->m_groupsObjArr as $groupObj)
		{
			if ($groupObj->m_State == NEW_GROUP)
			{ // add to database
				$res = $this->m_groupsTbl->addImportedGroup($groupObj->m_DirID, $groupObj->m_Name);
				if(is_object($res))
				{
					//error object:
					return HSP_ERR_DB_ERROR;
				}
				$log = "New";
			}
			elseif ($groupObj->m_State == DELETED_GROUP)
			{ 	// Remove from database
				$res = $this->m_groupsTbl->removeImportedGroup($groupObj->m_id);
				if(HSP_SUCCESS == $res)
				{
					// Remove from GAT table:
					$res = $this->m_groupsTbl->removeGatUat($groupObj->m_id, $groupObj->m_Name);
				}
				$log = "Delete";
			}
			elseif ($groupObj->m_State == UPDATE_GROUP)
			{ // update database
				$res = $this->m_groupsTbl->updateImportedGroup($groupObj->m_id,$groupObj->m_Name);
				if(HSP_SUCCESS == $res)
				{
					// Update GAT table:
					$res = $this->m_groupsTbl->updateGatUat($groupObj->m_id, $groupObj->m_oldName, $groupObj->m_Name);
				}
				$log = "Update";
			}
		}
		
		
		$this->onShowGroups($dirID);
		parent::CriaLog($log ."_". trim(GROUPS_SAVE_BTN));
		return $res;
	}

	function associateGroups()
	{
		// when ever a group is renamed or removed from the directory
		// we need to give the user the ability to reconnect->associate the 'floating'
		// groups.

		// first we test if the user selected any groups from both lists
		// we need to make sure the user selects only one group from each list

		if (isset( $_POST['availableGroups']) && isset( $_POST['importedGroups']))
		{
			$selectedAvailableGroups = $_POST['availableGroups'];
			$selectedImportedGroups = $_POST['importedGroups'];

			if (count($selectedAvailableGroups) == 1 && count($selectedImportedGroups) == 1)
			{
				// get the selected groups (which are in arrays)
				$availableIndex = $selectedAvailableGroups[0];
				$importedIndex = $selectedImportedGroups[0];

				// get the groups names
				$tmpImportedGroup = $this->m_importedGroups[$importedIndex];
				$tmpAvailableGroup = $this->m_availableGroups[$availableIndex];

	   			$asocciated = false;
	   			// loop through group objects and set the state and name
	   			foreach ( $this->m_groupsObjArr as $key=>$groupObj)
	   			{
	   				if ( $groupObj->m_Name == $tmpImportedGroup && !$groupObj->m_isAssociated)
	   				{
	   					$this->m_groupsObjArr[$key]->m_State = UPDATE_GROUP;

	   					// Update the oldName field, get rid of square brackets:
	   					$this->m_groupsObjArr[$key]->m_oldName = ltrim((rtrim($this->m_groupsObjArr[$key]->m_Name, "]")), "[");

	   					$this->m_groupsObjArr[$key]->m_Name = $tmpAvailableGroup;
	   					$asocciated = true;
	   					$this->m_session->set(PAGECHANGED, 'changed');
	   					break;
	   				}
	   			}

	   			if (!$asocciated)
   				{
   					// error msg, user can associate only mismatched groups.
   					$errorCode = array(HSP_ERR_GROUPS_ASSOC_MISMATCHED_ERROR);
					$this->m_session->set(SESSION_ERRORS, $errorCode);
   				}
   				else
   				{
					// remove the group from left (available) list and
					// add the the group to the right (imported) list
					unset($this->m_availableGroups[$availableIndex]);
		   			$this->m_importedGroups[$importedIndex] = $tmpAvailableGroup;
   				}

	   			$this->sortAndUpdateSessions();
			}
			else
			{
				// error msg saying user must select only one item from each list
				$errorCode = array(HSP_ERR_GROUPS_SELECT_ONE_ERROR);
				$this->m_session->set(SESSION_ERRORS, $errorCode);
			}
		}
		else
		{
			// error msg saying user must select an item from each list
			$errorCode = array(HSP_ERR_GROUPS_MUST_SELECT_ERROR);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}

	function sortAndUpdateSessions()
	{
		// sort the two lists and update the session variables
		natcasesort($this->m_importedGroups);
		natcasesort($this->m_availableGroups);

		// save variables to the Session so we can get them in later post's calls
		$this->m_session->set(SESSION_AVAILABLE_GROUPS, $this->m_availableGroups);
		$this->m_session->set(SESSION_IMPORTED_GROUPS, $this->m_importedGroups);
		$this->m_session->set(SESSION_DB_GROUPS, $this->m_groupsObjArr);
	}

	function GetDirectoryName($dirID)
	{
		// get directory name by directory id
		$res = $this->m_groupsTbl->GetDirectoryName($dirID);
		return $res;
	}

	function onShowGroups($dirID)
	{
		if ( $this->getDirectoryGroups($dirID) )
		{
			$this->getImportedListFromDB($dirID);
	
			$this->synchronizeList();
	
			$this->populateAvailableList();
			$this->populateImportedList();
	
			$this->m_session->set(SESSION_AVAILABLE_GROUPS, $this->m_availableGroups);
			$this->m_session->set(SESSION_IMPORTED_GROUPS, $this->m_importedGroups);
		}
	}
	
	function onClearGroups()
	{
		
		$this->m_availableGroups = null;
		$this->m_importedGroups = null;
		
		$this->populateAvailableList();
		$this->populateImportedList();
	
		$this->m_session->set(SESSION_AVAILABLE_GROUPS, $this->m_availableGroups);
		$this->m_session->set(SESSION_IMPORTED_GROUPS, $this->m_importedGroups);	
		
	}
	
	function authenticate( $userName, $password, $dirID)
	{					
		$dirAuthObj = new authentication( $this->GetDatabase() ,$this->m_session );
		return $dirAuthObj->authenticate( $userName, $password, $dirID );	
	}
	
}
?>