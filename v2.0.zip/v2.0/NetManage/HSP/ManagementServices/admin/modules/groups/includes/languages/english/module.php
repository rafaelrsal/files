<?PHP
define('GROUPS_MAIN_TXT','Groups');
define('GROUPS_HELP_LNK','Help');
define('GROUPS_REQUIRED_TXT','denotes required field');
define('GROUPS_DIRECTORIES_LBL','Directories:');
define('GROUPS_LIST_LBL','Available Groups:');
define('GROUPS_IMPORTED_LBL','Selected Groups:');
define('GROUPS_IMPORT_BTN','Show Groups');
define('GROUPS_CLEAR_BTN', 'Clear');
define('GROUPS_ADD_BTN','   Add ->   ');
define('GROUPS_REMOVE_BTN','<- Remove');
define('GROUPS_SAVE_BTN','   Save   ');
define('GROUPS_ASSOCIATE_BTN','Associate  ');
define('GROUPS_CHOOSE_DIR_TXT','Select a directory...');
define('GROUPS_SELECT','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--- Select ---');
define('GROUPS_VERIFY_DLG','Verify Connection');
?>