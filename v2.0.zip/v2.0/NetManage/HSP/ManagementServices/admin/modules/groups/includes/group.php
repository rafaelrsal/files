<?PHP
define('NOCHANGE_GROUP',0);
define('NEW_GROUP',1);
define('DELETED_GROUP',2);
define('UPDATE_GROUP',3);

class group
{	
	var $m_id;
	var $m_DirID;
	var $m_Name;
	var $m_oldName;
	var $m_State;
	var $m_isAssociated;
	function group($dir,$name,$id=null,$state=NOCHANGE_GROUP,$associated=true, $oldName=null)
	{
		$this->m_id = $id;
		$this->m_State = $state;
		$this->m_DirID = $dir;
		$this->m_Name = $name;
		$this->m_oldName = $oldName;
		$this->m_isAssociated = $associated;
	}
}
?>
