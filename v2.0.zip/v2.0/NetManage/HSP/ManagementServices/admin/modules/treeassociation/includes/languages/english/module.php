<?PHP
define('ASSOC_USER_TXT','User Applications - ');
define('ASSOC_GROUP_TXT','Group Applications - ');
define('ASSOC_USER_STYLE_LBL','Choose template style:');
define('ASSOC_NAME_LBL','Node name:');
define('ASSOC_ICON_LBL','Icon file:');
define('ASSOC_DESC_LBL','Description:');
define('ASSOC_APP_TYPE_LBL','Application type:');
define('ASSOC_PREVIEW_BTN','Preview');
define('ASSOC_SAVE_BTN','Save');
define('ASSOC_BACK_BTN','< Back');
define('ASSOC_EMPTY_APP_TYPE_TXT','None');
define('ASSOC_CHANGES','There are unsaved changes on this page. OK to ignore changes?');
define('ASSOC_HEADER_DETAILS_TXT','Details');
define('ASSOC_APP_TYPE_TXT','None');
define('ASSOC_W2H_TXT','OnWeb Web-to-Host');
define('ASSOC_ONWEB_TXT','OnWeb application');
define('ASSOC_LINK_TXT','URL');
define('ASSOC_PROTECTED_LINK_TXT','URL, protected');
define('ASSOC_LOCALSTART_TXT','Enable Local Start');
define('ASSOC_PLATFORM_LBL','Platform:');
define('ASSOC_MOBILE_LBL','Mobile');
define('ASSOC_DESKTOP_LBL','Desktop');
?>