<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: module.php
  Purpose: treeAssociation module - association the HSP applications to a user/group.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
?>

<script language="JavaScript" type="text/javascript">
<!--
<?php include ("includes/LMenu/libjs/layersmenu-browser_detection.js"); ?>
// -->
</script>
<script language="JavaScript" type="text/javascript" src="includes/LMenu/libjs/layerstreemenu-cookies.js"></script>

<?PHP
require_once('HTML/QuickForm.php');

include_once ("includes/LMenu/lib/PHPLIB.php");
include_once ("includes/LMenu/lib/layersmenu-common.inc.php");
include_once ("includes/LMenu/lib/treemenu.inc.php");
require_once ("includes/classes/LMenu.php");

require_once('admin/modules/treeAssociation/includes/treeAssociationTbl.php');

define('SESSION_SET_PERMISSIONS_DETAILS', 	'setPermissionsItemDetails');

class treeAssociation extends ModuleBase
{
	var $m_bIsGroup;
	var $m_entityID;
	var $m_entityName;
	var $m_selectedNode;
	var $m_arrSelectedNodesList;
	var $m_treeView;
	var $m_treeViewMenu;
	
	function treeAssociation($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$db  = &parent::GetDatabase();
		$this->m_treeAssocTbl = new treeAssociationTbl($db);
		
		$this->m_session->remove(SESSION_MESSAGES);

	}
	
	function init()
	{
		parent::init("treeAssociation");

		$this->m_selectedNode = 0;
		$this->m_arrSelectedNodesList = null;
		$this->m_bIsGroup = "false";
		$this->m_entityName = null;
		$this->m_entityID = 0;
		
		$permissionDetails = $this->m_session->value(SESSION_SET_PERMISSIONS_DETAILS);

		if(is_array($permissionDetails) && count($permissionDetails) >0)
		{
			$dirName = $permissionDetails['displayName'];
			$this->m_entityName = $permissionDetails['name'];
			$this->m_entityID = $permissionDetails['id'];
			$type = $permissionDetails['type'];
			$details = ASSOC_USER_TXT;
			if($type == "Group")
			{
				$details = ASSOC_GROUP_TXT;
				$this->m_bIsGroup = "true";
			}
			$details .=$this->m_entityName;
		}		
		
		if("1" != $this->m_entityID ||  "true" == $this->m_bIsGroup)
		{
			$details .= '@'.$dirName;
		}
		// for print preview. see print.php
		$_SESSION['print_preview_header'] = $details;
		
		$bIsGroup = false;
		if ( $this->m_bIsGroup == "true" )
		{
			$bIsGroup = true;
		}
		
		$enableLocalstart = '';
		$enableLocalstartFromDb = $this->m_treeAssocTbl->getLocalstartState( $this->m_entityID,$bIsGroup );		
		
		if( isset($_GET['checked']) )
		{
			if ( $_GET['checked']  == 'true' )
			{
				$enableLocalstart = 'CHECKED';
			}			
		}
		elseif ( $enableLocalstartFromDb )
		{
			$enableLocalstart = 'CHECKED';
		}
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm("treeAssociationForm"); //default is post
		
		$this->m_form->addElement('text', 'name',  ASSOC_NAME_LBL, array('size' => 20, 'maxlength' => 255));
		$this->m_form->addElement('text', 'icon', ASSOC_ICON_LBL);
		$this->m_form->addElement('text', 'description', ASSOC_DESC_LBL);
		$this->m_form->addElement('text', 'apptype', ASSOC_APP_TYPE_LBL);
		$this->m_form->addElement('text', 'platform', ASSOC_PLATFORM_LBL);
		
		$this->m_form->addElement('header', 'header', $details);
		$this->m_form->addElement('text', 'header2',ASSOC_HEADER_DETAILS_TXT);
		$this->m_form->addElement('submit', 'save', ASSOC_SAVE_BTN,"class='NewButton'");
		$this->m_form->addElement('button', 'back', ASSOC_BACK_BTN,"onclick=onBack() class='NewButton'");
		$this->m_form->addElement('button', 'preview', ASSOC_PREVIEW_BTN,"onclick=loadApplicationTreePreview() class='NewButton'");
		$this->m_form->addElement('select', 'style', ASSOC_USER_STYLE_LBL,$this->getStyleList());
		$this->m_form->addElement('hidden', 'back_button', 'none');
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->addElement('checkbox', 'enableLocalstart', ASSOC_LOCALSTART_TXT, "",$enableLocalstart." onclick=isChanged=true");


		// Present the data of a node as read only:
		$temp = &$this->m_form->getElement("name");
		$temp->freeze();
		$temp = &$this->m_form->getElement("icon");
		$temp->freeze();
		$temp = &$this->m_form->getElement("description");
		$temp->freeze();
		$temp = &$this->m_form->getElement("apptype");
		$temp->freeze();
		$temp = &$this->m_form->getElement("platform");
		$temp->freeze();
		
	}
	
	function process()
	{
		$bNodeUnmarked = false;
		$enableLocalstartState = '';
		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$style = $this->m_treeAssocTbl->getStyle($this->m_entityID,$this->m_bIsGroup);
			$selectElement = &$this->m_form->getElement("style");
			$selectElement->setSelected($style);
			
			if(isset($_GET['nodeID']))
			{
				$res = $this->getNodeData($_GET['nodeID']);
				$descArray = explode(";", $this->m_form->getElementValue("description"));
				foreach($descArray as $desc)
				{
					if(HSP_SUCESS == $res &&  $desc == $_GET['roll'])
					{
						$this->m_selectedNode = $_GET['nodeID'];
						$this->m_arrSelectedNodesList = $this->m_session->value(SESSION_SELECTED_NODES_LIST);
						
						if((is_array($this->m_arrSelectedNodesList)) && 
											(in_array($this->m_selectedNode, $this->m_arrSelectedNodesList)))
						{
							// If the selected node already appears in the list it means it 
							// actually needs to be dis-selected. Thus we later on don't present it's
							// details:
							$bNodeUnmarked = true;
						}
						
						// User marked a node thus changed the gat/uat:
						$isUpdated = "true";
						$this->m_session->set(SESSION_PAGECHANGED, $isUpdated);

						if(isset($_GET['treeIndex']))
						{
							$treeIndex = $_GET['treeIndex'];
							$this->m_session->set(SESSION_NODE_TREE_POSITION, $treeIndex);
						}
					}
				}
			}
			else
			{
				$this->m_session->remove(SESSION_NODE_TREE_POSITION);
				// Make sure the list is empty:
				$this->m_session->remove(SESSION_SELECTED_NODES_LIST);
				// Get the user/group subtree nodes, and update the $this->m_arrSelectedNodesList,
				// so it can be presented on the HAT itself.
				$res = $this->GetExistingTree();
				if(HSP_SUCCESS != $res)
				{
					$errorCode = array($res);
					$this->m_session->set(SESSION_ERRORS, $errorCode);
				}
			}
		}
		else
		{
			/////////// POST ////////////
			/////////  BACK /////////////
			if(isset($_POST['back_button']) && ("back" == $_POST['back_button']))
			{
				// Clear fields and go back to Assoc Application page:
				$this->m_session->remove(SESSION_SELECTED_NODES_LIST);
				$this->m_session->remove(SESSION_PAGECHANGED);	
				Header('Location: admin.php?module=setPermissions&roll='.$_POST['roll']);
				exit();

			}

			///////////  SAVE /////////////
			if(isset($_POST['save']) )
			{
				if(("1" == $this->m_entityID) && ("true" != $this->m_bIsGroup))
				{
					$this->m_entityName = "anonymous";
				}

				$this->m_arrSelectedNodesList = $this->m_session->value(SESSION_SELECTED_NODES_LIST);

				// Save in the data base the user/group name, id, and the list of
				// selected nodes:
				$type = "group";
				$bIsGroup = true;
				if($this->m_bIsGroup == "false")
				{
					$type = "user";
					$bIsGroup = false;	
				}
				
				// Transform array to string:
				$res = HSP_SUCCESS;
				$enableLocalstart = '';
				
				if ( isset($_POST['enableLocalstart']) )
				{
					$res = $this->m_treeAssocTbl->updateLocalstartState( $this->m_entityID , 1 , $bIsGroup );
					$enableLocalstart = 'CHECKED';
				}
				else 
				{
					$res = $this->m_treeAssocTbl->updateLocalstartState( $this->m_entityID , 0 , $bIsGroup );
				}
				$this->m_form->removeElement('enableLocalstart');
				$this->m_form->addElement('checkbox', 'enableLocalstart', ASSOC_LOCALSTART_TXT, "",$enableLocalstart." onclick=isChanged=true");
				
				
				$this->m_session->remove(SESSION_PAGECHANGED);
				
				if ( is_array($this->m_arrSelectedNodesList ) )
				{
					if ( !count( $this->m_arrSelectedNodesList ) )
					{ // this means that there are no selected nodes
					  // clear premissions for this entity
						$res = $this->m_treeAssocTbl->clearPermissions( $this->m_entityID , $this->m_entityName );
					}
					else 
					{					
						$nodeList = implode(",", $this->m_arrSelectedNodesList);
						// First remove the old tree:
		
						$res = $this->m_treeAssocTbl->removeGatUat($this->m_entityID, $this->m_entityName);
						if(HSP_SUCCESS == $res)
						{
							$res = $this->m_treeAssocTbl->insertToGatUat($this->m_entityID, $this->m_entityName, $nodeList, $type);
		
							// udi zisser, add style to user / group table
							if ( isset($_POST['style']) )
							{
								$styleName = htmlspecialchars($_POST['style']);
								if ( $type == 'user')
								{
									$res = $this->m_treeAssocTbl->updateUserStyle( $this->m_entityID , $styleName);								
								}
								else
								{
									$res = $this->m_treeAssocTbl->updateGroupStyle( $this->m_entityID , $styleName);
								}
							}
							
							$this->m_session->remove(SESSION_PAGECHANGED);						
							parent::CriaLog(ASSOC_SAVE_BTN);
						}
					}
				}		
				if(HSP_SUCCESS != $res)
				{
					$errorCode = array($res);
					$this->m_session->set(SESSION_ERRORS, $errorCode);
				}

			}
		}
		
		if((0 != intval($this->m_selectedNode)) && (false == $bNodeUnmarked))
		{
			$res = $this->getNodeData($this->m_selectedNode);
		}
		
	}
	
	function finalize()
	{
		$arrVars = array();

		// Build the menu:
		$this->m_treeViewMenu = new TreeMenu();
		$this->m_treeViewMenu->setImgwww("includes/LMenu/images/"); // allowing different icons.
		$this->m_treeViewMenu->setImgdir("includes/LMenu/images/");
		$this->m_treeViewMenu->setLibjsdir("includes/LMenu/libjs/");
		$db = $this->m_treeAssocTbl->getDB(); 
		$this->m_treeViewMenu->setDBConnParms($db->getDSNasString());
		$this->m_treeViewMenu->setTableName(TABLE_TREE);
		
		if(0 != $this->m_selectedNode)
		{
			if(is_array($this->m_arrSelectedNodesList))
			{
				// Search the already selected nodes. If new node ID already exists it
				// must be removed from the list. Else, inserted to the list and presented
				// as selected as a result.
				if(false === ($key = array_search($this->m_selectedNode, $this->m_arrSelectedNodesList)))
				{
					array_push($this->m_arrSelectedNodesList, $this->m_selectedNode);
				}
				else
				{
					unset($this->m_arrSelectedNodesList[$key]);
				}
			}
			else
			{
				// The first selected node:
				$this->m_arrSelectedNodesList = array();
				array_push($this->m_arrSelectedNodesList, $this->m_selectedNode);
			}
		}

		if( is_array($this->m_arrSelectedNodesList) && count($this->m_arrSelectedNodesList) )
		{
			$arrVars['bPreview'] = 1;
			// Create a temp file that will hold the GAT/UAT and present it
			$res = $this->prepareSubTreeFile($this->m_arrSelectedNodesList);
			if(HSP_SUCCESS != $res)
			{
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);
			}
		}
		else
		{
			//disable the print preview button
			$arrVars['bPreview'] = 0;
		}		
		
		$isUpdated = $this->m_session->value(SESSION_PAGECHANGED);
		if("" == $isUpdated)
		{
			$isUpdated = "false";
		}

		$arrVars["setupdated"] = $isUpdated;		
		
		$arrVars['strMesg'] = ASSOC_CHANGES;
			
		// Let the tree menu build the tree and mark the selected paths:
		$this->m_treeViewMenu->scanTableForMenu("HSPTree1", "" , "", $this->m_arrSelectedNodesList);
		
		if(is_array($this->m_arrSelectedNodesList))
		{	// keep the list of selected nodes:
			$this->m_session->set(SESSION_SELECTED_NODES_LIST, $this->m_arrSelectedNodesList);
		}
		
		$arrVars['appsTree'] = $this->m_treeViewMenu->newTreeMenu("HSPTree1");
		
		$treeNodePosition = $this->m_session->value(SESSION_NODE_TREE_POSITION);
		$arrVars["treeIndex"] = $treeNodePosition;
		//************************GUILHERME LIMA 12/03/2013***********************
		$arrVars['roll'] = $_SESSION['roll'];
		
		parent::finalize($arrVars);
	}
	
	/**
	* The method to get the a selected node data from the database
	* @param int $nodeID the id of the selected node
	* @access public
	* @return void
	*/
	function getNodeData($nodeID)
	{
		$arrTreeRes = null;

		// Get the id of the application:
		$res = $this->m_treeAssocTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);

		$icon = $arrTreeRes[7];

		// If the icon file is the application default, there is no need to show it explicitly:
		if((W2H_ICON == $icon) || (ONWEB_ICON == $icon) || (LINK_ICON == $icon) || (PROTECTED_LINK_ICON == $icon))// do the same check for each application type
		{
			$icon = "default";
		}


		if(HSP_SUCCESS == $res)
		{
			if((null == $arrTreeRes[3]) || ("" == $arrTreeRes[3]))
			{
				$arrTreeRes[3] = ASSOC_APP_TYPE_TXT;
			}
			elseif ( $arrTreeRes[3] == 'w2h')
			{
				$arrTreeRes[3] = ASSOC_W2H_TXT;
			}
			elseif ( $arrTreeRes[3] == 'onWeb')
			{
				$arrTreeRes[3] = ASSOC_ONWEB_TXT;
			}
			elseif ( $arrTreeRes[3] == 'url')
			{
				// Check if this is a protected url
				$res = $this->m_treeAssocTbl->GetRowForField(TABLE_APPS_LINKS, 'appID', $arrTreeRes[2], $arrAppRes);
				if(HSP_SUCCESS == $res)
				{
					if("0" == $arrAppRes[2])
					{
						// usuall link
						$arrTreeRes[3] = ASSOC_LINK_TXT;
					}
					else
					{
						// protected:
						$arrTreeRes[3] = ASSOC_PROTECTED_LINK_TXT;
					}
				}
				else
				{
					return $res;
				}
			}
			$platform = $arrTreeRes[13]?ASSOC_MOBILE_LBL:ASSOC_DESKTOP_LBL;		
			
			$arrTreeRes[4] = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $arrTreeRes[4]);
			$arrTreeRes[6] = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $arrTreeRes[6]);
			$this->m_form->setDefaults(array(	'name'			=>$arrTreeRes[4],
												'icon'			=>$icon,
												'description'	=>$arrTreeRes[6],
												'apptype'		=>$arrTreeRes[3],
												'platform'		=>$platform));
			return $res;

		}

		$errorCode = array($res);
		$this->m_session->set(SESSION_ERRORS, $errorCode);

		return $res;
	}

	function prepareSubTreeFile($nodeList = null)
 	{
 		include_once("includes/LMenu/lib/layersmenu-process.inc.php");
 		$this->m_treeView = new ProcessLayersMenu();
 		$db = $this->m_treeAssocTbl->getDB();
 		$this->m_treeView->setDBConnParms($db->getDSNasString());
 		$this->m_treeView->setTableName(TABLE_TREE);
			
		if((is_null($nodeList)) || (!is_array($nodeList)))
		{
			// Running preview from Application Tree. The user wants to see
			// the whole tree, so the selected node is 2 (the ID of the top level node):
			$nodeList = array("2");
		}

		// Scan table will take care that the href of each node points to nothing:
		$this->m_treeView->scanTableForMenu("stam1","","previewNoTop", $nodeList);
		$strFile = $this->m_treeView->getMenuStructure("stam1");

		// This file is used for testing preview purposes only:
		$fileName = "tree.preview";

		// Save file:
		$path = "data/apptrees/"; // TODO: the path should be a general define.

		if(file_exists($path.$fileName))
		{
			// Avoid php warnings:
			if(is_writable($path.$fileName) == false)
				return 	HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
		}

		// Running over the old file whether exists or not:
		$handle = @fopen($path.$fileName, "w");
		if($handle)
		{
			$res = fwrite($handle, $strFile);
			fclose($handle);
			if(false === $res)
			{
				return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
			}
			return HSP_SUCCESS;
		}

		return 	HSP_ERR_FILE_NOT_FOUND;
 	}
	function GetExistingTree()
	{
		$res = HSP_ERR_DB_ERROR;
		$arrRes = null;
		
		if(("1" == $this->m_entityID) && ("true" != $this->m_bIsGroup))
		{
			$this->m_entityName = "anonymous";
		}

		// Get the user/group data:
		$arrRes = $this->m_treeAssocTbl->GetAllEx("SELECT nodeList FROM ".TABLE_GAT_UAT." WHERE id=$this->m_entityID AND name=\"$this->m_entityName\";");
 		//$res = $this->m_treeAssocTbl->GetRowForField(	TABLE_hsp_gat_uat,"id", $this->m_entityID, $arrRes);
 		if(is_array($arrRes))
 		{
			$res = HSP_SUCCESS;
 			if(count($arrRes) > 0)
 			{
 				// Extract the nodeList string to an array:
 				$this->m_arrSelectedNodesList = explode(",", $arrRes[0][0]);
 			}
 		}

 		return $res;
 	}

 	function getStyleList()
 	{
 		$list = array();
 		$dirpath = PORTAL_STYLE_DIR;

 		$dh = opendir($dirpath);

   		while (false !== ($file = readdir($dh)))
   		{
			//Don't list subdirectories
   			if (is_dir("$dirpath/$file") && $file != '.' && $file != '..' && $file != 'mobile' )
   			{
				//Truncate the file extension and capitalize the first letter
       			$list[$file] = $file;
			}
		}

		closedir($dh);
 		
     	return $list;
 	}
}
?>