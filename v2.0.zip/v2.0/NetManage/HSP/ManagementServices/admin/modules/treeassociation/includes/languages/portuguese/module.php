<?PHP
define('ASSOC_USER_TXT','Aplica��es do Usu�rio - ');
define('ASSOC_GROUP_TXT','Aplica��es do Grupo - ');
define('ASSOC_USER_STYLE_LBL','Escolha o estilo do template:');
define('ASSOC_NAME_LBL','Nome do N�:');
define('ASSOC_ICON_LBL','Arquivo do Icone:');
define('ASSOC_DESC_LBL','Descri��o:');
define('ASSOC_APP_TYPE_LBL','Tipo de Aplica��o:');
define('ASSOC_PREVIEW_BTN','Visualizar');
define('ASSOC_SAVE_BTN','Salvar');
define('ASSOC_BACK_BTN','< Voltar');
define('ASSOC_EMPTY_APP_TYPE_TXT','Nenhum');
define('ASSOC_CHANGES','Existem altera��es n�o salvas nesta p�gina. OK para ignorar as altera��es?');
define('ASSOC_HEADER_DETAILS_TXT','Detalhes');
define('ASSOC_APP_TYPE_TXT','Nenhum');
define('ASSOC_W2H_TXT','OnWeb Web-to-Host');
define('ASSOC_ONWEB_TXT','Aplica��o OnWeb');
define('ASSOC_LINK_TXT','URL');
define('ASSOC_PROTECTED_LINK_TXT','URL, protegida');
define('ASSOC_LOCALSTART_TXT','Habilitar Local Start');
define('ASSOC_PLATFORM_LBL','Plataforma:');
define('ASSOC_MOBILE_LBL','Mobile');
define('ASSOC_DESKTOP_LBL','Desktop');
?>