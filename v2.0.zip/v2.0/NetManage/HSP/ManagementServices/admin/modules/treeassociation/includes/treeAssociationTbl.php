<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created:     Mars 2004

  Title: treeAssoicationTbl.php
  Purpose: Controlling all DB connectivity for the treeAssoication module.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('admin/modules/applicationsTree/includes/applicationsTreeTbl.php');
 
class treeAssociationTbl extends applicationsTreeTbl 
{
	
	function treeAssociationTbl($peardb)	
	{
		parent::applicationsTreeTbl($peardb);
	}

	function insertToGatUat($id, $name, $nodeList, $type)
	{
		$fields_values = array(	'id' => $id,
								'name' => $name,
								'nodeList' => $nodeList,
								'type_entity' => $type,
								);
		
		return $this->m_pearDB->AutoExecute(TABLE_GAT_UAT, $fields_values);
	}
	
	function updateUserStyle( $uid , $style )
	{
		$fields_values = array( 'style'  => $style );
		return $this->m_pearDB->AutoExecute(TABLE_USERS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$uid.';');
	}
	
	function updateGroupStyle( $gid , $style )
	{
		$fields_values = array( 'style'  => $style );
		return $this->m_pearDB->AutoExecute(TABLE_GROUPS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$gid . ';');
	}
	
	function getStyle( $id , $isGroup = false )
	{
		$sql = null;
		if ( $isGroup )
		{
			$sql = "SELECT style FROM ".TABLE_GROUPS." WHERE id=$id;";
		}
		else
		{
			$sql = "SELECT style FROM ".TABLE_USERS." WHERE id=$id;";
		}
		
		$this->m_pearDB->getOne( $sql , $style );
		return $style;
	}
	
	function getLocalstartState( $id , $isGroup = false )
	{
		$sql = null;
		if ( $isGroup )
		{
			$sql = "SELECT localstart FROM ".TABLE_GROUPS." WHERE id=$id;";
		}
		else
		{
			$sql = "SELECT localstart FROM ".TABLE_USERS." WHERE id=$id;";
		}
		
		$this->m_pearDB->getOne( $sql , $localstart );
		return $localstart;
	}
	
	function updateLocalstartState( $id , $state, $isGroup = false )
	{
		$fields_values = array( 'localstart'  => $state );
		
		if ( $isGroup )
		{
			return $this->m_pearDB->AutoExecute(TABLE_GROUPS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$id . ';');
		}
		else 
		{
			return $this->m_pearDB->AutoExecute(TABLE_USERS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$id.';');		
		}
	}
	
	function clearPermissions( $id , $name )
	{
		$sql = "DELETE FROM ".TABLE_GAT_UAT. " WHERE id=$id AND name=\"$name\";";
		$ret = $this->m_pearDB->Query($sql);		
		
		if ( DB::isError($ret) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		return HSP_SUCCESS;
	}
}
?>