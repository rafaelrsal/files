function initPopup()
{
	onChangeType();
	document.getElementById('popupErrors').innerHTML = "&nbsp;";
	win.document.getElementById('newdir').focus();
	document.getElementsByName('name').item(0).focus();
	
	if ( isEmpty ('ssoname') )
	{
		document.getElementsByName('ssoname').item(0).disabled = true;
		document.getElementById('enableSSOChk').checked = false;
	}
}

function finalizePopup()
{
	win.document.getElementsByName('buttonClicked').item(0).value = 'save';     

	if ( validateForm() )			
	{
		 win.document.getElementById('DirForm').submit();
		 window.close();
	}
	else
	{
		document.getElementsByName('name').item(0).focus();
	}	
}

function onChangeType()
{
	var type = document.getElementById('type').value;
	if ( 0 == type) //CUSTOM
	{		    	
		  document.all.div0.style.display='none';
		  document.all.div1.style.display='none';
		  document.all.div2.style.display='none';
		  document.all.div3.style.display='none';
		  document.all.div4.style.display='inline';
		  document.all.div5.style.display='none';
		  document.all.div6.style.display='none';
		  document.all.div7.style.display='none';
		  document.all.div8.style.display='none';
		  document.all.div9.style.display='none'; 
	}
	else if (1 == type) //AD
	 {
		  document.all.div0.style.display='none';
		  document.all.div1.style.display='inline';
		  document.all.div2.style.display='none';
		  document.all.div3.style.display='none';
		  document.all.div4.style.display='none';
		  document.all.div5.style.display='inline';
		  
		  if ('' == document.getElementById( 'port' ).value )
		  {
			document.getElementById( 'port' ).value = 389;
		  }
		  document.all.div6.style.display='none';
		  document.all.div7.style.display='none';
		  document.all.div8.style.display='inline';
		  document.all.div9.style.display='inline'; 
	 }
	else if(2 == type) //LDAP
	 {
		  document.all.div0.style.display='none';
		  document.all.div1.style.display='inline';
		  document.all.div2.style.display='inline';
		  document.all.div3.style.display='inline';
		  document.all.div4.style.display='none';
		  document.all.div5.style.display='none';
		  if ('' == document.getElementById( 'port' ).value )
		  {
			document.getElementById( 'port' ).value = 389;
		  }
		  document.all.div6.style.display='none';
		  document.all.div7.style.display='none';
		  document.all.div8.style.display='none';
		  document.all.div9.style.display='none'; 
	 }
	else if ( 3 == type) //NDS
	 {		    	
		  document.all.div0.style.display='none';
		  document.all.div1.style.display='inline';
		  document.all.div2.style.display='none';
		  document.all.div3.style.display='none';
		  document.all.div5.style.display='none';
		  if ('' == document.getElementById( 'port' ).value )
		  {
				document.getElementById( 'port' ).value = 389;
		  }
		  document.all.div4.style.display='none';
		  document.all.div6.style.display='none';
		  document.all.div7.style.display='none';
		  document.all.div8.style.display='none';
		  document.all.div9.style.display='none'; 
	 }
	else if ( 4 == type) //NT
	 {		    	
		  document.all.div0.style.display='inline';
		  document.all.div1.style.display='none';
		  document.all.div2.style.display='none';
		  document.all.div3.style.display='none';
		  document.all.div4.style.display='none';
		  document.all.div5.style.display='none';
		  document.all.div6.style.display='inline';
		  document.all.div7.style.display='inline';
		  document.all.div8.style.display='none';
		  document.all.div9.style.display='none'; 
	 }		
}

function DoDefaultEnterKey(e)
{
	if( CheckEnter(e) )
	{	
		setParameters();
		finalizePopup();
	}
	else
	{
		return;
	}
}
function setParameters()
{
	win.document.getElementsByName('type').item(0).value = document.getElementsByName('type').item(0).value;
	win.document.getElementsByName('dirname').item(0).value = document.getElementsByName('dirname').item(0).value;
	win.document.getElementsByName('name').item(0).value = document.getElementsByName('name').item(0).value;
	win.document.getElementsByName('host').item(0).value = document.getElementsByName('host').item(0).value;
	win.document.getElementsByName('basedn').item(0).value = document.getElementsByName('basedn').item(0).value;
	win.document.getElementsByName('user').item(0).value = document.getElementsByName('user').item(0).value;
	win.document.getElementsByName('group').item(0).value = document.getElementsByName('group').item(0).value;
	win.document.getElementsByName('user_identifier').item(0).value = document.getElementsByName('user_identifier').item(0).value;
	win.document.getElementsByName('customDirList').item(0).value = document.getElementsByName('customDirList').item(0).value;
	win.document.getElementsByName('ssoname').item(0).value	= document.getElementsByName('ssoname').item(0).value;
	win.document.getElementById('ssonameChk').checked	= document.getElementById('ssonameChk').checked;
}

function onCancel()
{
	win.document.getElementsByName('buttonClicked').item(0).value = 'cancel';
	win.document.getElementById('newdir').focus();
	window.close();
}


function onToggleSSO()
{
	if ( document.getElementById('enableSSOChk').checked )
	{
		document.getElementsByName('ssoname').item(0).disabled = false;
	}
	else
	{
		document.getElementsByName('ssoname').item(0).value = '';
		document.getElementsByName('ssoname').item(0).disabled = true;			
	}
}
function validateForm()
{	
	var type = document.getElementById('type').value;			
	if (isEmpty ( 'name' ))
	{    
		document.getElementById('popupErrors').innerHTML = win.document.getElementById('error1').value;
		return false;
	}
	
	if (1 == type || 3 == type) //AD or eDirectoy
	{
		if (isEmpty ( 'host' ))
		{
			document.getElementById('popupErrors').innerHTML = win.document.getElementById('error2').value;
			return false;
		}
		else if ( !validatePort() )
		{
			document.getElementById('popupErrors').innerHTML = win.document.getElementById('error3').value;
			return false;
		}
	}
	else if (2 == type ) //LDAP
	{
		if (isEmpty ( 'host' ))
		{
			document.getElementById('popupErrors').innerHTML = win.document.getElementById('error2').value;
			return false;
		}
		else if ( !validatePort() )
		{
			document.getElementById('popupErrors').innerHTML = win.document.getElementById('error3').value;
			return false;
		}
		else if ( isEmpty ( 'basedn' ) )
		{
		  document.getElementById('popupErrors').innerHTML = win.document.getElementById('error4').value;
			return false;
		}
		else if ( isEmpty ( 'user' ) )
		{
			document.getElementById('popupErrors').innerHTML = win.document.getElementById('error5').value;
			return false;
		}
		else if ( isEmpty ( 'group' ) )
		{
			document.getElementById('popupErrors').innerHTML = win.document.getElementById('error6').value;
			return false;
		}
		else if ( isEmpty ( 'user_identifier' ) )
		{
			document.getElementById('popupErrors').innerHTML = win.document.getElementById('error7').value;
			return false;
		}
	}
	
	if ( 1 == type ) //AD
	{
		if ( isEmpty ( 'ssoname' ) && document.getElementById('enableSSOChk').checked )
		{
			document.getElementById('popupErrors').innerHTML = win.document.getElementById('error8').value;
			return false;
		}
	}
	
	return true;
}
