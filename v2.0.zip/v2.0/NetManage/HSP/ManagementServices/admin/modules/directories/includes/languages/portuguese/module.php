<?PHP
define('DIR_MAIN_TXT','Configura��o de Diret�rios');
define('DIR_TYPE_LBL','Tipo:');
define('DIR_NAME_LBL','Nome de exibi��o:');
define('DIR_DIR_NAME_LBL','Nome do Diret�rio:');
define('DIR_HOST_LBL','Host:');
define('DIR_PORT_LBL','Porta:');
define('DIR_USER_DN','Usu�rio DN:');
define('DIR_GROUP_DN','Grupo DN:');
define('DIR_BASE_DN','Base DN:');
define('DIR_LIST_TXT','Diret�rio Corrente:');
define('DIR_SSONAME_LBL' , 'Dom�nio:');
define('DIR_ENABLE_SSO_LBL' , 'Habilitar SSO');

define('DIR_CLEAR_BTN','Novo');
define('DIR_SAVE_BTN','Salvar');
define('DIR_EDIT_BTN','Editar');
define('DIR_DELETE_BTN','Remover');
define('DIR_HELP_LNK','Ajuda');
define('DIR_VERIFY_BTN','Verificar Conex�o');
define('DIR_REQUIRED_TXT','verifique os campos obrigat�rios');
define('DIR_NAME_REQ_MSG','Informe o nome');

define('DIR_PORT_REQ_MSG','Informe a porta');
define('DIR_BASEDN_REQ_MSG','Informe a base dn');
define('DIR_USERDN_REQ_MSG','Informe o usu�rio dn');
define('DIR_GROUPDN_REQ_MSG','Informe o grupo dn');
define('DIR_HOST_REQ_MSG','Informe o host');
define('DIR_USER_ID_REQ_MSG','Infome o identificador do usu�rio');
define('DIR_DIRNAME_REQ_MSG','Informe o nome do diret�rio');
define('DIR_SSO_EMPTY_REQ_MSG','Informe o nome do dom�nio SSO');

define('DIR_USER_IDETIFIER_LBL','Identificador do usu�rio:');
define('DIR_PORT_ERR_MSG','A Porta deve ser um n�mero inteiro entre 0 e 65536');
define('DIR_TYPE_NT','Dom�nio NT');
define('DIR_TYPE_ADS','Active Directory');
define('DIR_TYPE_SUNONE','LDAP');
define('DIR_TYPE_EDIRECTORY','eDirectory');
define('DIR_TYPE_CUSTOM','Diret�rio Customizado');
define('DIR_DELETE_CONFIRMATION','Voc� tem certeza que deseja remover o diret�rio selecionado?\nRemovendo um diret�rio voc� estar� removento tamb�m todas as informa��es relacionadas a ele.,\ntais como grupos e usu�rios, do database do HSP.');
define('DIR_CANCEL_BTN','Cancelar');
define('DIR_DIRECTORY_LBL','Diret�rio');
define('DIR_NAME_HDR_LBL' , 'Diret�rio / Nome do Host');
define('DIR_TYPE_HDR_LBL' , 'Tipo');
define('DIR_DISPLAY_NAME_HDR_LBL' , 'Nome de exibi��o');
?>