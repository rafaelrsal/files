<?PHP
define('DIR_MAIN_TXT','Directories Configuration');
define('DIR_TYPE_LBL','Type:');
define('DIR_NAME_LBL','Display name:');
define('DIR_DIR_NAME_LBL','Directory name:');
define('DIR_HOST_LBL','Host:');
define('DIR_PORT_LBL','Port:');
define('DIR_USER_DN','User DN:');
define('DIR_GROUP_DN','Group DN:');
define('DIR_BASE_DN','Base DN:');
define('DIR_LIST_TXT','Current Directories:');
define('DIR_SSONAME_LBL' , 'Domain:');
define('DIR_ENABLE_SSO_LBL' , 'Enable SSO');

define('DIR_CLEAR_BTN','New');
define('DIR_SAVE_BTN','Save');
define('DIR_EDIT_BTN','Edit');
define('DIR_DELETE_BTN','Delete');
define('DIR_HELP_LNK','Help');
define('DIR_VERIFY_BTN','Verify Connection');
define('DIR_REQUIRED_TXT','denotes required field');
define('DIR_NAME_REQ_MSG','Enter a name');

define('DIR_PORT_REQ_MSG','Enter a port');
define('DIR_BASEDN_REQ_MSG','Enter base dn');
define('DIR_USERDN_REQ_MSG','Enter user dn');
define('DIR_GROUPDN_REQ_MSG','Enter group dn');
define('DIR_HOST_REQ_MSG','Enter host');
define('DIR_USER_ID_REQ_MSG','Enter user identifier');
define('DIR_DIRNAME_REQ_MSG','Enter directory name');
define('DIR_SSO_EMPTY_REQ_MSG','Enter SSO domain name');

define('DIR_USER_IDETIFIER_LBL','User identifier:');
define('DIR_PORT_ERR_MSG','Port number should be an integer between 0 and 65536');
define('DIR_TYPE_NT','NT Domain');
define('DIR_TYPE_ADS','Active Directory');
define('DIR_TYPE_SUNONE','LDAP');
define('DIR_TYPE_EDIRECTORY','eDirectory');
define('DIR_TYPE_CUSTOM','Custom Directory');
define('DIR_DELETE_CONFIRMATION','Are you sure you want to delete the selected directory?\nDeleting a directory completely removes it and all related information,\nsuch as groups and users, from the HSP database.');
define('DIR_CANCEL_BTN','Cancel');
define('DIR_DIRECTORY_LBL','Directory');
define('DIR_NAME_HDR_LBL' , 'Directory / Host Name');
define('DIR_TYPE_HDR_LBL' , 'Type');
define('DIR_DISPLAY_NAME_HDR_LBL' , 'Display Name');
?>