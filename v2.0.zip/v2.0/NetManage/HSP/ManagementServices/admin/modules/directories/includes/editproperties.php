<?PHP
$language = $_GET['language'];
require_once("languages/$language/module.php");
?>



<html>
	<head>
		<title><?php echo $_GET['Title'] ?></title>
		<script language="JavaScript" src="module.js"></script>
		<link rel="stylesheet" type="text/css" href="/hsp/includes/stylesheets/hsp.css">
	</head>
	<body id=bodProperties onload='javascript:TakePropertiesFromOpener();'>

		<table height="100%">
		<tr>
			<td width="5px">
			</td>
			<td>
			<font color="red">
				<div ID="errors"></div>
			</font>
			</td>
		</tr>
		<tr>
		<td width="5px">
		</td>
		<td height="99%" valign="top">
			<div id=divProperties>
			</div>
		</td>
		<td width="5px">
		</td>
		</tr>
		<tr>
		<td>
		</td>
		<td height="99%" class="smallText">
			<hr>
			<font color="red" size="1">*</font><?php echo DIR_REQUIRED_TXT ?><br>
			
		</td>
		</tr>

		<tr>
		<td>
		</td>
		<td height="99%">
			<table width=100%>
				<tr>
					<td width=50%>
					</td>
					<td width=50% align=right>
						<input type=submit class="NewButton" value="<?php echo DIR_SAVE_BTN ?>" onclick="Save();return false;">
						<input type=button class="NewButton" value="<?php echo DIR_CANCEL_BTN ?>" onclick="onCancel();">
					</td>
				</tr>
			</table>
		</td>
		</tr>
	</body>
</html>