<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Aug 2004
  Title: module.php (directories)
  Purpose: System directories configuration
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

require_once('admin/includes/classes/authentication.php');
require_once('admin/modules/directories/includes/directoriesTbl.php');
require_once('admin/modules/DirectoryAuth/module.php');

class directories extends ModuleBase
{
	var $m_dirArray = array();
	var $m_session;
	var $m_moduleName;
	var $m_trustedDominsArray;
	var $m_customDirArray;
	var $m_form;
	var $m_bValidate;
	var $m_db;
		
	// directory list
	var $m_dirTypeValues;
	var $m_dirTypesArray;
	
	//editing parameters
	var $m_selectedRow;
	var $m_dirDetails;
	var $m_bEditMode;
	
	// authentication
	var $m_dirAuthObj;
	
	function directories($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		parent::init("directories");
		$this->m_db  = &parent::GetDatabase();
		$this->m_dirTbl = new directoriesTbl($this->m_db);
		$this->getAllDirectories();
		
		$this->m_dirTypeValues = array( DIR_TYPE_CUSTOM=>'0',DIR_TYPE_ADS=>'1',DIR_TYPE_SUNONE=>'2',DIR_TYPE_EDIRECTORY=>'3',DIR_TYPE_NT=>'4' );
		$this->m_dirTypesArray = array(	$this->m_dirTypeValues[DIR_TYPE_ADS]=>DIR_TYPE_ADS,
										$this->m_dirTypeValues[DIR_TYPE_SUNONE]=>DIR_TYPE_SUNONE,
										$this->m_dirTypeValues[DIR_TYPE_NT]=>DIR_TYPE_NT,
										$this->m_dirTypeValues[DIR_TYPE_EDIRECTORY]=>DIR_TYPE_EDIRECTORY,
										$this->m_dirTypeValues[DIR_TYPE_CUSTOM]=>DIR_TYPE_CUSTOM										
										);
		
		$this->m_bEditMode = 'false'; //used only when the edit button is pressed
		$this->m_dirDetails = null; //used for edit manipulations
		$this->m_selectedRow = 1;
		$this->m_bValidate = 'true';
		
		// Instantiate the HTML_QuickForm object
		$formName = 'DirForm';
		$this->m_form = new HTML_QuickForm($formName); //default is post
		$this->m_dirAuthObj = new directoryAuth($globalobjects, $formName);
		$this->m_dirAuthObj->init();
		$this->m_dirAuthObj->process();
		$this->m_dirAuthObj->finalize();
	}
	
	function init()
	{
		$this->getTrustedDomains();
		$this->getCustomDirNames();		
		
		if (is_null($this->m_trustedDominsArray))
		{
			unset($this->m_dirTypesArray[$this->m_dirTypeValues[DIR_TYPE_NT]]);
		}		

		if (is_null($this->m_customDirArray))
		{
			unset($this->m_dirTypesArray[$this->m_dirTypeValues[DIR_TYPE_CUSTOM]]);
		}		
		
		// Build the database form:
		$this->m_form->addElement('header', 'header', 	DIR_MAIN_TXT);
		$this->m_form->addElement('button', 'newdir', 	DIR_CLEAR_BTN,	'class="NewButton" onclick="OpenPropertiesWindow(\''. DIR_CLEAR_BTN .'\',\'modeNew\');" style="width:73px;"');
		$this->m_form->addElement('submit', 'editdir', 	DIR_EDIT_BTN,	'class="NewButton" onclick="beforEdit();" class="NewButton" style="width:73px;"');
		$this->m_form->addElement('button', 'deletedir',DIR_DELETE_BTN, 'class="NewButton" onclick="deleteDir();" style="width:73px;"');
		$this->m_form->addElement('button', 'verify', 	DIR_VERIFY_BTN, 'class="NewButton" onclick="openVerifyWindow();" style="width:150px;"');
		
		$this->m_form->addElement('submit', 'save', 	DIR_SAVE_BTN, 'class="NewButton" onclick="setContent();return false;"');
		$this->m_form->addElement('button', 'cancel', 	DIR_CANCEL_BTN, 'class="NewButton" onclick="onCancel();"');
		
		$this->m_form->addElement('hidden', 'buttonClicked','');
		$this->m_form->addElement('hidden', 'selectedRow', 1);
		$this->m_form->addElement('hidden', 'dirId', -1);
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->addElement('select', 'type', DIR_TYPE_LBL,$this->m_dirTypesArray, 'onChange="onChangeType()" onkeypress="DoDefaultEnterKey(event)" class="FixedWidthObjects"');
		$this->m_form->addElement('text', 'name', DIR_NAME_LBL, array('size' => 20, 'maxlength' => 255, 'class'=>"FixedWidthObjects"));
		// just for NT Domain
		$this->m_form->addElement('select', 'dirname', DIR_DIR_NAME_LBL, $this->m_trustedDominsArray, 'class="FixedWidthObjects" onkeypress="DoDefaultEnterKey(event)" ' );
		
		// just for Custom dir
		
		$this->m_form->addElement('select', 'customDirList', DIR_DIR_NAME_LBL, $this->m_customDirArray, 'class="FixedWidthObjects" onkeypress="DoDefaultEnterKey(event)"' );
		$this->m_form->addElement('text', 'host', DIR_HOST_LBL, array('size' => 20, 'maxlength' => 255, 'class'=>"FixedWidthObjects"));
		$this->m_form->addElement('text', 'port', DIR_PORT_LBL, array('size' => 5, 'maxlength' => 5));
		$this->m_form->addElement('text', 'basedn', DIR_BASE_DN, array('size' => 20, 'maxlength' => 255, 'style' => 'width:200px'));
		$this->m_form->addElement('text', 'user', DIR_USER_DN, array('size' => 20, 'maxlength' => 255, 'style' => 'width:200px'));
		$this->m_form->addElement('text', 'group', DIR_GROUP_DN, array('size' => 20, 'maxlength' => 255, 'style' => 'width:200px'));
		$this->m_form->addElement('text', 'user_identifier', DIR_USER_IDETIFIER_LBL, array('size' => 20, 'maxlength' => 255, 'style' => 'width:200px'));
		$this->m_form->addElement('text', 'ssoname', DIR_SSONAME_LBL, array('size' => 20, 'maxlength' => 255, 'class'=>"FixedWidthObjects"));
		
		$this->m_form->addElement('hidden', 'error1', DIR_NAME_REQ_MSG);
		$this->m_form->addElement('hidden', 'error2', DIR_HOST_REQ_MSG);
		$this->m_form->addElement('hidden', 'error3', DIR_PORT_ERR_MSG);
		$this->m_form->addElement('hidden', 'error4', DIR_BASEDN_REQ_MSG);
		$this->m_form->addElement('hidden', 'error5', DIR_USERDN_REQ_MSG);
		$this->m_form->addElement('hidden', 'error6', DIR_GROUPDN_REQ_MSG);
		$this->m_form->addElement('hidden', 'error7', DIR_USER_ID_REQ_MSG);
		$this->m_form->addElement('hidden', 'error8', DIR_SSO_EMPTY_REQ_MSG);
	}
	
	function process()
	{
		$errorCode = null;
		
		$formValuesArray = $this->m_form->exportValues();	
		$this->m_selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));		
		
		if ( "deletedir" == $formValuesArray['buttonClicked'])
		{
			$res = $this->removeSelectedRow();
			
			if( $res == HSP_SUCCESS)
			{
				// clean all fields in the form
				$this->saveDirList();
				$this->getAllDirectories(); //get it sorted from the db
				parent::CriaLog(DIR_DELETE_BTN);
			}
			else
			{
				$errorCode = $res;
			}
		}
		elseif (array_key_exists("editdir", $formValuesArray))
		{
			//for further use in the tpl file (we need to know that we are in edit mode)
			$this->m_bEditMode = 'true';
			
			$this->m_dirDetails = $this->m_dirArray[$this->m_selectedRow-1];
		}
		elseif ( "save" == $formValuesArray['buttonClicked'])
		{
			$res = $this->doSave( $formValuesArray['dirId'] );
			if ( HSP_SUCCESS == $res )
			{
				$this->setSelectedRow($formValuesArray['dirId']);
				$this->saveDirList();
			}
			else
			{
				$errorCode = $res;
			}
		}
		elseif (isset( $_POST['buttonClickedAuth'] ) && 'ok' == $_POST['buttonClickedAuth'])
		{
			$res = $this->authenticate();
			if ( HSP_SUCCESS != $res )
			{
				$errorCode = $res;
			}
		}
		
		if ( null != $errorCode )
		{
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}
	
	function finalize()
	{
		if ( is_null( $this->m_dirDetails['ssoname'] ) )
		{
			$ssonameCheckbox = '';
		}
		else 
		{
			$ssonameCheckbox = 'checked';
		}
		
		$arrVars = array( 'editMode'=> $this->m_bEditMode,
				'selectedRow'=> $this->m_selectedRow,		
				'bValidated'=> $this->m_bValidate,
				'tblDirs' => $this->generateTable(),
				'lblDelete'=>DIR_DELETE_BTN,
				'lblEdit'=>DIR_EDIT_BTN,
				'lblNew'=>DIR_CLEAR_BTN,
				'lblDIR_DELETE_CONFIRMATION'=>DIR_DELETE_CONFIRMATION,
				'lblVerify'=>DIR_VERIFY_BTN,		
				'lblDirectory'=>rawurlencode(DIR_DIRECTORY_LBL),
				'DirForm_required_note'=>DIR_REQUIRED_TXT,
				'authTitle'=>DIR_VERIFY_BTN,		
				'moduleName'=>  $this->m_moduleName,
				'authenticationDiv'=>  $this->m_dirAuthObj->GetContent(),
				'customDirLabel'=> DIR_TYPE_CUSTOM,
				'enableSSOvalue'=>$ssonameCheckbox,
				'enableSSOlbl'=>DIR_ENABLE_SSO_LBL
				);

		if ( $this->m_bEditMode == 'true')
		{
			$arrVarsEditMode = array('dirId'=> $this->m_dirDetails['id'],
						'display_name'=> $this->m_dirDetails['display_name'],
						'type_dir'=>$this->m_dirDetails['type_dir'],
						'port'=>$this->m_dirDetails['port'],
						'base_dn'=>$this->m_dirDetails['base_dn'],
						'host'=>$this->m_dirDetails['host'],
						'group_dn'=>$this->m_dirDetails['group_dn'],
						'user_dn'=>$this->m_dirDetails['user_dn'],
						'ldap_user_identifier'=>$this->m_dirDetails['ldap_user_identifier'],
						'customDirId'=>$this->m_dirDetails['customDirId'],
						'ssoname'=>$this->m_dirDetails['ssoname']						
						);
			$arrVars = array_merge($arrVars, $arrVarsEditMode );
		}
		

      
		$moduleName = 'directories';
    	$this->m_session->set(SESSION_PREV_MODULE, $moduleName );
    	parent::finalize($arrVars, "directories");
	}

	function getAllDirectories()
	{
		// get all domain names from db
		$this->m_dirArray = $this->m_dirTbl->getAllEx();
	}
				
	function add( $paramList, &$dirId)
	{
		$res = HSP_SUCCESS;
		$fields_values = array(	'display_name' =>trim ( $paramList['displayname'] ),
								'type_dir' =>$paramList['type'],
								'port'=>$paramList['port'],
								'base_dn'=>$paramList['basedn'],
								'host'=>$paramList['host'],	
								'group_dn'=>$paramList['groupdn'],
								'user_dn'=>$paramList['userdn'],
								'ldap_user_identifier'=>$paramList['userIdentifier'],
								'customDirId'=>$paramList['customDirId'],
								'ssoname'=>$paramList['ssoname']
								);
		
		if ( $dirId && -1 != $dirId) //edit directory mode
		{
			$res = $this->m_dirTbl->update($fields_values, $dirId);
			if($res == HSP_SUCCESS)
			{
				parent::CriaLog(DIR_EDIT_BTN);
			}
		}
		else // new directory mode
		{
			$res = $this->m_dirTbl->insert($fields_values, $dirId);
			if($res == HSP_SUCCESS)
			{
				parent::CriaLog(DIR_CLEAR_BTN);
			}
		}
		
		if ( HSP_SUCCESS != $res )
		{
			return $res;
		}		
		$this->getAllDirectories(); //get it sorted from the db
	}

	function removeSelectedRow()
	{
		$id = $this->m_dirArray[$this->m_selectedRow-1]['id'];
		
		$ret = $this->m_dirTbl->remove($id);
		if ($ret == HSP_SUCCESS)
		{
			unset($this->m_dirArray[$this->m_selectedRow - 1]);
			// Remove relevant Gat/Uat:
			
			$ret = $this->removeFromGatUat($id);
			
			if(HSP_SUCCESS == $ret)
			{
				$ret = $this->removeImportedGroupsAndUsers($id);
			}
		}
		
		$this->m_selectedRow = 1;
		return $ret;
	}

	function removeFromGatUat($id)
	{
		$res = HSP_ERR_DB_ERROR;
		
		// Get all the entities in the domain:
		$recordSet = $this->m_dirTbl->getGroupsAndUserByDirID($id);		
		
		if ( is_array($recordSet) )
		{
			if (!count($recordSet)) // there are no records for this id in the db (it is still ok)
			{
				return HSP_SUCCESS;
			}
			
			// Remove from gat/uat all permissions for entities in the domain:
			foreach ($recordSet as $theRecord)
			{
				$res = $this->m_dirTbl->removeGatUat($theRecord[0], $theRecord[1]);
				if(HSP_SUCCESS != $res)
				{
					return $res;
				}
			}
			return $res;	
		}
		
		return $recordSet; // when the retured value is not an array, it is an error.
	}
	
	function removeImportedGroupsAndUsers($id)
	{
		return $this->m_dirTbl->removeImportedGroupsAndUsers($id);
	}
	
	/*
	this functio will generate a file containing the html statments for the drop down in the user
	logon screen.
	the format is:
	<option value="dirname,dirID">Display name</option>
	ex:
	<option value="gennady_ad,100">ADD-GENNADY</option>
	*/
	function saveDirList()
	{
		$fp = fopen('data/directoylist', 'w');

		foreach ($this->m_dirArray as $dir)
		{
			fwrite($fp, '<option value="' . $dir['id'] . '">'.$dir['display_name'].'</option>');
		}
		fclose($fp);
	}

	function getTrustedDomains()
	{
		$this->m_trustedDominsArray = array();
		if ( $this->m_session->exists(SESSION_TRUSTEDDOMAINS_CACHE) )
		{
			$this->m_trustedDominsArray =  $this->m_session->value(SESSION_TRUSTEDDOMAINS_CACHE);
		}
		else
		{
			if(!extension_loaded(PHP_AUTH_MODULE))
			{
				dl(PHP_AUTH_DLL);
			}

			$domains = gettrusteddomains();
			if (is_array($domains) && count($domains))
			{
				foreach ($domains as $domain)
				{
					$this->m_trustedDominsArray[$domain] = $domain;
				}

				// cache the domains for later use.
				if ( count($this->m_trustedDominsArray) )
				{
					natcasesort($this->m_trustedDominsArray);
					$this->m_session->set(SESSION_TRUSTEDDOMAINS_CACHE, $this->m_trustedDominsArray);
				}
			}
			else
			{
				$this->m_trustedDominsArray = null;
			}
		}
	}
	
	function generateTable()
	{
		$tblDirectories = new HTML_Table('id="tblDirs" border="1" class="DataTable" bordercolor="black"');
		
		$headerArr = array(DIR_DISPLAY_NAME_HDR_LBL, DIR_TYPE_HDR_LBL , DIR_NAME_HDR_LBL);
		$tblDirectories->addRow($headerArr , "class='ShortTableHeader'");		

		foreach ( $this->m_dirArray as $key=>$dirRow )
		{
			$rownum = $key + 1 ;
			
			$shortName = $dirRow['display_name'];
			
			if ( strlen($dirRow['display_name']) > 17 )
			{
				$shortName = substr($dirRow['display_name'], 0, 16) . '...';
			}
			
			$row = array ( $shortName, $this->m_dirTypesArray[$dirRow['type_dir']] , $dirRow['host']);
			$tblDirectories->addRow( $row  , "class='UnSelectedRow' onclick='TableRowClick(this,$rownum)'" , 'TD' , true );
			
			$name = $dirRow['display_name'];			
			$attib = array("class='DataCell' title='$name'","class='DataCell'","class='DataCell'");
			$tblDirectories->setRowAttributes($rownum , $attib, false);
		}
		
		return $tblDirectories->toHtml();
	}
	
	function doSave( &$dirId )
	{
		$displayname 	= htmlspecialchars($this->m_form->exportValue('name'));
		$host 			= htmlspecialchars($this->m_form->exportValue('host'));
		$port 			= htmlspecialchars($this->m_form->exportValue('port'));
		$basedn 		= htmlspecialchars($this->m_form->exportValue('basedn'));
		$userdn 		= htmlspecialchars($this->m_form->exportValue('user'));
		$groupdn 		= htmlspecialchars($this->m_form->exportValue('group'));
		$userIdentifier = htmlspecialchars($this->m_form->exportValue('user_identifier'));
		$type 			= htmlspecialchars($this->m_form->exportValue('type'));
		$ssoname		= htmlspecialchars($this->m_form->exportValue('ssoname'));				
		$dirname = null;
		
		if ( $type == $this->m_dirTypeValues[DIR_TYPE_NT] )
		{
			$dirnameElement =  &$this->m_form->getElement('dirname');
			$domainArr = $dirnameElement->getSelected();
			$dirname = $this->m_trustedDominsArray[$domainArr[0]];
			if (isset($_POST['ssonameChk']) && 'on' == $_POST['ssonameChk'])
			{
				$ssoname = $dirname;
			}
			else 
			{
				$ssoname = null;
			}
		}
		elseif ( $type == $this->m_dirTypeValues[DIR_TYPE_CUSTOM] )		
		{
			$dirnameElement =  &$this->m_form->getElement('customDirList');
			$domainArr = $dirnameElement->getSelected();
			$dirname = $this->m_customDirArray[$domainArr[0]];
		}
		
		if ( '' == trim( $ssoname ) )
		{
			$ssoname = null;
		}
		elseif ( !is_null( $ssoname ) )
		{
			foreach ( $this->m_dirArray as $dirItem )
			{
				if ( strtolower( $dirItem['ssoname'] ) == strtolower( $ssoname ) && $dirItem['id'] != $dirId )
				{
					return HSP_ERR_SSONAME_EXISTS;
				}
			}
		}
		
		$paramList = array();
		
		$paramList['selectedDirID'] = $dirId;
		$paramList['displayname'] 	= $displayname;
		$paramList['customDirId'] 	= null;

		$paramList['type'] = $type;
		if ( $type == $this->m_dirTypeValues[DIR_TYPE_NT] )
		{
			$paramList['dirname'] 			= $dirname;
			$paramList['port'] 				= null;
			$paramList['basedn'] 			= null;
			$paramList['host'] 				= $dirname;
			$paramList['groupdn'] 			= null;
			$paramList['userdn'] 			= null;
			$paramList['userIdentifier'] 	= null;
			$paramList['ssoname'] 			= $ssoname;
		}
		elseif ( $type == $this->m_dirTypeValues[DIR_TYPE_SUNONE])
		{
			$paramList['port'] 				= $port;
			$paramList['basedn']			= $basedn;
			$paramList['host'] 				= $host;
			$paramList['groupdn'] 			= $groupdn;
			$paramList['userdn'] 			= $userdn;
			$paramList['userIdentifier'] 	= $userIdentifier;
			$paramList['dirname'] 			= '';
			$paramList['ssoname'] 			= null;
		}
		elseif ($type == $this->m_dirTypeValues[DIR_TYPE_ADS])
		{
			$paramList['port'] 				= $port;
			$paramList['basedn']			= null;
			$paramList['host'] 				= $host;
			$paramList['groupdn'] 			= null;
			$paramList['userdn'] 			= null;
			$paramList['userIdentifier'] 	= null;
			$paramList['dirname'] 			= '';
			$paramList['ssoname'] 			= $ssoname;
		}
		elseif ($type == $this->m_dirTypeValues[DIR_TYPE_EDIRECTORY])
		{
			$paramList['port'] 				= $port;
			$paramList['basedn']			= $basedn;
			$paramList['host'] 				= $host;
			$paramList['groupdn'] 			= null;
			$paramList['userdn'] 			= null;
			$paramList['userIdentifier'] 	= null;
			$paramList['dirname'] 			= '';
			$paramList['ssoname'] 			= null;
		}
		elseif ( $type == $this->m_dirTypeValues[DIR_TYPE_CUSTOM] )
		{
			$paramList['dirname'] 			= $dirname;
			$paramList['port'] 				= null;
			$paramList['basedn'] 			= null;
			$paramList['host'] 				= $dirname;
			$paramList['groupdn'] 			= null;
			$paramList['userdn'] 			= null;
			$paramList['userIdentifier'] 	= null;
			$paramList['customDirId'] 		= $domainArr[0];
			$paramList['ssoname'] 			= null;
		}
		
		return $this->add( $paramList, $dirId );
	}
	
	function authenticate()
	{
		$userName = $_POST['username'];
		$password = $_POST['password'];
					
		$id = $this->m_dirArray[$this->m_selectedRow-1]['id'];
		$dirAuthObj = new authentication( $this->m_db ,$this->m_session );
		
		return $dirAuthObj->authenticate( $userName, $password, $id );	
	}
	
	function getCustomDirNames()
	{
		$customDirNames = $this->m_dirTbl->getCustomDirsList();
		
		if ( count($customDirNames) )
		{			
			foreach ($customDirNames as $dirItem )
			{
				$this->m_customDirArray[$dirItem['id']] = $dirItem['name'];
			}
		}

		if ( is_array($this->m_customDirArray) )
		{
			natcasesort($this->m_customDirArray);
		}
	}
	
	// set the new location of the directory in the displayed table
	function setSelectedRow($dirId)
	{
		foreach ($this->m_dirArray as $key=>$directory)
		{
			if ($directory['id'] == $dirId)
			{
				$this->m_selectedRow = $key+1;
				return;
			}
		}
	}
}
?>