<?PHP
class directoriesTbl
{
	var $m_pearDB;
	function directoriesTbl(&$peardb)	
	{
		$this->m_pearDB = $peardb;
		$this->m_pearDB->connect();		
	}

	function getAllEx()
	{
		return $this->m_pearDB->GetAllEx("SELECT * FROM ".TABLE_DIRECTORIES." ORDER BY display_name", null, DB_FETCHMODE_ASSOC);
	}
	
	function insert( $fields_values, &$dirId )
	{	
		$displayName = $fields_values['display_name'];
		$sql = "SELECT COUNT(id) FROM " . TABLE_DIRECTORIES ." WHERE display_name=\"$displayName\";";
		$this->m_pearDB->GetOne($sql, $count);
		
		if ( DB::isError($count) )
		{
			return HSP_ERR_DB_ERROR;
		}
		
		if (!$count)
		{
			$ret = $this->m_pearDB->AutoExecute(TABLE_DIRECTORIES, $fields_values);
			
			if ($ret == HSP_SUCCESS)
			{
				$ret  = $this->m_pearDB->getOne("SELECT MAX(id) FROM ".TABLE_DIRECTORIES.";", $dirId);
				if ( DB::isError($ret) )
				{
					return HSP_ERR_DB_ERROR;
				}
			}
			else
			{
				return HSP_ERR_DB_ERROR;
			}
		}
		else
		{
			return HSP_ERR_DIRNAME_ALREADY_DEFINED;
		}
		
		return HSP_SUCCESS;		
	}

	function update($fields_values, $dirId)
	{
		$displayName = $fields_values['display_name'];
		$sql = "SELECT COUNT(id) FROM " . TABLE_DIRECTORIES ." WHERE display_name=\"$displayName\" AND id!=$dirId;";
		$this->m_pearDB->GetOne($sql, $count);
		
		if ( DB::isError($count) )
		{
			return HSP_ERR_DB_ERROR;
		}
		
		if (!$count)
		{
			return $this->m_pearDB->AutoExecute(TABLE_DIRECTORIES, $fields_values, DB_AUTOQUERY_UPDATE,'id="'.$dirId.'";');			
		}

		return HSP_ERR_DIRNAME_ALREADY_DEFINED;
	}
	
	function remove($id)
	{
		$sql = "DELETE FROM ".TABLE_DIRECTORIES . " WHERE id={$id};";
		$ret = $this->m_pearDB->Query($sql);
		
		if ( DB::isError($ret) )
		{
			$ret = HSP_ERR_DB_SQL_ERROR;
		}
		else
		{
			$ret = HSP_SUCCESS;
		}
		
		return $ret;
	}
	
	function removeImportedGroupsAndUsers($dirId)
	{
		$ret = HSP_ERR_DB_SQL_ERROR;
		$sql = "DELETE FROM ".TABLE_GROUPS . " WHERE dirID='{$dirId}';";
		$ret = $this->m_pearDB->Query($sql);
		
		if ( DB::isError($ret) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
			
		$sql = "DELETE FROM ".TABLE_USERS . " WHERE dirID='{$dirId}';";
		$ret = $this->m_pearDB->Query($sql);
		
		if ( DB::isError($ret) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		return HSP_SUCCESS;		
	}

	function getGroupsAndUserByDirID($dirID)
	{
		$recSetGroups = $this->m_pearDB->GetAllEx("SELECT id,name FROM ".TABLE_GROUPS." WHERE dirID=$dirID");
		
		$recSetUsers = $this->m_pearDB->GetAllEx("SELECT id,name FROM ".TABLE_USERS." WHERE dirID=$dirID");
		
		if(!is_array($recSetGroups))
		{
			return $recSetUsers;
		}

		if(!is_array($recSetUsers))
		{
			return $recSetGroups;
		}
			
		// Merge to one rec set:
		return  array_merge($recSetGroups, $recSetUsers);
	}
	
	function removeGatUat($id, $name)
	{
		$sql = "DELETE FROM ".TABLE_GAT_UAT. " WHERE id=$id AND name=\"$name\";";		
		$ret = $this->m_pearDB->Query($sql);
		
		if ( DB::isError($ret) )
		{
			$ret  = HSP_ERR_DB_SQL_ERROR;
		}
		else
		{
			$ret = HSP_SUCCESS;
		}
		
		return $ret;
	}

	function getCustomDirsList()
	{	
		$sql = "SELECT id, name FROM ".TABLE_CUSTOM_DIRECTORY . ";";
		$ret = $this->m_pearDB->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		
		if ( DB::isError($ret) )
		{
			$ret  = HSP_ERR_DB_SQL_ERROR;
		}
		return $ret;
	}
}
?>