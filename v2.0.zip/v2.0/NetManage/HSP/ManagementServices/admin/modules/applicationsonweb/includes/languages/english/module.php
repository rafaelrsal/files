<?PHP
define('APPSONWEB_MAIN_TXT','OnWeb Application - ');
define('APPSONWEB_URL_LBL','Server URL:');
define('APPSONWEB_USERNAME_LBL','User name:');
define('APPSONWEB_PASSWORD_LBL','Password:');
define('APPSONWEB_APPLIST_LBL','Applications:');
define('APPSONWEB_OLD_APP_TXT','Previously selected application:');
define('APPSONWEB_CANCEL_BTN','Cancel');
define('APPSONWEB_GETAPPS_BTN','Get Applications');
define('APPSONWEB_BACK_BTN','< Back');
define('APPSONWEB_SAVE_BTN','Save');
define('APPSONWEB_REQUIRED_TXT','denotes required field');
define('APPSONWEB_URL_REQ_MSG','OnWeb Server URL is required');
?>

