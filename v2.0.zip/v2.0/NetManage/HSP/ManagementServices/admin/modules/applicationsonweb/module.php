<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey
  					Udi Zisser
  					
  Date Created:     Mars 2004

  Title:            applicationsOnWeb.php
  Purpose:          ApplicationsOnWeb module - building the HSP tree of applications.
  Limitations:		Requires PHP 4+

 ============================================================================*/
?>

<?PHP
require_once('HTML/QuickForm.php');
require_once('includes/classes/xmlWrapper.php');
require_once('admin/modules/applicationsOnWeb/includes/applicationsOnWebTbl.php');


define("ONWEB_TIME_OUT", 30);

class applicationsOnWeb extends ModuleBase
{
	var $m_appOnWebTbl;
	var $m_requestMode;
	var $m_saveEnabled;
	var $m_isupdated;
		
	function applicationsOnWeb($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$db  = &parent::GetDatabase();
		$this->m_appOnWebTbl = new applicationsOnWebTbl($db);
	}

	// Initialize the form which is the skeleton of the page:
	function init()
	{
		parent::init("applicationsOnWeb");

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('appsOnWebForm','post','','',"onsubmit='onGet();return false;'"); //default is post

		$header = APPSONWEB_MAIN_TXT.$this->m_session->value(SESSION_NODE_NAME);		
		$this->m_form->addElement('header', 'header',$header);		
		$this->m_form->addElement('text', 'url', APPSONWEB_URL_LBL, array('size' => 50, 'maxlength' => 255, 'onchange' => "updated()"));		
		$this->m_form->addElement('text', 'username', APPSONWEB_USERNAME_LBL, array('size' => 20, 'maxlength' => 255));
		$this->m_form->addElement('password', 'password', APPSONWEB_PASSWORD_LBL, array('size' => 20, 'maxlength' => 255));
		$this->m_form->addElement('button', 'cancel', APPSONWEB_CANCEL_BTN,"onclick=onReturn('cancel') class='NewButton'");
		$this->m_form->addElement('submit', 'getApps', APPSONWEB_GETAPPS_BTN, "onclick='onGet();return false;' class='NewButton' style='width:100px'");
		$this->m_form->addElement('button', 'back', APPSONWEB_BACK_BTN,"onclick=onReturn('back') class='NewButton'");
		$this->m_form->addElement('submit', 'save', APPSONWEB_SAVE_BTN, "onclick=onSave() class='NewButton'");
		$this->m_form->addElement('hidden', 'button_clicked', "none");
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->applyFilter('username', 'trim');
		$this->m_form->applyFilter('password', 'trim');
		$this->m_form->applyFilter('url', 'trim');
		$this->m_form->addRule('url',  APPSONWEB_URL_REQ_MSG, 'required');
		$this->m_form->setRequiredNote(APPSONWEB_REQUIRED_TXT);		
	}
	
	// Process the submition requests:
	function process()
	{
	
		$res = HSP_SUCCESS;
		$this->m_isupdated = "false";
		$this->m_saveDisabled = "true"; // the default is not to enable the save button.
		$arrRes = null;
		$applist = array(); // list of onWeb application for the specified server url				
		
		$this->m_requestMode = $this->m_session->value(SESSION_NEW_NODE);
		
		if((isset($_POST['button_clicked'])) && ("back" == $_POST['button_clicked']))
		{
			$this->m_session->remove(SESSION_ONWEB_PREV_URL);													
			$this->m_session->remove(SESSION_ONWEB_PREV_APP);

			// Go back to 'applicationsData' page:
			// Update the app type:
			$onWeb = 'onWeb';
			$this->m_session->set(SESSION_NODE_APPTYPE, $onWeb);
			// Let the next screen know who called it:
			$module = 'applicationsOnWeb';
			$this->m_session->set(SESSION_PREV_MODULE, $module);
			Header('Location: admin.php?module=applicationsData&roll='.$_POST['roll']);
			exit();
		}		

		if((isset($_POST['button_clicked'])) && ("cancel" == $_POST['button_clicked']))
		{
			// Go back to 'applicationsTree' page:
			$this->m_session->remove(SESSION_ONWEB_PREV_URL);													
			$this->m_session->remove(SESSION_ONWEB_PREV_APP);

			$module = 'applicationsOnWeb';
			$this->m_session->set(SESSION_PREV_MODULE, $module);
			Header('Location: admin.php?module=applicationsTree&roll='.$_POST['roll']);
			exit();
		}
		
		
		if ($this->m_form->validate())
		{
			$url = htmlspecialchars($this->m_form->exportValue('url'));
			
			if($url == $this->m_session->value(SESSION_ONWEB_PREV_URL))
			{
				// Show the previos application selected for this onweb server:
				$this->m_form->addElement('text', 'old_app', APPSONWEB_OLD_APP_TXT);		
				
				$this->m_form->setDefaults(	array("old_app" => $this->m_session->value(SESSION_ONWEB_PREV_APP)));
												
				$old_app = &$this->m_form->getElement("old_app");
				$old_app->freeze();
			}

			if((isset($_POST['button_clicked'])) && ("getApps" == $_POST['button_clicked']))
			{
				$this->m_isupdated = "true";
				$username = htmlspecialchars($this->m_form->exportValue('username'));
				$password = htmlspecialchars($this->m_form->exportValue('password'));

				$res = $this->GetAppList($applist, $url, $username, $password);

				if (( count($applist) ) && (HSP_SUCCESS == $res))
				{
					// Create a list with no url, only name and displayname:
					foreach($applist as $keyName =>$arrTLR)
						$noUrlAppList[$keyName]	= $arrTLR["displayname"];

					// we do not want to show the list if it is empty
					$this->m_form->addElement('select', 'applications', APPSONWEB_APPLIST_LBL,$noUrlAppList, 'onkeypress="DoDefaultEnterKey(event)"');
					
					$this->m_saveDisabled = "false";
					
					// save the list of application for finish cycle
					$this->m_session->set(SESSION_ONWEB_APPS, $applist);
				}
			}
			
			if((isset($_POST['button_clicked'])) && ("save" == $_POST['button_clicked']))
			{
				$save = "";
				// Get all the POST and SESSION values:
				$name = $this->m_session->value(SESSION_NODE_NAME);
				$description = $this->m_session->value(SESSION_NODE_DESC);
				$icon = $this->m_session->value(SESSION_NODE_ICON);
				$appWindow = $this->m_session->value(SESSION_APP_BEHAVIOR);
				$appMobileGeneral = $this->m_session->value(SESSION_APP_MOBILE);
				$this->m_isupdated = "true";
									
				if($icon == null)
				{
					// Make a default -- TEMPORARY!
					$icon = ONWEB_ICON;
				}

				// List of name and array(url+displayname) -- (don eonly cause php somehow doesn't get the 'select' submition) 
				$applist = $this->m_session->value(SESSION_ONWEB_APPS);
				//Create a list with no url, only name and displayname:
				foreach($applist as $keyName =>$arrTLR)
					$noUrlAppList[$keyName]	= $arrTLR["displayname"];
				$this->m_form->addElement('select', 'applications', APPSONWEB_APPLIST_LBL,$noUrlAppList);
				
				$application = htmlspecialchars($this->m_form->exportValue('applications'));
				
				//Make sure the host url is terminated with '/' or '\':
				$url = rtrim($url, "\\");
				$url = rtrim($url, "\/");
				$url = $url."/";
				
				// ******* NOTICE - at run time the final URL will look like this:
				//
				// http://OnWebIP:port/myHPApp/myHPApp.htm, it sends http://OnWebIP:port/?ONWEB_InfoRule=_HSP.LaunchApp(_ONWEB_CGIDATA_)
				// &appName=myHPApp&HSPUser=testusr&startPage=myHPApp.htm	
				//
				// That's why we make all preperations below - in order to save time in running the application in the portal side.
				
				//appURL saved like this: &startPage=myHPApp.htm
				$appURL = '&startPage='.$applist[$application]["url"];
				
				$arrParms = array('display_name'=>$applist[$application]["displayname"] , 'name'=>$application , 'hostURL'=>$url, 'appURL'=>$appURL);
				
				// we need to handle 2 situations: edit old node or add a new node
				if('edit' == $this->m_requestMode)
				{
					$res = $this->updateNode($name, $icon, $description, $arrParms,$appWindow,$appMobileGeneral);
				}
				else
				{					
					$res = $this->saveNode(	$name, $icon, $description, $arrParms,
				  	$this->m_appOnWebTbl, 
					$this->m_session->value(SESSION_NODE_ID),
					$appWindow,
					$appMobileGeneral);

					$save = "&clicked=finish";
				}

				if(HSP_SUCCESS == $res)
				{
					$this->m_session->remove(SESSION_ONWEB_PREV_URL);													
					$this->m_session->remove(SESSION_ONWEB_PREV_APP);

					// Let the next screen know who called it:					
					$module = 'applicationsOnWeb';
					$this->m_session->set(SESSION_PREV_MODULE, $module);
					
					parent::CriaLog($this->m_requestMode ."_". trim(APPSONWEB_SAVE_BTN));
					Header("Location: admin.php?module=applicationsTree$save&roll=".$_POST['roll']);
					exit();
				}
			}
		}

		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$this->m_form->setDefaults(array(	"url" => "http://"));
			
			// A GET request:
			if(('edit' == $this->m_requestMode) &&
					("onWeb" == $this->m_session->value(SESSION_NODE_PREV_APPTYPE)))
			{
				// Get old paramters:
				$nodeID = $this->m_session->value(SESSION_NODE_ID);
				$res = $this->m_appOnWebTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);	

				// Make sure we are editing the same application type:
				if((HSP_SUCCESS == $res) && ("onWeb" == $arrTreeRes[3]))

				{
					$res = $this->m_appOnWebTbl->GetRowForField(TABLE_APPS_ONWEB, 'appID', $arrTreeRes[2], $arrAppRes);
					if(HSP_SUCCESS == $res)	
					{	
						$this->m_form->addElement('text', 'old_app', APPSONWEB_OLD_APP_TXT);		
						
						$this->m_form->setDefaults(array("url" => $arrAppRes[3], 
														"old_app" => $arrAppRes[1]));
														
						$this->m_session->set(SESSION_ONWEB_PREV_URL, $arrAppRes[3]);													
						$this->m_session->set(SESSION_ONWEB_PREV_APP, $arrAppRes[1]);

						$old_app = &$this->m_form->getElement("old_app");
						$old_app->freeze();
					}
				}
			}
		}		

		if(HSP_SUCCESS != $res)
		{	// If we reached here, action failed:
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}
	
	// Build the page and send it to display:
	function finalize()
	{
		$nodeName = $this->m_session->value(SESSION_NODE_NAME);
		
		$arrVars = array("setupdated"=>$this->m_isupdated,
						 "strNodeName"=>$nodeName,
						 "save_disabled"=>$this->m_saveDisabled);
		parent::finalize($arrVars);
	}
	
	function saveNode($name, $icon, $description, $arrParms, $db, & $parentID, $appWindow, $appMobileGeneral, $insideCall = true)
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$arrRes = null;
			
		if(false == $insideCall)
		{
			// Called from outside:
			$db = new applicationsOnWebTbl($db);
		}

		// First insert application data to application table in the DB:
		$res = $db->insertToAppList($arrParms);
		if(HSP_SUCCESS == $res)
		{
			// Now enter the application as a node in the tree.
				
			// Get the application id (of the recentley application that was
			// inserted to the application table). This id is to be kept as a link
			// between the node and its application:
			$appID = 0;
			$res = $db->getMaxEntryID(TABLE_APPS_ONWEB, 'appID',  $arrRes);
			if(HSP_SUCCESS == $res)
			{
					
				$appID = $arrRes[0];
				unset($arrRes);
	
				// Build the link of the new node
				if(HSP_SUCCESS == $res)
					{
					// Insert node below the selected node. Notice we send the application id also
					// (Later on we will get the real Node URL and update the Node entry
					// with the right url):
					$res = $db->insertToHSPTree($parentID, $appID, "onWeb", $name, $icon, $description, $appWindow, $appMobileGeneral);
					if(HSP_SUCCESS == $res)
					{
						// Get the id of the recently entered node:
						$res = $db->getMaxEntryID(TABLE_TREE, 'id', $arrRes);							
						// Update the url(==href) field of the recently inserted node in hsp_tree:
						$params = array("href" => "navigate($arrRes[0])");
						$res = $db->updateTree($arrRes[0], $params); 
						
						if(HSP_SUCCESS == $res)
						{
							// Update the father the he has a new baby born: he is no longer a "leaf":
							$paramArr2 = array("status" => "1");
							$res = $db->updateTree( $parentID, $paramArr2 );
						}
						
						if(true == $insideCall)
						{
							// Update the node id:
							$this->m_session->set(SESSION_NODE_ID, $arrRes[0]);
						}
						else
						{
							// Update the parentID:
							$parentID = $arrRes[0];
						}
						
					} 
					else
					{
						// Could not insert a new node to the tree, so we need to remove the application
						// entery that was inserted prior to this action:
						$db->remove(TABLE_APPS_ONWEB, "appID", $appID);
					}

				}
			}
			
			if(true == $insideCall)
			{
				$this->m_session->remove(SESSION_NEW_NODE);
			}
		}
		
		return $res;
	}
	
	function updateNode($name, $icon, $description, $arrParms, $appBehavior, $appMobileGeneral )
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$nodeID = $this->m_session->value(SESSION_NODE_ID);
		$appID = 0;

		$res = $this->m_appOnWebTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);
		if(HSP_SUCCESS == $res)
		{
			$appID = $arrTreeRes[2];
			// Check first if the previous application wasn't this one
			// e.g. it was a link and now it was asked to be a onweb session:
			$prevApp = $this->m_session->value(SESSION_NODE_PREV_APPTYPE);
			if('onWeb' == $prevApp)
			{
				// The application type remained the same, just update the application list 
				// and the tree:
				$res = $this->m_appOnWebTbl->updateAppList($appID, $arrParms);				
				if(HSP_SUCCESS == $res)
				{
					$params = array("text"=>$name, "icon"=> $icon, "title"=>$description, "newWindow"=>$appBehavior, "mobile"=>$appMobileGeneral );
					$res = $this->m_appOnWebTbl->updateTree($nodeID, $params); 
				}
			}
			else 
			{
				if('url' == $prevApp)
					// Remove the link application from it's list:
					$res = $this->m_appOnWebTbl->remove(TABLE_APPS_LINKS, "appID", $appID);
				elseif('w2h' == $prevApp)
					// Remove the w2h application from it's list:
					$res = $this->m_appOnWebTbl->remove(TABLE_APPS_W2H, "appID", $appID);
				//elseif some other appplication
				
				if((HSP_SUCCESS == $res) || ('' == $prevApp /*previosly folder*/))
					// Add the new application:
					$res = $this->addAppAndUpdateTree($nodeID, $name, $icon, $description, $arrParms);
			}
		}
	
		return  $res;
	}



	function addAppAndUpdateTree($nodeID, $name, $icon, $description, $arrParms)
	{
		$res = $this->m_appOnWebTbl->insertToAppList($arrParms);
		if(HSP_SUCCESS == $res)
		{
			// Get the appID of the recently inserted application:
			$res = $this->m_appOnWebTbl->getMaxEntryID(TABLE_APPS_ONWEB, 'appID',  $arrRes);					
			if(HSP_SUCCESS == $res)
			{
				// Update the node tree table with the new application:
				$params = array("appID"=>$arrRes[0], "application"=>"onWeb", "text"=>$name, "icon"=> $icon, "title"=>$description);
				$res = $this->m_appOnWebTbl->updateTree($nodeID, $params); 
			}
		}		
		return $res;
	}
	
	
	
	
	function GetURL($url, &$ret_header, $port=80, $send_header = array(), $query = array(), $method = "GET")
	{
		$header = ''; // guarda os cabecalhos da resposta
		$body  = '';  // guarda o corpo da resposta
		$buffer = ''; // buffer de leitura do socket
		
		$ret_header = array();
		
		$url_stuff = parse_url($url);
		
		if (!isset($url_stuff["path"]))
		   $url_stuff["path"] = "/";

		// The default is 80, but we can get a different port in url:		   
		if(isset($url_stuff["port"])) 
			$port = $url_stuff["port"];
		
		/*  	REMARK ************** this is valid for php5 *** mhoter
		
		   if (isset($url_stuff["query"]))
		       $_query = http_build_query($url_stuff["query"]);
		
		   if (sizeof($query))
		       $_query = http_build_query($query);
		*/
		
		// Added by mhoter
		$_query = $url_stuff["query"];
		
		$fp = @fsockopen ($url_stuff['host'], $port, $errno, $errstr);
		
		if ($fp) {
		   if ($method == "POST") {
		       $header  = "$method $url_stuff[path] HTTP/1.1\r\n";
		       $header .= "Content-length: " . strlen($_query) . "\r\n";
		       $header .= "Content-type: application/x-www-form-urlencoded\r\n";
		   } else {
		       // montar os cabe?alhos de envio
		       if (isset($url_stuff['query']))
		           $header  = "$method $url_stuff[path]?$url_stuff[query] HTTP/1.1\r\n";
		       else
		           $header  = "$method $url_stuff[path] HTTP/1.1\r\n";
		   }
		
		   $header .= "Host: $url_stuff[host]\r\n";
		   foreach ($send_header as $hname => $hvalue)
		       $header .= "$hname: $hvalue\r\n";
		   $header .= "\r\n";
		
		   // enviar os cabecalhos
		   fputs($fp, $header);
		   if ($method == "POST")
		       fputs($fp, $_query);
		
		   // Added by mhoter:    
		   stream_set_timeout($fp, ONWEB_TIME_OUT);
		   $status = socket_get_status($fp);

			while(!feof($fp) )
			{
				$buffer .= fgets($fp, 4096);
				$status = socket_get_status($fp);
				if($status['timed_out'])
				{
					// We are timed out -- probably no Onweb Appl list found.
					// TODO: return error code - no onweb apps found.
					fclose($fp);
					return (-1);
				}
			}

			// separar cabecalhos do corpo ( [cabechalho]\r\n\r\n[corpo] )
		   $ret = strpos($buffer, "\r\n\r\n", 0);
		   if ($ret == false) {
		       fclose($fp);
		       return -1;
		   }
		
		   $header = substr($buffer, 0, $ret); // cabecalho da respota
		   $body  = substr($buffer, $ret + 4); // corpo da resposta
		
		   $header = str_replace("\r\n" , "\n", $header);
		   $array_h = explode("\n", $header);
		
		   foreach ($array_h as $line => $val) {
		       if (strpos($val, "HTTP/1") !== 0) {
		           $h = explode(":", $val);
		           $v = $h;
		           $h = $h[0];
		           array_shift($v); // shift left
		           $v = implode(":", $v); // reconstruct value
		           $ret_header[$h] = $v;
		
		           // save cookies
		           if (strtolower($h) === "set-cookie")
		               $send_header['Cookie'] = $v;
		
		       } else {
		           $ret_header['HTTP'] = $val;
		           $ret_header['HTTP_VERSION'] = substr($val, 5, 3);
		           $ret_header['HTTP_RETURN'] = substr($val, 9, 3);
		           $ret_header['HTTP_MESSAGE'] = substr($val, 12);
		       }
		   }
		
		   // Se o cabecalho possuir um campo "Location", segui-lo...
		   if (isset($ret_header['Location'])) {
		       $body = GetURL($ret_header['Location'], $send_header, $ret_header);
		   }
		   fclose ($fp);
		}
		return $body;
	}
	
	function GetAppList(& $applist, $url, $userName, $pwd)
	{
		$res = HSP_ERR_PARSING_XML;
		
		// Set the onWeb request:
		$onwebReq = $url."/?&SALVO_UserID=$userName&SALVO_Password=$pwd&SALVO_Request=Readfile&fileName=tlr.xml&ViScreen=JavaApp&SALVO_CCIO=SALVO_Vi";
		
		// Get the OnWEb server response -- this is tlr.xml file:
		$strResponse =  @$this->GetURL($onwebReq, $ret_header);
		
		if(("" == $strResponse) || (-1 == $strResponse))
		{
			return HSP_ERR_INVALID_URL;
		}

		if(0 < strpos($strResponse, "SALVO_HTC"))
		{
			if(0 < strpos($strResponse, "135"))
			{
				//  OneWeb err135 Login failed -> Wrong user name/password:
				return HSP_ERR_INVALID_CREDENTIALS;
			}
			if(0 < strpos($strResponse, "140"))
			{
				//  OneWeb err140  - There is no application on this server
				return HSP_ERR_NO_ONWEB_APPS;
			}
		}
					
		
		$strXML = stristr($strResponse, "<?xml");

		if(false != $strXML)
		{
			
			$wrapper = new xmlWrapper();
			$wrapper->initFromString($strXML);
			$applist = $wrapper->getOnWebApps();
			if(count($applist) > 0)
			{
				return HSP_SUCCESS;
			}
		}
	
		return $res;
	}
}
?>