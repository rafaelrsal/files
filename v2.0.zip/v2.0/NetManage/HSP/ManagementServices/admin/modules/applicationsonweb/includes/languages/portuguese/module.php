<?PHP
define('APPSONWEB_MAIN_TXT','Aplica��o OnWeb - ');
define('APPSONWEB_URL_LBL','URL do Servidor:');
define('APPSONWEB_USERNAME_LBL','Nome do Usu�rio:');
define('APPSONWEB_PASSWORD_LBL','Senha:');
define('APPSONWEB_APPLIST_LBL','Aplica��es:');
define('APPSONWEB_OLD_APP_TXT','Aplica��o previamente selecionada:');
define('APPSONWEB_CANCEL_BTN','Cancelar');
define('APPSONWEB_GETAPPS_BTN','Capturar');
define('APPSONWEB_BACK_BTN','< Voltar');
define('APPSONWEB_SAVE_BTN','Salvar');
define('APPSONWEB_REQUIRED_TXT','Verificar campos obrigat�rios');
define('APPSONWEB_URL_REQ_MSG','� necess�rio informar a URL do servidor OnWeb');
?>

