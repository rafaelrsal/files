<?PHP
class adminUsersTbl
{
	var $m_pearDB;
	function adminUsersTbl(&$peardb)	
	{
		if(!extension_loaded('HSPSecurModule'))
		{
			dl('php_HSPSecurModule.dll');
		}

		$this->m_pearDB = $peardb;
		$this->m_pearDB->connect();
	}
	
/*	function insert($username,$password,$roll='admin')
	{
		return;
		
		$encrpt_password = encrypt_str($password);
		$fields_values = array(	'username'   =>$username,
					'password' => $encrpt_password,
					'roll' => $roll
					);		
		$ret = $this->m_pearDB->AutoExecute(TABLE_ADMIN_USERS, $fields_values, DB_AUTOQUERY_INSERT);
		return $ret;
	}
*/
/*	function updatePassword($username,$newpassword)
	{
		return 0;
		$encrpt_password = encrypt_str($newpassword);
		$fields_values = array(	'username'=>$username,
					'password' =>  $encrpt_password);
		$ret = $this->m_pearDB->AutoExecute(TABLE_ADMIN_USERS, $fields_values, DB_AUTOQUERY_UPDATE,'username="'.$username.'";');
		return $ret;
	}
*/	
/*	function validate($username,$password)
	{
		if(HSP_SUCCESS == $this->m_pearDB->GetRowForField(TABLE_ADMIN_USERS, "username", $username, $arrRes))
		{
			if(is_array($arrRes))
			{
				if($password == decrypt_str($arrRes[2]))
			return true;
			}
		}
		
		return false;
	}
*/	
}
?>