<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title:            module.php
  Purpose:          Changing admin users data.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/ 
 
require_once('HTML/QuickForm.php');
require_once('includes/classes/xmlWrapper.php');

class userData extends ModuleBase
{
	var $m_wrapper = null;
	var $m_bisInit;
		
	function userData($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		$this->m_wrapper = new xmlWrapper();
		$this->m_wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME);
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('userDataForm'); //default is post
	}
	function  init()
	{
		parent::init("userData");
		
		$this->m_bisInit = $this->m_session->value(SESSION_INIT_CONFIG);
		if ( $this->m_bisInit )
		{
			$msgCode = array(USERDATA_HEADER_TXT);
			$this->m_session->set(SESSION_MESSAGES, $msgCode);
		}

		// Build the login form:
		$this->m_form->addElement('header', 'header', USERDATA_HEADER_TXT);
		$this->m_form->addElement('text', 'username', USERDATA_USERNAME_LBL, array('size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => "FixedWidthObjects",'readonly'=>'readonly'));
		$this->m_form->addElement('password', 'oldpassword', USERDATA_OLDPASSWORD_LBL, array('size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => "FixedWidthObjects"));
		$this->m_form->addElement('password', 'newpassword', USERDATA_NEWPASSWORD_LBL, array('size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => "FixedWidthObjects"));
		$this->m_form->addElement('password', 'reenterpassword', USERDATA_REENTERPASSWORD_LBL, array('size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => "FixedWidthObjects" ));
		$this->m_form->addElement('submit', 'apply', USERDATA_BTN,"class='NewButton FixedWidthObjects'");
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->setRequiredNote(USERDATA_TXT_REQUIRED);
		

		
		$this->m_form->addRule('oldpassword', USERDATA_OLDPWD_REQ_MSG, 'required');
		$this->m_form->addRule('newpassword', USERDATA_NEWPWD_REQ_MSG, 'required');
		$this->m_form->addRule('reenterpassword', USERDATA_RPTPWD_REQ_MSG, 'required');
		$this->m_form->addRule(array('newpassword', 'reenterpassword'), USERDATA_MISMATCH_MSG, 'compare', null);

		$this->m_form->setDefaults(array('username'=>$this->m_username));
	}
	function process()
	{
		if ($this->m_form->validate())
		{
			$errorCode = HSP_ERR_INVALID_CREDENTIALS;
			// We need to verify the old password is correct in order to allow
			// the modification.
			$username = htmlspecialchars($this->m_form->exportValue('username'));
			$oldpassword = htmlspecialchars($this->m_form->exportValue('oldpassword'));
			$newpassword = htmlspecialchars($this->m_form->exportValue('newpassword'));
			$dbConfig = new DBConfig();
			
			if($dbConfig->ChangeAdminPassword($username, $oldpassword, $newpassword) == "ok")
			{// atualizou senha?				
				//cria log
				parent::CriaLog(USERDATA_BTN);
				// Redirect to the home module:
				Header('Location: admin.php?module=home&roll='.$_POST['roll']);
				// Get rid of the message, next screen does not need it:
				$this->m_session->remove(SESSION_MESSAGES);
				exit();
			}
			
			// if(true == $this->checkUserCredentials($username,$oldpassword))
			// {
				// // Enter to the DB
				// $errorCode = $this->updatePassword($username,$newpassword);
				// if($errorCode == HSP_SUCCESS)
				// {
					// // Everything is fine.
					// // Initialization is done. Update the HSP session state:
					// $this->m_bisInit = false;
					// $this->m_session->set(SESSION_INIT_CONFIG, $this->m_bisInit);

					// // upgrade in flow zero
					// if ( isset( $_SESSION[SESSION_UPGRADE] ))
					// {
						// Header('Location: admin.php?module=maintenance&roll='.$_POST['roll']);
					// }
					// else
					// {					
						// // Redirect to the home module:
						
					// }
					
					// // Get rid of the message, next screen does not need it:
					// $this->m_session->remove(SESSION_MESSAGES);
					// exit();
				// }
			// }

			$errorCode = array(HSP_ERR_INVALID_CREDENTIALS);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}
	function finalize()
	{
		$arrVars = array();
		parent::finalize($arrVars);
	}

	function checkUserCredentials($username,$password)
	{
		$umftConfig = $this->m_wrapper->getUMConfigInfo();
		if ( strtolower($umftConfig['user_name']) == strtolower($username) &&
			 $umftConfig['password']  == $password)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function updatePassword($username,$password)
	{
		$umftConfig['user_name'] = $username;
		$umftConfig['password']  = $password;
		
		$this->m_wrapper->setUMConfigInfo($umftConfig);
	
		$fp = @fopen( CONFIG_XML_PATH . CONFIG_XML_NAME, "wb");
		if(true == $fp)
		{
			if(fputs($fp, $this->m_wrapper->toString()))
			{
				fclose($fp);
				parent::CriaLog(USERDATA_BTN);
				return HSP_SUCCESS;
			}
		}

		return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;		
	}
}
?>