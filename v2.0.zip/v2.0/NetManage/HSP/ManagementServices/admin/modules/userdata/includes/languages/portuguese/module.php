<?PHP
define('USERDATA_HEADER_TXT' , '<br>&nbsp;&nbsp;&nbsp;&nbsp;Alterar Senha');
define('USERDATA_USERNAME_LBL', 'Usu�rio:');
define('USERDATA_OLDPASSWORD_LBL', 'Senha atual:');
define('USERDATA_NEWPASSWORD_LBL', 'Nova senha:');
define('USERDATA_REENTERPASSWORD_LBL', 'Confirme nova senha:');
define('USERDATA_BTN','Confirmar');
define('USERDATA_TXT_REQUIRED','verifique os campos obrigat�rios');
define('USERDATA_USERNAME_REQ_MSG','Informe seu usu�rio');
define('USERDATA_OLDPWD_REQ_MSG','Informe sua senha atual');
define('USERDATA_NEWPWD_REQ_MSG','Informe sua nova senha');
define('USERDATA_RPTPWD_REQ_MSG','Confirme nova senha');
define('USERDATA_MISMATCH_MSG','A senha n�o corresponde');
define('USERDATA_MSG','Informe a nova senha de administrador.');
?>