<?PHP
define('USERDATA_HEADER_TXT' , '<br>&nbsp;&nbsp;&nbsp;&nbsp;Change Password');
define('USERDATA_USERNAME_LBL', 'User name:');
define('USERDATA_OLDPASSWORD_LBL', 'Old password:');
define('USERDATA_NEWPASSWORD_LBL', 'New password:');
define('USERDATA_REENTERPASSWORD_LBL', 'Confirm new password:');
define('USERDATA_BTN','Apply');
define('USERDATA_TXT_REQUIRED','denotes required field');
define('USERDATA_USERNAME_REQ_MSG','Enter your user name');
define('USERDATA_OLDPWD_REQ_MSG','Enter your old password');
define('USERDATA_NEWPWD_REQ_MSG','Enter your new password');
define('USERDATA_RPTPWD_REQ_MSG','Confirm new password');
define('USERDATA_MISMATCH_MSG','The passwords do not match');
define('USERDATA_MSG','Enter the new administrator password.');
?>