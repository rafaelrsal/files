<?PHP
define('REPORT4_MAIN_TXT','Esta��es Conectadas');
define('REPORT4_BACK_BTN','< Voltar');
define('REPORT4_PRINT_BTN','Imprimir');
define('REPORT4_EXPORT_BTN','Exportar');
define('REPORT4_COL1','ID Sess�o');
define('REPORT4_COL2','IP Local');
define('REPORT4_COL3','ID Usu�rio');
define('REPORT4_COL4','TP Host');
define('REPORT4_COL5','IP Host');
define('REPORT4_COL6','Hor�rio de In�cio');
define('REPORT4_COL7','Dura��o (h:m:s)');
?>