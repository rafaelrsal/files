<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Celso Viana
  Date Created: Nov 2010
  Title: report4.php
  Purpose: full report,  simples emulation.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('HTML/QuickForm.php');

require_once('HTML/Table.php');
require_once('includes/classes/PearDB.php');
require_once('Admin/includes/classes/reportGenerator.php');

class report4 extends ModuleBase
{
	var $m_db;
	var $m_reportGenerator;

	function report4($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('report4Form'); //default is post
	}

	function init()
	{
		parent::init("report4");

		$this->m_form->addElement('header', 'header', REPORT4_MAIN_TXT);
		$this->m_form->addElement('submit', 'back', REPORT4_BACK_BTN,"class='NewButton'");
		$this->m_form->addElement('submit', 'print', REPORT4_PRINT_BTN, 'class="NewButton" onclick = printReport()');
		$this->m_form->addElement('submit', 'export', REPORT4_EXPORT_BTN,"class='NewButton'");

		$this->m_form->addElement('text', 'fromdate', REPORT_DATE_LBL);
		$this->m_form->addElement('text', 'fromtime', REPORT_TIME_LBL);
		$this->m_form->addElement('text', 'todate', REPORT_DATE_LBL);
		$this->m_form->addElement('text', 'totime', REPORT_TIME_LBL);

		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$tmpElement = &$this->m_form->getElement('fromdate');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('fromtime');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('todate');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('totime');
		$tmpElement->freeze();
	}

	function process()
	{
		$formValuesArray = $this->m_form->exportValues();

		$fromDate 	= $this->m_session->value('fromDate');
		$toDate 	= $this->m_session->value('toDate');
		$fromTime 	= $this->m_session->value('fromTime');
		$toTime 	= $this->m_session->value('toTime');

		$this->m_form->setDefaults(array('fromdate'=>$fromDate, 'todate'=>$toDate,'fromtime'=>$fromTime.':00:00','totime'=>$toTime.':00:00'));

		$this->m_reportGenerator = new reportGenerator(REPORT4_MAIN_TXT, $this->m_language , "reports" );
		$colArr = array(REPORT4_COL3,REPORT4_COL2,REPORT4_COL4,REPORT4_COL5,REPORT4_COL6,REPORT4_COL7);
// Celso - 13.01.2011 --> Limpeza de emula��es simples expiradas e sele��o de emula��es simples validas.						  						
		$sqle = "delete from hsp_emulacao_simples
				where datepart(mi,CONVERT(char(10),GETDATE() - LAST_UPDATE,108)) + (datepart(hh,CONVERT(char(10),GETDATE() - LAST_UPDATE,108)) * 60) >".TimeClearEmulation;			

		$this->m_db->GetAllEx($sqle);
//
		$table = $this->m_reportGenerator->createTable($this->m_db, TABLE_EMULACAO_SIMPLES, $colArr, $this->formSQL($fromDate, $toDate, $fromTime, $toTime));
		$this->m_db->disconnect();

		if ( array_key_exists("back", $formValuesArray) )
		{
			$this->goBack($fromDate, $toDate, $fromTime, $toTime );
		}
		elseif ( array_key_exists("export", $formValuesArray))
		{
			parent::CriaLog(REPORT4_EXPORT_BTN);
			$this->m_reportGenerator->createHeaderTxt(REPORT4_MAIN_TXT,$fromDate, $toDate, $fromTime, $toTime);
			$this->m_reportGenerator->downloadCSV();
		}

		$res = $this->m_reportGenerator->prepareReportPage();

		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}

	function finalize()
	{
		$arrVars = array(	"report4Form_from_txt"=>REPORT_FROM_TXT,
							"report4Form_to_txt"=>REPORT_TO_TXT,
							"report_table"=>$this->m_reportGenerator->getReportAsIFrame());

		parent::finalize($arrVars);
	}

	function goBack($fromDate, $toDate, $fromTime, $toTime)
	{
		$this->m_session->set('fromDate', $fromDate);
		$this->m_session->set('toDate', $toDate);
		$this->m_session->set('fromTime', $fromTime);
		$this->m_session->set('toTime', $toTime);

		$this->m_session->set('reportName', $this->m_moduleName);

		Header('Location: admin.php?module=reports&roll='.$_POST['roll']);
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		exit();
	}

	function formSQL($fromDate, $toDate, $fromTime, $toTime)
	{
		if ( 'mysql' == $this->m_db->getDBSyntax() )
		{

		}
		elseif ( 'mssql' == $this->m_db->getDBSyntax() )
		{
			$sql = "SELECT USER_ID,
						   IP_LOCAL,
						   TP_HOST = 
							Case TP_HOST
								when 'AS' then 'AS/400'
								when 'MF' then 'Mainframe Display' 
								when 'MP' then 'Mainframe Printer' 
								when 'UX' then 'Unix'
								else 'Desconhecido'
							end, 
						   IP_HOST,
						   START_TIME,
						   convert(varchar(10),DATEDIFF(hh, START_TIME, GETDATE()))+':'+
							 convert(varchar(10),DATEDIFF(mi, START_TIME, GETDATE())-(DATEDIFF(hh, START_TIME, GETDATE())*60))+':'+
							 convert(varchar(10),DATEDIFF(ss, START_TIME, GETDATE())-(DATEDIFF(mi, START_TIME, GETDATE())*60))AS DURACAO
					FROM ".TABLE_EMULACAO_SIMPLES."
					WHERE
					START_TIME >= convert(datetime,'$fromDate $fromTime:00:00',20) AND START_TIME < convert(datetime,'$toDate $toTime:00:00',20)
					";
		}
		return $sql;
	}
}
?>