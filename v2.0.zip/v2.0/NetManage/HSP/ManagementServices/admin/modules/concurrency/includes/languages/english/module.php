<?PHP
define('CONCURRENCY_REFRESH_BTN','Refresh');
define('CONCURRENCY_1_LBL','Number of registered applications: ');
define('CONCURRENCY_2_LBL','Number of portal users: ');
define('CONCURRENCY_3_LBL','Number of connected sessions: ');
define('CONCURRENCY_4_LBL','Number of simples emulation active: ');
define('CONCURRENCY_5_LBL','Number of simultaneous connected users: ');
define('CONCURRENCY_TABLE_HEADER','<b>Details:</b>');
define('CONCURRENCY_TABLE','<b>Connected sessions details:</b>');
define('CONCURRENCY_APP_TYPE','Application Type');
define('CONCURRENCY_EMU_TYPE','Emulation Type');
define('CONCURRENCY_COUNT','Count');
define('CONCURRENCY_APP_W2H','OnWeb Web to Host');
define('CONCURRENCY_APP_ONWEB','OnWeb Application');
define('CONCURRENCY_APP_PC2H','PC to Host');
define('CONCURRENCY_HSP','HSP');
define('CONCURRENCY_CORP','Corporate Portal');
?>