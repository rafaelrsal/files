<?PHP
define('CONCURRENCY_REFRESH_BTN','Atualizar');
define('CONCURRENCY_1_LBL','N�mero de aplica��es registradas: ');
define('CONCURRENCY_2_LBL','N�mero de usu�rios no portal: ');
define('CONCURRENCY_3_LBL','N�mero de sess�es conectadas: ');
define('CONCURRENCY_4_LBL','N�mero de sess�es simultaneamente conectadas: ');
define('CONCURRENCY_5_LBL','N�mero de usu�rios simultaneamente conectados: ');
define('CONCURRENCY_TABLE_HEADER','<b>Detalhes:</b>');
define('CONCURRENCY_TABLE','<b>Detalhes das sess�es conectadas:</b>');
define('CONCURRENCY_APP_TYPE','Tipo de Aplica��o');
define('CONCURRENCY_EMU_TYPE','Tipo de Emula��o');
define('CONCURRENCY_COUNT','Contador');
define('CONCURRENCY_APP_W2H','OnWeb Web to Host');
define('CONCURRENCY_APP_ONWEB','Aplica��o OnWeb');
define('CONCURRENCY_APP_PC2H','PC to Host');
define('CONCURRENCY_HSP','HSP');
define('CONCURRENCY_CORP','Portal Corporativo');
?>