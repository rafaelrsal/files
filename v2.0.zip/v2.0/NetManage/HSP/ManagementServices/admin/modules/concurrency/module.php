<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: global_defines.php
  Purpose: Monitoring concurrency module.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('HTML/QuickForm.php');
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');
require_once('HTML/Table.php');
require_once('includes/classes/stringTranslation.php');
require_once('includes/classes/whosOnline.php');
class concurrency extends ModuleBase
{
	var $m_db;
	var $m_RefreshRate = 60;
	var $m_DataApp; // variavel para dados retornados dos apps, os quais est�o sendo utilizados e suas devidas quantidades
	
	function concurrency($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('ConcurrencyForm'); //default is post
	}

	function  init()
	{
		parent::init("concurrency");

		// Build the concurrency form:
		$this->m_form->addElement('text', 'concurrency1', CONCURRENCY_1_LBL, array('size' => 20, 'maxlength' => 20));
		$this->m_form->addElement('text', 'concurrency2', CONCURRENCY_2_LBL, array('size' => 20, 'maxlength' => 20));
		$this->m_form->addElement('text', 'concurrency3', CONCURRENCY_3_LBL, array('size' => 20, 'maxlength' => 20));
		$this->m_form->addElement('text', 'concurrency4', CONCURRENCY_4_LBL, array('size' => 20, 'maxlength' => 20));
		// Ale - 10/03/2011 Incluir mais uma linha na p�gina de Estat�stica referente ao n�mero de usu�rios simultaneamente conectados	
		$this->m_form->addElement('text', 'concurrency5', CONCURRENCY_5_LBL, array('size' => 20, 'maxlength' => 20));		
	}
	function process()
	{
		if ( 'mysql' == $this->m_db->getDBSyntax() )
		{
			$sql1 = 'SELECT COUNT( DISTINCT SESSION_ID )
					FROM ' .  TABLE_REGISTRATION_INFO . '
					WHERE
					( ( REGISTER_STATUS=1 ) AND ( HEARTBEAT_INTERVAL > 0 )	AND	( unix_timestamp( END_TIME) + ( HEARTBEAT_INTERVAL /1000  )  + 60 ) >= unix_timestamp(SYSDATE()))
					OR
					( ( REGISTER_STATUS =1 ) AND ( HEARTBEAT_INTERVAL =0 ) )';

			$sql2 = 'SELECT COUNT(CONNECTION_ID)
					FROM '.TABLE_CONNECTION_INFO.'
					WHERE
						CONNECTED =1
						AND
						(
							( unix_timestamp(SYSDATE()) < ( unix_timestamp(END_TIME) + (HEARTBEAT_INTERVAL/1000) + 60))
							OR
							( HEARTBEAT_INTERVAL =0 )
						);';
		}
		elseif ( 'mssql' == $this->m_db->getDBSyntax() )
		{
			/*$sql1 = "SELECT COUNT( DISTINCT T1.SESSION_ID )
						  FROM ".TABLE_REGISTRATION_INFO."  T1
										 LEFT  JOIN
									 ".TABLE_CONNECTION_INFO." T2
						 ON T1.SESSION_ID = T2.SESSION_ID
							WHERE ( (T1.REGISTER_STATUS=1 )
									AND
									( T1.HEARTBEAT_INTERVAL > 0 )
									AND
									(DATEDIFF(second, T1.END_TIME, GETDATE()) < (T1.HEARTBEAT_INTERVAL / 1000 + 60))
								  )
								  OR
							( ( T1.REGISTER_STATUS =1 ) AND ( T1.HEARTBEAT_INTERVAL =0 ) ) OR
							( ( T2.CONNECTED =1 ) AND ( T1.REGISTER_STATUS =1 ) AND
							( T2.HEARTBEAT_INTERVAL >0 )
								AND
								(
									(DATEDIFF(second, T1.END_TIME, GETDATE()) < (T1.HEARTBEAT_INTERVAL / 1000 + 60))
								)
							) OR
							( ( T1.REGISTER_STATUS =1 ) AND ( T2.CONNECTED =1 ) AND ( T2.HEARTBEAT_INTERVAL=0 ) )";*/
							
			$sql1 = "SELECT (COUNT(t1.appID)+
					(SELECT COUNT(T2.appID) FROM " . TABLE_APPS_ONWEB . " T2) +
					(SELECT COUNT (T3.appID) FROM " . TABLE_APPS_W2H . " T3)
						) FROM " . TABLE_APPS_LINKS .  " t1";


			$sql2 = "SELECT COUNT(CONNECTION_ID)
						  FROM ".TABLE_CONNECTION_INFO."
						  WHERE CONNECTED =1 AND
						(
							 (DATEDIFF(second, END_TIME, GETDATE()) < (HEARTBEAT_INTERVAL / 1000 + 60))
							 OR
							( HEARTBEAT_INTERVAL =0 )
						)";
// Celso - 13.01.2011 --> Sql de limpeza de emula��es simples expiradas e sele��o de emula��es simples validas.						  						
			$sql3 = "SELECT COUNT(ID)
						  FROM ".TABLE_EMULACAO_SIMPLES."";			

  			$sqle = "delete from hsp_emulacao_simples
					where datepart(mi,CONVERT(char(10),GETDATE() - LAST_UPDATE,108)) + (datepart(hh,CONVERT(char(10),GETDATE() - LAST_UPDATE,108)) * 60) >".TimeClearEmulation;			
// Fim
// Ale - 10.03.2011 --> Sql para pegar os usu�rios conectados simultaneamente
			$sql5 = "SELECT COUNT(DISTINCT USER_ID)
						  FROM ".TABLE_EMULACAO_SIMPLES."";			
		}

		$data = $this->m_db->GetAllEx($sql1);
		$count1 = $data[0][0];

		$whos = new whosOnline($this->m_db);
		$whos->deleteExpiredEntries();
		$count2 = $whos->count();

		$data = $this->m_db->GetAllEx($sql2);
		$count3 = $data[0][0];
// Celso - 13.01.2011 --> Limpeza de emula��es simples expiradas e sele��o de emula��es simples validas.						  						
		//$this->m_db->GetAllEx($sqle);

		$data = $this->m_db->GetAllEx($sql3);
		$count4 = $data[0][0];
//
// Ale - 10.03.2011 --> Executa o sql5
		$data = $this->m_db->GetAllEx($sql5);
		$count5 = $data[0][0];


		$element = &$this->m_form->getElement('concurrency1');
		$element->setValue($count1);
		$element->freeze();
		$element = &$this->m_form->getElement('concurrency2');
		$element->setValue($count2);
		$element->freeze();
		$element = &$this->m_form->getElement('concurrency3');
		$element->setValue($count3);
		$element->freeze();
		$element = &$this->m_form->getElement('concurrency4');
		$element->setValue($count4);
		$element->freeze();
// Ale - 10.03.2011 --> Apresenta os usu�rios concorrentes
		$element = &$this->m_form->getElement('concurrency5');
		$element->setValue($count5);
		$element->freeze();
		
	}
	
	function finalize()
	{
		$refresh = "<META HTTP-EQUIV=\"refresh\" CONTENT=\"$this->m_RefreshRate\">";

		$arrVars = array(	"ConcurrencyForm_table_header_label"=>CONCURRENCY_TABLE,
							"ConcurrencyForm_table_header_html"=>$this->buildTable(),
							"ConcurrencyForm_refresh_rate"=>$refresh,
							"ConcurrencyForm_Charts_str"=>$this->RetStrGraf(),
							"Hsp_Text"=>CONCURRENCY_HSP,
							"Corp_text"=>CONCURRENCY_CORP
							);

		parent::finalize($arrVars);
	}

	function buildTable()
	{
		$this->m_language->RequireLangFile( 'stringTranslation.php' , "reports" );
		$stringTranslation = new stringTranslation();

		if ( 'mysql' == $this->m_db->getDBSyntax() )
		{
			$sql = "SELECT APPLICATION_TYPE, EMULATION_TYPE , COUNT( * ) AS NUMBER_OF_CONNECTIONS
				FROM
				" . TABLE_REGISTRATION_INFO ." T1, ". TABLE_CONNECTION_INFO." T2
				WHERE
					T1.SESSION_ID = T2.SESSION_ID
				AND (
					( ( T2.CONNECTED =1) AND (T2.HEARTBEAT_INTERVAL >0) AND ((unix_timestamp(T2.END_TIME) + (T2.HEARTBEAT_INTERVAL/1000) + 60) >= unix_timestamp(SYSDATE())))
					OR
					((T2.CONNECTED =1) AND (T2.HEARTBEAT_INTERVAL =0))
					)
				GROUP BY
					APPLICATION_TYPE, EMULATION_TYPE
				ORDER BY
					`APPLICATION_TYPE` LIMIT 0 , 5000";
		}
		elseif ( 'mssql' == $this->m_db->getDBSyntax() )
		{
			$sql = "SELECT TOP 5000 APPLICATION_TYPE, EMULATION_TYPE , COUNT( * ) AS NUMBER_OF_CONNECTIONS
						FROM " . TABLE_REGISTRATION_INFO ." T1, ". TABLE_CONNECTION_INFO." T2
						WHERE
							T1.SESSION_ID = T2.SESSION_ID AND
							 ( ( ( T2.CONNECTED =1) AND
							(T2.HEARTBEAT_INTERVAL >0)
							AND
								(DATEDIFF(second, T1.END_TIME, GETDATE()) < (T1.HEARTBEAT_INTERVAL / 1000 + 60))
							) OR
						((T2.CONNECTED =1) AND (T2.HEARTBEAT_INTERVAL =0)) )
						GROUP BY APPLICATION_TYPE, EMULATION_TYPE ORDER BY APPLICATION_TYPE";
						
			$sql2 = "SELECT 'Emulacao Simples' as APPLICATION_TYPE, tp_host = 
							Case tp_host
								when 'AS' then 'AS/400'
								when 'MF' then 'Mainframe Display' 
								when 'MP' then 'Mainframe Printer' 
								when 'UX' then 'Unix'
								else 'Desconhecido'
							end, 
							count(tp_host) as NUMBER_OF_CONNECTIONS
						FROM " . TABLE_EMULACAO_SIMPLES ."
						GROUP BY TP_HOST";			
		}

		$res  = $this->m_db->GetAllEx($sql);
		$res2 = $this->m_db->GetAllEx($sql2);
		$res  = array_merge($res, $res2);
		$this->m_DataApp = $res;
		
		$table = new HTML_Table('id="ConcurrencyTable" border="1" class="DataTable" bordercolor="black"');

		$headerArr = array (CONCURRENCY_APP_TYPE,CONCURRENCY_EMU_TYPE,CONCURRENCY_COUNT);
        for ($i = 0; $i < 3; $i++)
        {
			$table->setHeaderContents( 0, $i, $headerArr[$i] );
        }

 		$table->setRowAttributes(0,"class='TableHeader'");
		for ($i = 1; $i < count($res)+1; $i++)
		{
			for ($j = 0; $j < 3; $j++)
    		{
				$table->setCellContents( $i,$j, $stringTranslation->translate( $res[$i-1][$j] ));
    		}
		}
        return $table->toHTML();
	}
	
	/**********************************************
		Fun��o para gera��o de dados do Gr�fico
		Retorno - Um array especifico da entrada 
				de dados solicitada pelo gr�fico
	***********************************************/
	function RetStrGraf()
	{
		$strResult = "";
		// loop para percorrer todas aplica��es
		foreach($this->m_DataApp as $key=>$value)
		{
				$strResult .= "['$value[1]',$value[2]],";
		}
		$lenStrResult = strlen($strResult); // tamanho da string
		$strResult = substr($strResult, 0, $lenStrResult -1); // remove ultimo caracter
		
		return $strResult;
	}
}
?>