<?PHP
define('MANAGESESSIONS_MAIN_TXT','Portal de Gerenciamento de Usu�rios');
define('MANAGESESSIONS_DELETE_MSG','Voc� tem certeza que deseja remover esta entrada?');
define('MANAGESESSIONS_DELETE_BTN','Remover');
define('MANAGESESSIONS_USER_COUNT_TXT','N�mero de usu�rios do portal: ');
define('MANAGESESSIONS_COL2','Nome do Usu�rio');
define('MANAGESESSIONS_COL3','Nome Completo');
define('MANAGESESSIONS_COL4','Diret�rio');
define('MANAGESESSIONS_COL5','Hor�rio do Logon');
define('MANAGESESSIONS_COL6','Hor�rio da �ltima Opera��o');
define('MANAGESESSIONS_COL7','Endere�o IP');
?>