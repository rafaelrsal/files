<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Dec 2004
  Title: managePortalSessions.php
  Purpose: report
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('HTML/QuickForm/Renderer/ITStatic.php');
require_once('HTML/QuickForm.php');
require_once('HTML/Template/Sigma.php');
require_once('HTML/Table.php');
require_once('includes/classes/PearDB.php');
require_once('includes/classes/whosOnline.php');

class managePortalSessions extends ModuleBase
{
	var $m_db;
	var $m_whosOnlineSessionIdArray;
	var $m_whosOnlineArray;
	var $m_whosOnline;	
	
	function managePortalSessions($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db = &parent::GetDatabase();
		$this->m_db->connect();
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('managePortalSessionsForm'); //default is post
		$this->m_whosOnlineArray = array();
		$this->m_whosOnlineSessionIdArray = array();
		$this->formSQL();
		$this->m_whosOnline = new whosOnline($this->m_db);
		$this->m_whosOnline->deleteExpiredEntries();
	}
	
	function  init()
	{
		parent::init("managePortalSessions");
		
		$this->m_form->addElement('header', 'header', MANAGESESSIONS_MAIN_TXT);		
		$this->m_form->addElement('button', 'delete', MANAGESESSIONS_DELETE_BTN, 'onclick=onDelete() class="NewButton"');
		
		$this->m_form->addElement('text', 'userCount', MANAGESESSIONS_USER_COUNT_TXT, array('size' => 20, 'maxlength' => 20));		
		
		$this->m_form->addElement('hidden', 'buttonClicked','');
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$selectedRow = '';
		if (isset($this->m_whosOnlineSessionIdArray[0][0]))
		{
			$selectedRow = $this->m_whosOnlineSessionIdArray[0][0];
		}
		$this->m_form->addElement('hidden', 'selectedRow', $selectedRow );
		
	}
	
	function process()
	{
			
		
		
		$formValuesArray = $this->m_form->exportValues();
		$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));

		
		if ( "delete" == $formValuesArray['buttonClicked'] )
		{			
			$res = $this->doDelete($selectedRow);
			$this->formSQL();
			if (isset($this->m_whosOnlineSessionIdArray[0][0]))
			{
				$element = &$this->m_form->getElement('selectedRow');
				$element->setValue($this->m_whosOnlineSessionIdArray[0][0]);
			}
		}
		
		$element = &$this->m_form->getElement('userCount');
		$count = count($this->m_whosOnlineArray);
		if ( $count < 1 )
		{
			$count = '0';
		}
		$element->setValue($count);
		$element->freeze();
		
	}
	
	function finalize()
	{		
		$arrVars = array( 	"managePortalSessionsForm_table"=>$this->generateTable(),
							"confirm_delete"=>MANAGESESSIONS_DELETE_MSG
					 );
							
		parent::finalize($arrVars);		
		
	}
	
	function formSQL()
	{
		$sql = "SELECT username,fullName,directory,timeEntry,timeLastClick,ipAddress FROM " . TABLE_WHOS_ONLINE . ";";		
		$this->m_whosOnlineArray = $this->m_db->GetAllEx($sql, null,DB_FETCHMODE_ORDERED);
		foreach ( $this->m_whosOnlineArray as $index=>$row)
		{
			$this->m_whosOnlineArray[$index][3] = strftime("%Y-%m-%d %H:%M:%S" ,$row[3]);
			$this->m_whosOnlineArray[$index][4] = strftime("%Y-%m-%d %H:%M:%S" ,$row[4]);
		}
		$this->m_whosOnlineSessionIdArray = $this->m_db->GetAllEx("SELECT sessionId	FROM " . TABLE_WHOS_ONLINE . ";", null,DB_FETCHMODE_ORDERED);		
	}
	
	function generateTable()
	{
		$tblWhos = new HTML_Table('id="tblWhosOnline" border="1" class="DataTable" bordercolor="black"');
		
		$headerArr = array(MANAGESESSIONS_COL2,MANAGESESSIONS_COL3,MANAGESESSIONS_COL4,MANAGESESSIONS_COL5,MANAGESESSIONS_COL6,MANAGESESSIONS_COL7);
		$tblWhos->addRow($headerArr , "class='ShortTableHeader'");		

		foreach ( $this->m_whosOnlineArray as $key=>$row )
		{
			$rownum = $key + 1 ;
			$sessionId = $this->m_whosOnlineSessionIdArray[$key][0];			
			$tblWhos->addRow( $row  , "class='UnSelectedRow' onclick='TableRowClick(this,$rownum,\"$sessionId\")'" , 'TD' , true );
		}
		
		return $tblWhos->toHtml();
	}
	
	function doDelete($sessionId)
	{
		//$sessionId = $this->m_whosOnlineSessionIdArray[$selectedRow-1][0];
		$this->m_whosOnline->unregister($sessionId);
		parent::CriaLog(MANAGESESSIONS_DELETE_BTN);
	}
	
	
}
?>