<?PHP
define('REPORT2_MAIN_TXT','Logged-on Users');
define('REPORT2_BACK_BTN','< Back');
define('REPORT2_PRINT_BTN','Print');
define('REPORT2_EXPORT_BTN','Export');
define('REPORT2_COL1','User Name');
define('REPORT2_COL2','Last Connected Client');
define('REPORT2_COL3','Total Connection Time');
define('REPORT2_COL4','Connected');
?>