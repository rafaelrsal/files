<?PHP
define('REPORT2_MAIN_TXT','Usu�rios Conectados');
define('REPORT2_BACK_BTN','< Voltar');
define('REPORT2_PRINT_BTN','Imprimir');
define('REPORT2_EXPORT_BTN','Exportar');
define('REPORT2_COL1','Nome do Usu�rio');
define('REPORT2_COL2','�ltimo Cliente Conectado');
define('REPORT2_COL3','Tempo Total de Conex�o');
define('REPORT2_COL4','Conectado');
?>