<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: report2.php
  Purpose: present users that are\were connected to hosts in a timeframe.
  		   The following fields will be present: "User, Last Connected Client, Total Connection Time, Currently Connected".
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('HTML/QuickForm.php');

require_once('HTML/Table.php');
require_once('includes/classes/PearDB.php');
require_once('Admin/includes/classes/reportGenerator.php');

class report2 extends ModuleBase
{
	var $m_db;
	var $m_reportGenerator;

	function report2($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('report2Form'); //default is post
	}

	function init()
	{
		parent::init("report2");

		$this->m_form->addElement('header', 'header', REPORT2_MAIN_TXT);
		$this->m_form->addElement('submit', 'back', REPORT2_BACK_BTN,"class='NewButton'");
		$this->m_form->addElement('submit', 'print', REPORT2_PRINT_BTN, 'class="NewButton" onclick = printReport()');
		$this->m_form->addElement('submit', 'export', REPORT2_EXPORT_BTN,"class='NewButton'");

		$this->m_form->addElement('text', 'fromdate', REPORT_DATE_LBL);
		$this->m_form->addElement('text', 'fromtime', REPORT_TIME_LBL);
		$this->m_form->addElement('text', 'todate', REPORT_DATE_LBL);
		$this->m_form->addElement('text', 'totime', REPORT_TIME_LBL);
		
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);

		$tmpElement = &$this->m_form->getElement('fromdate');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('fromtime');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('todate');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('totime');
		$tmpElement->freeze();
	}

	function process()
	{
		$formValuesArray = $this->m_form->exportValues();

		$fromDate 	= $this->m_session->value('fromDate');
		$toDate 	= $this->m_session->value('toDate');
		$fromTime 	= $this->m_session->value('fromTime');
		$toTime 	= $this->m_session->value('toTime');

		$this->m_form->setDefaults(array('fromdate'=>$fromDate, 'todate'=>$toDate,'fromtime'=>$fromTime.':00:00','totime'=>$toTime.':00:00'));

		$this->m_reportGenerator = new reportGenerator(REPORT2_MAIN_TXT, $this->m_language , "reports" );
		$colArr = array(REPORT2_COL1.'        ',REPORT2_COL3/*,REPORT2_COL3,REPORT2_COL4*/);
		$table = $this->m_reportGenerator->createTable($this->m_db, TABLE_CONNECTION_INFO, $colArr, $this->formSQL($fromDate, $toDate, $fromTime, $toTime));
		$this->truncateUserDurationTable();
		$this->m_db->disconnect();

		if ( array_key_exists("back", $formValuesArray) )
		{
			$this->goBack($fromDate, $toDate, $fromTime, $toTime );
		}
		elseif ( array_key_exists("export", $formValuesArray))
		{
			parent::CriaLog(REPORT2_EXPORT_BTN);
			$this->m_reportGenerator->createHeaderTxt(REPORT2_MAIN_TXT,$fromDate, $toDate, $fromTime, $toTime);
			$this->m_reportGenerator->downloadCSV();
		}

		$res = $this->m_reportGenerator->prepareReportPage();

		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}

	function finalize()
	{
		$arrVars = array(	"report2Form_from_txt"=>REPORT_FROM_TXT,
							"report2Form_to_txt"=>REPORT_TO_TXT,
							"report_table"=>$this->m_reportGenerator->getReportAsIFrame());

		parent::finalize($arrVars);
	}

	function goBack($fromDate, $toDate, $fromTime, $toTime)
	{
		$this->m_session->set('fromDate', $fromDate);
		$this->m_session->set('toDate', $toDate);
		$this->m_session->set('fromTime', $fromTime);
		$this->m_session->set('toTime', $toTime);

		$this->m_session->set('reportName', $this->m_moduleName);

		Header('Location: admin.php?module=reports&roll='.$_POST['roll']);
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		exit();
	}

	function formSQL($fromDate, $toDate, $fromTime, $toTime)
	{
		if ( 'mysql' == $this->m_db->getDBSyntax() )
		{
			$sql1 = "CREATE TABLE IF NOT EXISTS ".TABLE_USER_DURATION." (SELECT T2.LOGGED_ON_USER AS USER, CASE WHEN T1.CONNECTED =0 THEN ( unix_timestamp( T1.END_TIME )  - unix_timestamp( T1.START ))
				ELSE 0
				END AS NOT_CONNECTED,
				CASE
				WHEN T1.CONNECTED =1 AND T1.HEARTBEAT_INTERVAL = 0
				THEN ( unix_timestamp( SYSDATE())  - unix_timestamp( T1.START ))
				ELSE 0
				END AS CONNECTED_AND_NO_HEARTBEAT,
				CASE
				WHEN ( (T1.CONNECTED =1 AND T1.HEARTBEAT_INTERVAL > 0 ) AND (( ( T1.HEARTBEAT_INTERVAL /1000 ) +60 + unix_timestamp(T1.END_TIME) ) > unix_timestamp(SYSDATE())  ))
				THEN ( unix_timestamp( SYSDATE())  - unix_timestamp( T1.START ))
				ELSE 0
				END AS CONNECTED_AND_ALIVE,
				CASE
				WHEN ((T1.CONNECTED =1 AND T1.HEARTBEAT_INTERVAL > 0 ) AND ( ( ( T1.HEARTBEAT_INTERVAL /1000 ) +60 + unix_timestamp(T1.END_TIME) ) <= unix_timestamp(SYSDATE(  ))  ))
				THEN ( unix_timestamp( T1.END_TIME )  - unix_timestamp( T1.START ) + T1.HEARTBEAT_INTERVAL /1000 + 60 )
				ELSE 0
				END AS CONNECTED_AND_DEAD
				FROM  ".TABLE_CONNECTION_INFO." T1,  ".TABLE_REGISTRATION_INFO." T2
				WHERE T1.SESSION_ID = T2.SESSION_ID
				AND
				( T1.START >=  '$fromDate $fromTime:00:00'
				AND
				T1.END_TIME<'$toDate $toTime:00:00' )) LIMIT 0 , 5000;";

			$this->m_db->Query($sql1);

			$sql2 = "SELECT USER AS USER,SEC_TO_TIME( SUM(CONNECTED_AND_DEAD) + SUM(CONNECTED_AND_NO_HEARTBEAT)+SUM(CONNECTED_AND_ALIVE)+SUM(NOT_CONNECTED)  ) AS TOTAL_TIME FROM ".TABLE_USER_DURATION." GROUP BY USER LIMIT 0 , 5000;";
		}
		elseif ( 'mssql' == $this->m_db->getDBSyntax() )
		{
			$sql1  = "SELECT TOP 5000 T2.LOGGED_ON_USER AS USERNAME ,
							CASE WHEN T1.CONNECTED =0
								THEN  DATEDIFF( ss,T1.START,T1.END_TIME)
							ELSE 0
							END AS NOT_CONNECTED,
							CASE WHEN T1.CONNECTED =1 AND T1.HEARTBEAT_INTERVAL = 0
								THEN DATEDIFF(ss,T1.START,GETDATE())
							ELSE 0
							END AS CONNECTED_AND_NO_HEARTBEAT,
							CASE WHEN ( (T1.CONNECTED =1 AND T1.HEARTBEAT_INTERVAL > 0 )
										AND
										(DATEDIFF(second, T1.END_TIME, GETDATE()) < (T1.HEARTBEAT_INTERVAL / 1000 + 60))
									  )
							THEN DATEDIFF(ss,T1.START,GETDATE())
							ELSE 0
							END AS CONNECTED_AND_ALIVE,
							CASE WHEN ((T1.CONNECTED =1 AND T1.HEARTBEAT_INTERVAL > 0 )
									   AND
									   (DATEDIFF(second, T1.END_TIME, GETDATE()) > (T1.HEARTBEAT_INTERVAL / 1000 + 60))
									  )
							THEN DATEDIFF(ss,T1.START,DATEADD(ss,T1.HEARTBEAT_INTERVAL /1000 + 60, T1.END_TIME ))
							ELSE 0
							END AS CONNECTED_AND_DEAD
							INTO ".TABLE_USER_DURATION." FROM hsp_connection_info T1, hsp_registration_info T2 WHERE T1.SESSION_ID = T2.SESSION_ID
							AND
							( T1.START >=  '$fromDate $fromTime:00:00'
							AND
							T1.END_TIME<'$toDate $toTime:00:00' )";
						
					$this->m_db->Query($sql1);

				$sql2 = "SELECT TOP 5000 USERNAME AS USERNAME,
							  CONVERT(	   char(10),
												   DATEADD(ss,
											 SUM(CONNECTED_AND_DEAD)+SUM(NOT_CONNECTED)+SUM(CONNECTED_AND_NO_HEARTBEAT)+SUM(CONNECTED_AND_ALIVE),0),
											 108
										   )
							  AS TOTAL_TIME FROM ".TABLE_USER_DURATION."
							GROUP BY USERNAME";
							
		}
		return $sql2;
	}

	function truncateUserDurationTable()
	{
		if ( 'mssql' == $this->m_db->getDBSyntax() )
		{
			$sql1 = "DROP TABLE ".TABLE_USER_DURATION.";";
		}else
		{
			$sql1 = "TRUNCATE TABLE ".TABLE_USER_DURATION.";";
		}

		$this->m_db->Query($sql1);
	}
}
?>
