<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:	Hoter Mickey
  		Udi Zisser
  		Guy Schetrit

  Date Created:	Oct 2004

  Purpose:	Monitoring client configuration module.
  Limitations:	Requires PHP 4.3.4 and up

 ============================================================================*/
require_once('HTML/QuickForm.php');
require_once('includes/classes/xmlWrapper.php');

define('MAX_NUMBER_OF_TABS',20);
define('MIN_SERVER_TIMEOUT',60);

class userManagmentConfig extends ModuleBase
{	
	var $m_checkState1;
	var $m_checkState2;
	var $m_checkState3;
	var $m_checkState4;
	var $m_checkState5;
	var $m_wrapper;
	
	function userManagmentConfig($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		$this->m_checkState1 = ''; // enable new window checkbox
		$this->m_checkState2 = ''; // show remember password checkbox
		$this->m_checkState3 = ''; // enable global session limit checkbox
		$this->m_checkState4 = ''; // set default for new window to true
		$this->m_checkState5 = ''; // enable localstart
		
		$this->m_wrapper = new xmlWrapper();
	}
	
	function init()
	{
		parent::init("userManagmentConfig");

		$this->m_wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME);
		$configParams = $this->m_wrapper->getConfigParams();
		
		$enableNewWindow	 	= $configParams['enableNewWindow'];
		$showRememberPassword	= $configParams['showRememberPassword'];
		$globalSessionLimit		= $configParams['globalSessionLimit'];
		$numberOfTabs 		 	= $configParams['numberOfTabs'];
		$serverTimeout		 	= $configParams['serverTimeout'];
		$setOpenNewWindow	 	= $configParams['setOpenNewWindow'];
		$enableLocalstart		= $configParams['enableLocalstart'];
		
		if ('true' == $enableNewWindow )
		{
			$this->m_checkState1	= 'checked';
		}
		
		if ('true' == $showRememberPassword )
		{
			$this->m_checkState2	= 'checked';
		}
		
		if ('true' == $globalSessionLimit )
		{
			$this->m_checkState3	= 'checked';
		}

		if ('true' == $setOpenNewWindow )
		{
			$this->m_checkState4	= 'checked';
		}
		
		if ('true' == $enableLocalstart )
		{
			$this->m_checkState5	= 'checked';
		}
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('userManagmentConfigForm'); //default is post

		// Build the Configuration form:
		$this->m_form->addElement('header', 'header_general', USERMNG_GENERAL_HEADER);
		$this->m_form->addElement('text', 'serverTimeout',USERMNG_SERVER_TIMEOUT_LBL, array('size' => 3, 'maxlength' => 5,'onchange' => "updated()"));
		$this->m_form->addElement('text', 'numberOfTabs', USERMNG_NUMBER_OF_TABS_LBL, array('size' => 3, 'maxlength' => 2,'onchange' => "updated()"));
		$this->m_form->addElement('submit', 'save', USERMNG_SAVE_BTN,'class="NewButton" "onclick="onSave();return false;" ShortFixedWidthObjects');
		$this->m_form->addElement('button', 'restore', USERMNG_RESTORE_BTN,'class="NewButton" "onclick="onRestore()" style="width:110px"');
		$this->m_form->addElement('hidden', 'buttonClicked','');
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->setDefaults(array('numberOfTabs'=>$numberOfTabs, 'serverTimeout'=>$serverTimeout ));
	}
	
	function process()
	{		
		$res = HSP_SUCCESS;
		$buttonClicked	= $this->m_form->exportValue('buttonClicked');

		if ( 'save' == $buttonClicked )
		{
			$numberOfTabs	= htmlspecialchars($this->m_form->exportValue('numberOfTabs'));
			$serverTimeout	= htmlspecialchars($this->m_form->exportValue('serverTimeout'));
			
			$res = $this->onSave( $numberOfTabs, $serverTimeout );
			if ( HSP_SUCCESS != $res )
			{
				$this->m_session->set(SESSION_ERRORS, $res);
			}
			parent::CriaLog(USERMNG_SAVE_BTN);
		}
	}
	
	function finalize()
	{		
		$arrVars = array(	"lblCheckbox"=>USERMNG_ENABLE_RUN_IN_A_NEW_WINDOW_LBL,
							"numberOfTabsErrMsg"=>USERMNG_ERR_NUMBER_OF_TABS_MSG,
							"timeoutErrMsg"=>USERMNG_ERR_SERVER_TIMEOUT_MSG,
							"numberOfTabsReqMsg"=>USERMNG_NUMBER_OF_TABS_REQ_MSG,
							"timeoutReqMsg"=>USERMNG_SERVER_TIMEOUT_REQ_MSG,
							"requiredNote"=>USERMNG_REQUIRED_TXT,
							"maxNumberOfTabs"=>MAX_NUMBER_OF_TABS,
							"minServerTimeout"=>MIN_SERVER_TIMEOUT,
							"lblShowRememberPassword"=>USERMNG_REMEMBERPASSOWRD_LBL,
							"enableRunInNewWindow"=>$this->m_checkState1, 
							"showRememberPassword"=>$this->m_checkState2,
							"globalSessionLimit"=>$this->m_checkState3,
							"setOpenNewWindow"=>$this->m_checkState4,
							"enableLocalstart"=>$this->m_checkState5,
							"userManagmentConfigForm_header_portal"=>USERMNG_PORTAL_HEADER,
							"userManagmentConfigForm_portal_txt"=>USERMNG_PORTAL_TEXT,
							"lblGlobalSessionLimit"=>USERMNG_GLOBAL_SESSION_LIMIT,
							"lblSetOpenInNewWindow"=>USERMNG_SET_RUN_IN_A_NEW_WINDOW_LBL,
							"lblLocalstart"=>USERMNG_LOCALSTART														
							);
							
							
		parent::finalize($arrVars);
	}
	
	function onSave( $numberOfTabs, $serverTimeout )
	{
		if (isset($_POST['enableRunInNewWindowChk']) && 'on' == $_POST['enableRunInNewWindowChk'])
		{
			$enableClients = 'true';
			$this->m_checkState1 = 'checked';			
		}
		else
		{
			$enableClients = 'false';
			$this->m_checkState1 = '';			
		}
		
		if (isset($_POST['showRememberPasswordChk']) && 'on' == $_POST['showRememberPasswordChk'])
		{			
			$rememberPassword = 'true';
			$this->m_checkState2 = 'checked';
		}
		else
		{
			$rememberPassword = 'false';
			$this->m_checkState2 = '';
		}
		
		if (isset($_POST['globalSessionLimitChk']) && 'on' == $_POST['globalSessionLimitChk'])
		{
			$globalSessionLimit = 'true';
			$this->m_checkState3 = 'checked';			
		}
		else
		{
			$globalSessionLimit = 'false';
			$this->m_checkState3 = '';			
		}

		if (isset($_POST['setOpenInNewWindowChk']) && 'on' == $_POST['setOpenInNewWindowChk'])
		{
			$setOpenNewWindow = 'true';
			$this->m_checkState4 = 'checked';			
		}
		else
		{
			$setOpenNewWindow = 'false';
			$this->m_checkState4 = '';			
		}

		if (isset($_POST['enableLocalstartChk']) && 'on' == $_POST['enableLocalstartChk'])
		{
			$enableLocalstart = 'true';
			$this->m_checkState5 = 'checked';			
		}
		else
		{
			$enableLocalstart = 'false';
			$this->m_checkState5 = '';			
		}
		$configParams = array();
		$configParams['enableNewWindow'] 		= $enableClients;
		$configParams['numberOfTabs'] 			= $numberOfTabs;
		$configParams['serverTimeout'] 			= $serverTimeout;
		$configParams['showRememberPassword'] 	= $rememberPassword;
		$configParams['globalSessionLimit'] 	= $globalSessionLimit;
		$configParams['setOpenNewWindow'] 		= $setOpenNewWindow;
		$configParams['enableLocalstart'] = $enableLocalstart;
		
		$this->m_wrapper->setConfigParams($configParams);
		$this->m_wrapper->serialize(CONFIG_XML_PATH . CONFIG_XML_NAME);
		
		$this->saveJsConfiguration($configParams);
	}
	
	function saveJsConfiguration($configParams)
	{
		$fp = fopen('data/portalConfiguration.js', 'w');
		
		fwrite($fp, 'var enableNewWindow = ' . $configParams['enableNewWindow'] . '; ');
		fwrite($fp, 'var numberOfTabs = ' . $configParams['numberOfTabs'] . '; ');		
		fwrite($fp, 'var rememberPassword = ' . $configParams['showRememberPassword'] . '; ');
		fwrite($fp, 'var globalSessionLimit = ' . $configParams['globalSessionLimit'] . '; ');
		fwrite($fp, 'var setOpenNewWindow = ' . $configParams['setOpenNewWindow'] . '; ');
		fwrite($fp, 'var enableLocalstart = ' . $configParams['enableLocalstart'] . '; ');
		fclose($fp);
		
		$fp = fopen('data/defines.php', 'w');
		
		fwrite($fp, "<?PHP define('MAX_EXECUTEION_TIME', " . $configParams['serverTimeout'] . '); ?>');
		fwrite($fp, "<?PHP define('GLOBAL_SESSION_LIMIT', " . $configParams['globalSessionLimit'] . '); ?>');
		
		fclose($fp);		
	}


}
?>