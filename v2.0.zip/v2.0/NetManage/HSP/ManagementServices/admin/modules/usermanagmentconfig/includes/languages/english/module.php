<?PHP
define('USERMNG_PORTAL_HEADER','Portal Preferences');
define('USERMNG_PORTAL_TEXT','Display the following in Portal View: ');
define('USERMNG_GENERAL_HEADER','General Preferences');
define('USERMNG_NUMBER_OF_TABS_LBL','Number of open sessions (1-20):');
define('USERMNG_SERVER_TIMEOUT_LBL','Server timeout (seconds):');
define('USERMNG_ENABLE_RUN_IN_A_NEW_WINDOW_LBL','Open in new window');
define('USERMNG_SET_RUN_IN_A_NEW_WINDOW_LBL','Set default for new window to true');
define('USERMNG_REMEMBERPASSOWRD_LBL','Remember password');
define('USERMNG_SAVE_BTN','Save');
define('USERMNG_RESTORE_BTN','Restore Defaults');
define('USERMNG_NUMBER_OF_TABS_REQ_MSG','Number of tabs is required');
define('USERMNG_SERVER_TIMEOUT_REQ_MSG','Server timeout is required');
define('USERMNG_ERR_NUMBER_OF_TABS_MSG','Number of tabs should be an integer between 1 and 20');
define('USERMNG_ERR_SERVER_TIMEOUT_MSG','Server timeout should be at least 60 seconds');
define('USERMNG_REQUIRED_TXT','denotes required field');
define('USERMNG_GLOBAL_SESSION_LIMIT','Enable portal restrictions');
define('USERMNG_LOCALSTART','Enable Local Start');
?>