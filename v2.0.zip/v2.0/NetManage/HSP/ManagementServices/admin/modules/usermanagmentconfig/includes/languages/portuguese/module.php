<?PHP
define('USERMNG_PORTAL_HEADER','Prefer�ncias do Portal');
define('USERMNG_PORTAL_TEXT','Apresentar o seguinte na vis�o do Portal: ');
define('USERMNG_GENERAL_HEADER','Prefer�ncias Gerais');
define('USERMNG_NUMBER_OF_TABS_LBL','N�mero de sess�es abertas (1-20):');
define('USERMNG_SERVER_TIMEOUT_LBL','Timeout do Servidor (seconds):');
define('USERMNG_ENABLE_RUN_IN_A_NEW_WINDOW_LBL','Abrir em uma nova janela');
define('USERMNG_SET_RUN_IN_A_NEW_WINDOW_LBL','Definir true como padr�o para a nova janela');
define('USERMNG_REMEMBERPASSOWRD_LBL','Relembrar senha');
define('USERMNG_SAVE_BTN','Salvar');
define('USERMNG_RESTORE_BTN','Restaurar Padr�es');
define('USERMNG_NUMBER_OF_TABS_REQ_MSG','N�mero de abas � requerido');
define('USERMNG_SERVER_TIMEOUT_REQ_MSG','Timeout do servidor requerido');
define('USERMNG_ERR_NUMBER_OF_TABS_MSG','O n�mero de abas deve ser um inteiro entre 1 e 20');
define('USERMNG_ERR_SERVER_TIMEOUT_MSG','O Timeout do servidor deve ser pelo menos 60 seconds');
define('USERMNG_REQUIRED_TXT','verifique os campos obrigat�rios');
define('USERMNG_GLOBAL_SESSION_LIMIT','Habilitar restri��es do portal');
define('USERMNG_LOCALSTART','Habilitar Local Start');
?>