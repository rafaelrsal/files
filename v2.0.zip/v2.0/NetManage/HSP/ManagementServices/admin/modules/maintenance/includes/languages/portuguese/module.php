<?PHP
define('MAINTENANCES_STATUS_ON_LBL','Um upgrade de vers�o do HSP est� pronto para ser instalado. Para continuar com a atualiza��o, pressione Aplicar. Enquanto voc� n�o pressionar Aplicar, o sistema pode ficar inst�vel. Consequentemente voc� n�o deve executar nenhum comando HSP antes que o processo de upgrade esteja conclu�do.');
define('MAINTENANCES_APPLY_BTN','Aplicar');
?>