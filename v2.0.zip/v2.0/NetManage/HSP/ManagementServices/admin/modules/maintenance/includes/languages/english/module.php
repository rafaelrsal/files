<?PHP
define('MAINTENANCES_STATUS_ON_LBL','An upgrade version of HSP is ready to be installed. To continue upgrading, click Apply. Until you click Apply, the system is unstable. Consequently, you should  not run any HSP commands before the upgrade process is complete.');
define('MAINTENANCES_APPLY_BTN','Apply');
?>