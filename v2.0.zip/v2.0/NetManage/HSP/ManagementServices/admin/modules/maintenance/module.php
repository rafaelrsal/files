<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:	Udi Zisser
  			Guy Schetrit

  Date Created:	Mars 2004

  Purpose:	Maintenance module.
  Limitations:	Requires PHP 4.3.4 and up

 ============================================================================*/
require_once('HTML/QuickForm.php');
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');



class maintenance extends ModuleBase
{
	var $m_db;
	var $m_upgrade;
	
	function maintenance($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db = &parent::GetDatabase();
		$this->m_db->connect();
	}
	
	function init()
	{
		parent::init("maintenance");
		
		$this->m_firstTime = false;
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('MaintenanceForm'); //default is post

		// Build the Configuration form:
		$this->m_form->addElement('text', 'maintenanceStatus', MAINTENANCES_STATUS_ON_LBL, array('size' => 20, 'maxlength' => 255 ) );
		$this->m_form->addElement('submit', 'apply', MAINTENANCES_APPLY_BTN,'class="NewButton" ShortFixedWidthObjects');
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
	}
	
	function process()
	{
		if ( isset( $_SESSION[SESSION_UPGRADE] ) )
		{
			$this->m_upgrade = $_SESSION[SESSION_UPGRADE];
		}
		
		if ( 'POST' == $_SERVER['REQUEST_METHOD'] )
		{			
			$this->onApply();
		}
	}
	
	function finalize()
	{
		$arrVars = array( 'maintenanceStatus' => MAINTENANCES_STATUS_ON_LBL,
						  'bButtonEnabled' => 'true' );
		parent::finalize($arrVars);
	}

	function onApply()
	{
		$this->m_upgrade->run();
		unset($_SESSION[SESSION_UPGRADE]);
		
		// Redirect to the home module
		Header('Location: admin.php?module=home');
		exit();
	}
}
?>