<?PHP
/*===========================================================================

        Copyright (c) 2013, Slice TI.  All Rights Reserved.  
 ============================================================================

  Author: Guilherme Lima
  Date Created: April 2013
  Title:            database methods
  Purpose:          methods for db access
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
 require_once('HTML/QuickForm.php');
 require_once('includes/classes/xmlWrapper.php');
 
 class newUser extends ModuleBase{
	
	var $m_form;
	var $m_globalobjects;
	var $m_roll;
	var $m_dbConfig;
	var $m_internalUserArr;
	var $m_db;
	var $m_dbConfig;
	
	function newUser($globalobjects){
		parent::ModuleBase($globalobjects);
		$this->m_form = new HTML_QuickForm('newUserForm'); //default is post
		$this->m_dbConfig = new DBConfig(); // setar permissions 
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
	}
	
	function init(){
		parent::init("newUser");
		
		$this->m_form->addElement('button', 'newUser', NEWUSER_NEW_BTN, "class='NewButton' onclick='onNew();return false;'");
		$this->m_form->addElement('submit', 'save',    NEWUSER_SAVE_BTN,  "class='NewButton' onclick='setContent();return false;'");
		$this->m_form->addElement('button', 'cancel',  NEWUSER_CANCEL_BTN,  "class='NewButton' onclick='self.close();'");
		$this->m_form->addElement('button', 'delete',  NEWUSER_DELETE_BTN, "onclick=onDelete() class='NewButton'");
		$this->m_form->addElement('button', 'reset', NEWUSER_RESET_BTN, "onclick='onReset();return false;' class='NewButton' style=width:106px");
		
		$this->m_form->addElement('text', 'user',   NEWUSER_USER_LBL, array('size' => 20, 'maxlength' => 255, 'class' => 'FixedWidthObjects'));
		
		
		$this->m_form->addElement('hidden', 'buttonClicked','');
		$this->m_form->addElement('hidden', 'selectedRow', 1);	
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		$this->m_form->addElement('hidden', 'permRoll', '');
		$this->m_form->addElement('hidden', 'error1', NEWUSER_USER_REQ_MSG);
		
		$this->populateUserListArr();
	}
	
	function process(){
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$res = HSP_SUCCESS;	
			
			$formValuesArray = $this->m_form->exportValues();
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));
			
			if("reset" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onReset($selectedRow);
			}
			elseif("delete" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onDelete($selectedRow);
			}
			elseif("new" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onNew();
			}
			if(HSP_SUCCESS != $res){
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);	
			}
			else{
				$this->populateUserListArr();
			}
		}
	}
	
	function finalize()
	{
		$language = parent::GetLanguage();
		
		$arrVars = array(	"tbluser"=>$this->generateTable(),					        
					        "confirm_delete"=>NEWUSER_CONFIRM_DELETE_MSG,
							"confirm_reset"=>NEWUSER_CONFIRME_RESET_MSG,
					        "selectedRow"=>$this->getSelectedUserIndex(),
					        "lblNew"=>rawurlencode(NEWUSER_NEW_USER),
					        "moduleName"=>$this->m_moduleName,
							"roll_lbl"=>NEWUSER_ROLL_LBL,
					        'newUserForm_required_note'=>NEWUSER_REQUIRED_TXT);       
		parent::finalize( $arrVars , 'newUser' );
	}
	
	// Fun��o para selecionar o index do linha selecionada
	function getSelectedUserIndex()
	{
		foreach ( $this->m_internalUserArr as $index=>$dir )
		{
			if ( $dir['uid'] == $dirId )
			{
				return $index+1;
			}
		}
		return 1;
	}
	
	// Fun��o para gera��o de tabela
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tbluser" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(NEWUSER_USER_LBL , NEWUSER_ROLL_LBL);
		$headerAttribArr = array("class='TableHeader' width=200px","class='TableHeader' width=200px");
		$tblBackups->addRow($headerArr , $headerAttribArr );
		
		foreach ( $this->m_internalUserArr as $key=>$dirRow )
		{
			$rownum = $key + 1 ;
			
			$shortName = $dirRow['username'];
			
			if ( strlen($shortName) > 23 )
			{
				$shortName = substr($dirRow['username'], 0, 23) . '...';
			}
			
			$shortDesc = $dirRow['roll'];
			
			if ( strlen($shortDesc) > 47 )
			{
				$shortDesc = substr($dirRow['roll'], 0, 47) . '...';
			}			
			
			$row = array ( $shortName , $shortDesc );			
			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
		
			$user = $dirRow['username'];
			$roll = $dirRow['roll'];
			$attib = array("class='DataCell' title='$user'","class='DataCell' title='$roll'");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}
		
		return $tblBackups->toHtml();
	}
	
	// Fun��o para popular array gen�rico
	function populateUserListArr()
	{
		$this->m_internalUserArr = $this->m_db->GetAllEx("SELECT * FROM ".TABLE_ADMIN_USERS . ";", null, DB_FETCHMODE_ASSOC);
		
 		$this->sortDirArr();
	}
	
	// Fun��o para Colocar em ordem os itens da tabela
	function sortDirArr()
	{
		$tmpArr = array();
		foreach($this->m_internalUserArr as $directoryItem)
		{
			$tmpArr[] = $directoryItem['username'];
		}
		
		natcasesort($tmpArr);
		
		$newFileListArray = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $this->m_internalUserArr as $directoryItem )
			{
				if ($name == $directoryItem['username'] )
				{
					$newFileListArray[] = $directoryItem;
					break;
				}
			}			
		}
		
		$this->m_internalUserArr = $newFileListArray;
	}
	
	function onReset($selectedRow)
	{
		$userId = $this->m_internalUserArr[$selectedRow-1]['uid'];
		if($this->m_dbConfig->ResetPassaword($userId) == 'ok')
		{ // resetou senha?
			parent::CriaLog(NEWUSER_RESET_BTN, $this->m_internalUserArr[$selectedRow-1]['username']);
			return HSP_SUCCESS;
		}
		else
		{
			return HSP_ERR_DB_ERROR;
		}
	}
	
	function onDelete($selectedRow)
	{
		$userName = $this->m_internalUserArr[$selectedRow-1]['username'];
		if($this->m_dbConfig->RemoveAdminUser($userName) == 'ok')
		{ // resetou senha?
			parent::CriaLog(NEWUSER_DELETE_BTN, $userName);
			return HSP_SUCCESS;
		}
		else
		{
			return HSP_ERR_DB_ERROR;
		}
	}
	
	function onNew()
	{
		$user = htmlspecialchars($this->m_form->exportValue('user'));
		$roll = htmlspecialchars($this->m_form->exportValue('permRoll'));
		if($this->m_dbConfig->CreateNewAdminUser($user,NEWUSER_DEFAULT_PASSWORD, $roll) == 'ok')
		{ // resetou senha?
			parent::CriaLog(NEWUSER_NEW_BTN, $user);
			return HSP_SUCCESS;
		}
		else
		{
			return HSP_ERR_DB_ERROR;
		}
	}
 }
?>