<?PHP 
define('NEWUSER_NEW_BTN', 'New');
define('NEWUSER_RESET_BTN', 'Restart Password');
define('NEWUSER_DELETE_BTN', 'Remove');
define('NEWUSER_CANCEL_BTN', 'Cancel');
define('NEWUSER_SAVE_BTN', 'Save');

define('NEWUSER_USER_LBL', 'User');
define('NEWUSER_ROLL_LBL',	'Role');

define('NEWUSER_USER_REQ_MSG', 'Inform the name of user');
define('NEWUSER_REQUIRED_TXT','verify ');
define('NEWUSER_CONFIRM_DELETE_MSG','You are certain if you want remove this user?');
define('NEWUSER_CONFIRME_RESET_MSG','You are certain if you want restart password of this user?');
define('NEWUSER_NEW_USER','New User');

define('NEWUSER_DEFAULT_PASSWORD','password');
?>