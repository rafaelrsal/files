<?PHP 
define('NEWUSER_NEW_BTN', 'Novo');
define('NEWUSER_RESET_BTN', 'Resetar Senha');
define('NEWUSER_DELETE_BTN', 'Remover');
define('NEWUSER_CANCEL_BTN', 'Cancelar');
define('NEWUSER_SAVE_BTN', 'Salvar');

define('NEWUSER_USER_LBL', 'Usu�rio');
define('NEWUSER_ROLL_LBL',	'Role');

define('NEWUSER_USER_REQ_MSG', 'Informe o nome do usu�rio');
define('NEWUSER_REQUIRED_TXT','verifique ');
define('NEWUSER_CONFIRM_DELETE_MSG','Voc� tem certeza que deseja remover este usu�rio?');
define('NEWUSER_CONFIRME_RESET_MSG','Voc� tem certeza que deseja resetar a senha deste usu�rio?');
define('NEWUSER_NEW_USER','Novo Usu�rio');

define('NEWUSER_DEFAULT_PASSWORD','password');
?>