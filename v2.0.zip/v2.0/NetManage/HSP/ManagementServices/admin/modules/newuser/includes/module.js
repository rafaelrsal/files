function initPopup()
{
	document.getElementById('popupErrors').innerHTML = '&nbsp;';
	// GUILHERME LIMA 02/04/2013
	var documento = document.getElementById('roll'); // div para inclus�o do checkbox
	
	//zerar documento
	documento.innerHTML = ""; 

	// loop para rodas todas permis�es possiveis
	for (var i = 0; i < permission.length; i++)
	{
		if(permission[i].nome == "admin") // admin como default
		{
			// documento.innerHTML = documento.innerHTML + '<input type="radio" checked="checked" name="rolls" value='+ permission[i].nome +' /> '+ permission[i].nome;// exibe permiss�o em radio
		}
		else
		{
			if(i == 1)
			{
				documento.innerHTML = documento.innerHTML + '<input type="radio" checked="checked" name="rolls" value='+ permission[i].nome +' /> '+ permission[i].nome;// exibe permiss�o em radio
			}
			else
			{
				documento.innerHTML = documento.innerHTML + '<input type="radio" name="rolls" value='+ permission[i].nome +' /> '+ permission[i].nome;// exibe permiss�o em radio
			}
		}
		if((i)%2 ==0)
		{
			documento.innerHTML = documento.innerHTML + '<br/>';
		}
	} // end for	
}

function finalizePopup()
{			    
	if( validateForm() )
	{
		saveDirectory();
	}
	else
	{
		document.getElementsByName('user').item(0).focus();
	}
}

function saveDirectory()
{
	var rolls = document.getElementsByName('rolls');
	
	win.document.getElementsByName('user').item(0).value 				= document.getElementsByName('user').item(0).value;
	
	for (i = 0; i < rolls.length; i++)
	{
		if(rolls[i].checked)
		{
			win.document.getElementsByName('permRoll').item(0).value	= rolls[i].value;
			break;
		}
	}
	
	
	win.document.getElementById('newUserForm').submit();
	window.close();
}

function validateForm()
{	
	if (isEmpty ( 'user' ))
	{    
		document.getElementById('popupErrors').innerHTML = win.document.getElementById('error1').value;
		return false;
	}
	return true;
}

