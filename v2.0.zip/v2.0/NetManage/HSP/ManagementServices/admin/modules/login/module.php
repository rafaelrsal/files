<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title:            module.php (login)
  Purpose:          Entry point for loging in to the HSP administration console.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/

require_once('HTML/QuickForm.php');

require_once('includes/classes/xmlWrapper.php');
require_once('upgrade/upgrade.php');

class login extends ModuleBase
{
	var $m_db;
	var $m_bisInit;
	var $rolltype;
	
	function login($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db  = &parent::GetDatabase();
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('loginForm'); //default is post
	}
	
	function  init()
	{
		parent::init("login");
		
		$isValidated = false;
		$isErrorFound = false;
		// Check if this is the first time HSP administration console is run.
		// This is done by checking error code - file not found, entered at the
		// admin.php.
		// If so we need to get DB and password information for on going use:

		$ret = $this->m_db->connect();
		
		$this->m_bisInit = &$this->m_session->value(SESSION_INIT_CONFIG);
		if (HSP_SUCCESS == $ret)
		{
			$this->m_bisInit = !$this->isDBExists() ? true : $this->m_bisInit;
		}
		else
		{
			$this->m_bisInit = true;
		}
				
		// Set defaults for the form elements
		$this->m_form->setDefaults(array('name'=>'admin'));

		// Build the login form:
		$this->m_form->addElement('header', 'header', LOGIN_HEADER_TXT);
		$this->m_form->addElement('text', 'name', LOGIN_USERNAME_LBL, array('size' => 20, 'maxlength' => 255));
		$this->m_form->addElement('password', 'password', LOGIN_PASSWORD_LBL, array('size' => 20, 'maxlength' => 255));
		$this->m_form->addElement('submit', 'submit', LOGIN_BTN,"class='NewButton' style='width=110px'");
		$this->m_form->setRequiredNote(LOGIN_TXT_REQUIRED);

		// Define filters and validation rules
		$this->m_form->applyFilter('name', 'trim');
		$this->m_form->addRule('name', LOGIN_NAME_REQ_MSG, 'required');
		$this->m_form->addRule('password', LOGIN_PWD_REQ_MSG, 'required');
	}
	
	function process()
	{
		if ($this->m_form->validate())
		{
			$enteredPwd = null;
			$isValidated = true;

			$username = htmlspecialchars($this->m_form->exportValue('name'));
			$password = htmlspecialchars($this->m_form->exportValue('password'));

			$Credentials = false;
			$isKeyIniErr = false;

			if($this->m_bisInit)
			{
				$dbConfig = new DBConfig();
				$errCode = $dbConfig->init();
				if ( $errCode != HSP_ERR_FILE_NOT_FOUND )
				{
					if ($dbConfig->UserVerify($username,$password) != 'vazio')
					{
						$Credentials = true;
					}
					elseif(checkUserCredentials($usrename,$password)){
						$Credentials = true;
					}
					//$key_ini = $dbConfig->getInitParams();
				}
				else
				{
					$this->m_session->set(SESSION_ERRORS, $errCode);
					$key_ini = $dbConfig->getInitParams();
				}

				if ($key_ini)
				{
					if ($username == strtolower($key_ini['username']) && $password == $key_ini['password'])
					{
						$Credentials = true;
					}
				}
			}
			else
			{
				$dbConfig = new DBConfig();
				if ($dbConfig->UserVerify($username,$password) != 'vazio') // verifica se usu�rio � valido
				{
					$Credentials = true;
					$arruserinfo = array();
					$arruserinfo = $dbConfig->UserVerify($username,$password);
					$rolltype = $arruserinfo['roll'];
					$user = $arruserinfo['user'];
				}
				elseif($this->checkUserCredentials($username,$password)){
						$Credentials = true;
						$rolltype='admin';
						$user = $username;
				}
				// else
				// {
					// $key_ini = $dbConfig->getInitParams();
					
					// if ($key_ini)
				// {
					// if ($username == strtolower($key_ini['username']) && $password == $key_ini['password'])
					// {
						// $Credentials = true;
					// }
				// }
				// }
			}

			if ( $Credentials == false )
			{
				$errorCode = array(HSP_ERR_INVALID_CREDENTIALS);
				$this->m_session->set(SESSION_ERRORS, $errorCode);
				Header('Location: admin.php?module=login');
				exit();
			}
			else
			{	
				if ( !$this->m_bisInit )
				{
					if ( $this->upgrade() == false )
					{
						$errorCode = array(HSP_ERR_UPGRADE_FAILED);
						$this->m_session->set(SESSION_ERRORS, $errorCode);
						Header('Location: admin.php?module=login');
						exit();
					}
				}
							
				$this->m_session->set(SESSION_ADMIN_AUTH_FLAG, true); // set the flag to true so we concider this session authenticated
				if($this->m_bisInit)
				{
					// Redirect the Database configuration module
					Header('Location: admin.php?module=database');
					exit();
				}
				else
				{
					if ( isset( $_SESSION[SESSION_UPGRADE] ))
					{
						// Redirect to the maintenance module:
						Header('Location: admin.php?module=maintenance');
						exit();
					}
					// Redirect to the home module
					Header('Location: admin.php?module=home&roll='.$rolltype.'&username='.$user); // Passando parametro roll para para pagina inicial
					exit();
				}
			}
		}
	}
	function finalize()
	{
		$loginMessage = '';
		if($this->m_bisInit)
		{
			$loginMessage = LOGIN_INITIAL_CONFIG_MSG;
		}
		
		$arrVars = array( 	"please"=>LOGIN_PLEASE_TXT,
							"loginMessage"=> $loginMessage);
							
		parent::finalize($arrVars);
	}

	function checkUserCredentials($username,$password)
	{
		$wrapper = new xmlWrapper();
		$wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME);
		$umftConfig = $wrapper->getUMConfigInfo();
		if ( strtolower($umftConfig['user_name']) == strtolower($username) &&
			 $umftConfig['password']  == $password)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	//we assume the DB exists if the hsp_directories table exists
	function isDBExists()
	{
		$ret = null;
		$sql = 'select * from ' .  TABLE_DIRECTORIES .';';
		$this->m_db->GetOne($sql, $ret);

		//on error db_error object
		if ( DB::isError($ret) )
		{
			return false;
		}
		return true;
	}
	
	function upgrade()
	{
		$upgrade = new Upgrade( $this->m_db );
		if ( $upgrade->init() )
		{
			if ( $upgrade->getDoUpgrade() )
			{
				$_SESSION[SESSION_UPGRADE] = $upgrade;
			}
			else
			{
				unset($_SESSION[SESSION_UPGRADE]);
			}
			return true;
		}
		
		return false;
	}
}
?>