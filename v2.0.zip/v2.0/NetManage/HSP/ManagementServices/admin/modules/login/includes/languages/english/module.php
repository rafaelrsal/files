<?PHP
define('LOGIN_HEADER_TXT' , 'Welcome to Host Services Platform Logon');
define('LOGIN_PLEASE_TXT' , 'Enter your user name and password');
define('LOGIN_USERNAME_LBL', 'User name:');
define('LOGIN_PASSWORD_LBL', 'Password:');
define('LOGIN_BTN','Logon');
define('LOGIN_TXT_REQUIRED','denotes required field');
define('LOGIN_NAME_REQ_MSG','Enter your user name');
define('LOGIN_PWD_REQ_MSG','Enter your password');
define('LOGIN_INITIAL_CONFIG_MSG','You are running HSP Administrator for the first time.<br>You need to enter the required details.');
?>