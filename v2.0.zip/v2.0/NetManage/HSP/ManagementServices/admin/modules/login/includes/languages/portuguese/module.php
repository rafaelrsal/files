<?PHP
define('LOGIN_HEADER_TXT' , 'Bem vindo ao Portal de Acesso Externo aos Hosts');
define('LOGIN_PLEASE_TXT' , 'Informe seu usu�rio e senha');
define('LOGIN_USERNAME_LBL', 'Usu�rio:');
define('LOGIN_PASSWORD_LBL', 'Senha:');
define('LOGIN_BTN','Logon');
define('LOGIN_TXT_REQUIRED','verifique os campos obrigat�rios');
define('LOGIN_NAME_REQ_MSG','Informe seu usu�rio');
define('LOGIN_PWD_REQ_MSG','Informe sua senha');
define('LOGIN_INITIAL_CONFIG_MSG','Voc� est� executando o Administrador do HSP pela pimeira vez.<br>� necess�rio preencher as informa��es requeridas.');
?>