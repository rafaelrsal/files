function initPopup()
{
	document.getElementById('popupErrors').innerHTML = '&nbsp;';
	document.getElementsByName('paramName').item(0).focus();
}

function finalizePopup()
{	
	if ( validateForm() )			
	{			    
		 saveParameter()
	}
	else
	{
		document.getElementsByName('paramName').item(0).focus();
	}
}

function saveParameter()
{
	if ( 'true' == win.document.getElementsByName('bEditMode').item(0).value)
	{
		win.document.getElementsByName('buttonClicked').item(0).value 	= 'edit';
	}
	else
	{
		win.document.getElementsByName('buttonClicked').item(0).value 	= 'new';
	}
	win.document.getElementsByName('paramName').item(0).value 	= document.getElementsByName('paramName').item(0).value;
	win.document.getElementsByName('paramValue').item(0).value 	= document.getElementsByName('paramValue').item(0).value;
	
	win.document.getElementById('userParametersForm').submit();
	window.close();
}

function validateForm()
{	
	if (isEmpty ( 'paramName' ))
	{    
		document.getElementById('popupErrors').innerHTML = win.document.getElementById('error1').value;
		return false;
	}
	return true;
}
