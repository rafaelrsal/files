<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

require_once('admin/modules/directories/module.php');

define('SESSION_SET_USER_PARAMETERS_DETAILS', 	'setUserParametersDetails');


class userParameters extends ModuleBase
{
	var $m_db;
	var $m_bEditMode;
	var $m_isAnonymous;
	
	var $m_userId;
	var $m_userName;
	var $m_dirName;
	
	var $m_userParametersArr;

	var $m_globalobjects;
	
	function userParameters($globalobjects)
	{
		$this->m_globalobjects = $globalobjects;
		parent::ModuleBase($globalobjects);
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();

		$this->m_form = new HTML_QuickForm('userParametersForm'); //default is post
		
		$this->m_bEditMode = 'false'; //used only when the edit button is pressed		
		$this->m_isAnonymous = false;
	}
	
	function init()
	{		
		parent::init("userParameters");
		$this->m_form->addElement('button', 'newParam', 		USERPARAMETERS_NEW_BTN, 	"class='NewButton' onclick='onNew();return false;'");
		$this->m_form->addElement('submit', 'editParam', 		USERPARAMETERS_EDIT_BTN,  	"class='NewButton' onclick='onEdit();return false;'");
		$this->m_form->addElement('button', 'deleteParam',		USERPARAMETERS_DELETE_BTN,   	"onclick=onDelete() class='NewButton'");
		$this->m_form->addElement('button', 'back',				USERPARAMETERS_BACK_BTN,   		"onclick=onBack() class='NewButton'");
		
		$this->m_form->addElement('submit', 'save', 			USERPARAMETERS_SAVE_BTN,  "class='NewButton' onclick='setContent();return false;'");
		$this->m_form->addElement('button', 'cancel', 			USERPARAMETERS_CANCEL_BTN,  "class='NewButton' onclick='self.close();'");		
		
		$this->m_form->addElement('text', 'paramName', 			USERPARAMETERS_NAME_LBL, array('size' => 20, 'maxlength' => 255, 'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'paramValue', 		USERPARAMETERS_VALUE_LBL, array('size' => 40, 'maxlength' => 255, 'class' => 'FixedWidthObjects', 'style' => 'width:300px'));
		
		$this->m_form->addElement('hidden',	'paramName');
		$this->m_form->addElement('hidden', 'paramValue');		
		$this->m_form->addElement('hidden', 'buttonClicked','');
		$this->m_form->addElement('hidden', 'selectedRow', 1);

		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->addElement('hidden', 'error1', USERPARAMETERS_NAME_REQ_MSG);
		$this->m_form->addElement('hidden', 'bEditMode', '');
		
		$details = $this->m_session->value( SESSION_SET_USER_PARAMETERS_DETAILS );		
		
		$this->m_userId = $details['id'];		
		$this->m_userName = $details['name'];
		
		if(('Anonymous' == $this->m_userName) && (1 == $this->m_userId))
		{
			$this->m_isAnonymous = true;
		}
		else 
		{
			$this->m_dirName = $details['displayName'];	
		}
		
		$this->populateUserParametersArr();
	}

	function process()
	{
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$res = HSP_SUCCESS;		
			
			$formValuesArray = $this->m_form->exportValues();
			
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));			
			
			if ( "new" == $formValuesArray['buttonClicked'] )
			{
				$res = $this->onNew();
			}
			elseif ("edit" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onEdit($selectedRow);
			}
			elseif ( "delete" == $formValuesArray['buttonClicked'] )
			{	
				if($this->onDelete($selectedRow) == HSP_SUCCESS)
				{
					parent::CriaLog(USERPARAMETERS_DELETE_BTN);
				}
				
			}
			
			if(HSP_SUCCESS != $res)
			{
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);				
			}
			else
			{
				// we call populate on success in order to reflect the new state
				$this->populateUserParametersArr();
			}
		}
	}
	
	function finalize()
	{
		$anonymous = "true";
		$userDetails = USERPARAMETERS_PARAMETERS_TITLE.$this->m_userName;

		if(false === $this->m_isAnonymous)
		{
			$userDetails = $userDetails.'@'.$this->m_dirName;
			$anonymous = "false";
		}
		$arrVars = array(	"tblParams"=>$this->generateTable(),					        					        
					        "moduleName"=>$this->m_moduleName,
					        'editMode'=> $this->m_bEditMode,
					        'userParametersForm_required_note'=>USERPARAMETERS_REQUIRED_TXT,
					        'userdetails'=>$userDetails,
							'roll'=>$_SESSION['roll'],
					        'lblNew'=>rawurlencode(USERPARAMETERS_NEW_PARAMETER),
					        'lblEdit'=>rawurlencode(USERPARAMETERS_EDIT_PARAMETER),
					        'anonymous'=>$anonymous);
					        
		parent::finalize( $arrVars , 'userParameters' );
	}
	
	function getSelectedDirIndex()
	{
		foreach ( $this->m_userParametersArr as $index=>$parameter )
		{
			if ( $parameter['name'] == $this->m_editParameter[0]['name'] )
			{
				return $index+1;
			}
		}
		
		return 1; // we never get here.
	}
	
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tblParams" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(USERPARAMETERS_NAME_LBL , USERPARAMETERS_VALUE_LBL);
		$headerAttribArr = array("class='TableHeader' width=200px","class='TableHeader' width=200px");
		$tblBackups->addRow($headerArr , $headerAttribArr );
		
		foreach ( $this->m_userParametersArr as $key=>$dirRow )
		{
			$rownum = $key + 1 ;
			
			$shortName = $dirRow['paramName'];
			
			if ( strlen($shortName) > 23 )
			{
				$shortName = substr($dirRow['paramName'], 0, 23) . '...';
			}
			
			$shortValue = $dirRow['paramValue'];
			
			if ( strlen($shortValue) > 47 )
			{
				$shortValue = substr($dirRow['paramValue'], 0, 47) . '...';
			}			
			
			//$shortName = htmlspecialchars($shortName);
			$row = array ( $shortName , $shortValue );			
			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
		
			$name = $dirRow['paramName'];
			$value = $dirRow['paramValue'];
			$attib = array("class='DataCell' title='$name'","class='DataCell' title='$value'");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}
		
		return $tblBackups->toHtml();
	}
	
	function populateUserParametersArr()
	{
		$this->m_userParametersArr = $this->m_db->GetAllEx("SELECT * FROM ". TABLE_USER_PARAMETER . " WHERE userId=$this->m_userId;", null, DB_FETCHMODE_ASSOC);
		
 		$this->sortDirArr();
	}
	
	//sort the directory list by name
	function sortDirArr()
	{
		$tmpArr = array();
		foreach($this->m_userParametersArr as $parameter)
		{
			$tmpArr[] = $parameter['paramName'];
		}
		
		natcasesort($tmpArr);
		
		$newArray = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $this->m_userParametersArr as $parameter )
			{
				if ($name == $parameter['paramName'] )
				{
					$newArray[] = $parameter;
					break;
				}
			}			
		}
		
		$this->m_userParametersArr = $newArray;
	}
	
	function onNew()
	{	
		$name = htmlspecialchars($this->m_form->exportValue('paramName'));
		$name = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $name);
		$value = htmlspecialchars($this->m_form->exportValue('paramValue'));		
		
		$fields_values = array(	'userId'=>$this->m_userId,
								'paramName'=>$name ,
								'paramValue'=>$value );
		
		$sql = "SELECT COUNT(paramName) FROM " . TABLE_USER_PARAMETER ." WHERE paramName=\"$name\" AND userId=$this->m_userId;";
		
		$this->m_db->GetOne($sql, $count);
		if ( DB::isError($count) )
		{
			return HSP_ERR_DB_ERROR;
		}
		if (!$count)
		{
			$ret = $this->m_db->AutoExecute( TABLE_USER_PARAMETER, $fields_values );
			
			if ( DB::isError($ret) )
			{
				return HSP_ERR_DB_ERROR;
			}
		}
		else
		{
			return HSP_ERR_USER_PARAM_ALREADY_DEFINED;
		}

		$this->sortDirArr();
		parent::CriaLog(USERPARAMETERS_NEW_BTN);
		return HSP_SUCCESS;
	}
	
	function onEdit($selectedRow)
	{
		$name = htmlspecialchars($this->m_form->exportValue('paramName'));
		$value = htmlspecialchars($this->m_form->exportValue('paramValue'));		
		$oldName = $this->m_userParametersArr[$selectedRow-1]['paramName'];
		$this->m_userParametersArr[$selectedRow-1]['name'] = $name;
		
		$fields_values = array(	'userId'=>$this->m_userId,
								'paramName'=>$name ,
								'paramValue'=>$value );

		$count = 0;
		if ( $oldName != $name )
		{
			$sql = "SELECT COUNT(paramName) FROM " . TABLE_USER_PARAMETER ." WHERE paramName=\"$name\" AND userId=$this->m_userId;";
		
			$this->m_db->GetOne($sql, $count);
			if ( DB::isError($count) )
			{
				return HSP_ERR_DB_ERROR;
			}
		}
		
		if (!$count)
		{	
			$ret = $this->m_db->AutoExecute( TABLE_USER_PARAMETER, $fields_values, DB_AUTOQUERY_UPDATE,"userId=$this->m_userId AND paramName=\"$oldName\";" );
		
			if ( DB::isError($ret) )
			{
				return HSP_ERR_DB_ERROR;
			}
		}
		else
		{
			return HSP_ERR_USER_PARAM_ALREADY_DEFINED;
		}
				
		$this->sortDirArr();
		parent::CriaLog(USERPARAMETERS_EDIT_BTN);
		return HSP_SUCCESS;
	}
	
	function onManageUsersGroups($selectedRow)
	{
		$dirId = $this->m_userParametersArr[$selectedRow-1]['id'];		
		Header("Location: admin.php?module=editCustomDir&dirId=$dirId&roll=".$_POST['roll']);
		exit();
	}

	function onDelete($selectedRow)
	{
		$retVal = HSP_SUCCESS;
		$name = $this->m_userParametersArr[$selectedRow-1]['paramName'];
		
		$sql = "DELETE FROM ".TABLE_USER_PARAMETER . " WHERE paramName=\"$name\" AND userId=$this->m_userId;";
		
		$ret = $this->m_db->Query($sql);
		if ( !DB::isError($ret) )
		{
			unset($this->m_userParametersArr[$selectedRow - 1]);
		}
		else
		{
			$retVal = HSP_ERR_DB_SQL_ERROR;
		}
		
		return $retVal;
	}
}
?>