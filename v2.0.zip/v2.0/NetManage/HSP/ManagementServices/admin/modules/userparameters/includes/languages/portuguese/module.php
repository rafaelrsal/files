<?PHP
define('USERPARAMETERS_NEW_BTN','Novo');
define('USERPARAMETERS_EDIT_BTN','Editar');
define('USERPARAMETERS_BACK_BTN','< Voltar');

define('USERPARAMETERS_DELETE_BTN','Remover');
define('USERPARAMETERS_SAVE_BTN','Salvar');
define('USERPARAMETERS_CANCEL_BTN','Cancelar');

define('USERPARAMETERS_NAME_LBL','Nome do Par�metro');
define('USERPARAMETERS_VALUE_LBL','Valor do Par�metro');

define('USERPARAMETERS_NAME_REQ_MSG','Informe o nome do par�metro.');
define('USERPARAMETERS_REQUIRED_TXT','verifique os campos obrigat�rios');
define('USERPARAMETERS_PARAMETERS_TITLE','Par�metros do Usu�rio - ');

define('USERPARAMETERS_NEW_PARAMETER','Novo par�metro');
define('USERPARAMETERS_EDIT_PARAMETER','Editar par�metro');

?>