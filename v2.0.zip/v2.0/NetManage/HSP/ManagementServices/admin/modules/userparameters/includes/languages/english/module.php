<?PHP
define('USERPARAMETERS_NEW_BTN','New');
define('USERPARAMETERS_EDIT_BTN','Edit');
define('USERPARAMETERS_BACK_BTN','< Back');

define('USERPARAMETERS_DELETE_BTN','Delete');
define('USERPARAMETERS_SAVE_BTN','Save');
define('USERPARAMETERS_CANCEL_BTN','Cancel');

define('USERPARAMETERS_NAME_LBL','Parameter name');
define('USERPARAMETERS_VALUE_LBL','Parameter value');

define('USERPARAMETERS_NAME_REQ_MSG','Enter parameter name.');
define('USERPARAMETERS_REQUIRED_TXT','denotes required field');
define('USERPARAMETERS_PARAMETERS_TITLE','User Parameters - ');

define('USERPARAMETERS_NEW_PARAMETER','New parameter');
define('USERPARAMETERS_EDIT_PARAMETER','Edit parameter');

?>