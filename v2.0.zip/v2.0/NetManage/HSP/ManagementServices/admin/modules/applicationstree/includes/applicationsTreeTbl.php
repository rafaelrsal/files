<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created:     Mars 2004

  Title: applicationsTreeTbl.php
  Purpose: Controlling all DB connectivity for the applicationsTree module.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
class applicationsTreeTbl
{
	var $m_pearDB;
	
	function applicationsTreeTbl($peardb)	
	{
		$this->m_pearDB = $peardb;
		$this->m_pearDB->connect();
	}

	function getDB()
	{
		return $this->m_pearDB;
	}
	
	function GetRowForField($tablename, $fieldname, $value, &$arrRes)
	{
		return $this->m_pearDB->GetRowForField($tablename, $fieldname, $value, $arrRes);
	}
	
	function updateGatUat($id, $name, $arrParams)
	{
		return $this->m_pearDB->AutoExecute(TABLE_GAT_UAT, $arrParams, DB_AUTOQUERY_UPDATE,'id='.$id.' AND name="'.$name.'";');		
	}

	function remove($tableName, $idName, $idVal)
	{
		$sql = "DELETE FROM ".$tableName. " WHERE $idName=$idVal;";
		$ret = $this->m_pearDB->Query($sql);
		if (HSP_ERR_DB_SQL_ERROR != $ret)
			return HSP_SUCCESS;
		return $ret;
	}
	
	function GetAllEx($query)
	{
		return $this->m_pearDB->GetAllEx($query);
	}

	function removeGatUat($id, $name)
	{
		$sql = "DELETE FROM ".TABLE_GAT_UAT. " WHERE id=$id AND name=\"$name\";";
		$ret = $this->m_pearDB->Query($sql);
		if (HSP_ERR_DB_SQL_ERROR != $ret)
			return HSP_SUCCESS;
		return $ret;
	}

	function updateOrder($id, $order)
	{
		

		$sql = "UPDATE hsp_tree SET orderfield=$order WHERE id = $id;";
		$ret = $this->m_pearDB->Query($sql);
		
		if (HSP_ERR_DB_SQL_ERROR == $ret)
		{
			return ret;
		}
	}

	function updateStatus($id, $status)
	{
		$sql = "UPDATE hsp_tree SET status=$status WHERE id = $id;";
		$ret = $this->m_pearDB->Query($sql);
		
		if (HSP_ERR_DB_SQL_ERROR == $ret)
		{
			return ret;
		}
	}	

}
?>