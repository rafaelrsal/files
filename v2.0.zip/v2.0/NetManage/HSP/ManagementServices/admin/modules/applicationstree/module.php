<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: module.php
  Purpose: applicationsTree module - building/editing the HSP tree of applications.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
?>

<script language="JavaScript" type="text/javascript">
<!--
<?php include ("includes/LMenu/libjs/layersmenu-browser_detection.js"); ?>
// -->
</script>
<script language="JavaScript" type="text/javascript" src="includes/LMenu/libjs/layerstreemenu-cookies.js"></script>
<?PHP
require_once('HTML/QuickForm.php');

include_once ("includes/LMenu/lib/PHPLIB.php");
include_once ("includes/LMenu/lib/layersmenu-common.inc.php");
include_once ("includes/LMenu/lib/treemenu.inc.php");
require_once ("includes/classes/LMenu.php");

require_once('admin/modules/applicationsTree/includes/applicationsTreeTbl.php');

// For Copy/Cut/Paste needs:
require_once('admin/modules/applicationsData/module.php');
require_once('admin/modules/applicationsURL/module.php');
require_once('admin/modules/applicationsOnWeb/module.php');
require_once('admin/modules/applicationsW2H/module.php');

class applicationsTree extends ModuleBase
{
	var $m_appTreeTbl;
	var $m_showPasteBtn;
	
	function applicationsTree($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		$this->m_showPasteBtn = false;
		

		$db  = &parent::GetDatabase();
		$this->m_appTreeTbl = new applicationsTreeTbl($db);
		
		$this->m_session->remove(SESSION_MESSAGES);

	}
	
	function init()
	{
		parent::init("applicationsTree");

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm("applicationsTreeForm"); //default is post
		
		$this->m_form->addElement('text', 'name',  APPSTREE_NAME_LBL, array('size' => 20, 'maxlength' => 255));
		$this->m_form->addElement('text', 'icon', APPSTREE_ICON_LBL);
		$this->m_form->addElement('text', 'description', APPSTREE_DESC_LBL);
		$this->m_form->addElement('text', 'apptype', APPSTREE_APP_TYPE_LBL);
		$this->m_form->addElement('text', 'platform', APPSTREE_PLATFORM_LBL);

		// for print preview. see print.php
		$_SESSION['print_preview_header'] = APPSTREE_MAIN_TXT;
		$this->m_form->addElement('header', 'header', APPSTREE_MAIN_TXT);
		$this->m_form->addElement('text', 'header2',APPSTREE_HEADER_DETAILS_TXT);
		
		$this->m_form->addElement('submit', 'new', APPSTREE_NEW_BTN,"onclick = onNewOrEdit('new'); class='NewButton'");
		$this->m_form->addElement('submit', 'edit', APPSTREE_EDIT_BTN,"onclick = onNewOrEdit('edit'); class='NewButton'");
		$this->m_form->addElement('button', 'delete', APPSTREE_DELETE_BTN, 'onclick = clearFields() class="NewButton"');
		$this->m_form->addElement('hidden', 'button_clicked', "none");
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);

		// Sort management
		$this->m_form->addElement('radio', 'sort_range', null, APPSTREE_SORT_ONE_LEVEL_RDO, 0); 
		$this->m_form->addElement('radio', 'sort_range', null, APPSTREE_SORT_SUBTREE_RDO, 1); 
		$this->m_form->addElement('submit', 'ok', APPSTREE_OK_BTN,"onclick=onPopupOK() class='NewButton'");
		$this->m_form->addElement('text', 'sort_lbl',APPSTREE_SET_LBL);
		$this->m_form->addElement('submit', 'save', APPSTREE_SAVE_BTN,"onclick=onPopupSave() class='NewButton'");
		$this->m_form->addElement('button', 'cancel', APPSTREE_CANCEL_BTN,"onclick=onPopupCancel() class='NewButton'");
		////

		// Present the data of a node as read only:
		$temp = &$this->m_form->getElement("name");
		$temp->freeze();
		$temp = &$this->m_form->getElement("icon");
		$temp->freeze();
		$temp = &$this->m_form->getElement("description");
		$temp->freeze();
		$temp = &$this->m_form->getElement("apptype");
		$temp->freeze();
		$temp = &$this->m_form->getElement("platform");
		$temp->freeze();
		
	}
	
	function process()
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		
		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$tmpNodeID = $this->m_session->value(SESSION_NODE_ID);
			if(false == $tmpNodeID)	
			{
				$tmpNodeID = "2";	
			}
			
			if(isset($_GET['origin']))
			{
				// Clear optional garabage:
				$this->m_session->remove(SESSION_PREV_MODULE);
				$this->m_session->remove(SESSION_NODE_ID);
				$this->m_session->remove(SESSION_NODE_TO_COPY);
				$this->m_session->remove(SESSION_NODE_TO_CUT);
				$tmpNodeID = "2";	
				$res = HSP_SUCCESS;
			}
			elseif('applicationsTree' == $this->m_session->value(SESSION_PREV_MODULE))
			{
				// Coming from a post-delete action (the page calls itself after delete):
				$this->m_session->remove(SESSION_PREV_MODULE);
				$res = HSP_SUCCESS;
			}
			else
			{
				// make sure the list is empty in case you come from appAssoc tree!
				$this->m_session->remove(SESSION_SELECTED_NODES_LIST);
				// Get the current selected nodeID, and put it in the global session var.
				// Will be used after validation in order to know where to insert
				// the new node!
				//$tmpNodeID = 2;
				if (isset($_GET['nodeID']))
				{
					$nodeToDealWith = 0;
					// The user clicked a node in the tree.
					$this->m_session->remove(SESSION_NODE_ID);
					$tmpNodeID = $_GET['nodeID'];
					$this->m_session->set(SESSION_NODE_ID, $tmpNodeID);
					
					// If it is part of copy/paste request, we need to see if we can paste to
					// this selected node:
					if($this->m_session->exists(SESSION_NODE_TO_CUT))
					{
						$this->m_session->remove(SESSION_NODE_TO_COPY);
						$nodeToDealWith = $this->m_session->value(SESSION_NODE_TO_CUT);
					}
					elseif($this->m_session->exists(SESSION_NODE_TO_COPY))
					{
						$this->m_session->remove(SESSION_NODE_TO_CUT);
						$nodeToDealWith = $this->m_session->value(SESSION_NODE_TO_COPY);
					}

					if(0 != $nodeToDealWith)
					{
						// We are in copy/cut. Check a few rules:
						if($tmpNodeID != $nodeToDealWith) // The detination node cannot be the source node.
						{
							$res = $this->validateNodeName($nodeToDealWith, $tmpNodeID);// Make sure the name of the node to cut/copy does not already exist.

							if(HSP_SUCCESS == $res)
							{
								if(null != $this->prepareRequest($tmpNodeID, $nodeToDealWith)) // the destination cannot be a son of the source
								{
									// Everything is OK. Enable the paste button
									$this->m_showPasteBtn = true;	
								}
							}
						}
					}

					if(isset($_GET['treeIndex']))
					{
						$treeIndex = $_GET['treeIndex'];
					}
					
					$res = HSP_SUCCESS;
				}
				else
				{
					$res = HSP_SUCCESS;
										
					if(('applicationsData' == $this->m_session->value(SESSION_PREV_MODULE)) ||
					   ('applicationsURL' == $this->m_session->value(SESSION_PREV_MODULE)) ||
					   ('applicationsW2H' == $this->m_session->value(SESSION_PREV_MODULE)) ||
					   ('applicationsOnWeb' == $this->m_session->value(SESSION_PREV_MODULE)))
					{
						if (isset($_GET['clicked']))
						{
							// "finish" was clicked.
							// Get the node's parent ID, in order to mark the father as the selected node:
							$res = $this->m_appTreeTbl->GetRowForField(TABLE_TREE, 'id', $tmpNodeID, $arrTreeRes);
							if(HSP_SUCCESS == $res)
							{
								$this->m_session->set(SESSION_NODE_ID, $arrTreeRes[1]);
								$tmpNodeID = $arrTreeRes[1];
							}
						}
					}
				}
			}

			if((1 != $tmpNodeID) && $res == HSP_SUCCESS)
			{
				// Prepare the data of the node for presentation and next modules:
				$res= $this->getNodeData($tmpNodeID);
			}
			
		}
		else
		{
			////////////// POST /////////////////
			
			////////////// NEW /////////////////
			if(((isset($_POST['button_clicked'])) && ($_POST['button_clicked'] == "new")))
			{
				if(false == $this->m_session->exists(SESSION_NODE_ID))
				{
					// The user asked to add a node under the base or clicked add with no selection.
					// This new node must be added under the base:
					$baseID = 2;
					$this->m_session->set(SESSION_NODE_ID, $baseID);
				}
				$this->m_session->remove(SESSION_APP_MOBILE);
				$this->m_session->remove(SESSION_NODE_APPTYPE);
				$this->m_session->remove(SESSION_NODE_NAME);

				// Cancel any previous copy/cut request:
				$this->m_session->remove(SESSION_NODE_TO_COPY);
				$this->m_session->remove(SESSION_NODE_TO_CUT);
				
				$new = 'new';
				// Let us know that this is a new entry:
				$this->m_session->set(SESSION_NEW_NODE, $new);
	
				// Let the next screen know who called it:
				$module = 'applicationsTree';
				$this->m_session->set(SESSION_PREV_MODULE, $module);
				Header('Location: admin.php?module=applicationsData&roll='.$_POST['roll']);
				exit();
			}
			
			/////////  EDIT ///////////
			if(((isset($_POST['button_clicked'])) && ($_POST['button_clicked'] == "edit")) )
			{
				// USER CLICKED THE EDIT BUTTON //

				// Cancel any previous copy/cut request:
				$this->m_session->remove(SESSION_NODE_TO_COPY);
				$this->m_session->remove(SESSION_NODE_TO_CUT);
				
				// If no session ID selected then cannot preform action - return error:
				if($this->m_session->exists(SESSION_NODE_ID))
				{
					// get all the POST values, insert to session params:
					$name = htmlspecialchars($this->m_form->exportValue('name'));
					$name = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $name);
					$this->m_session->set(SESSION_NODE_NAME, $name);

					$icon= htmlspecialchars($this->m_form->exportValue('icon'));
					$this->m_session->set(SESSION_NODE_ICON, $icon);

					$description = htmlspecialchars($this->m_form->exportValue('description'));
					$description = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $description);
					$this->m_session->set(SESSION_NODE_DESC, $description);

					$appType = htmlspecialchars($this->m_form->exportValue('apptype'));
					if(APPSTREE_EMPTY_APP_TYPE_TXT == $appType)
						// This has no type, leave the type field empty:
						$appType = "";
						// this is ugly but.... ask mickey...
					$applicationType = '';
					
					if ($appType == APPSTREE_LINK_TXT) 
					{
						$applicationType = 'url';
					}
					elseif ($appType == APPSTREE_W2H_TXT)
					{
						$applicationType = 'w2h';
					}
					elseif ($appType == APPSTREE_ONWEB_TXT)
					{
						$applicationType = 'onWeb';
					}
					elseif ($appType == APPSTREE_PROTECTED_LINK_TXT)
					{
						$applicationType = 'url';
						$this->m_session->set(SESSION_LINK_PROTECTED, "protected");
					}
					
					$this->m_session->set(SESSION_NODE_APPTYPE, $applicationType);

					// Goto the applicationData module and edit the node:
					$edit = 'edit';
					// Let us know that this is a new entry:
					$this->m_session->set(SESSION_NEW_NODE, $edit);
					// Let the next screen know where to go back to:
					$module = 'applicationsTree';
					$this->m_session->set(SESSION_PREV_MODULE, $module);
					Header('Location: admin.php?module=applicationsData&roll='.$_POST['roll']);
					exit();
				}
				else
					$res = HSP_ERR_MISSING_NODE_SELECTION;
			}
			elseif((isset($_POST['button_clicked'])) && ("cut" == $_POST['button_clicked']))
			{
				/////////// cut ///////////
				if($this->m_session->exists(SESSION_NODE_ID))
				{
					$this->m_session->remove(SESSION_NODE_TO_COPY);
					$nodeID = $this->m_session->value(SESSION_NODE_ID);
					$this->m_session->set(SESSION_NODE_TO_CUT, $nodeID);					
					$res = HSP_SUCCESS;
				}
				else
				{
					$res = HSP_ERR_MISSING_NODE_SELECTION;
				}
			}
			elseif((isset($_POST['button_clicked'])) && ("copy" == $_POST['button_clicked']))
			{
				/////////// copy ///////////
				if($this->m_session->exists(SESSION_NODE_ID))
				{
					$this->m_session->remove(SESSION_NODE_TO_CUT);
					$nodeID = $this->m_session->value(SESSION_NODE_ID);
					$this->m_session->set(SESSION_NODE_TO_COPY, $nodeID);					
					$res = HSP_SUCCESS;
				}
				else
				{
					$res = HSP_ERR_MISSING_NODE_SELECTION;
				}

			}
			elseif((isset($_POST['button_clicked'])) && ("paste" == $_POST['button_clicked']))
			{
				if($this->m_session->exists(SESSION_NODE_ID))
				{
					$nodeID = $this->m_session->value(SESSION_NODE_ID);

					if($this->m_session->exists(SESSION_NODE_TO_CUT))
					{
						$this->m_session->remove(SESSION_NODE_TO_COPY);
						$nodeToCut = $this->m_session->value(SESSION_NODE_TO_CUT);
						
						$res = $this->cut($nodeID, $nodeToCut);
						// Allow only one cut action:
						$this->m_session->remove(SESSION_NODE_TO_CUT);
					}
					if($this->m_session->exists(SESSION_NODE_TO_COPY))
					{
						$this->m_session->remove(SESSION_NODE_TO_CUT);
						$nodeToCopy = $this->m_session->value(SESSION_NODE_TO_COPY);

						$res = $this->copy($nodeID, $nodeToCopy);
					}
				}	
				else
				{
					$res = HSP_ERR_MISSING_NODE_SELECTION;
				}
			}
			elseif((isset($_POST['button_clicked'])) && ($_POST['button_clicked'] == "sort_asc_main"))			
			{
				// Cancel any previous copy/cut request:
				$this->m_session->remove(SESSION_NODE_TO_COPY);
				$this->m_session->remove(SESSION_NODE_TO_CUT);

				if((isset($_POST['sort_range'])) && ($_POST['sort_range'] == "0"))
				{
					// Sort one level - only direct subordinats:
					$res = $this->setSortOrder();
				}
				else
				{
					// Sort the whole subtree
					$rootID = $this->m_session->value(SESSION_NODE_ID);
					$res = $this->setSortOrderRecursive($rootID);
				}
			}
			elseif((isset($_POST['button_clicked'])) && ($_POST['button_clicked'] == "sort_desc_main"))
			{
				// Cancel any previous copy/cut request:
				$this->m_session->remove(SESSION_NODE_TO_COPY);
				$this->m_session->remove(SESSION_NODE_TO_CUT);
				
				if((isset($_POST['sort_range'])) && ($_POST['sort_range'] == "0"))
				{
					// Sort one level - only direct subordinats:
					$res = $this->setSortOrder(false);
				}
				else
				{
					// Sort the whole subtree
					$rootID = $this->m_session->value(SESSION_NODE_ID);
					$res = $this->setSortOrderRecursive($rootID, false);
				}
			}
			elseif((isset($_POST['button_clicked'])) && ($_POST['button_clicked'] == "save"))
			{
				// Cancel any previous copy/cut request:
				$this->m_session->remove(SESSION_NODE_TO_COPY);
				$this->m_session->remove(SESSION_NODE_TO_CUT);
				$parentID = $this->m_session->value(SESSION_NODE_ID);
				
				// Reorder the sub nodes:
				if(isset($_POST['order']))
				{
					$newOrderList =$_POST['order'];
					for ($index = 0; $index < count($newOrderList); ++$index)								
					{
						$newOrderListTmp = $newOrderList[$index];
						$theQuery = "SELECT id FROM hsp_tree WHERE parent_id=$parentID AND text=\"$newOrderListTmp\";";
						$resArr = $this->m_appTreeTbl->GetAllEx($theQuery);
						
						if(is_array($resArr) && count($resArr)>0)
						{
							$res = $this->m_appTreeTbl->updateOrder($resArr[0][0], $index+1);
						}
						else
						{
							// DB error:
							$res = $resArr;
						}
					}
				}
				else
				{
					// Probably empty list:
					$res = HSP_SUCCESS;
				}
			}			
			elseif((isset($_POST['button_clicked'])) && ($_POST['button_clicked'] == "delete"))
			{
				// USER CLICKED THE DELETE BUTTON //
				/////////////////   DELETE ///////////

				// Cancel any previous copy/cut request:
				$this->m_session->remove(SESSION_NODE_TO_COPY);
				$this->m_session->remove(SESSION_NODE_TO_CUT);
				
				if($this->m_session->exists(SESSION_NODE_ID))
				{
					$arrTreeRes = null;
					$nodeID = $this->m_session->value(SESSION_NODE_ID);

					// Get the node's parent ID, in order to mark the father as the selected node, when the node
					// itself is already gone to hell:
					$res = $this->m_appTreeTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);
					if(HSP_SUCCESS == $res)
					{
						// Call a recursive function to delete all the sub-tree:
						$res = $this->removeNode($this->m_session->value(SESSION_NODE_ID));
						if(HSP_SUCCESS == $res)
						{	// The node was removed, ignore it's marking in session:
							$this->m_session->remove(SESSION_NODE_ID);
							if(1 < $arrTreeRes[1])
							{
								$parentID = $arrTreeRes[1];
								// If all the father sons left home he needs to know his alone - a "leaf":
								$query = "SELECT id FROM hsp_tree WHERE parent_id=$parentID";
								$resArr = $this->m_appTreeTbl->GetAllEx($query);
								if(is_array($resArr))
								{
									if(0 == count($resArr))
									{
										// Update the status:
										$res = $this->m_appTreeTbl->updateStatus($parentID, "0");
									}
								}
								
								if(HSP_SUCCESS == $res)
								{
									// Navigate to the same page with the 'father' of the laready 
									// deleted node, so the "father" is selected with it's details
									// in the right pane:
									$this->m_session->set(SESSION_NODE_ID, $arrTreeRes[1]);
									$this->m_session->set(SESSION_PREV_MODULE, $this->m_moduleName);
									parent::CriaLog(APPSTREE_DELETE_BTN);
									Header('Location: admin.php?module=applicationsTree&roll='.$_POST['roll']);
									exit();								
								}
					         }
				        }
					}
				}
				else
					// We cannot delete a node without the user selecting it first!
					$res = HSP_ERR_MISSING_NODE_SELECTION;
			}
		}

		// Get the "sons" of the node for order requests:
		$theNodeID = $this->m_session->value(SESSION_NODE_ID);
		if(false == $theNodeID)
		{
			// Default is the top-level
			$theNodeID = 2;
		}
		
		$sonsList = array();
		$index = 0;
		$theQuery = "SELECT orderfield,text FROM hsp_tree WHERE parent_id=$theNodeID ORDER BY orderfield;";
		$resArr = $this->m_appTreeTbl->GetAllEx($theQuery);
		foreach ($resArr as $key=>$val)
		{
			$sonsList[$index] = $val[1];
			++$index;
		}
		$this->m_form->addElement('select', 'order', APPSTREE_SLCT_LBL, $sonsList,'multiple size=12 style="width:150"id="order" onmousewheel="mousewheel(this);" onkeypress="DoDefaultEnterKey(event);"');

		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}
	
	function finalize()
	{
		$arrVars = array();

		// Build the menu:
		$treeView = new TreeMenu();
		$treeView->setImgwww("includes/LMenu/images/"); // allowing different icons.
		$treeView->setImgdir("includes/LMenu/images/");
		$treeView->setLibjsdir("includes/LMenu/libjs/");
		$db = $this->m_appTreeTbl->getDB(); 
		$treeView->setDBConnParms($db->getDSNasString());
		$treeView->setTableName(TABLE_TREE);
		
		// Decide which node to mark if at all:
		$nodeToMark = $this->m_session->value(SESSION_NODE_ID);
		if((2 == $nodeToMark) || (false == $nodeToMark))
		{
			$nodeToMark = 2;
			$this->m_session->set(SESSION_NODE_ID, $nodeToMark);

			$arrVars['delete_disabled'] = "true";
			$arrVars['edit_disabled'] = "true";
			$arrVars['cut_disabled'] = "true";
			$arrVars['copy_disabled'] = "true";
			$arrVars['cut_icon'] = "cut_disabled.gif";
			$arrVars['copy_icon'] = "copy_disabled.gif";
			
		}
		else
		{
			$arrVars['delete_disabled'] = "false";
			$arrVars['edit_disabled'] = "false";
			$arrVars['cut_disabled'] = "false";
			$arrVars['copy_disabled'] = "false";
			$arrVars['cut_icon'] = "cut.gif";
			$arrVars['copy_icon'] = "copy.gif";
		}
		
		if($this->m_showPasteBtn == true)
		{
			// Allow multipule copy actions:
			$arrVars['paste_disabled'] = "false";
			$arrVars['paste_icon'] = "paste.gif";			
		}
		else
		{
			$arrVars['paste_disabled'] = "true";
			$arrVars['paste_icon'] = "paste_disabled.gif";						
		}
		
		if($this->isNodeLeaf($nodeToMark))
		{
			// Don't allow sorting on a leaf:
			$arrVars['sort_asc_disabled'] = "true";
			$arrVars['sort_desc_disabled'] = "true";
			$arrVars['sort_cust_disabled'] = "true";
			$arrVars['sort_asc_icon'] = "sort_asc_disabled.gif";
			$arrVars['sort_desc_icon'] = "sort_desc_disabled.gif";
			$arrVars['sort_cust_icon'] = "cust_sort_disabled.gif";
			
		}
		else
		{
			// Allow sortin gon non-leaf nodes:
			$arrVars['sort_asc_disabled'] = "false";
			$arrVars['sort_desc_disabled'] = "false";
			$arrVars['sort_cust_disabled'] = "false";
			$arrVars['sort_asc_icon'] = "sort_asc.gif";
			$arrVars['sort_desc_icon'] = "sort_desc.gif";
			$arrVars['sort_cust_icon'] = "custom_sort.gif";
		}

		$arrVars['sort_asc_title'] = APPSTREE_SORT_ASC_BTN;
		$arrVars['sort_desc_title'] = APPSTREE_SORT_DESC_BTN;
		$arrVars['sort_custom_title'] = APPSTREE_SORT_CUSTOM_BTN;
		$arrVars['up_title'] = APPSTREE_UP_BTN;
		$arrVars['down_title'] = APPSTREE_DOWN_BTN;
		$arrVars['top_title'] = APPSTREE_TOP_BTN;
		$arrVars['bottom_title'] = APPSTREE_BOTTOM_BTN;
		$arrVars['cut_title'] = APPSTREE_CUT_BTN;
		$arrVars['copy_title'] = APPSTREE_COPY_BTN;
		$arrVars['paste_title'] = APPSTREE_PASTE_BTN;
		$arrVars['preview_title'] = APPSTREE_PREVIEW_BTN;
		$arrVars['roll'] = $_SESSION['roll'];

		// Prepare for preview purposes:
		$res = $this->prepareSubTreeFile();
		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
		
		// NOTICE - the selected node is to be emphasized.
		// In order to do so a file in the original LMENU code
		// which was not written by NM  was modified -
		// ..\LMEMU\lib\layersmenu-common.inc.php, function name scanTableForMenu() -- (mhoter)
		$treeView->scanTableForMenu("HSPTree1", "" , "", $nodeToMark);

		$arrVars['strMesg'] = APPSTREE_CONFIRM_MSG;
		$arrVars['appsTree'] = $treeView->newTreeMenu_Original("HSPTree1", $nodeToMark, $treeNodePosition);
		$arrVars["setupdated"] = "false";
		$arrVars["moduleName"] = $this->m_moduleName;
		$arrVars["lblSetOrder"] = APPSTREE_SET_TITLE;
		
		$arrVars["nodeToOrderName"] = $this->m_form->getElementValue('name');
		
		$arrVars["treeIndex"] = $treeNodePosition;
		
		parent::finalize($arrVars);
	}
	
	/**
	* A recursive function for removal of
	* @param int $nodeID the id of the selected node
	* @access public
	* @return error code
	*/
	function removeNode($nodeID, $cutAction = false)
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$arrRes = null;

		// Get all nodes of those who are the sons of the selected node:
		$arrSubNodes = $this->m_appTreeTbl->GetAllEx("SELECT id FROM ".TABLE_TREE." WHERE parent_id=$nodeID;");

		if(is_array($arrSubNodes))
		{
			foreach($arrSubNodes as $subNode)
			{
				// Delete recursively all sub nodes(and their applications:)
				$res = $this->removeNode($subNode[0], $cutAction);
				if(HSP_SUCCESS != $res)
					return $res;
			}
		}

		// Get the application type & ID in order to remove it from application list:
 		$res = $this->m_appTreeTbl->GetRowForField(	TABLE_TREE,"id", $nodeID, $arrRes);
		if(HSP_SUCCESS == $res)
		{
			if($cutAction == false)
			{
				// This is a Delete action, so we need to remove the apps.
				// (In a Cut action we don't want to remove the apps!)
				$appID = $arrRes[2];
				$appType = $arrRes[3];
	
				if('url' == $appType)
					// Remove the application from the application list:
					$res = $this->m_appTreeTbl->remove(TABLE_APPS_LINKS, "appID", $appID);
				elseif ('w2h' == $appType)
					// Remove the application from the application list:
					$res = $this->m_appTreeTbl->remove(TABLE_APPS_W2H, "appID", $appID);
				elseif ('onWeb' == $appType)
					// Remove the application from the application list:
					$res = $this->m_appTreeTbl->remove(TABLE_APPS_ONWEB, "appID", $appID);
				//elseif Rumba...
			}
			
			if(HSP_SUCCESS == $res)
			{
				// Remove it from the GAT/UAT tables:
				$res = $this->cleanGatUat($nodeID);
				if(HSP_SUCCESS == $res)
					// Now remove the node itself:
					$res = $this->m_appTreeTbl->remove(TABLE_TREE, "id", $nodeID);
			}
		}

		return $res;
	}

	/**
	* A e function for removal of a non relevant node from the GAT/UAT
	* @param int $nodeID the id of the selected node that was removed.
	* @access public
	* @return error code
	*/
 	function cleanGatUat($nodeID)
 	{
 		$res = HSP_SUCCESS;

 		$arrNodes = null;

		// Get all GATS/UATS
		$arrGATS = $this->m_appTreeTbl->GetAllEx("SELECT * FROM ".TABLE_GAT_UAT.";");
		foreach ($arrGATS as $gat)
		{
			$arrNodes = explode(",", $gat[2]);
			if(is_array($arrNodes))
			{
				foreach($arrNodes as $key=>$node)
				{
					if($node == $nodeID)
					{
						// delete the node from the list of nodes for this GAT:
						unset($arrNodes[$key]);
						// Reindex the array:
						$arrNodes = array_values($arrNodes) ;

						if(count($arrNodes)>0)
						{
							// Update the GAT itself, tha t a node was removed:
							$strNodes = implode(",", $arrNodes);
							$arrParms = array("nodeList"=>$strNodes);
							$res = $this->m_appTreeTbl->updateGatUat($gat[0], $gat[1], $arrParms);

							break;
						}
					}
				}

				if(empty($arrNodes))
				{
					// Then the GAT/UAT has no nodes at all, remove it:
					$res = $this->m_appTreeTbl->removeGatUat($gat[0], $gat[1]);
				}
			}
		}

		return $res;
 	}	

	/**
	* The method to get the a selected node data from the database
	* @param int $nodeID the id of the selected node
	* @access public
	* @return void
	*/
	function getNodeData($nodeID)
	{
		$arrTreeRes = null;

		// Get the id of the application:
		$res = $this->m_appTreeTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);
		if(HSP_SUCCESS != $res)
		{
			return $res;
		}
		
		$icon = $arrTreeRes[7];

		// If the icon file is the application default, there is no need to show it explicitly:
		if((W2H_ICON == $icon) || (ONWEB_ICON == $icon) || (LINK_ICON == $icon) || (PROTECTED_LINK_ICON == $icon))// do the same check for each application type
		{
			$icon = "default";
		}


		if((null == $arrTreeRes[3]) || ("" == $arrTreeRes[3]))
		{
			$arrTreeRes[3] = APPSTREE_APP_TYPE_TXT;
		}
		elseif ( $arrTreeRes[3] == 'w2h')
		{
			$arrTreeRes[3] = APPSTREE_W2H_TXT;
		}
		elseif ( $arrTreeRes[3] == 'onWeb')
		{
			$arrTreeRes[3] = APPSTREE_ONWEB_TXT;
		}
		elseif ( $arrTreeRes[3] == 'url')
		{
			// Check if this is a protected url
			$res = $this->m_appTreeTbl->GetRowForField(TABLE_APPS_LINKS, 'appID', $arrTreeRes[2], $arrAppRes);
			if(HSP_SUCCESS == $res)
			{
				if("0" == $arrAppRes[2])
				{
					// usuall link
					$arrTreeRes[3] = APPSTREE_LINK_TXT;
				}
				else
				{
					// protected:
					$arrTreeRes[3] =APPSTREE_PROTECTED_LINK_TXT;
				}
			}
			else
			{
				return $res;
			}
		}
		$platform = $arrTreeRes[13]?APPSTREE_MOBILE_LBL:APPSTREE_DESKTOP_LBL;
		
		$arrTreeRes[4] = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $arrTreeRes[4]);
		$arrTreeRes[6] = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $arrTreeRes[6]);
		$this->m_form->setDefaults(array('name'=>$arrTreeRes[4],
									'icon'=>$icon,
									'description'=>$arrTreeRes[6],
									'apptype' => $arrTreeRes[3],
									'platform' => $platform ));

		$this->m_session->set(SESSION_APP_BEHAVIOR, $arrTreeRes[12]);
		$this->m_session->set(SESSION_APP_MOBILE, $arrTreeRes[13]);
											
		return HSP_SUCCESS;
	}

	function prepareSubTreeFile($nodeList = null)
 	{

 		include_once("includes/LMenu/lib/layersmenu-process.inc.php");
 		$treeView = new ProcessLayersMenu();
 		$db = $this->m_appTreeTbl->getDB();
 		$treeView->setDBConnParms($db->getDSNasString());
 		$treeView->setTableName(TABLE_TREE);
			
		if((is_null($nodeList)) || (!is_array($nodeList)))
		{
			// Running preview from Application Tree. The user wants to see
			// the whole tree, so the selected node is 2 (the ID of the top level node):
			$nodeList = array("2");
		}

		// Scan table will take care that the href of each node points to nothing:
		$treeView->scanTableForMenu("stam1","","preview", $nodeList);
		$strFile = $treeView->getMenuStructure("stam1");

		// This file is used for testing preview purposes only:
		$fileName = "tree.preview";

		// Save file:
		$path = "data/apptrees/"; // TODO: the path should be a general define.

		if(file_exists($path.$fileName))
		{
			// Avoid php warnings:
			if(is_writable($path.$fileName) == false)
				return 	HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
		}

		// Running over the old file whether exists or not:
		$handle = @fopen($path.$fileName, "w");
		if($handle)
		{
			$res = fwrite($handle, $strFile);
			fclose($handle);
			if(false === $res)
			{
				return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
			}
			return HSP_SUCCESS;
		}

		return 	HSP_ERR_FILE_NOT_FOUND;
 	}

 	function copy($destNode, $nodeToCopy)
 	{
 		// First try to see if the operation is legal:
		if(null != ($arrSubTree = $this->prepareRequest($destNode, $nodeToCopy)))
		{
			// Now that we got the subtree, start copying:
			return $this->createSubTree($destNode, $nodeToCopy, $arrSubTree);
		}

		// The request failed the first test : the node selected as a desteny
		// is in the subtree to be copied - illigal:
		return HSP_ERR_ILLEGAL_OPERATION;
 	}

 	function cut($destNode, $nodeToCut)
 	{
 		$res = HSP_ERR_ILLEGAL_OPERATION;
 		$arrRes = null;

 		// Get the nodetoCut data:
 		$res = $this->m_appTreeTbl->GetRowForField(TABLE_TREE, 'id', $nodeToCut, $arrRes);	
 		if(HSP_SUCCESS == $res)		
 		{
 			$oldParentID = $arrRes[1];
			$db = $this->m_appTreeTbl->getDB();
			$db = new applicationsDataTbl($db);

			// Insert it under the destNode:
			$res = $db->insertToHSPTree($destNode, $arrRes[2], $arrRes[3], $arrRes[4], $arrRes[7], $arrRes[6], $arrRes[12], $arrRes[13]);
			if(HSP_SUCCESS == $res)
			{
				$newId = 0;
				// Get the id of the recently entered node:
				$res = $db->getMaxEntryID(TABLE_TREE, 'id', $arrRes);
				$newId = $arrRes[0];
				
				// Update the url(==href) field of the recently inserted node in hsp_tree:
				$paramArr = array("href" => "navigate($newId)");
				$res = $db->updateTree( $arrRes[0], $paramArr );
				if(HSP_SUCCESS == $res)
				{
					// Get all the sons of the nodeToCut:
					$arrSubNodes = $this->m_appTreeTbl->GetAllEx("SELECT id FROM ".TABLE_TREE." WHERE parent_id=$nodeToCut;");

					if(is_array($arrSubNodes))
					{
						// Assign the sons the new parent location:
						$paramArr = array("parent_id" => "$newId");
						foreach($arrSubNodes as $subNode)
						{
							$res = $db->updateTree( $subNode[0], $paramArr );
							if(HSP_SUCCESS != $res)
								return $res;
						}
						
						// Upadate the new father: u r no longer a leaf:
						$res = $this->m_appTreeTbl->updateStatus($destNode, "1");
						if(HSP_SUCCESS == $res)
						{
							// Remove the original subtree:
							$res = $this->removeNode($nodeToCut, true);
							if(HSP_SUCCESS == $res)
							{
								// If all the OLD father sons left home he needs to know his alone - a "leaf":
								$query = "SELECT id FROM hsp_tree WHERE parent_id=$oldParentID";
								$resArr = $this->m_appTreeTbl->GetAllEx($query);
								if(is_array($resArr))
								{
									if(0 == count($resArr))
									{
										// Update the status:
										$res = $this->m_appTreeTbl->updateStatus($oldParentID, "0");
									}
								}
					        }
						}
					}
					else
					{
						$res = HSP_ERR_DB_ERROR;
					}
				}		
	 		}
 		}
 		
 		return $res;
 	}
 	
 	function getSons($parentID, $arrAllTree, & $arrSubTree)
 	{ 
 		$node = new node();
 		
		foreach($arrAllTree as $treeEntry)
		{
			if($parentID == $treeEntry[0])
			{
				// Insert the node to the sub tree:
				$node->addNodeData($treeEntry);
			}
			elseif($parentID == $treeEntry[1])
			{
				$node->addSon($treeEntry[0]);
				
				// Recursive call:
				$this->getSons($treeEntry[0], $arrAllTree, $arrSubTree);
			}
		}
		
		// Insert the node to the subtree:
		$arrSubTree[$node->getNodeID()] = $node;
 	}
 	
 	function prepareRequest($destNode, $nodeToCopy)
 	{
		$arrAllTree = null;
 		$arrSubTree = array();
 		
 		$query = "SELECT * FROM hsp_tree";
 		
 		// Get all rows for table hsp_tree:
 		$arrAllTree = $this->m_appTreeTbl->GetAllEx($query);
 		
		if(is_array($arrAllTree))
		{
			//OPTIONAL QUERY ?? --> SELECT * FROM `hsp_tree` CONNECT BY PRIOR `parent_id`=`id` START WITH `id`=$nodeToCopy
			$this->getSons($nodeToCopy, $arrAllTree, $arrSubTree);
			
			if(HSP_SUCCESS == ($res = $this->validateRequest($arrSubTree, $destNode)))
			{
				return $arrSubTree;
			}
			
			return null;
		}
  		
 	}
 	function validateRequest($arrSubTree, $destNode)
 	{
 		// Make sure you can paste to the destNode. If it is a node in the subtree, than
 		// the operation is illigal:
 		
 		foreach ($arrSubTree as $key => $value)
 		{
 			if($destNode == $key)
 			{
 				return HSP_ERR_ILLEGAL_OPERATION;
 			}
 		}
 		
 		return HSP_SUCCESS;
 	}

 	function createSubTree($destNode, $nodeToCopy, $arrSubTree)
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$nodeHandler = null;
		$node = $arrSubTree[$nodeToCopy];
		$nodeDetails = $node->getDetails();
		$arrAppRes = null;
		$arrAppsParams = null;
		
		if(is_null($nodeDetails[3] /*appType*/)) //none
		{
			// No application is defined:
			$res = applicationsData::saveNode($nodeDetails[4],
											$nodeDetails[7],
											$nodeDetails[6],
											$this->m_appTreeTbl->getDB(),
											$destNode,
											0,
											$nodeDetails[13],
										 	false);	
		}		
		elseif("url" == $nodeDetails[3])
		{
			// Get app fileds:
			$res = $this->m_appTreeTbl->GetRowForField(TABLE_APPS_LINKS, 'appID', $nodeDetails[2], $arrAppRes);
			if(HSP_SUCCESS == $res)
			{
				$res = applicationsURL::saveNode(	$nodeDetails[4],
													$nodeDetails[7],
													$nodeDetails[6],
													$arrAppRes[1],
												 	$this->m_appTreeTbl->getDB(),
												 	$destNode,
												 	false,
												 	$nodeDetails[12],
												 	$nodeDetails[13],
												 	$arrAppRes[2],
												 	$arrAppRes[4],
												 	$arrAppRes[3]);	
			}
		}
		elseif("w2h" == $nodeDetails[3])
		{
			// Get app fileds:
			$res = $this->m_appTreeTbl->GetRowForField(TABLE_APPS_W2H, 'appID', $nodeDetails[2], $arrAppRes);
			$arrAppsParams["paramStr"] = $arrAppRes[1];
			$arrAppsParams["hostURL"] = $arrAppRes[2];
			$arrAppsParams["version"] = $arrAppRes[3];
			$arrAppsParams["subType"] = $arrAppRes[4];
			$arrAppsParams["fileName"] = $arrAppRes[5];
			
			if(HSP_SUCCESS == $res)
			{
				$res = applicationsW2H::saveNode(	$nodeDetails[4],
													$nodeDetails[7],
													$nodeDetails[6],
													$arrAppsParams,
												 	$this->m_appTreeTbl->getDB(),
												 	$destNode,
												 	$nodeDetails[12],
												 	$nodeDetails[13],
												 	false);	
			}
			
		}
		elseif("onWeb" == $nodeDetails[3])
		{
			// Get app fileds:
			$res = $this->m_appTreeTbl->GetRowForField(TABLE_APPS_ONWEB, 'appID', $nodeDetails[2], $arrAppRes);
			$arrAppsParams["display_name"] = $arrAppRes[1];
			$arrAppsParams["name"] = $arrAppRes[2];
			$arrAppsParams["hostURL"] = $arrAppRes[3];
			$arrAppsParams["appURL"] = $arrAppRes[4];

			if(HSP_SUCCESS == $res)
			{
				//				 saveNode($name,$icon,$description, $params, $db,& $parentID, $insideCall = true)
				$res = applicationsOnWeb::saveNode(	$nodeDetails[4],
													$nodeDetails[7],
													$nodeDetails[6],
													$arrAppsParams,
												 	$this->m_appTreeTbl->getDB(),
												 	$destNode,
												 	$nodeDetails[12],
												 	$nodeDetails[13],
												 	false
												 	);	
			}
		}
		//elseif....	
			
		if(HSP_SUCCESS == $res)
		{
			$sons = $node->getSonsIDs();
			
			if(count($sons)>0)
			{
				//Continue creating sons recursivley:
				foreach($sons as $sonID)
				{
					$res = $this->createSubTree($destNode, $sonID, $arrSubTree);
					if(HSP_SUCCESS != $res)
					{
						break;	
					}
				}
			}
		}
		
		return $res;
	}

	function setSortOrder($isAsc=true)
	{
		$parentID = $this->m_session->value(SESSION_NODE_ID);

		$query = "SELECT id FROM hsp_tree WHERE parent_id=$parentID ORDER BY ";

		if(true == $isAsc)
		{
			// Ascending tree order:
			$query .= " status DESC, text ASC";
		}				
		else
		{
			// Descending tree order:
			$query .= " status ASC, text DESC";		
		}

		// Get the name ordered nodes:
		$resArr = $this->m_appTreeTbl->GetAllEx($query);
		
		// Go over each node and update it's order field:
		for($i=0; $i <count($resArr); ++$i)
		{
			$res = $this->m_appTreeTbl->UpdateOrder($resArr[$i][0], $i+1);
		}
	}
	
	function validateNodeName($nodeID, $parentID)
	{
		// Get the node name:
		$res = $this->m_appTreeTbl->GetRowForField(TABLE_TREE, 'id', $nodeID, $arrTreeRes);		
		if(HSP_SUCCESS == $res)		
		{
			// Find if there is already a node with that name under the parent:
			$name = $arrTreeRes[4];
			$sql = "select id from hsp_tree where parent_id = $parentID and text=\"$name\"";	

			$arrRes = $this->m_appTreeTbl->GetAllEx($sql);

			$res = HSP_SUCCESS;

			if(count($arrRes) > 0)
			{
				// Found:
				$res = HSP_ERR_NAME_ALREADY_EXISTS;
			}
		}
		
		return $res;
	}
	
	
	function setSortOrderRecursive($rootID, $isAsc=true)
	{
		$arrOut = array();
		$tableFields = array(
								"id"		=> "id",
								"parent_id"	=> "parent_id",
								"text"		=> "text",
							);

		$query = "SELECT " .
				$tableFields["id"] . " AS id, " .
				$tableFields["parent_id"] . " AS parent_id, " .
				$tableFields["text"] . " AS text 
			FROM " . "hsp_tree" . "
			WHERE " . $tableFields["id"] . " <> 1 ORDER BY ";

		if(true == $isAsc)
		{
			// Ascending tree order:
			$query .= "status DESC, ";
			$query .= $tableFields["text"] . " ASC";
		}				
		else
		{
			// Descending tree order:
			$query .= "status ASC, ";
			$query .= $tableFields["text"] . " DESC";		
		}

		// Get the name ordered nodes:
		$resArr = $this->m_appTreeTbl->GetAllEx($query);
		
		if(is_array($resArr))
		{
			// Arrange the nodes orders according to their subtree 
			// belonging (recursively):
			$this->determineOrder($resArr, $rootID, $arrOut);
		}
		else
		{
			$res = HSP_ERR_DB_ERROR;
		}
		
		// Go over each node and update it's order field:
		foreach($arrOut as $id=>$order)
		{
			$res = $this->m_appTreeTbl->UpdateOrder($id, $order);
		}
		
		return $res;
	}

	function determineOrder($tmpArray, $parent_id=1, &$arrOut) {
		reset ($tmpArray);
		$order = 1;
		foreach($tmpArray as $node)
		{
			$id = $node[0];
			if ($node[1] == $parent_id) {
				$arrOut[$node[0]] = $order++;
				unset($node);
				$this->determineOrder($tmpArray, $id, $arrOut);
			}
		}
	}
	
	// Remark - A leaf here is also a node with only one son!!
	function isNodeLeaf($nodeID)
	{
		$sql = "select id from hsp_tree where parent_id = $nodeID";
			
		$arrRes = $this->m_appTreeTbl->GetAllEx($sql);

		if(count($arrRes) > 1) //notice!!!
		{
			// More than one son is a possible sort:
			return false;
		}
		
		// Cannot sort leaf/one son:
		return true;
	}
}

class node
{
	var $m_nodeID;
	var $m_parentID;
	var $m_details;
	var $m_arrSonsIDs;
	
	
	function node()
	{
		$this->m_arrSonsIDs = array();
	}
	
	function addNodeData($details) // CTOR
	{
		$this->m_nodeID = $details[0];
		$this->m_parentID = $details[1];
		$this->m_details = $details;
	}
	
	function addSon($sonID)
	{
		array_push($this->m_arrSonsIDs, $sonID);
	}
	
	function getNodeID()
	{
		return $this->m_nodeID;
	}
	
	function getDetails()
	{
		return  $this->m_details;
	}
	
	function getSonsIDs()
	{
		return $this->m_arrSonsIDs;
	}
}

?>