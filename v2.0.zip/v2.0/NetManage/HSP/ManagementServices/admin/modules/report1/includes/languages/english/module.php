<?PHP
define('REPORT1_MAIN_TXT','Connected Sessions');
define('REPORT1_BACK_BTN','< Back');
define('REPORT1_PRINT_BTN','Print');
define('REPORT1_EXPORT_BTN','Export');
define('REPORT1_COL1','Date/Hour (d/m/y hh:mm)');
define('REPORT1_COL2','User');
define('REPORT1_COL3','Group');
define('REPORT1_COL4','Application');
define('REPORT1_COL5','Connected');
define('REPORT1_COL6','Start Time');
define('REPORT1_COL7','Duration (h:m:s)');
define('REPORT1_COL8','Security Protocol');
?>