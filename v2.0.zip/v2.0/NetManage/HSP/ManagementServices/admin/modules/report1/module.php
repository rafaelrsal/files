<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: report1.php
  Purpose: full report,  connections.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('HTML/QuickForm.php');

require_once('HTML/Table.php');
require_once('includes/classes/PearDB.php');
require_once('Admin/includes/classes/reportGenerator.php');

class report1 extends ModuleBase
{
	var $m_db;
	var $m_reportGenerator;
	var $m_internalArrLog;

	function report1($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('report1Form'); //default is post
	}

	function init()
	{
		parent::init("report1");

		$this->m_form->addElement('header', 'header', REPORT1_MAIN_TXT);
		$this->m_form->addElement('submit', 'back', REPORT1_BACK_BTN,"class='NewButton'");
		$this->m_form->addElement('submit', 'print', REPORT1_PRINT_BTN, 'class="NewButton" onclick = printReport()');
		$this->m_form->addElement('submit', 'export', REPORT1_EXPORT_BTN,"class='NewButton'");

		$this->m_form->addElement('text', 'fromdate', REPORT_DATE_LBL);
		$this->m_form->addElement('text', 'fromtime', REPORT_TIME_LBL);
		$this->m_form->addElement('text', 'todate', REPORT_DATE_LBL);
		$this->m_form->addElement('text', 'totime', REPORT_TIME_LBL);
		
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);

		$tmpElement = &$this->m_form->getElement('fromdate');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('fromtime');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('todate');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('totime');
		$tmpElement->freeze();
	}

	function process()
	{
		$formValuesArray = $this->m_form->exportValues();

		$fromDate 	= $this->m_session->value('fromDate');
		$toDate 	= $this->m_session->value('toDate');
		$fromTime 	= $this->m_session->value('fromTime');
		$toTime 	= $this->m_session->value('toTime');

		$this->RecInfoLog($fromDate, $toDate, $fromTime, $toTime);
		
		
		$this->m_form->setDefaults(array('fromdate'=>$fromDate, 'todate'=>$toDate,'fromtime'=>$fromTime.':00:00','totime'=>$toTime.':00:00'));

		$this->m_reportGenerator = new reportGenerator(REPORT1_MAIN_TXT, $this->m_language , "reports" );

		

		$this->m_db->disconnect();

		if ( array_key_exists("back", $formValuesArray) )
		{
			$this->goBack($fromDate, $toDate, $fromTime, $toTime );
		}
		elseif ( array_key_exists("export", $formValuesArray))
		{
			parent::CriaLog(REPORT1_EXPORT_BTN);
			$this->ExportToCSV();
			
		}

		$res = $this->m_reportGenerator->prepareReportPage();

		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}

	function finalize()
	{
		$arrVars = array(	"report1Form_from_txt"=>REPORT_FROM_TXT,
							"report1Form_to_txt"=>REPORT_TO_TXT,
							"report_table"=>$this->generateTable());

		parent::finalize($arrVars);
	}

	// Fun��o para gera��o de tabela
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tblReport1" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(REPORT1_COL1 , REPORT1_COL2, REPORT1_COL3);
		$headerAttribArr = array("class='TableHeader' width=200px","class='TableHeader' width=200px","class='TableHeader' width=200px" );
		$tblBackups->addRow($headerArr , $headerAttribArr );
		
		foreach ( $this->m_internalArrLog as $key=>$dirRow )
		{
			$rownum = $key + 1 ;
			
			$TblDate = $dirRow[0];
			
			$TblUser = $dirRow[1];
					
			$TblGroup = $dirRow[2];
			
			$row = array ( $TblDate , $TblUser, $TblGroup );			
			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
		
			$date = $dirRow[1];
			$user = $dirRow[2];
			$group = $dirRow[2];
			$attib = array("class='DataCell' title='$date'","class='DataCell' title='$user'", "class='DataCell' title='$group'");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}
		
		return $tblBackups->toHtml();
	}
	
	function goBack($fromDate, $toDate, $fromTime, $toTime)
	{
		$this->m_session->set('fromDate', $fromDate);
		$this->m_session->set('toDate', $toDate);
		$this->m_session->set('fromTime', $fromTime);
		$this->m_session->set('toTime', $toTime);

		$this->m_session->set('reportName', $this->m_moduleName);

		Header('Location: admin.php?module=reports&roll='.$_POST['roll']);
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		exit();
	}
	
	/************************************************
		Autor: Guilherme Chiozzini de Lima
		Data: june 2013
		Fun��o para recuperar dados dos arquivos de 
			logon do portal.
	************************************************/
	function RecInfoLog($fromdate, $todate, $fromHour=null, $toHour = null)
	{
		$firstDate = strtotime(date("d/m/Y H:i:s", strtotime($fromdate. " " . $fromHour .":00"))); // primeira data hora
		$filepath = "log/portal/"; // caminho do arquivo
		$filename = ""; // variavel para nome do arquivo (data - 20130611.hsp)
		$arrLinhas = array(); // array para cada linha do arquivo
		$arrLinhaColuna = array(array()); // array de linha por coluna explode (chr(10) e ;)
		$cont = 0; // contador para nao se perder na troca de arquivos
		$fhsp; // variavel para handle do arquivo
		$buffer =""; // buffer do arquivo aberto
		$auxHour=""; // auxiliar para hora
		while(strtotime($fromdate) <= strtotime($todate))// loop de para percorrer todas as datas selecionadas
		{
			$filename = date("Ymd", strtotime($fromdate)) . ".hsp"; // nome do arquivo a ser procurado
			if(file_exists($filepath.$filename)) // existe arquivo?
			{//sim
				$fhsp = @fopen($filepath.$filename, "r"); // abertura do arquivo existente
				$buffer = @fread($fhsp, filesize($filepath.$filename)); // leitura do arquivo por completo
				$arrLinhas = explode(chr(10), trim($buffer)); // separa��o do lido por linhas
				foreach($arrLinhas as $linha) // loop para percorrer todas as linhas
				{
					$auxHour = explode(";", trim($linha));
					if($firstDate < strtotime($auxHour[0]) && strtotime(date("d/m/Y H:i:s", strtotime($todate." ".$toHour .":00"))) > strtotime($auxHour[0])) // est� entre o intervalo requerido?
					{
						$arrLinhaColuna[$cont] = explode(";", trim($linha)); // separa  conteudo por ";"
						$cont = $cont + 1; // contador para n�o se perder na troca de arquivos
					}
				}
			}
			// finaliza o loop inserindo mais um dia na data corrente
			$fromdate = date("Y-m-d", strtotime("+1 day", strtotime($fromdate)));
		}
		
		$this->m_internalArrLog = $arrLinhaColuna; // retorna array [linhas] [colunas] 
	}
	
	/************************************************
		Autor: Guilherme Chiozzini de Lima
		Data: june 2013
		Fun��o exportar dados para csv
	************************************************/
	function ExportToCSV()
	{
		$strCSV = "data/hora;usuario;grupo\n";
		foreach($this->m_internalArrLog as $linhas)
		{
			$strCSV .= implode(";", $linhas) . "\n";
		}
			
		ob_clean();
		
		$filename = 'LoggedUsers.csv';

		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");

		//To force a download on MSIE for Windows, you don't have to use "attachment", but you need it for all other browsers.
		$user_agent = strtolower ($_SERVER["HTTP_USER_AGENT"]);
		if ((is_integer (strpos($user_agent, "msie"))) && (is_integer (strpos($user_agent, "win"))))
		{
			header("Content-Disposition: filename=".basename($filename).";");
		}
		else
		{
			header("Content-Disposition: attachment; filename=".basename($filename).";");
		}

		header("Content-Transfer-Encoding: binary");

		//file size
		$size = array_sum(count_chars ($strCSV));

		header("Content-Length: ".$size);
		//ob_end_flush();
		echo $strCSV;
		exit();
	}

}
?>