<?PHP
define('REPORT1_MAIN_TXT','Sess�es Conectadas');
define('REPORT1_BACK_BTN','< Voltar');
define('REPORT1_PRINT_BTN','Imprimir');
define('REPORT1_EXPORT_BTN','Exportar');
define('REPORT1_COL1','Data/Hora (d/m/a hh:mm)');
define('REPORT1_COL2','Usu�rio');
define('REPORT1_COL3','Grupo');
define('REPORT1_COL4','Aplica��o');
define('REPORT1_COL5','Conectado');
define('REPORT1_COL6','Hor�rio de In�cio');
define('REPORT1_COL7','Dura��o (h:m:s)');
define('REPORT1_COL8','Protocolo de Seguran�a');
?>