function initPopup()
{
}

function finalizePopup()
{
}

function TakePropertiesFromOpener()
{	        
}

function SaveExport()
{
  
	window.close();
}

function onPopupSave()
{
	var selectedUsers = document.getElementsByName('selectUsers[]').item(0);
	var winSelectedUsers = win.document.getElementsByName('selectUsers[]').item(0);
	
	for(i = 0 ; i < selectedUsers.length ; i++)
	{
		winSelectedUsers[i].selected = selectedUsers[i].selected;
	}

	win.document.getElementsByName('buttonClicked').item(0).value 	= 'popupSave';
	win.document.getElementById('editCustomDirGroupForm').submit();
	window.close();
}

function onPopupCancel()
{
	window.close();
}

function DoDefaultEnterKey(e)
{
	if(CheckEnter(e))
	{
		document.getElementById('popupSave').click();
	}
}
