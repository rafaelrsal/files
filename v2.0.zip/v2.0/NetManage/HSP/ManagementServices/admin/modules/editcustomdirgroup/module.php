<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

define('INTERNALDIR_ID', 'internalDirId');
define('INTERNALDIRGROUP_ID', 'internalDirGroupId');
define('SESSION_CUSTOMDIR_MODE', 'customDirectoryMode');

define('CUSTOM_GROUP_AVAILABLE_USERS', 'customAvailableUsers');
define('CUSTOM_GROUP_MEMBER_USERS', 'customMemberUsers');

define('CUSTOM_GROUP_DETAILS', 'customGroupDetails');

class editCustomDirGroup extends ModuleBase
{
	var $m_db;
	
	var $m_users; 			// all users associated with this directory id
	var $m_availableUsers; 	// appears in the javascript/html select pane
	var $m_memberUsers; 	// full details located in the table
	
	var $m_internalDirGroupId; // the current user id
	
	function editCustomDirGroup($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
		$this->m_form = new HTML_QuickForm('editCustomDirGroupForm'); //default is post
	}
	
	function init()
	{		
		parent::init("editCustomDirGroup");
		// buttons		
		$this->m_form->addElement('button', 'add',		EDITCUSTOMDIRGROUP_ADD_BTN,	"onclick=onAdd() class='NewButton'");		
		$this->m_form->addElement('button', 'remove',	EDITCUSTOMDIRGROUP_REMOVE_BTN,"onclick=onRemove() class='NewButton'");
		$this->m_form->addElement('button', 'back',		EDITCUSTOMDIRGROUP_BACK_BTN,"onclick=onBack() class='NewButton'");
		$this->m_form->addElement('submit', 'save',		EDITCUSTOMDIRGROUP_SAVE_BTN,  "onclick='onSave();return false;' class='NewButton'");		
		// text		
		$this->m_form->addElement('text', 'name', 	EDITCUSTOMDIRGROUP_NAME_LBL, array('size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('text', 'description',EDITCUSTOMDIRGROUP_DESCRIPTION_LBL, array('size' => 40, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects', 'style' => 'width:420px'));
		// hiddens
		$this->m_form->addElement('hidden', 'buttonClicked','');	
		$this->m_form->addElement('hidden', 'selectedRow', 1);
		$this->m_form->addElement('hidden', 'mode','new');
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->addElement('select', 'selectUsers', EDITCUSTOMDIRGROUP_SELECTUSERS_LBL, null,'multiple size=15 style="width:200" onkeypress="DoDefaultEnterKey(event)"');
		$this->m_form->addElement('submit', 'popupSave',	EDITCUSTOMDIRGROUP_POPUP_SAVE_BTN,	"onclick=onPopupSave();return false; class='NewButton'");		
		$this->m_form->addElement('button', 'popupCancel',	EDITCUSTOMDIRGROUP_POPUP_CANCEL_BTN,	"onclick=onPopupCancel() class='NewButton'");
		
		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			if ( isset($_GET['id'] ) )
			{	// edit mode
				$this->m_internalDirGroupId = $_GET['id'];
			}
			elseif ( $this->m_session->value(INTERNALDIRGROUP_ID) )
			{
				$this->m_internalDirGroupId = $this->m_session->value(INTERNALDIRGROUP_ID);
			}

			if ( null != $this->m_internalDirGroupId )
			{
				$this->m_session->set(INTERNALDIRGROUP_ID, $this->m_internalDirGroupId );
				$this->m_form->addElement('hidden', 'mode', 'edit');
			}
		}
		else
		{ // we are in post -> we can use the saved dir id
			$this->m_internalDirGroupId = $this->m_session->value(INTERNALDIRGROUP_ID);
		}
		
		$this->populateAvailableUsersPopup();
	}

	function process()
	{
		$this->setGroupParams();
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$res = HSP_SUCCESS;		
			
			$formValuesArray = $this->m_form->exportValues();
			
			$groupDetails = array();
			$groupDetails['name'] = htmlspecialchars($this->m_form->exportValue('name'));
			$groupDetails['description'] = htmlspecialchars($this->m_form->exportValue('description'));
			$this->m_session->set(CUSTOM_GROUP_DETAILS, $groupDetails);		

			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));
			
			if ( "save" == $formValuesArray['buttonClicked'])
			{
				$res = $this->onSave( $formValuesArray );
				if(HSP_SUCCESS == $res)
				{
					parent::CriaLog($this->m_session->value(SESSION_CUSTOMDIR_MODE) ."_". EDITCUSTOMDIRGROUP_SAVE_BTN);
					$this->onBack();
				}
			}
			elseif ( "back" == $formValuesArray['buttonClicked'])
			{
				$this->onBack();
			}
			elseif ( "remove" == $formValuesArray['buttonClicked'])
			{
				$this->onRemove($selectedRow);
			}
			elseif ( "popupSave" == $formValuesArray['buttonClicked'])
			{
				$selectedUsers = $this->m_form->exportValue('selectUsers');
				if ($selectedUsers)
				{
					$this->addUsers($selectedUsers);
				}
			}

			if(HSP_SUCCESS != $res)
			{
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);				
			}
		}

		
		// after removing/saving/adding the new groups from the db, repopulate the arrays
		$this->populateAvailableUsersPopup();
		
		// we call populate on success in order to reflect the new state
		$this->setGroupParams();			

		$this->m_form->removeElement('selectUsers');
		$this->m_form->addElement('select', 'selectUsers', EDITCUSTOMDIRGROUP_SELECTUSERS_LBL,$this->m_availableUsers,'multiple size=15 style="width:200" onkeypress="DoDefaultEnterKey(event)"');
	}
	
	function finalize()
	{
		$noAvailableUsers = 0;
		if ( !count($this->m_availableUsers) )
		{
			$noAvailableUsers = 1;
		}
		
		$strTitle = $this->m_session->value(SESSION_CUSTOMDIR_MODE) == 'editMode' ? EDITCUSTOMDIRGROUP_EDIT_TITLE_TXT : EDITCUSTOMDIRGROUP_ADD_TITLE_TXT;
				
		$language = parent::GetLanguage();		
		$arrVars = array( 	"tblItems"=>$this->generateTable(),
							"moduleName"=>$this->m_moduleName,
					        "language"=>$language->m_Language,
					        "strTitle"=>$strTitle,
					        "strTableTitle"=>EDITCUSTOMDIRGROUP_TABLE_TITLE_TXT,
					        "lblUsers"=>rawurlencode(EDITCUSTOMDIRGROUP_USERS_TXT),
					        "name_req_msg"=>EDITCUSTOMDIRGROUP_NAME_REQ_MSG_TXT,
					        "msgPageChanged"=> MENUITEM_CHANGES,
					        "noAvailableUsers"=>$noAvailableUsers,
					        "editCustomDirGroupForm_required_note"=>CUSTOM_DIR_REQUIRED_TXT,
					        "directoryName"=>$this->getDirName());
					        
		parent::finalize($arrVars, "editCustomDirGroup");
	}
	
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tblItems" border="1" class="DataTable" bordercolor="black""');
		
		$headerAttribArr = array("class='TableHeader' width=200px","class='TableHeader' width=400px");
		$headerArr = array(EDITCUSTOMDIRGROUP_TABLE_NAME_LBL , EDITCUSTOMDIRGROUP_TABLE_DESCRIPTION_LBL);
		$tblBackups->addRow($headerArr , $headerAttribArr);		
		
		foreach ( $this->m_memberUsers as $key=>$fileRow )
		{
			$rownum = $key + 1 ;
			$shortName = $fileRow['name'];
			
			if ( strlen($shortName) > 21 )
			{
				$shortName = substr($fileRow['name'], 0, 21) . '...';
			}
			
			$shortDesc = $fileRow['description'];
			
			if ( strlen($shortDesc) > 50 )
			{
				$shortDesc = substr($fileRow['description'], 0, 48) . '...';
			}
			
			$row = array ($shortName , $shortDesc );			
			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
			
			$name = $fileRow['name'];			
			$description = $fileRow['description'];
			$attib = array("class='DataCell' title='$name'","class='DataCell' title='$description'");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}
		
		return $tblBackups->toHtml();
		
	}
	
	function setGroupParams()
	{		
		$groupDetails = $this->m_session->value(CUSTOM_GROUP_DETAILS);

		if (!is_array($groupDetails))
		{
			$groupParams = $this->m_db->GetAllEx("SELECT name, description FROM ".TABLE_CUSTOM_GROUPS . " WHERE id=$this->m_internalDirGroupId;", null, DB_FETCHMODE_ASSOC );		
	
			$this->m_form->setDefaults(array('name'=>$groupParams[0]['name']));		
			$this->m_form->setDefaults(array('description'=>$groupParams[0]['description']));
		}
		else
		{
			$this->m_form->setDefaults(array('name'=>$groupDetails['name']));		
			$this->m_form->setDefaults(array('description'=>$groupDetails['description']));		
		}
	}
	
	function onSave( $formValues )	
	{		
		$groupName = trim($formValues['name']);
		$groupName = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $groupName);
		$description = $formValues['description'];
		$description = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $description);
		
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		
		$fields_values = array(	'dirID'=>$dirId,
								'name'=>$groupName,								
								'description'=>$description);
		if ( $this->m_internalDirGroupId )	
		{
			// Editing mode check if there is a group with a different ID and the same name:
			$sql = "SELECT count(id) FROM ".TABLE_CUSTOM_GROUPS . " WHERE name=\"$groupName\" AND dirId=$dirId AND id!=$this->m_internalDirGroupId;";
		}							
		else
		{
			// Inserting.. check if there exist a group with the same name
			$sql = "SELECT count(id) FROM ".TABLE_CUSTOM_GROUPS . " WHERE name=\"$groupName\" AND dirId=$dirId;";
		}
		$this->m_db->GetOne( $sql, $isExist);
		if ( !$isExist )
		{	
			if ( $this->m_internalDirGroupId )
			{
				$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_GROUPS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$this->m_internalDirGroupId.';' );
				if ( HSP_SUCCESS != $ret )
				{
					$ret = HSP_ERR_DB_ERROR;
				}
			}
			else //insert mode
			{
				$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_GROUPS, $fields_values );
				if ( HSP_SUCCESS != $ret )
				{
					$ret = HSP_ERR_DB_ERROR;
				}
				$sql = "SELECT MAX( id ) FROM " . TABLE_CUSTOM_GROUPS .";";
				$this->m_db->GetOne($sql, $this->m_internalDirGroupId);
				$this->m_session->set(INTERNALDIRGROUP_ID, $this->m_internalDirGroupId );
			}
		}
		else
		{
			$ret = HSP_CUSTOMDIR_GROUP_EXISTS;	
		}
						
		$this->insertDBCrossReference();
		return $ret;								
	}

	function addUsers($selectedUsers)
	{
		// add selected users to the memeber users list
		foreach( $selectedUsers as $userIndex )
		{			
			foreach ( $this->m_users as $user )
			{
				if ($this->m_availableUsers[$userIndex] == $user['name'])
				{
					$this->m_memberUsers[] = array('name'=>$user['name'], 'description'=>$user['description'], 'id'=>$user['id']);
					break;
				}
			}
		}

		// remove the selected users from the available users list
		foreach ( $this->m_memberUsers as $memberUser)
		{
			foreach ( $this->m_availableUsers as $key=>$availableUser )	
			{
				if ( $memberUser['name'] == $availableUser)
				{
					unset($this->m_availableUsers[$key]);
					break;
				}
			}
		}
		
		$this->m_session->set(CUSTOM_GROUP_MEMBER_USERS, $this->m_memberUsers);
		$this->m_session->set(CUSTOM_GROUP_AVAILABLE_USERS, $this->m_availableUsers);
	}
	
	function insertDBCrossReference()
	{
		// delete old cross reference
		$sql = "DELETE FROM " . TABLE_CUSTOM_CROSS . " WHERE groupId=" . $this->m_internalDirGroupId . ";";
		$this->m_db->Query($sql);
		
		// insert new cross reference
		foreach ( $this->m_memberUsers as $member )
		{
			$this->insertUserGroupCrossRefer($member['id']);
		}
	}
	
	//sort the file list by file modified date
	function sortArr(&$arr)
	{
		$tmpArr = array();
		
		foreach($arr as $item)
		{
			$tmpArr[] = $item['name'];
		}
		
		natcasesort($tmpArr);
		
		$newArr = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $arr as $item )
			{
				if ($name == $item['name'])
				{
					$newArr[] = $item;
					break;
				}
			}			
		}
		
		$arr = $newArr;
	}
	
	function onBack()
	{
		Header('Location: admin.php?module=editCustomDir&roll='.$_POST['roll']);
		exit();
	}
	
	function populateAvailableUsersPopup()
	{
		$memberUsers = $this->m_session->value(CUSTOM_GROUP_MEMBER_USERS);
		$availableUsers = $this->m_session->value(CUSTOM_GROUP_AVAILABLE_USERS);

		$dirID = $this->m_session->value(INTERNALDIR_ID);
		$this->m_users = $this->m_db->GetAllEx("SELECT id, name, description FROM ".TABLE_CUSTOM_USERS . " WHERE dirID=$dirID;", null, DB_FETCHMODE_ASSOC );

		if ( !is_array($memberUsers) || !is_array($availableUsers))
		{		
			$memberUserIds = array();
			if ( null != $this->m_internalDirGroupId )
			{				
				$memberUserIds = $this->m_db->GetAllEx("SELECT userId FROM ". TABLE_CUSTOM_CROSS . " WHERE groupId=$this->m_internalDirGroupId;", null, DB_FETCHMODE_ASSOC );
			}
			
			$userIds = array();
			
			foreach ($memberUserIds as $userId)
			{
				$userIds[] = $userId['userId'];
			}
			
			$this->m_availableUsers = array();
			$this->m_memberUsers = array();
			
			foreach ($this->m_users as $user)
			{
				if (!in_array($user['id'], $userIds))
				{
					$this->m_availableUsers[] = $user['name'];
				}
				else
				{
					$this->m_memberUsers[] = array('name'=>$user['name'], 'description'=>$user['description'], 'id'=>$user['id']);
				}
			}
			
			$this->m_session->set(CUSTOM_GROUP_MEMBER_USERS, $this->m_memberUsers);
			$this->m_session->set(CUSTOM_GROUP_AVAILABLE_USERS, $this->m_availableUsers);
		}
		else
		{
			$this->m_availableUsers = $availableUsers;
			$this->m_memberUsers = $memberUsers;
		}
		
		natcasesort($this->m_availableUsers);
		$this->sortArr($this->m_memberUsers);
	}
	
	function insertUserGroupCrossRefer($userIndex)
	{
		//$fields_values = array('userId'=>$this->m_internalDirUserId, 'groupId'=>$groupIndex);
		$fields_values = array('userId'=>$userIndex, 'groupId'=>$this->m_internalDirGroupId);
		
		$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_CROSS, $fields_values );
	}
	
	function onRemove($selectedRow)
	{
		$id = $this->m_memberUsers[$selectedRow-1]['id'];
		
		foreach ( $this->m_users as $user)
		{
			if ($user['id'] == $id )
			{
				$userName = $user['name'];
				$this->m_availableUsers[] = $userName;
				break;
			}
		}
		
		unset($this->m_memberUsers[$selectedRow-1]);

		$this->m_session->set(CUSTOM_GROUP_MEMBER_USERS, $this->m_memberUsers);
		$this->m_session->set(CUSTOM_GROUP_AVAILABLE_USERS, $this->m_availableUsers);
	}
	
	function getDirName()
	{	
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		$sql = "SELECT name FROM ".TABLE_CUSTOM_DIRECTORY . " WHERE id=$dirId;";
		
		$this->m_db->GetOne($sql, $name);
		
		return $name;
	}
}
?>