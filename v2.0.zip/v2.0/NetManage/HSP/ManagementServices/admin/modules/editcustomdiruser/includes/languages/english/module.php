<?PHP
define('EDITCUSTOMDIRUSER_ADD_BTN','Add');
define('EDITCUSTOMDIRUSER_REMOVE_BTN','Remove');
define('EDITCUSTOMDIRUSER_SAVE_BTN','Save');
define('EDITCUSTOMDIRUSER_BACK_BTN','Cancel');

define('EDITCUSTOMDIRUSER_NAME_LBL','Name:');
define('EDITCUSTOMDIRUSER_DESCRIPTION_LBL','Description:');

define('EDITCUSTOMDIRUSER_TABLE_NAME_LBL','Name');
define('EDITCUSTOMDIRUSER_TABLE_DESCRIPTION_LBL','Description');


define('EDITCUSTOMDIRUSER_SELECTUSERS_LBL','Available Groups');
define('EDITCUSTOMDIRUSER_POPUP_SAVE_BTN','OK');
define('EDITCUSTOMDIRUSER_POPUP_CANCEL_BTN','Cancel');

define('EDITCUSTOMDIRUSER_TABLE_TITLE_TXT','Member of');
define('EDITCUSTOMDIRUSER_ADD_TITLE_TXT','Add User');
define('EDITCUSTOMDIRUSER_EDIT_TITLE_TXT','Edit User');

define('EDITCUSTOMDIRUSER_GROUPS_TXT','Groups');

define('EDITCUSTOMDIRUSER_FULLNAME_LBL','Full name:');
define('EDITCUSTOMDIRUSER_PASSWORD_LBL','Password:');
define('EDITCUSTOMDIRUSER_CONFIRMPASS_LBL','Confirm password:');
define('EDITCUSTOMDIRUSER_MUST_CHANGE_PASS_LBL','User must change password at next logon');
define('EDITCUSTOMDIRUSER_ACCOUT_DISABLED_LBL','Account is disabled');
define('EDITCUSTOMDIRUSER_CANNOTCHANGEPASS_LBL','User cannot change password');
define('EDITCUSTOMDIRUSER_NAME_REQ_MSG_TXT','User name is required');
define('EDITCUSTOMDIRUSER_PASSWORD_REQ_MSG_TXT','Password  is required');
define('EDITCUSTOMDIRUSER_CONFIRMPASSWORD_REQ_MSG_TXT','Confirm password is required');
define('EDITCUSTOMDIRUSER_PASSWORDMATCH_MSG_TXT','Confirm password must match password');
define('CUSTOM_DIR_REQUIRED_TXT' ,'denotes required field');

?>