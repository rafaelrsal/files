function initPopup()
{
}

function finalizePopup()
{
}

function TakePropertiesFromOpener()
{  
}

function onPopupSave()
{  
	var selectedGroups = document.getElementsByName('selectGroups[]').item(0);
	var winSelectedGroups = win.document.getElementsByName('selectGroups[]').item(0);
	
	for(i = 0 ; i < selectedGroups.length ; i++)
	{
		winSelectedGroups[i].selected = selectedGroups[i].selected;
	}

	win.document.getElementsByName('buttonClicked').item(0).value 	= 'popupSave';
	win.document.getElementById('editCustomDirUserForm').submit();
	window.close();
}

function onPopupCancel()
{
	window.close();
}

function DoDefaultEnterKey(e)
{
	if(CheckEnter(e))
	{
		document.getElementById('popupSave').click();
	}
}
