<?PHP
define('EDITCUSTOMDIRUSER_ADD_BTN','Adicionar');
define('EDITCUSTOMDIRUSER_REMOVE_BTN','Remover');
define('EDITCUSTOMDIRUSER_SAVE_BTN','Salvar');
define('EDITCUSTOMDIRUSER_BACK_BTN','Cancelar');

define('EDITCUSTOMDIRUSER_NAME_LBL','Nome:');
define('EDITCUSTOMDIRUSER_DESCRIPTION_LBL','Descri��o:');

define('EDITCUSTOMDIRUSER_TABLE_NAME_LBL','Nome');
define('EDITCUSTOMDIRUSER_TABLE_DESCRIPTION_LBL','Descri��o');


define('EDITCUSTOMDIRUSER_SELECTUSERS_LBL','Grupos Dispon�veis');
define('EDITCUSTOMDIRUSER_POPUP_SAVE_BTN','OK');
define('EDITCUSTOMDIRUSER_POPUP_CANCEL_BTN','Cancelar');

define('EDITCUSTOMDIRUSER_TABLE_TITLE_TXT','Membro de');
define('EDITCUSTOMDIRUSER_ADD_TITLE_TXT','Adicionar Usu�rio');
define('EDITCUSTOMDIRUSER_EDIT_TITLE_TXT','Editar Usu�rio');

define('EDITCUSTOMDIRUSER_GROUPS_TXT','Grupos');

define('EDITCUSTOMDIRUSER_FULLNAME_LBL','Nome completo:');
define('EDITCUSTOMDIRUSER_PASSWORD_LBL','Senha:');
define('EDITCUSTOMDIRUSER_CONFIRMPASS_LBL','Confirma senha:');
define('EDITCUSTOMDIRUSER_MUST_CHANGE_PASS_LBL','Usu�rio deve alterar a senha no pr�ximo logon');
define('EDITCUSTOMDIRUSER_ACCOUT_DISABLED_LBL','Conta desabilitada');
define('EDITCUSTOMDIRUSER_CANNOTCHANGEPASS_LBL','Usu�rio n�o pode alterar a senha');
define('EDITCUSTOMDIRUSER_NAME_REQ_MSG_TXT','Nome do usu�rio � obrigat�rio');
define('EDITCUSTOMDIRUSER_PASSWORD_REQ_MSG_TXT','Senha � obrigat�ria');
define('EDITCUSTOMDIRUSER_CONFIRMPASSWORD_REQ_MSG_TXT','Confirmar a senha � obrigat�rio');
define('EDITCUSTOMDIRUSER_PASSWORDMATCH_MSG_TXT','A confirma��o da senha deve ser igual a senha');
define('CUSTOM_DIR_REQUIRED_TXT' ,'verificar os campos obrigat�rios');

?>