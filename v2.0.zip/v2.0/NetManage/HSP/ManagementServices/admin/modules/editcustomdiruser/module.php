<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

define('INTERNALDIR_ID', 'internalDirId');
define('INTERNALDIRUSER_ID', 'internalDirUserId');
define('SESSION_CUSTOMDIR_MODE', 'customDirectoryMode');

define('CUSTOM_USER_AVAILABLE_GROUPS', 'customAvailableGroups');
define('CUSTOM_USER_MEMBER_OF_GROUPS', 'customMemberOfGroups');

define('CUSTOM_USER_DETAILS', 'customUserDetails');

class editCustomDirUser extends ModuleBase
{
	var $m_db;
	
	var $m_groups;                  // all groups associated with this directory id
	var $m_availableGroups;         // appears in the javascript/html select pane
	var $m_memberOfGroups;   // full details located in the table
	
	var $m_internalDirUserId;       // the current user id
	
	var $m_changePassSet;
	var $m_disabledSet;
	var $m_cannotChangePassSet;
	
	var $m_bEditMode;
	
	function editCustomDirUser($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
		$this->m_form = new HTML_QuickForm('editCustomDirUserForm'); //default is post
		
		$this->m_bEditMode = false;
	}
	
	function init()
	{		
		parent::init("editCustomDirUser");
		
		// buttons		
		$this->m_form->addElement('button', 'add',		EDITCUSTOMDIRUSER_ADD_BTN,	"tabindex='9' onclick=onAdd() class='NewButton'");		
		$this->m_form->addElement('button', 'remove',	EDITCUSTOMDIRUSER_REMOVE_BTN,"tabindex='10' onclick=onRemove() class='NewButton'");
		$this->m_form->addElement('button', 'back',     EDITCUSTOMDIRUSER_BACK_BTN,"tabindex='12' onclick=onBack() class='NewButton'");
		$this->m_form->addElement('submit', 'save',		EDITCUSTOMDIRUSER_SAVE_BTN,  "tabindex='11' onclick='onSave();return false;' class='NewButton'");		
		// text		
		$this->m_form->addElement('text', 'name', 		EDITCUSTOMDIRUSER_NAME_LBL, array( 'tabindex' => "1", 'size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects') );
		$this->m_form->addElement('text', 'description',EDITCUSTOMDIRUSER_DESCRIPTION_LBL, array( 'tabindex' => "5", 'size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects', 'style' => 'width:438px'));
		
		$this->m_form->addElement('text', 'fullName',	EDITCUSTOMDIRUSER_FULLNAME_LBL, array( 'tabindex' => "2",  'size' => 20, 'maxlength' => 255, 'onchange' => "updated()" , 'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('password', 'password',	EDITCUSTOMDIRUSER_PASSWORD_LBL, array( 'tabindex' => "3", 'size' => 20, 'maxlength' => 255, 'onchange' => "updated()" , 'class' => 'FixedWidthObjects'));
		$this->m_form->addElement('password', 'confirmPass',EDITCUSTOMDIRUSER_CONFIRMPASS_LBL, array( 'tabindex' => "4", 'size' => 20, 'maxlength' => 255, 'onchange' => "updated()" , 'class' => 'FixedWidthObjects'));
		
		// hiddens
		$this->m_form->addElement('hidden', 'buttonClicked','');	
		$this->m_form->addElement('hidden', 'selectedRow', 1);
		$this->m_form->addElement('hidden', 'mode', 'new');
		//*************GUILHERME LIMA 11/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->addElement('select', 'selectGroups', EDITCUSTOMDIRUSER_SELECTUSERS_LBL, null,'multiple size=15 style="width:200" onkeypress="DoDefaultEnterKey(event)"');
		$this->m_form->addElement('submit', 'popupSave',	EDITCUSTOMDIRUSER_POPUP_SAVE_BTN,	"onclick=onPopupSave();return false; class='NewButton'");		
		$this->m_form->addElement('button', 'popupCancel',	EDITCUSTOMDIRUSER_POPUP_CANCEL_BTN,	"onclick=onPopupCancel() class='NewButton'");
		
		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			if ( isset($_GET['id'] ) )
			{	// edit mode
				$this->m_internalDirUserId = $_GET['id'];
			}
			elseif ( $this->m_session->value(INTERNALDIRUSER_ID) )
			{
				$this->m_internalDirUserId = $this->m_session->value(INTERNALDIRUSER_ID);
			}

			if ( null != $this->m_internalDirUserId )
			{
				$this->m_session->set(INTERNALDIRUSER_ID, $this->m_internalDirUserId );
				$this->m_form->addElement('hidden', 'mode', 'edit');
			}
		}
		else
		{ // we are in post -> we can use the saved dir id
			$this->m_internalDirUserId = $this->m_session->value(INTERNALDIRUSER_ID);
		}
		
        $this->populateAvailableGroupsPopup();
    }

	function process()
	{	
	    $this->setUserParams();
       
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$res = HSP_SUCCESS;		
			
			$formValuesArray = $this->m_form->exportValues();
                        
            $mustChangePassChk = false;		
			if (isset($_POST['mustChangePassChk']) && 'on' == $_POST['mustChangePassChk'])
			{
				$mustChangePassChk = true;
			}
			
			$disableAccountChk = false;
			if (isset($_POST['disableAccountChk']) && 'on' == $_POST['disableAccountChk'])
			{
				$disableAccountChk = true;
			}
			
			$cannotChangePassword = false;
			if (isset($_POST['cannotChangePassChk']) && 'on' == $_POST['cannotChangePassChk'])
			{
				$cannotChangePassword = true;
			}
            
            $userDetails = array();
			$userDetails['name'] = htmlspecialchars($this->m_form->exportValue('name'));
			$userDetails['fullName'] = htmlspecialchars($this->m_form->exportValue('fullName'));
            $userDetails['description'] = htmlspecialchars($this->m_form->exportValue('description'));
            $userDetails['password'] = htmlspecialchars($this->m_form->exportValue('password'));
            $userDetails['changePassword'] = $mustChangePassChk;
            $userDetails['disabled'] = $disableAccountChk;
            $userDetails['cannotChangePassword'] = $cannotChangePassword;
            
			$this->m_session->set(CUSTOM_USER_DETAILS, $userDetails);
            
			$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));			
			
			if ( "save" == $formValuesArray['buttonClicked'])
			{					
				$res = $this->onSave($formValuesArray, $mustChangePassChk, $disableAccountChk, $cannotChangePassword );
				if(HSP_SUCCESS == $res)
				{
					parent::CriaLog($this->m_session->value(SESSION_CUSTOMDIR_MODE) . "_" . EDITCUSTOMDIRUSER_SAVE_BTN);
                	$this->onBack();
				}
			}
			elseif ( "back" == $formValuesArray['buttonClicked'])
			{
				$this->onBack();
			}
			elseif ( "remove" == $formValuesArray['buttonClicked'])
			{
				$this->onRemove($selectedRow);
			}
			elseif ( "popupSave" == $formValuesArray['buttonClicked'])
			{
				$selectedGroups = $this->m_form->exportValue('selectGroups');
				if ($selectedGroups)
				{
					$this->addGroups($selectedGroups);
				}
			}
			
			if(HSP_SUCCESS != $res)
			{
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);				
			}
		}
		
        // after removing/saving/adding the new groups from the db, repopulate the arrays
		$this->populateAvailableGroupsPopup();				
		// we call populate on success in order to reflect the new state
		$this->setUserParams();			
        
		$this->m_form->removeElement('selectGroups');
		$this->m_form->addElement('select', 'selectGroups', EDITCUSTOMDIRUSER_SELECTUSERS_LBL,$this->m_availableGroups,'multiple size=15 style="width:200" onkeypress="DoDefaultEnterKey(event)"');	
	}
	
	function finalize()
	{
		$noAvailableGroups = 0;
        if ( !count($this->m_availableGroups) )
		{
			$noAvailableGroups = 1;
		}

		$tblBackups = new HTML_Table('id="tblTitle" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(EDITCUSTOMDIRUSER_NAME_LBL , EDITCUSTOMDIRUSER_DESCRIPTION_LBL);
		$tblBackups->addRow($headerArr , "class='TableHeader'");
		$strTableTitle = $tblBackups->toHtml();
		
		$strTitle = $this->m_session->value(SESSION_CUSTOMDIR_MODE) == 'editMode' ? EDITCUSTOMDIRUSER_EDIT_TITLE_TXT : EDITCUSTOMDIRUSER_ADD_TITLE_TXT;
		
		$language = parent::GetLanguage();		
		$arrVars = array( 	"tblItems"=>$this->generateTable(),
		 					"moduleName"=>$this->m_moduleName,
					        "language"=>$language->m_Language,
					        "strTitle"=>$strTitle,
					        "strTableTitle"=>EDITCUSTOMDIRUSER_TABLE_TITLE_TXT,
					        "lblGroups"=>EDITCUSTOMDIRUSER_GROUPS_TXT,
					        "lblmustChangePass"=>EDITCUSTOMDIRUSER_MUST_CHANGE_PASS_LBL,
					        "lbldisableAccountChk"=>EDITCUSTOMDIRUSER_ACCOUT_DISABLED_LBL,
					        "lblcannotChangePassChk"=>EDITCUSTOMDIRUSER_CANNOTCHANGEPASS_LBL,
					        "changePassSet"=>$this->m_changePassSet,
					        "disabledSet"=>$this->m_disabledSet,
					        "cannotChangePassSet"=>$this->m_cannotChangePassSet,
					        "name_req_msg"=>EDITCUSTOMDIRUSER_NAME_REQ_MSG_TXT,
					        "password_req_msg"=>EDITCUSTOMDIRUSER_PASSWORD_REQ_MSG_TXT,
					        "confirmPass_req_msg"=>EDITCUSTOMDIRUSER_CONFIRMPASSWORD_REQ_MSG_TXT,
					        "passwordMatch_req_msg"=>EDITCUSTOMDIRUSER_PASSWORDMATCH_MSG_TXT,
					        "msgPageChanged"=>MENUITEM_CHANGES,
					        "noAvailableGroups"=>$noAvailableGroups,
                            "editCustomDiruSERForm_required_note"=>CUSTOM_DIR_REQUIRED_TXT,
                            "directoryName"=>$this->getDirName(),
                            "tblTitle"=>$strTableTitle);

		parent::finalize($arrVars, "editCustomDirUser");
	}
	
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tblItems" border="1" class="DataTable" bordercolor="black""');
		$headerAttribArr = array("class='TableHeader' width=200px","class='TableHeader' width=400px");
		$headerArr = array(EDITCUSTOMDIRUSER_TABLE_NAME_LBL , EDITCUSTOMDIRUSER_TABLE_DESCRIPTION_LBL);
		$tblBackups->addRow($headerArr , $headerAttribArr);		
		
		foreach ( $this->m_memberOfGroups as $key=>$fileRow )		
        {
            $rownum = $key + 1 ;
            $shortName = $fileRow['name'];
			
			if ( strlen($shortName) > 21 )
			{
				$shortName = substr($fileRow['name'], 0, 21) . '...';
			}
			
			$shortDesc = $fileRow['description'];
			
			if ( strlen($shortDesc) > 50 )
			{
				$shortDesc = substr($fileRow['description'], 0, 48) . '...';
			}
			
			$row = array ($shortName , $shortDesc );			
			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
			
			$name = $fileRow['name'];			
			$description = $fileRow['description'];
			$attib = array("class='DataCell' title='$name'","class='DataCell' title='$description'");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
        }
        return $tblBackups->toHtml();
	}
	
	function insertDBCrossReference()
	{
		// delete old cross reference
		$sql = "DELETE FROM " . TABLE_CUSTOM_CROSS . " WHERE userId=" . $this->m_internalDirUserId . ";";
		$this->m_db->Query($sql);
		
		// insert new cross reference
		foreach( $this->m_memberOfGroups as $group )
		{			
            $this->insertUserGroupCrossRefer($group['id']);
		}
    }
	
	//sort the file list by file modified date
	function sortArr(&$arr)
	{
		$tmpArr = array();
		
		foreach($arr as $item)
		{
			$tmpArr[] = $item['name'];
		}
		
		natcasesort($tmpArr);
		
		$newArr = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $arr as $item )
			{
				if ($name == $item['name'] )
				{
					$newArr[] = $item;
					break;
				}
			}			
		}
		
		$arr = $newArr;
	}
	
	function onBack()
	{
		Header('Location: admin.php?module=editCustomDir&roll='.$_POST['roll']);
		exit();
	}
	
	function onSave( $formValues , $mustChangePassChk, $disableAccountChk, $cannotChangePassword )	
	{
		if(!extension_loaded('HSPSecurModule'))
		{
			dl('php_HSPSecurModule.dll');
		}
		
		$userName = trim($formValues['name']);
		$userName = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $userName);
		$fullName = $formValues['fullName'];
		$fullName = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $fullName);
		$description = $formValues['description'];
		$description = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $description);
		
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		
		$fields_values = array(	'dirID'=>$dirId,
								'name'=>$userName,
								'fullName'=>$fullName,
								'description'=>$description,
								'password'=>encrypt_str($formValues['password']),
								'changePassword'=>$mustChangePassChk,
								'disabled'=>$disableAccountChk ,
								'cannotChangePassword'=>$cannotChangePassword);
								
		if ( $this->m_internalDirUserId )	
		{
			// Editing mode check if there is a user with a different ID and the same name:
			$sql = "SELECT count(id) FROM ".TABLE_CUSTOM_USERS . " WHERE name=\"$userName\" AND dirId=$dirId AND id!=$this->m_internalDirUserId;";
		}							
		else
		{
			// Inserting.. check if there exist a user with the same name
			$sql = "SELECT count(id) FROM ".TABLE_CUSTOM_USERS . " WHERE name=\"$userName\" AND dirId=$dirId;";
		}
								
		$this->m_db->GetOne( $sql, $isExist);
		if ( !$isExist )
		{	
			if ( $this->m_internalDirUserId )
			{
				$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_USERS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$this->m_internalDirUserId.';' );
				if ( HSP_SUCCESS != $ret )
				{
					$ret = HSP_ERR_DB_ERROR;
				}
			}
			else //insert mode
			{
				$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_USERS, $fields_values );
				if ( HSP_SUCCESS != $ret )
				{
					$ret = HSP_ERR_DB_ERROR;
				}
				$sql = "SELECT MAX( id ) FROM " . TABLE_CUSTOM_USERS .";";
				$this->m_db->GetOne($sql, $this->m_internalDirUserId);
				$this->m_session->set(INTERNALDIRUSER_ID, $this->m_internalDirUserId );
			}
		}
		else
		{
			$ret = HSP_CUSTOMDIR_USER_EXISTS;	
		}
						
		$this->insertDBCrossReference();
		return $ret;								
	}
	
	function setUserParams()
	{	
		if(!extension_loaded('HSPSecurModule'))
		{
			dl('php_HSPSecurModule.dll');
		}
		
		$userDetails = $this->m_session->value(CUSTOM_USER_DETAILS);

		if (!is_array($userDetails))
		{
			if(!is_null($this->m_internalDirUserId ) ) // edit user
			{
				$userParams = $this->m_db->GetAllEx("SELECT name, fullName, description, password, changePassword, disabled ,cannotChangePassword FROM ".TABLE_CUSTOM_USERS . " WHERE id=$this->m_internalDirUserId;", null, DB_FETCHMODE_ASSOC );
				
				$decryptedPass = decrypt_str($userParams[0]['password']);
				$this->m_form->setDefaults(array('name'=>$userParams[0]['name']));
				$this->m_form->setDefaults(array('fullName'=>$userParams[0]['fullName']));
				$this->m_form->setDefaults(array('description'=>$userParams[0]['description']));
				$this->m_form->setDefaults(array('password'=>$decryptedPass));
				$this->m_form->setDefaults(array('confirmPass'=>$decryptedPass));
				$this->m_changePassSet 		 = $userParams[0]['changePassword']?'checked':0;
				$this->m_disabledSet 		 = $userParams[0]['disabled']?'checked':0;
				$this->m_cannotChangePassSet = $userParams[0]['cannotChangePassword']?'checked':0;
			}
			else // new user
			{
				$this->m_form->setDefaults('');
				$this->m_form->setDefaults('');
				$this->m_form->setDefaults('');
				$this->m_form->setDefaults('');
				$this->m_form->setDefaults('');
				$this->m_changePassSet 		 = 0;
				$this->m_disabledSet 		 = 0;
				$this->m_cannotChangePassSet = 0;
			}
		}
		else // in progress user
		{
			$this->m_form->setDefaults(array('name'=>$userDetails['name']));		
			$this->m_form->setDefaults(array('fullName'=>$userDetails['fullName']));		
			$this->m_form->setDefaults(array('description'=>$userDetails['description']));		
			$this->m_form->setDefaults(array('password'=>$userDetails['password']));
			$this->m_form->setDefaults(array('confirmPass'=>$userDetails['password']));
			$this->m_changePassSet 		 = $userDetails['changePassword']?'checked':0;
			$this->m_disabledSet 		 = $userDetails['disabled']?'checked':0;
			$this->m_cannotChangePassSet = $userDetails['cannotChangePassword']?'checked':0;
		}
	}

	function populateAvailableGroupsPopup()
	{
        $memberOfGroups = $this->m_session->value(CUSTOM_USER_MEMBER_OF_GROUPS);
		$availableGroups = $this->m_session->value(CUSTOM_USER_AVAILABLE_GROUPS);
        
		$dirID = $this->m_session->value(INTERNALDIR_ID);
		$this->m_groups = $this->m_db->GetAllEx("SELECT id, name, description FROM ".TABLE_CUSTOM_GROUPS . " WHERE dirID=$dirID;", null, DB_FETCHMODE_ASSOC );
		
        if ( !is_array($memberOfGroups) || !is_array($availableGroups))
		{		
			$memberOfGroupsIds = array();
			if ( null != $this->m_internalDirUserId )
			{
                $memberOfGroupsIds = $this->m_db->GetAllEx("SELECT groupId FROM ". TABLE_CUSTOM_CROSS . " WHERE userId=$this->m_internalDirUserId;", null, DB_FETCHMODE_ASSOC );
            }
        
		    $groupIds = array();
		
		    foreach ($memberOfGroupsIds as $groupId)
    		{
    			$groupIds[] = $groupId['groupId'];
    		}
		
            $this->m_availableGroups = array();
            $this->m_memberOfGroups = array();
            
            foreach ($this->m_groups as $group)
            {
                if (!in_array($group['id'], $groupIds))
                {
                    $this->m_availableGroups[] = $group['name'];
                }
                else
                {
                    $this->m_memberOfGroups[] = array('name'=>$group['name'], 'description'=>$group['description'], 'id'=>$group['id']);
                }
            }
            
            $this->m_session->set(CUSTOM_USER_MEMBER_OF_GROUPS, $this->m_memberOfGroups);
            $this->m_session->set(CUSTOM_USER_AVAILABLE_GROUPS,  $this->m_availableGroups); 
        } 
        else
        {
            $this->m_availableGroups = $availableGroups;
			$this->m_memberOfGroups = $memberOfGroups;
        }
		
        natcasesort($this->m_availableGroups);
		$this->sortArr($this->m_memberOfGroups);
	}
	
	function insertUserGroupCrossRefer($groupIndex)
	{
		$fields_values = array('userId'=>$this->m_internalDirUserId, 'groupId'=>$groupIndex);
		
		$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_CROSS, $fields_values );
	}
	
	function onRemove($selectedRow)
	{
		$id = $this->m_memberOfGroups[$selectedRow-1]['id'];
		foreach ( $this->m_groups as $group)
		{
			if ($group['id'] == $id )
			{
				$groupName = $group['name'];
				$this->m_availableGroups[] = $groupName;
				break;
			}
		}
		
		unset($this->m_memberOfGroups[$selectedRow-1]);

		$this->m_session->set(CUSTOM_USER_MEMBER_OF_GROUPS, $this->m_memberOfGroups);
        $this->m_session->set(CUSTOM_USER_AVAILABLE_GROUPS,  $this->m_availableGroups);         
	}
	
	function addGroups($selectedGroups)
	{
		// add selected users to the memeber users list
		foreach( $selectedGroups as $groupIndex )
		{			
			foreach ( $this->m_groups as $group )
			{
				if ($this->m_availableGroups[$groupIndex] == $group['name'])
				{
					$this->m_memberOfGroups[] = array('name'=>$group['name'], 'description'=>$group['description'], 'id'=>$group['id']);
					break;
				}
			}
		}

		// remove the selected users from the available users list
		foreach ( $this->m_memberOfGroups as $memberOfGroup)
		{
			foreach ( $this->m_availableGroups as $key=>$availableGroup )	
			{
				if ( $memberOfGroup['name'] == $availableGroup)
				{
					unset($this->m_availableGroups[$key]);
					break;
				}
			}
		}
				
		$this->m_session->set(CUSTOM_USER_MEMBER_OF_GROUPS, $this->m_memberOfGroups);
        $this->m_session->set(CUSTOM_USER_AVAILABLE_GROUPS,  $this->m_availableGroups); 
	}
	
	function getDirName()
	{	
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		$sql = "SELECT name FROM ".TABLE_CUSTOM_DIRECTORY . " WHERE id=$dirId;";
		
		$this->m_db->GetOne($sql, $name);
		
		return $name;
	}	
}
?>