<?PHP
/*===========================================================================

        Copyright (c) 2013, Slice TI.  All Rights Reserved.  
 ============================================================================

  Author: Guilherme Lima
  Date Created: April 2013
  Title:            database methods
  Purpose:          methods for db access
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
 require_once('HTML/QuickForm.php');
 require_once('includes/classes/permissions.php');
 
 class roll extends ModuleBase{
	
	var $m_form;
	var $m_permission;
	var $m_internalArrRoll;
	
	function roll($globalObjects){
		parent::ModuleBase($globalObjects);
		$this->m_form = new HTML_QuickForm('rollForm');
		$this->m_permission = new Permission();
		$this->m_permission->initFromFile(CONFIG_XML_PATH . PERMISSION_XML_NAME);
	}
	
	function init(){
		parent::init("roll");
		
		$this->m_form->addElement('button', 'newRoll', ROLL_NEW_BTN, "class='NewButton' onclick='onNew();return false;'");
		$this->m_form->addElement('button', 'editRoll', ROLL_EDIT_BTN, "class='NewButton' onclick='onEdit();return false;'");
		$this->m_form->addElement('button', 'removeRoll', ROLL_DELETE_BTN, "class='NewButton' onclick='onRemove();return false;'");
		
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		$this->m_form->addElement('hidden', 'buttonClicked','');
		$this->m_form->addElement('hidden', 'selectedRow', 1);

		$this->populateRollListArr();
	}
	
	function process(){
		$res = HSP_SUCCESS;
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$formValuesArray = $this->m_form->exportValues();
			$selectedRow = $formValuesArray['selectedRow'];
			if("new" == $formValuesArray['buttonClicked']){
				$this->onNew();
			}
			elseif("edit" == $formValuesArray['buttonClicked']){
				$this->onEdit($selectedRow);
			}
			elseif("remove" == $formValuesArray['buttonClicked']){
				if(!$this->onRemove($selectedRow)){
					$res = HSP_ERR_ILLEGAL_OPERATION;
				}
			}
			if(HSP_SUCCESS != $res){
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);	
			}
			else{
				$this->populateRollListArr();
			}
		}
	}
	
	function finalize(){
		$language = parent::GetLanguage();
		
		$arrVars = array(	"tbluser"=>$this->generateTable(),			
					        "selectedRow"=>$this->getSelectedUserIndex(),
					        "lblNew"=>rawurlencode(NEWUSER_NEW_USER),
					        "moduleName"=>$this->m_moduleName,
							"confirm_delete"=>ROLL_CONFIRM_DELETE_MSG,
							"roll_lbl"=>ROLL_ROLL_LBL,
					        'newUserForm_required_note'=>NEWUSER_REQUIRED_TXT);       
		parent::finalize( $arrVars , 'roll' );
	}
	
	// Fun��o para selecionar o index do linha selecionada
	function getSelectedUserIndex()
	{
		return 1;
	}
	
	// Fun��o para gera��o de tabela
	function generateTable()
	{
		$tblBackups = new HTML_Table('id="tbluser" border="1" class="DataTable" bordercolor="black""');
		
		$headerArr = array(ROLL_ROLL_LBL , ROLL_MENU_LBL, ROLL_SUBMENU_LBL);
		$headerAttribArr = array("class='TableHeader' width=200px","class='TableHeader' width=200px","class='TableHeader' width=200px" );
		$tblBackups->addRow($headerArr , $headerAttribArr );
		
		foreach ( $this->m_internalArrRoll as $key=>$dirRow )
		{
			$rownum = $key + 1 ;
			
			$TblName = $dirRow['nome'];
			
			if ( strlen($TblName) > 23 )
			{
				$TblName = substr($dirRow['nome'], 0, 23) . '...';
			}
			
			$TblMenu = $this->MenuParse($dirRow['menu']);
			
			if ( strlen($TblMenu) > 47 )
			{
				$TblMenu = substr($this->MenuParse($dirRow['menu']), 0, 47) . '...';
			}			
			
			$TblSubmenu = $this->SubMenuParse($dirRow['submenu']);
			
			if ( strlen($TblSubmenu) > 47 )
			{
				$TblSubmenu = substr($this->SubMenuParse($dirRow['submenu']), 0, 47) . '...';
			}			
			
			$row = array ( $TblName , $TblMenu, $TblSubmenu );			
			
			$tblBackups->addRow( $row  , "class='UnSelectedRow' onclick='rowClicked(this,$rownum)'" , 'TD' , true );
		
			$nome = $dirRow['nome'];
			$menu = $dirRow['menu'];
			$submenu = $dirRow['submenu'];
			$attib = array("class='DataCell' title='$nome'","class='DataCell' title='$menu'", "class='DataCell' title='$submenu'");			
			$tblBackups->setRowAttributes($rownum , $attib, false);
		}
		
		return $tblBackups->toHtml();
	}
	
	// Fun��o para popular array gen�rico
	function populateRollListArr()
	{
		$this->m_internalArrRoll = $this->m_permission->SelectAllRolls();
		
 		$this->sortDirArr();
	}
	
	// Fun��o para Colocar em ordem os itens da tabela
	function sortDirArr()
	{
		$tmpArr = array();
		foreach($this->m_internalArrRoll as $rollItem)
		{
			$tmpArr[] = $rollItem['nome'];
		}
		
		natcasesort($tmpArr);
		
		$newFileListArray = array();
		
		foreach($tmpArr as $name)
		{
			foreach( $this->m_internalArrRoll as $rollItem )
			{
				if ($name == $rollItem['nome'] )
				{
					$newFileListArray[] = $rollItem;
					break;
				}
			}			
		}
		
		$this->m_internalArrRoll = $newFileListArray;
	}
	
	// Fun��o para trocar numeros por itens de menu
	function MenuParse($strMenuItens)
	{
		if($strMenuItens != "")
		{
			$arrItens = explode(";" , $strMenuItens);
			$arrNovo = array();
			foreach($arrItens as $key=>$item)
			{
				switch($item)
				{
					case('1'):
						$arrNovo[$key] = ROLL_MENU_SETTINGS;
						break;
					case('2'):
						$arrNovo[$key] = ROLL_MENU_USER_MANAGE;
						break;
					case('3'):
						$arrNovo[$key] = ROLL_MENU_APPLICATION_MANAGMENT;
						break;
					case('4'):
						$arrNovo[$key] = ROLL_MENU_MONITORING;
						break;
					default:
						break;
				}
			}
			return implode("; ", $arrNovo);
		}
		return "";
	}
	
	// Fun��o para trocar numeros por submenus
	// Recebe -> $strSumenuItens - itens que est�o bloqueados
	function SubMenuParse($strSubmenuItens)
	{
		if($strSubmenuItens)
		{
			$arrItens = explode(";", $strSubmenuItens);
			$arrNovo = array();
			foreach($arrItens as $key=>$item)
			{
				switch($item)
				{
					case('1'):
						$arrNovo[$key] = ROLL_DATABASE;
						break;
					case('2'):
						$arrNovo[$key] = ROLL_IMPORTEXPORT;
						break;
					case('3'):
						$arrNovo[$key] = ROLL_ADMIN_PASSWORD;
						break;
					case('14'):
						$arrNovo[$key] = ROLL_GENERAL_CONFIGURATION;
						break;
					case('19'):
						$arrNovo[$key] = ROLL_NEW_USER;
						break;
					case('33'):
						$arrNovo[$key] = ROLL_PERMISSIONS;
						break;
					case('4'):
						$arrNovo[$key] = ROLL_CUSTOM_DIRECTORIES;
						break;
					case('5'):
						$arrNovo[$key] = ROLL_SYSTEM_DIRECTORIES;
						break;
					case('6'):
						$arrNovo[$key] = ROLL_GROUPS;
						break;
					case('7'):
						$arrNovo[$key] = ROLL_USERS;
						break;
					case('8'):
						$arrNovo[$key] = ROLL_APPLICATION_BUILD;
						break;
					case('9'):
						$arrNovo[$key] = ROLL_ASSOC_APPLICATIONS;
						break;
					case('15'):
						$arrNovo[$key] = ROLL_APPLICATION_ANONYMOUS;
						break;
					case('17'):
						$arrNovo[$key] = ROLL_USER_PARAMETERS;
						break;
					case('10'):
						$arrNovo[$key] = ROLL_CONFIGURATION;
						break;
					case('11'):
						$arrNovo[$key] = ROLL_CLIENTCONFIGURATION;
						break;
					case('12'):
						$arrNovo[$key] = ROLL_REPORTS;
						break;
					case('13'):
						$arrNovo[$key] = ROLL_CONCURRENCY;
						break;
					case('25'):
						$arrNovo[$key] = ROLL_WHOS_ONLINE;
						break;
					case('16'):
						$arrNovo[$key] = ROLL_W2H_ADMIN;
						break;
					default:
						break;
				}
			}
			return implode(";", $arrNovo);
		}
		return "";
	}
	
	// Fun��o para novo roll
	function onNew(){
		Header('Location: admin.php?module=rolldata&roll='.$_POST['roll']);
		exit();
	}
	
	// Fun��o para editar roll
	function onEdit($selectedRow){
		$rollName = $this->m_internalArrRoll[$selectedRow -1]['nome'];
		Header("Location: admin.php?module=rolldata&name=$rollName&roll=".$_POST['roll']);
		exit();
	}
	
	// Fun��o para remover roll
	function onRemove($selectedRow){
		$rollName = $this->m_internalArrRoll[$selectedRow -1]['nome'];
		if ($this->m_permission->RemoveOldRoll($rollName)){
			parent::CriaLog(ROLL_DELETE_BTN, $rollName);
			return true;
		}
		return false;
	}
 }
 ?>