<?PHP
define('ROLL_NEW_BTN','Novo');
define('ROLL_EDIT_BTN','Editar');
define('ROLL_DELETE_BTN','Remover');

define('ROLL_ROLL_LBL', 'Role');
define('ROLL_MENU_LBL', 'Menu');
define('ROLL_SUBMENU_LBL', 'SubMenu');

define('ROLL_CONFIRM_DELETE_MSG','Deseja realmente remover este role?');

define('ROLL_MENU_SETTINGS','Configura��o do Sistema');
define('ROLL_DATABASE','Configurar Database');
define('ROLL_IMPORTEXPORT','Importar / Exportar Database');
define('ROLL_ADMIN_PASSWORD','Alterar Senha');
define('ROLL_GENERAL_CONFIGURATION','Configurar Prefer�ncias');
define('ROLL_NEW_USER', 'Novo Usu�rio Administrador');
define('ROLL_PERMISSIONS', 'Configurar Permiss�es');
define('ROLL_MENU_MONITORING','Monitoramento');
define('ROLL_CONFIGURATION','Configurar Servidor');
define('ROLL_CLIENTCONFIGURATION','Configurar Clientes');
define('ROLL_REPORTS','Gerar Relat�rios');
define('ROLL_CONCURRENCY','Estat�stica');
define('ROLL_MENU_USER_MANAGE','Gerenciamento de Usu�rios');
define('ROLL_CUSTOM_DIRECTORIES','Gerenciar Diret�rios Customizados');
define('ROLL_SYSTEM_DIRECTORIES','Selecionar Diret�rios');
define('ROLL_GROUPS','Selecionar Grupos');
define('ROLL_USERS','Selecionar Usu�rios');
define('ROLL_ASSOC_APPLICATIONS','Configurar Permiss�es');
define('ROLL_MENU_APPLICATION_MANAGMENT','Gerenciamento de Aplica��o');
define('ROLL_APPLICATION_BUILD','Criar �rvore de Aplica��o');
define('ROLL_APPLICATION_ANONYMOUS','Configurar Usu�rio Anonymous');
define('ROLL_HIDEPATH', 'NetManage - Host Services Platform');
define('ROLL_WHOS_ONLINE', 'Gerenciar Usu�rios do Portal');
define('ROLL_W2H_ADMIN', 'Gerenciar Usu�rios W2H');
define('ROLL_USER_PARAMETERS', 'Gerenciar Parametro de Usu�rio');
?>