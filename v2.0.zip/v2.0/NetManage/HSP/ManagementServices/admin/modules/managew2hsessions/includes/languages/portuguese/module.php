<?PHP
define('MANAGESESSIONS_MAIN_TXT','Gerenciamento de Usu�rios OnWeb Web to Host');
define('MANAGESESSIONS_DELETE_MSG','Voc� tem certeza que deseja remover esta entrada?');
define('MANAGESESSIONS_DELETE_BTN','Remover');
define('MANAGESESSIONS_USER_COUNT_TXT','N�mero de usu�rios simult�neos: ');
define('MANAGESESSIONS_SESSIONS_COUNT', 'N�mero de sess�es simult�neas: ');
define('MANAGESESSIONS_COL2','Nome do Usu�rio');
define('MANAGESESSIONS_COL3','IP Local');
define('MANAGESESSIONS_COL4','IP do Host');
define('MANAGESESSIONS_COL5','Hor�rio do Logon');
define('MANAGESESSIONS_COL6','Hor�rio da �ltima Opera��o');
define('MANAGESESSIONS_COL7','Tipo do Host');
define('MANAGESESSIONS_DELETE_PERIODO','Remover as entradas anteriores a data: ');
?>