<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Dec 2004
  Title: manageW2HSessions.php
  Purpose: report
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('HTML/QuickForm/Renderer/ITStatic.php');
require_once('HTML/QuickForm.php');
require_once('HTML/Template/Sigma.php');
require_once('HTML/Table.php');
require_once('includes/classes/PearDB.php');
require_once('includes/classes/w2hwhosOnline.php');

class manageW2hSessions extends ModuleBase
{
	var $m_db;
	var $m_whosOnlineSessionIdArray;
	var $m_whosOnlineArray;
	var $m_whosOnline;	
	var $m_SessionOpen;
	
	function manageW2hSessions($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		$this->m_db = &parent::GetDatabase();
		$this->m_db->connect();
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('manageW2HSessionsForm'); //default is post
		$this->m_whosOnlineArray = array();
		$this->m_whosOnlineSessionIdArray = array();
		$this->formSQL();
		$this->m_whosOnline = new w2hwhosOnline($this->m_db);
		// $this->m_whosOnline->deleteExpiredEntries();
	}
	
	function  init()
	{
		parent::init("manageW2HSessions");
		$this->m_form->addElement('header', 'header', MANAGESESSIONS_MAIN_TXT);		
		$this->m_form->addElement('button', 'delete', MANAGESESSIONS_DELETE_BTN, 'onclick=onDelete() class="NewButton"');
		$this->m_form->addElement('button', 'btdeleteperiodo', MANAGESESSIONS_DELETE_BTN, 'onclick=onDeleteDate() class="NewButton"');
		// $this->m_form->addElement('text', 'deleteperiodotxt', , 'name="data"');
		
		$this->m_form->addElement('text', 'userCount', MANAGESESSIONS_USER_COUNT_TXT, array('size' => 20, 'maxlength' => 20));		
		$this->m_form->addElement('text', 'sessionCount', MANAGESESSIONS_SESSIONS_COUNT,array('size' => 20, 'maxlength' => 20));
		
		$this->m_form->addElement('text', 'deleteperiodo', MANAGESESSIONS_DELETE_PERIODO,array('size' => 20, 'maxlength' => 20));
		
		$this->m_form->addElement('hidden', 'buttonClicked','');
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$selectedRow = '';
		if (isset($this->m_whosOnlineSessionIdArray[0][0]))
		{
			$selectedRow = $this->m_whosOnlineSessionIdArray[0][0];
		}
		$this->m_form->addElement('hidden', 'selectedRow', $selectedRow );
		
	}
	
	function process()
	{
			
		
		
		$formValuesArray = $this->m_form->exportValues();
		$selectedRow = htmlspecialchars($this->m_form->exportValue('selectedRow'));

		
		if ( "delete" == $formValuesArray['buttonClicked'] )
		{			
			$res = $this->doDelete($selectedRow);
			$this->formSQL();
			if (isset($this->m_whosOnlineSessionIdArray[0][0]))
			{
				$element = &$this->m_form->getElement('selectedRow');
				$element->setValue($this->m_whosOnlineSessionIdArray[0][0]);
			}
		}
		
			
		if ( "deleteDate" == $formValuesArray['buttonClicked'] )
		{			
			$this->doDeleteDate($_REQUEST['data']);
						
			$this->formSQL();
		}
		
		$element = &$this->m_form->getElement('userCount');
		$count = $this->m_whosOnline->count();
		if ( $count < 1 )
		{
			$count = '0';
		}
		$element->setValue($count);
		$element->freeze();
		
		$element = &$this->m_form->getElement('sessionCount');
		$count =  $this->m_whosOnline->SessionCount();
		$element->setValue($count);
		$element->freeze();
	}
	
	function finalize()
	{		
		$arrVars = array( 	"manageW2HSessionsForm_table"=>$this->generateTable(),
							"confirm_delete"=>MANAGESESSIONS_DELETE_MSG
					 );
							
		parent::finalize($arrVars);		
		
	}
	
	function formSQL()
	{
		$sql = "SELECT user_id,ip_local,ip_host,start_time,last_update,tp_host FROM " . TABLE_EMULACAO_SIMPLES . ";";		
		$this->m_whosOnlineArray = $this->m_db->GetAllEx($sql, null,DB_FETCHMODE_ORDERED);
		 foreach ( $this->m_whosOnlineArray as $index=>$row)
		 {
			 $this->m_whosOnlineArray[$index][3] = strftime("%d/%m/%Y - %H:%M" ,strtotime($row[3]));
			 $this->m_whosOnlineArray[$index][4] = strftime("%d/%m/%Y - %H:%M" ,strtotime($row[4]));
		 }
		$this->m_whosOnlineSessionIdArray = $this->m_db->GetAllEx("SELECT id FROM " . TABLE_EMULACAO_SIMPLES . ";", null,DB_FETCHMODE_ORDERED);		
	}
	
	function generateTable()
	{
		$tblWhos = new HTML_Table('id="tblWhosOnline" border="1" class="DataTable" bordercolor="black"');
		
		$headerArr = array(MANAGESESSIONS_COL2,MANAGESESSIONS_COL3,MANAGESESSIONS_COL4,MANAGESESSIONS_COL5,MANAGESESSIONS_COL6,MANAGESESSIONS_COL7);
		$tblWhos->addRow($headerArr , "class='ShortTableHeader'");		

		foreach ( $this->m_whosOnlineArray as $key=>$row )
		{
			$rownum = $key + 1 ;
			$sessionId = $this->m_whosOnlineSessionIdArray[$key][0];			
			$tblWhos->addRow( $row  , "class='UnSelectedRow' onclick='TableRowClick(this,$rownum,\"$sessionId\")'" , 'TD' , true );
		}
		
		return $tblWhos->toHtml();
	}
	
	 function doDelete($sessionId)
	 {
		 $this->m_whosOnline->unregister($sessionId);
		 parent::CriaLog(MANAGESESSIONS_DELETE_BTN);
	 }
	
	function doDeleteDate ($date)
	{
		$this->m_whosOnline->deleteDatesBefore($date);
		parent::CriaLog(MANAGESESSIONS_DELETE_BTN);
	}
}
?>