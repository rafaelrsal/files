<?PHP
define('MANAGESESSIONS_MAIN_TXT','Manage OnWeb Web to Host Users');
define('MANAGESESSIONS_DELETE_MSG','Are you sure you would like to delete this entry?');
define('MANAGESESSIONS_DELETE_BTN','Delete');
define('MANAGESESSIONS_USER_COUNT_TXT','Number of simultaneous users: ');
define('MANAGESESSIONS_SESSIONS_COUNT', 'Number of simultaneous sessions: ');
define('MANAGESESSIONS_COL2','User Name');
define('MANAGESESSIONS_COL3','Local IP');
define('MANAGESESSIONS_COL4','Host IP');
define('MANAGESESSIONS_COL5','Logon Time');
define('MANAGESESSIONS_COL6','Last Operation Time');
define('MANAGESESSIONS_COL7','Host Type');
define('MANAGESESSIONS_DELETE_PERIODO','Remove registry dates before: ');
?>