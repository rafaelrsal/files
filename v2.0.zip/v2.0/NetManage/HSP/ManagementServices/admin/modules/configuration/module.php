<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:	Hoter Mickey
  		Udi Zisser
  		Guy Schetrit

  Date Created:	Mars 2004

  Title:           	module.php (configuration)
  Purpose:	Monitoring configuration module.
  Limitations:	Requires PHP 4.3.4 and up

 ============================================================================*/
require_once('HTML/QuickForm.php');
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');
require_once('Admin/includes/classes/webServiceProxy.php');
require_once('Admin/includes/classes/xmlGenerator.php');

class configuration extends ModuleBase
{
	var $m_proxyService;
	var $m_db;
	var $m_firstTime;
	var $m_serverStatus;
	var $m_maintenanceInerval;
	var $m_serverAddress;
	var $m_availableState;
	
	function configuration($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
	}

	function init()
	{
		parent::init("configuration");
		
		$this->m_firstTime 	= false;

		$this->getInterval();
		$this->getServerAddress();
		
		if ( is_null($this->m_maintenanceInerval) )
		{
			$this->m_maintenanceInerval = 0;
			$enableMonitoring 			= true;
			$this->m_firstTime 			= true; //intervals are null in the db only at the fist use

			if (isset($_SERVER['COMPUTERNAME']))
			{
				$this->m_serverAddress 	= $_SERVER['COMPUTERNAME'] . ':' . $_SERVER['SERVER_PORT'];
			}
		}

		$this->m_serverStatus 	= '';
		if ( !is_null($this->m_serverAddress) && strlen(trim($this->m_serverAddress)))
		{
			$this->m_proxyService = new webServiceProxy("http://$this->m_serverAddress/hspmonitoring/hspmoniisext.dll?hspmonsrv");

			// !!! all errors are ignored in the initialization proccess !!!
			$this->m_proxyService->initProxy();
			
			//gschetrit - workaround start
			// added @ to nusoup.php soap_parser() function in order to
			// eliminate index not found error in iis (when first calling the monitoring service)
			$tmpStack = array(); // tmp stack
			$this->getServerStatus(); // stab call
			//gschetrit - workaround end

			$this->getServerStatus();
		}
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('ConfigurationForm'); //default is post

		// Build the Configuration form:
		$this->m_form->addElement('text', 'address', SRV_SERVER_ADDRESS_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()"));
		$this->m_form->addElement('text', 'interval', SRV_INTERVAL_LBL, array('size' => 20, 'maxlength' => 20,'onchange' => "updated()",'style' => 'width:40px'));
		$this->m_form->addElement('text', 'serverstatus', SRV_STATUS_LBL, array('size' => 20, 'maxlength' => 255));
		
		$this->m_form->addElement('hidden', 'buttonClicked','');	
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		if ( SRV_DEACTIVATED_ERR == $this->m_serverStatus || SRV_NOT_CONFIGURED_ERR == $this->m_serverStatus || '' == $this->m_serverStatus )
		{
			$this->m_form->addElement('submit', 'startstop', SRV_START_BTN,"onclick='showWaitEx();onSave();return false;', class='NewButton' ShortFixedWidthObjects");
		}
		else
		{
			$this->m_form->addElement('submit', 'startstop', SRV_STOP_BTN,"onclick='showWaitEx();onSave();return false;', class='NewButton' ShortFixedWidthObjects");
		}

		$this->m_form->setDefaults(array(  	'interval'=>$this->m_maintenanceInerval ,									
											'address'=>$this->m_serverAddress,
											'serverstatus'=>$this->m_serverStatus));
	}
	
	function process()
	{
		$errorCode = null;
		// get all the POST values
		$formValuesArray = $this->m_form->getSubmitValues();

		$this->m_maintenanceInerval 	= htmlspecialchars($this->m_form->exportValue('interval'));
		$this->m_serverAddress			= htmlspecialchars($this->m_form->exportValue('address'));

		if ( 'POST' == $_SERVER['REQUEST_METHOD'])
		{
			$this->onSave();
			
			if ( SRV_START_BTN == $formValuesArray['buttonClicked'])
			{
				$enableMonitoring = true;	
				parent::CriaLog(SRV_START_BTN);
			}
			else
			{
				$enableMonitoring = false;
				parent::CriaLog(SRV_STOP_BTN);
			}
			
			$connType = 0; // 0 - ODBC, 1 - Detailed
			$this->getDBConfigParams($DBConnectArr, $connType);

			// enable the monitoring service via web service.
			if (!is_null($this->m_serverAddress) && strlen(trim($this->m_serverAddress)))
			{
				$this->m_proxyService = new webServiceProxy("http://$this->m_serverAddress/hspmonitoring/hspmoniisext.dll?hspmonsrv");

				if ($this->m_proxyService->initProxy())
				{
					$errorCode = array(SRV_INIT_WS_ERR_MSG);
				}
				else
				{
					$confRes = 0;
					if ( $enableMonitoring ) // perform service configuration only before start.
					{
						$xmlGenerator = new xmlGenerator();
						$xml = $xmlGenerator->generateXML( $connType, $this->m_maintenanceInerval , $DBConnectArr );
						$confRes = $this->m_proxyService->configureServer(str_replace ( '<?xml' , '&lt;?xml' , $xml));
					}
					
					if ( -1 ==  $confRes ) //error configuring server
					{
						$errorCode = array(HSP_ERR_SET_MON_CFG);
					}
					else
					{
						if ( -1 == $this->m_proxyService->activateServer($enableMonitoring))
						{
							$errorCode = array(HSP_ERR_ACTIVATE_MON_SERVER);
						}
						else
						{
							$ret = $this->getServerStatus();
							if ( HSP_SUCCESS != $ret )
							{
								$errorCode = array($ret);
							}
						}
					}
				}
			}
		}
				
		if ( SRV_DEACTIVATED_ERR == $this->m_serverStatus || SRV_NOT_CONFIGURED_ERR == $this->m_serverStatus || '' == $this->m_serverStatus )
		{				
			$this->m_form->setDefaults(array( 'startstop'=>SRV_START_BTN));
			$this->m_availableState = SRV_START_BTN;
		}
		else
		{
			$this->m_form->setDefaults(array( 'startstop'=>SRV_STOP_BTN));
			$this->m_availableState = SRV_STOP_BTN;
		}
		
		$this->m_form->setDefaults(array('serverstatus'=>$this->m_serverStatus));
		//get the server's status after reconfiguration.

		$statusElement = &$this->m_form->getElement('serverstatus');
		$statusElement->setValue($this->m_serverStatus);
		
		
		$startStopElement = &$this->m_form->getElement('startstop');
		
		if ( $startStopElement->getValue() == SRV_STOP_BTN )
		{
			$this->m_form->updateElementAttr('address',array('size' => 20, 'maxlength' => 255,'onchange' => "updated()" , 'disabled'=>true ));
			$this->m_form->updateElementAttr('interval',array('size' => 20, 'maxlength' => 20,'onchange' => "updated()",'style' => 'width:40px', 'disabled'=>true ));
		}
		
		$serverStatus = &$this->m_form->getElement('serverstatus');
		$serverStatus->freeze();

		if ( null != $errorCode )
		{
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}
	
	function finalize()
	{
		$arrVars = array( 	"avaliableButton"=>$this->m_availableState,
							"hostRequiredErrorMessage"=>SRV_HOST_REQUIRED_ERR,
							"maintenanceRequiredErrorMessage"=>SRV_MAINTENANCE_REQUIRED_ERR,
							"maintenanceNumericErrorMessage"=>SRV_MAINTENANCE_NUMERIC_ERR,
							"ClientConfigurationForm_required_note"=>SRV__REQUIRED_TXT );
							
		parent::finalize($arrVars);
	}

	function onSave()
	{
		$intervalMsec = $this->m_maintenanceInerval*MSEC_A_DAY; //translate interval to msec
		
		if ($this->m_firstTime) //use insert method only if it's the first time
		{
			$this->setData($intervalMsec/MSEC_A_DAY);
		}
		else
		{
			$this->updateData($intervalMsec/MSEC_A_DAY);
		}
	}
	
	// $DBConnectArr - connection parameters
	// $connType - connection type - ODBC or Detailed
	function getDBConfigParams(&$DBConnectArr, &$connType)
	{
		$dbConfig = new DBConfig();
		$errCode = $dbConfig->init();
		if ( $errCode != HSP_ERR_FILE_NOT_FOUND )
		{
			$dbConfig->DBDeserialize();
			$dbData = $dbConfig->getDBData();

			if ( 'odbc' == $dbData['phptype'] )
			{
				$connType = 0;
				$DBConnectArr['dsn'] 		= $dbData['hostspec'];
				$DBConnectArr['user_name'] 	= $dbData['username'];
				$DBConnectArr['password'] 	= $dbData['password'];
				$DBConnectArr['type'] 		= $dbData['dbsyntax'];
			}
			else
			{
				$connType = 1;
				$DBConnectArr['phptype']	= $dbData['phptype'];
				$DBConnectArr['address'] 	= $dbData['hostspec'];
				$DBConnectArr['port'] 		= $dbData['port'];
				$DBConnectArr['name'] 		= $dbData['database'];
				$DBConnectArr['username'] 	= $dbData['username'];
				$DBConnectArr['password'] 	= $dbData['password'];
			}
		}
		else
		{
			$this->m_session->set(SESSION_ERRORS, $errCode);
		}
	}

	function getInterval()
	{
		$maint_interval = null;
		$sql = 'select maint_interval from ' .  TABLE_SERVICE_CONFIG .';';
		$this->m_db->GetOne($sql, $this->m_maintenanceInerval);
	}

	function getServerAddress()
	{
		$this->m_serverAddress = null;
		$sql = 'select server_address from ' .  TABLE_SERVICE_CONFIG .';';
		$this->m_db->GetOne($sql, $this->m_serverAddress);
	}

	function setData($maintenanceInterval)
	{
		// id field is auto_increment
		$fields_values = array( 'maint_interval' =>$maintenanceInterval ,
								'server_address' =>$this->m_serverAddress );
		return $this->m_db->AutoExecute(TABLE_SERVICE_CONFIG, $fields_values);
	}

	function updateData($maintenanceInterval)
	{		
		$fields_values = array( 'maint_interval' =>$maintenanceInterval ,
								'server_address' =>$this->m_serverAddress );
		return $this->m_db->AutoExecute(TABLE_SERVICE_CONFIG, $fields_values, DB_AUTOQUERY_UPDATE);
	}

	function getServerStatus()
	{
		$ret = HSP_SUCCESS;
		
		$status = $this->m_proxyService->getServerStatus();
		$serverStatus = '';
		switch ($status)
		{
			case 168099841: // Server configured and activated.
			{
				$serverStatus = SRV_CONFIGURED_ERR;
				break;
			}
			case 168820738: // Server configured but deactivated temporally.
			{
				$serverStatus = SRV_DEACTIVATED_ERR;
				break;
			}
			case 168361987: // Server not configured.
			{
				$serverStatus = SRV_NOT_CONFIGURED_ERR;
				break;
			}
			default:
			{
				$ret = HSP_ERR_GET_SERVER_STATUS;
			}
		}
		
		$this->m_serverStatus = $serverStatus;
		return $ret;
	}
}
?>