<?PHP
define('SRV_HEADER_TXT' , 'Configurar Preferencias');
define('SRV_START_BTN','Iniciar');
define('SRV_STOP_BTN','Parar');
define('SRV_INTERVAL_LBL','Intervalo de Manuten��o (dias):');
define('SRV_MONITORING_LBL','Habilitar servidor de monitoramento');
define('SRV_HEARTBEAT_REQ_MSG', 'Informar intervalo de Keep Alive');
define('SRV_REQUIRED_TXT','verifique os campos obrigat�rios');
define('SRV_SERVER_ADDRESS_LBL','Endere�o do servidor de monitoramento (endere�o:porta):');
define('SRV_INIT_WS_ERR_MSG','Erro ao inicializar o web service');
define('SRV_STATUS_LBL','Status do Servi�o:');

define('SRV_HOST_REQUIRED_ERR','Informe o endere�o do host.');
define('SRV_MAINTENANCE_REQUIRED_ERR','Informe o intervalo de manuten��o.');
define('SRV_MAINTENANCE_NUMERIC_ERR','O intervalo de manuten��o deve ser um inteiro positivo.');

define('SRV_CONFIGURED_ERR','Servi�o configurado e ativado.');
define('SRV_DEACTIVATED_ERR','Servi�o configurado e desativado.');
define('SRV_NOT_CONFIGURED_ERR', 'Servi�o n�o configurado.');
define('SRV__REQUIRED_TXT','verifique os campos obrigat�rios');
?>
