<?PHP
define('SRV_HEADER_TXT' , 'Configure Preferences');
define('SRV_START_BTN','Start');
define('SRV_STOP_BTN','Stop');
define('SRV_INTERVAL_LBL','Maintenance interval (days):');
define('SRV_MONITORING_LBL','Enable monitoring server');
define('SRV_HEARTBEAT_REQ_MSG', 'Keep Alive interval is missing');
define('SRV_REQUIRED_TXT','denotes required field');
define('SRV_SERVER_ADDRESS_LBL','Monitoring server address (address:port):');
define('SRV_INIT_WS_ERR_MSG','Error initializing web service');
define('SRV_STATUS_LBL','Service status:');

define('SRV_HOST_REQUIRED_ERR','Enter a host address.');
define('SRV_MAINTENANCE_REQUIRED_ERR','Maintenance interval is missing.');
define('SRV_MAINTENANCE_NUMERIC_ERR','Maintenance  interval should be a positive integer.');

define('SRV_CONFIGURED_ERR','Service configured and activated.');
define('SRV_DEACTIVATED_ERR','Service configured and deactivated.');
define('SRV_NOT_CONFIGURED_ERR', 'Service not configured.');
define('SRV__REQUIRED_TXT','denotes required field');
?>
