<?PHP
define('IMPORT_IMPORT_DIR_MAIN_TXT','Directories Configuration');
define('IMPORT_DIR_TYPE_LBL','Type:');
define('IMPORT_DIR_IMPORT_DIR_NAME_LBL','Directory name:');
define('IMPORT_DIR_HOST_LBL','Host:');
define('IMPORT_DIR_PORT_LBL','Port:');
define('IMPORT_DIR_USER_DN','User DN:');
define('IMPORT_DIR_GROUP_DN','Group DN:');
define('IMPORT_DIR_BASE_DN','Base DN:');
define('IMPORT_DIR_LIST_TXT','Current Directories:');
define('IMPORT_DIR_CLEAR_BTN','New');
define('IMPORT_DIR_SAVE_BTN','Save');
define('IMPORT_DIR_EDIT_BTN','Edit');
define('IMPORT_DIR_DELETE_BTN','Delete');
define('IMPORT_DIR_NEXT_BTN','Next >');
define('IMPORT_DIR_CLEARFORM_BTN','Clear');

define('IMPORT_DIR_AUTHENTICATE_LBL','Authenticate');
define('IMPORT_DIR_REQUIRED_TXT','denotes required field');

define('IMPORT_DIR_PORT_REQ_MSG','Enter a port');
define('IMPORT_DIR_BASEDN_REQ_MSG','Enter base dn');
define('IMPORT_DIR_USERDN_REQ_MSG','Enter user dn');
define('IMPORT_DIR_GROUPDN_REQ_MSG','Enter group dn');
define('IMPORT_DIR_HOST_REQ_MSG','Enter host');
define('IMPORT_DIR_USER_ID_REQ_MSG','Enter user identifier');
define('IMPORT_DIR_DIRNAME_REQ_MSG','Enter directory name');

define('IMPORT_DIR_USER_IDETIFIER_LBL','User identifier:');
define('IMPORT_DIR_PORT_ERR_MSG','Port number should be an integer between 0 and 65536');
define('IMPORT_DIR_TYPE_NT','NT Domain');
define('IMPORT_DIR_TYPE_ADS','Active Directory');
define('IMPORT_DIR_TYPE_SUNONE','LDAP');
define('IMPORT_DIR_TYPE_EDIRECTORY','eDirectory');
define('IMPORT_DIR_TYPE_CUSTOM','Custom Directory');
define('IMPORT_DIR_DELETE_CONFIRMATION','Are you sure you want to delete the selected directory?\nDeleting a directory completely removes it and all related information,\nsuch as groups and users, from the HSP database.');
define('IMPORT_DIR_CANCEL_BTN','Cancel');
define('IMPORT_DIR_DIRECTORY_LBL','Directory');
define('IMPORT_DIR_TITLE_LBL','Import Into');
define('IMPORT_DIR_CHANGES','There are unsaved changes on this page. OK to ignore changes?');
?>