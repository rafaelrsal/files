<?PHP
define('IMPORT_IMPORT_DIR_MAIN_TXT','Configura��o de Diret�rios');
define('IMPORT_DIR_TYPE_LBL','Tipo:');
define('IMPORT_DIR_IMPORT_DIR_NAME_LBL','Nome do Diret�rio:');
define('IMPORT_DIR_HOST_LBL','Host:');
define('IMPORT_DIR_PORT_LBL','Porta:');
define('IMPORT_DIR_USER_DN','Usu�rio DN:');
define('IMPORT_DIR_GROUP_DN','Grupo DN:');
define('IMPORT_DIR_BASE_DN','Base DN:');
define('IMPORT_DIR_LIST_TXT','Diret�rio Corrente:');
define('IMPORT_DIR_CLEAR_BTN','Novo');
define('IMPORT_DIR_SAVE_BTN','Savar');
define('IMPORT_DIR_EDIT_BTN','Ediart');
define('IMPORT_DIR_DELETE_BTN','Remover');
define('IMPORT_DIR_NEXT_BTN','Pr�ximo >');
define('IMPORT_DIR_CLEARFORM_BTN','Limpar');

define('IMPORT_DIR_AUTHENTICATE_LBL','Autenticar');
define('IMPORT_DIR_REQUIRED_TXT','verificar campos obrigat�rios');

define('IMPORT_DIR_PORT_REQ_MSG','Informe a porta');
define('IMPORT_DIR_BASEDN_REQ_MSG','Informe a base dn');
define('IMPORT_DIR_USERDN_REQ_MSG','Informe o usu�rio dn');
define('IMPORT_DIR_GROUPDN_REQ_MSG','Informe o grupo dn');
define('IMPORT_DIR_HOST_REQ_MSG','Informe o host');
define('IMPORT_DIR_USER_ID_REQ_MSG','Informe o identificador do usu�rio');
define('IMPORT_DIR_DIRNAME_REQ_MSG','Informe o nome do diret�rio');

define('IMPORT_DIR_USER_IDETIFIER_LBL','Identificador do usu�rio:');
define('IMPORT_DIR_PORT_ERR_MSG','A Porta deve ser um n�mero inteiro entre 0 e 65536');
define('IMPORT_DIR_TYPE_NT','Dom�nio NT');
define('IMPORT_DIR_TYPE_ADS','Active Directory');
define('IMPORT_DIR_TYPE_SUNONE','LDAP');
define('IMPORT_DIR_TYPE_EDIRECTORY','eDirectory');
define('IMPORT_DIR_TYPE_CUSTOM','Diret�rio Customizado');
define('IMPORT_DIR_DELETE_CONFIRMATION','Voc� tem certeza que deseja remover os diret�rios selecionados?\nRemovendo completamente o diret�rio, voc� tamb�m ir� remover todas as informa��es relacionadas a ele,\ntais como grupos e usu�rios, do database do HSP.');
define('IMPORT_DIR_CANCEL_BTN','Cancelar');
define('IMPORT_DIR_DIRECTORY_LBL','Diret�rio');
define('IMPORT_DIR_TITLE_LBL','Importar para');
define('IMPORT_DIR_CHANGES','Existem altera��o n�o salvas nesta p�gina. OK para ignorar as altera��es?');
?>