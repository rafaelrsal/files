<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Aug 2004
  Title: module.php (directories)
  Purpose: System directories configuration
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

require_once('admin/includes/classes/authentication.php');
require_once('admin/modules/DirectoryAuth/module.php');

define('SESSSION_DIRCONFIG_PARAMS','dirConfigParams');
define('INTERNALDIR_ID', 'internalDirId');

class importDirectories extends ModuleBase
{
	var $m_dirArray = array();
	var $m_trustedDominsArray;
	var $m_customDirArray;
		
	// directory list
	var $m_dirTypeValues;
	var $m_dirTypesArray;
	
	// authentication
	var $m_dirAuthObj;
	var $m_bisAuthenticated;
	
	var $m_paramList;
	
	function importDirectories($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		parent::init("importDirectories");
		$this->m_db = &parent::GetDatabase();
		$this->m_db->connect();
		
		$this->m_dirTypeValues = array( IMPORT_DIR_TYPE_CUSTOM=>'0',IMPORT_DIR_TYPE_ADS=>'1',IMPORT_DIR_TYPE_SUNONE=>'2',IMPORT_DIR_TYPE_EDIRECTORY=>'3',IMPORT_DIR_TYPE_NT=>'4' );
		$this->m_dirTypesArray = array(	$this->m_dirTypeValues[IMPORT_DIR_TYPE_ADS]=>IMPORT_DIR_TYPE_ADS,
										$this->m_dirTypeValues[IMPORT_DIR_TYPE_SUNONE]=>IMPORT_DIR_TYPE_SUNONE,
										$this->m_dirTypeValues[IMPORT_DIR_TYPE_NT]=>IMPORT_DIR_TYPE_NT,
										$this->m_dirTypeValues[IMPORT_DIR_TYPE_EDIRECTORY]=>IMPORT_DIR_TYPE_EDIRECTORY,
										$this->m_dirTypeValues[IMPORT_DIR_TYPE_CUSTOM]=>IMPORT_DIR_TYPE_CUSTOM										
										);
		
		$this->m_paramList = array();
		$this->m_bisAuthenticated = 'false';
		
		// Instantiate the HTML_QuickForm object
		$formName = 'importDirectoriesForm';
		$this->m_form = new HTML_QuickForm($formName); //default is post
		$this->m_dirAuthObj = new directoryAuth($globalobjects, $formName);
		$this->m_dirAuthObj->init();
		$this->m_dirAuthObj->process();
		$this->m_dirAuthObj->finalize();
	}
	
	function init()
	{
		$this->getTrustedDomains();
		$this->getCustomDirNames();
		
		if (is_null($this->m_trustedDominsArray))
		{
			unset($this->m_dirTypesArray[$this->m_dirTypeValues[IMPORT_DIR_TYPE_NT]]);
		}		

		if (is_null($this->m_customDirArray))
		{
			unset($this->m_dirTypesArray[$this->m_dirTypeValues[IMPORT_DIR_TYPE_CUSTOM]]);
		}		
		
		// Build the database form:
		$this->m_form->addElement('submit', 'next',		IMPORT_DIR_NEXT_BTN, 'class="NewButton" onclick="openVerifyWindow(); return false;"');
		$this->m_form->addElement('button', 'clear', 	IMPORT_DIR_CLEARFORM_BTN, 'class="NewButton" onclick="onClear();"');
		$this->m_form->addElement('button', 'cancel',		IMPORT_DIR_CANCEL_BTN,	"onclick=onCancel() class='NewButton'");
		
		$this->m_form->addElement('hidden', 'buttonClicked','');		
		$this->m_form->addElement('select', 'type', IMPORT_DIR_TYPE_LBL,$this->m_dirTypesArray, 'onChange="onChangeType(true)" onkeypress="DoDefaultEnterKey(event)" class="FixedWidthObjects"');
		// just for NT Domain
		$this->m_form->addElement('select', 'dirname', IMPORT_DIR_IMPORT_DIR_NAME_LBL, $this->m_trustedDominsArray ,'class="FixedWidthObjects" onkeypress="DoDefaultEnterKey(event)"');
		
		// just for Custom dir		
		$this->m_form->addElement('select', 'customDirList', IMPORT_DIR_IMPORT_DIR_NAME_LBL, $this->m_customDirArray, 'class="FixedWidthObjects" onkeypress="DoDefaultEnterKey(event)"');
		$this->m_form->addElement('text', 'host', IMPORT_DIR_HOST_LBL, array('size' => 20, 'maxlength' => 255, 'class'=>"FixedWidthObjects"));
		$this->m_form->addElement('text', 'port', IMPORT_DIR_PORT_LBL, array('size' => 5, 'maxlength' => 5));
		$this->m_form->addElement('text', 'basedn', IMPORT_DIR_BASE_DN, array('size' => 20, 'maxlength' => 255, 'style' => 'width:200px'));
		$this->m_form->addElement('text', 'user', IMPORT_DIR_USER_DN, array('size' => 20, 'maxlength' => 255, 'style' => 'width:200px'));
		$this->m_form->addElement('text', 'group', IMPORT_DIR_GROUP_DN, array('size' => 20, 'maxlength' => 255, 'style' => 'width:200px'));
		$this->m_form->addElement('text', 'user_identifier', IMPORT_DIR_USER_IDETIFIER_LBL, array('size' => 20, 'maxlength' => 255, 'style' => 'width:200px'));		
		
		$this->m_form->addElement('hidden', 'error2', IMPORT_DIR_HOST_REQ_MSG);
		$this->m_form->addElement('hidden', 'error3', IMPORT_DIR_PORT_ERR_MSG);
		$this->m_form->addElement('hidden', 'error4', IMPORT_DIR_BASEDN_REQ_MSG);
		$this->m_form->addElement('hidden', 'error5', IMPORT_DIR_USERDN_REQ_MSG);
		$this->m_form->addElement('hidden', 'error6', IMPORT_DIR_GROUPDN_REQ_MSG);
		$this->m_form->addElement('hidden', 'error7', IMPORT_DIR_USER_ID_REQ_MSG);
		
		//**************************GUILHERME LIMA 17/04/2013******************************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		//*********************************************************************************
	}
	
	function process()
	{
		$errorCode = HSP_SUCCESS;
		
		if ( isset($_GET['prevModule']) && $_GET['prevModule'] == 'importConfiguration' )
		{
			$this->setParamsDefaults();			
		}
		else 
		{
			$this->saveParamsToSession(); // to be used when browsed back from next page
		}
		
		$formValuesArray = $this->m_form->exportValues();	
		
		if (isset( $_POST['buttonClickedAuth'] ) && 'ok' == $_POST['buttonClickedAuth'])
		{			
			if ( !$this->authenticate() )
			{					
				$errorCode = HSP_ERR_AUTHENTICATION_ERROR;
			}
		}
		if ( HSP_SUCCESS == $errorCode )
		{
			// custom directory - no need for authentication
			if (isset( $_POST['buttonClicked'] ) && 'next' == $_POST['buttonClicked'])
			{
				// redirection is done by the javascrip
				// inorder to launch the pls wait dialog
				$this->m_bisAuthenticated = 'true';
			}
		}
		
		if ( null != $errorCode )
		{
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}
	
	function finalize()
	{
		$arrVars = array(
				'lblDelete'=>IMPORT_DIR_DELETE_BTN,
				'lblNew'=>IMPORT_DIR_CLEAR_BTN,
				'lblIMPORT_DIR_DELETE_CONFIRMATION'=>IMPORT_DIR_DELETE_CONFIRMATION,
				'lblVerify'=>IMPORT_DIR_NEXT_BTN,		
				'lblDirectory'=>IMPORT_DIR_DIRECTORY_LBL,
				'importDirectoriesForm_required_note'=>IMPORT_DIR_REQUIRED_TXT,
				'authTitle'=>IMPORT_DIR_AUTHENTICATE_LBL,		
				'moduleName'=>  $this->m_moduleName,
				'authenticationDiv'=>  $this->m_dirAuthObj->GetContent(),
				'customDirLabel'=> IMPORT_DIR_TYPE_CUSTOM,
				'mainTitle'=>IMPORT_DIR_TITLE_LBL,
				'titleDirName'=>$this->getDirName(),
				'strMesg'=>IMPORT_DIR_CHANGES,
				'roll'=> $_SESSION['roll'],
				'bisAuthenticated'=>$this->m_bisAuthenticated );

      
		$moduleName = 'importDirectories';
    	$this->m_session->set(SESSION_PREV_MODULE, $moduleName );
    	parent::finalize($arrVars, "importDirectories");
	}

	function getTrustedDomains()
	{
		$this->m_trustedDominsArray = array();
		if ( $this->m_session->exists(SESSION_TRUSTEDDOMAINS_CACHE) )
		{
			$this->m_trustedDominsArray =  $this->m_session->value(SESSION_TRUSTEDDOMAINS_CACHE);
		}
		else
		{
			if(!extension_loaded(PHP_AUTH_MODULE))
			{
				dl(PHP_AUTH_DLL);
			}

			$domains = gettrusteddomains();
			if (is_array($domains) && count($domains))
			{
				foreach ($domains as $domain)
				{
					$this->m_trustedDominsArray[$domain] = $domain;
				}

				// cache the domains for later use.
				if ( count($this->m_trustedDominsArray) )
				{
					natcasesort($this->m_trustedDominsArray);
					$this->m_session->set(SESSION_TRUSTEDDOMAINS_CACHE, $this->m_trustedDominsArray);
				}
			}
			else
			{
				$this->m_trustedDominsArray = null;
			}
		}
	}
	
	function authenticate()
	{
		$dirAuthObj = new authentication( $this->m_db ,$this->m_session );
		
		return $dirAuthObj->authenticateByParams( $this->m_paramList );	
	}
	
	function getCustomDirNames()
	{
		$customDirNames = $this->getCustomDirsList();
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		if ( count($customDirNames) )
		{			
			foreach ($customDirNames as $dirItem )
			{
				if ( $dirItem['id'] != $dirId)
				{
					$this->m_customDirArray[$dirItem['id']] = $dirItem['name'];
				}
			}
		}
	}
	
	function getCustomDirsList()
	{	
		$sql = "SELECT id, name FROM ".TABLE_CUSTOM_DIRECTORY . ";";
		$ret = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		
		if ( DB::isError($ret) )
		{
			$ret  = HSP_ERR_DB_SQL_ERROR;
		}
		return $ret;
	}
	
	function saveParamsToSession()
	{
		$host 			= htmlspecialchars($this->m_form->exportValue('host'));
		$port 			= htmlspecialchars($this->m_form->exportValue('port'));
		$basedn 		= htmlspecialchars($this->m_form->exportValue('basedn'));
		$userdn 		= htmlspecialchars($this->m_form->exportValue('user'));
		$groupdn 		= htmlspecialchars($this->m_form->exportValue('group'));
		$userIdentifier = htmlspecialchars($this->m_form->exportValue('user_identifier'));
		$type 			= htmlspecialchars($this->m_form->exportValue('type'));
				
		$dirname = null;
		
		if ( '0' == $type )
		{
			$dirnameElement =  &$this->m_form->getElement('customDirList');
			$domainArr = $dirnameElement->getSelected();
			$dirname = $this->m_customDirArray[$domainArr[0]];
		}
		elseif ( '4' == $type )
		{
			$dirnameElement =  &$this->m_form->getElement('dirname');
			$domainArr = $dirnameElement->getSelected();
			$dirname = $this->m_trustedDominsArray[$domainArr[0]];
		}
		
		
		$this->m_paramList['type_dir'] = $type;
		if (  '0' == $type )
		{
			$this->m_paramList['dirname'] 			= $dirname;
			$this->m_paramList['port'] 				= null;
			$this->m_paramList['base_dn'] 			= null;
			$this->m_paramList['host'] 				= $dirname;
			$this->m_paramList['group_dn'] 			= null;
			$this->m_paramList['user_dn'] 			= null;
			$this->m_paramList['ldap_user_identifier'] 	= null;
			$this->m_paramList['customDir'] 		= $domainArr[0];
		}
		elseif ( '1' == $type ) // DIR_TYPE_ADS
		{
			$this->m_paramList['port'] 				= $port;
			$this->m_paramList['base_dn']			= null;
			$this->m_paramList['host'] 				= $host;
			$this->m_paramList['group_dn'] 			= null;
			$this->m_paramList['user_dn'] 			= null;
			$this->m_paramList['ldap_user_identifier'] 	= null;
			$this->m_paramList['dirname'] 			= '';
		}
		elseif ( '2' == $type ) //DIR_TYPE_SUNONE
		{
			$this->m_paramList['port'] 				= $port;
			$this->m_paramList['base_dn']			= $basedn;
			$this->m_paramList['host'] 				= $host;
			$this->m_paramList['group_dn'] 			= $groupdn;
			$this->m_paramList['user_dn'] 			= $userdn;
			$this->m_paramList['ldap_user_identifier'] 	= $userIdentifier;
			$this->m_paramList['dirname'] 			= '';
		}
		elseif ( '3' == $type ) // DIR_TYPE_EDIRECTORY
		{
			$this->m_paramList['port'] 				= $port;
			$this->m_paramList['base_dn']			= null;
			$this->m_paramList['host'] 				= $host;
			$this->m_paramList['group_dn'] 			= null;
			$this->m_paramList['user_dn'] 			= null;
			$this->m_paramList['ldap_user_identifier'] 	= null;
			$this->m_paramList['dirname'] 			= '';
		}
		elseif ( '4' == $type  ) //DIR_TYPE_NT
		{
			$this->m_paramList['dirname'] 			= $dirname;
			$this->m_paramList['port'] 				= null;
			$this->m_paramList['base_dn'] 			= null;
			$this->m_paramList['host'] 				= $dirname;
			$this->m_paramList['group_dn'] 			= null;
			$this->m_paramList['user_dn'] 			= null;
			$this->m_paramList['ldap_user_identifier'] 	= null;
		}

		if (isset($_POST['username']))
		{
			$this->m_paramList['username'] = $_POST['username'];
		}
		if (isset($_POST['password']))
		{
			$this->m_paramList['password'] = $_POST['password'];
		}
		
		$this->m_session->set(SESSSION_DIRCONFIG_PARAMS, $this->m_paramList );
	}
	
	function setParamsDefaults()
	{
		$this->m_paramList = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
		
		if ( isset($this->m_paramList['type_dir']) )
		{
			$typeElement = &$this->m_form->getElement('type');		
			$typeElement->setSelected($this->m_paramList['type_dir']);
		}
		if ( isset($this->m_paramList['host']) )
		{
			$hostElement = &$this->m_form->getElement('host');
			$hostElement->setValue($this->m_paramList['host']);
		}
		if ( isset($this->m_paramList['port']) )
		{
			$portElement = &$this->m_form->getElement('port');
			$portElement->setValue($this->m_paramList['port']);
		}
		if ( isset($this->m_paramList['base_dn']) )
		{
			$basednElement = &$this->m_form->getElement('base_dn');
			$basednElement->setValue($this->m_paramList['base_dn']);
		}
		if ( isset($this->m_paramList['group_dn']) )
		{
			$groupdnElement = &$this->m_form->getElement('group_dn');
			$groupdnElement->setValue($this->m_paramList['group_dn']);
		}
		if ( isset($this->m_paramList['user_dn']) )
		{
			$userdnElement = &$this->m_form->getElement('user_dn');
			$userdnElement->setValue($this->m_paramList['user_dn']);
		}
		if ( isset($this->m_paramList['ldap_user_identifier']) )
		{
			$ldapIdElement = &$this->m_form->getElement('ldap_user_identifier');
			$ldapIdElement->setValue($this->m_paramList['ldap_user_identifier']);
		}
		if ( isset($this->m_paramList['dirname']) )
		{
			$dirnameElement = &$this->m_form->getElement('dirname');
			$dirnameElement->setSelected($this->m_paramList['dirname']);
		}
		if ( isset($this->m_paramList['customDir']) )
		{
			$customElement = &$this->m_form->getElement('customDirList');
			$customElement->setSelected($this->m_paramList['customDir']);
		}
	}

	function getDirName()
	{	
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		$sql = "SELECT name FROM ".TABLE_CUSTOM_DIRECTORY . " WHERE id=$dirId;";
		
		$this->m_db->GetOne($sql, $name);
		
		return $name;
	}	
}
?>