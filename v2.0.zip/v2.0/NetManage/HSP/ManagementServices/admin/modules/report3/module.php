<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: report3.php
  Purpose: report
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once 'HTML/QuickForm/Renderer/ITStatic.php';
require_once('HTML/QuickForm.php');
require_once 'HTML/Template/Sigma.php';

require_once('includes/classes/boxes.php');
require_once('HTML/Table.php');
require_once('includes/classes/PearDB.php');
require_once('Admin/includes/classes/reportGenerator.php');

class report3 extends ModuleBase
{
	var $m_db;
	var $m_reportGenerator;

	function report3($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db = &parent::GetDatabase();
		$this->m_db->connect();

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('report3Form'); //default is post
	}

	function  init()
	{
		parent::init("report3");

		$this->m_form->addElement('header', 'header', REPORT3_MAIN_TXT);
		$this->m_form->addElement('submit', 'back', REPORT3_BACK_BTN,"class='NewButton'");
		$this->m_form->addElement('submit', 'print', REPORT3_PRINT_BTN, 'class="NewButton" onclick = report.focus();window.print();');
		$this->m_form->addElement('submit', 'export', REPORT3_EXPORT_BTN,"class='NewButton'");
		$this->m_form->addElement('text', 'fromdate', REPORT_DATE_LBL);
		$this->m_form->addElement('text', 'fromtime', REPORT_TIME_LBL);
		$this->m_form->addElement('text', 'todate', REPORT_DATE_LBL);
		$this->m_form->addElement('text', 'totime', REPORT_TIME_LBL);

		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$tmpElement = &$this->m_form->getElement('fromdate');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('fromtime');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('todate');
		$tmpElement->freeze();
		$tmpElement = &$this->m_form->getElement('totime');
		$tmpElement->freeze();
	}

	function process()
	{
		$formValuesArray = $this->m_form->exportValues();

		$fromDate = $this->m_session->value('fromDate');
		$toDate = $this->m_session->value('toDate');
		$fromTime = $this->m_session->value('fromTime');
		$toTime = $this->m_session->value('toTime');

		$this->m_form->setDefaults(array('fromdate'=>$fromDate, 'todate'=>$toDate,'fromtime'=>$fromTime.':00:00','totime'=>$toTime.':00:00'));

		$this->m_reportGenerator = new reportGenerator(REPORT3_MAIN_TXT, $this->m_language , "reports" );
		$this->m_reportGenerator->createHeaderTxt(REPORT3_MAIN_TXT,$fromDate, $toDate, $fromTime, $toTime);
		$colArr = array(REPORT3_COL1,REPORT3_COL2,REPORT3_COL3,REPORT3_COL4,REPORT3_COL5,REPORT3_COL6,REPORT3_COL7,REPORT3_COL8,REPORT3_COL9);
		$table = $this->m_reportGenerator->createTable($this->m_db, TABLE_REGISTRATION_INFO, $colArr, $this->formSQL($fromDate, $toDate, $fromTime, $toTime));

		$this->m_db->disconnect();

		if ( array_key_exists("back", $formValuesArray) )
		{
			$this->goBack($fromDate, $toDate, $fromTime, $toTime);
		}
		elseif ( array_key_exists("export", $formValuesArray))
		{
			parent::CriaLog(REPORT3_EXPORT_BTN);
			$this->m_reportGenerator->downloadCSV();
		}

		$res = $this->m_reportGenerator->prepareReportPage();

		if(HSP_SUCCESS != $res)
		{
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}

	function finalize()
	{
		$arrVars = array(	"report3Form_from_txt"=>REPORT_FROM_TXT,
							"report3Form_to_txt"=>REPORT_TO_TXT,
							"report3Form_table"=>$this->m_reportGenerator->getReportAsIFrame());

		parent::finalize($arrVars);

	}

	function goBack($fromDate, $toDate, $fromTime, $toTime)
	{
		$this->m_session->set('fromDate', $fromDate);
		$this->m_session->set('toDate', $toDate);
		$this->m_session->set('fromTime', $fromTime);
		$this->m_session->set('toTime', $toTime);

		$this->m_session->set('reportName', $this->m_moduleName);

		Header('Location: admin.php?module=reports&roll='.$_POST['roll']);
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		exit();
	}

	function formSQL($fromDate, $toDate, $fromTime, $toTime)
	{
		if ( 'mysql' == $this->m_db->getDBSyntax() )
		{
			$sql="SELECT
		 	T1.LOGGED_ON_USER AS USER, T1.CLIENT_IP_ADDRESS AS CLIENT ,
		 	T1.START AS START_TIME, '".REPORT_YES_TXT."' AS ACTIVE,
			 SEC_TO_TIME( unix_timestamp(SYSDATE()) - unix_timestamp(T1.START) ) AS DURATION, T1.APPLICATION_TYPE,T1.EMULATION_TYPE,
			 T1.SESSION_NAME, T1.CLIENT_PLATFORM
			 FROM `".TABLE_REGISTRATION_INFO."` T1
		         WHERE
			 	T1.REGISTER_STATUS=1
				AND	(( (((T1.HEARTBEAT_INTERVAL /1000) + 60 + unix_timestamp(T1.END_TIME)) >= unix_timestamp(SYSDATE())
										 OR
										 T1.HEARTBEAT_INTERVAL = 0
										 )
									  )
			 AND ( T1.START >= '$fromDate $fromTime:00:00'
					 			  AND T1.END_TIME < '$toDate $toTime:00:00')
								)
			 LIMIT 0 , 1666
			 UNION
			 SELECT
			  	 T1.LOGGED_ON_USER AS USER, T1.CLIENT_IP_ADDRESS AS CLIENT , T1.START AS START_TIME,
			 	 '".REPORT_NO_TXT."' AS ACTIVE,
			 	 SEC_TO_TIME( unix_timestamp(T1.END_TIME) - unix_timestamp(T1.START) + (T1.HEARTBEAT_INTERVAL/1000) + 60  ) AS DURATION,
			 	 T1.APPLICATION_TYPE, T1.EMULATION_TYPE,
			 	 T1.SESSION_NAME, T1.CLIENT_PLATFORM
			 FROM
			 	`".TABLE_REGISTRATION_INFO."` T1
			 WHERE
			 T1.REGISTER_STATUS=1
			 				AND
			 				( (((T1.HEARTBEAT_INTERVAL /1000) + 60 + unix_timestamp(T1.END_TIME)) < unix_timestamp(SYSDATE()))
			 				  AND
			 				  (T1.HEARTBEAT_INTERVAL != 0)
			 				)
			 				AND
			 				( T1.START >= '$fromDate $fromTime:00:00'
			 				 AND
			 				 T1.END_TIME < '$toDate $toTime:00:00'
			 				)
			 LIMIT 0 , 1666
			 UNION
			 SELECT
			  	 T1.LOGGED_ON_USER AS USER, T1.CLIENT_IP_ADDRESS AS CLIENT , T1.START AS START_TIME,
			 	 '".REPORT_NO_TXT."' AS ACTIVE, SEC_TO_TIME( unix_timestamp(T1.END_TIME) - unix_timestamp(T1.START)) AS DURATION, T1.APPLICATION_TYPE, T1.EMULATION_TYPE,
			 	 T1.SESSION_NAME, T1.CLIENT_PLATFORM
			 FROM
			 	`".TABLE_REGISTRATION_INFO."` T1
			 WHERE
			 				T1.REGISTER_STATUS=0
			 				AND
			 				( T1.START >= '$fromDate $fromTime:00:00'
			 				 AND
			 				 T1.END_TIME < '$toDate $toTime:00:00'
			 				)
			 ORDER BY START_TIME LIMIT 0 , 1666;
			 ";
		}
		elseif ( 'mssql' == $this->m_db->getDBSyntax() )
		{
			$sql = "SELECT TOP 1666 T1.LOGGED_ON_USER AS 'USER', T1.CLIENT_IP_ADDRESS AS CLIENT, T1.START AS START_TIME,
										 'Yes' AS ACTIVE, CONVERT(char(10),GETDATE() - START, 108) AS DURATION,
										 T1.APPLICATION_TYPE,T1.EMULATION_TYPE,T1.SESSION_NAME, T1.CLIENT_PLATFORM
						FROM         hsp_registration_info T1
						WHERE     T1.REGISTER_STATUS = 1
										AND
										(
										   (
											   (DATEDIFF(second, END_TIME, GETDATE()) < (HEARTBEAT_INTERVAL / 1000 + 60))
											   OR
											   (T1.HEARTBEAT_INTERVAL = 0)
											)
											AND
											(T1.START >= '$fromDate $fromTime:00:00' AND T1.END_TIME < '$toDate $toTime:00:00'))
						UNION
							SELECT TOP 1666
								T1.LOGGED_ON_USER AS 'USER',
								T1.CLIENT_IP_ADDRESS AS CLIENT,
								T1.START AS START_TIME,
								'".REPORT_NO_TXT."' AS ACTIVE,
								CONVERT(char(10), T1.END_TIME - T1.START + (T1.HEARTBEAT_INTERVAL/1000) + 60,108) AS DURATION,
								T1.APPLICATION_TYPE,
								T1.EMULATION_TYPE,
								T1.SESSION_NAME,
								T1.CLIENT_PLATFORM
							FROM ".TABLE_REGISTRATION_INFO." T1
							WHERE
								T1.REGISTER_STATUS=1
								AND
								(
									(DATEDIFF(second, END_TIME, GETDATE()) > (HEARTBEAT_INTERVAL / 1000 + 60))
									AND
									(T1.HEARTBEAT_INTERVAL != 0)
								)
								AND
								 ( T1.START >= '$fromDate $fromTime:00:00' AND T1.END_TIME < '$toDate $toTime:00:00' )

						UNION
							SELECT TOP 1666
									T1.LOGGED_ON_USER AS 'USER',
									T1.CLIENT_IP_ADDRESS AS CLIENT ,
									T1.START AS START_TIME,
									'".REPORT_NO_TXT."' AS ACTIVE,
									CONVERT(char(10), T1.END_TIME - T1.START,108) AS DURATION,
									T1.APPLICATION_TYPE,
									T1.EMULATION_TYPE,
									T1.SESSION_NAME,
									T1.CLIENT_PLATFORM
							FROM ".TABLE_REGISTRATION_INFO." T1
							WHERE
									T1.REGISTER_STATUS=0
									AND
									( T1.START >= '$fromDate $fromTime:00:00' AND T1.END_TIME < '$toDate $toTime:00:00' )
						ORDER BY START_TIME ";

		}
		return $sql;
	}
}
?>