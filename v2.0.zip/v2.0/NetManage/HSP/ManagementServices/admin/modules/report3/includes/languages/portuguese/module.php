<?PHP
define('REPORT3_MAIN_TXT','Aplica��es Registradas');
define('REPORT3_BACK_BTN','< Voltar');
define('REPORT3_PRINT_BTN','Imprimir');
define('REPORT3_EXPORT_BTN','Exportar');
define('REPORT3_COL1','Nome do Usu�rio');
define('REPORT3_COL2','Cliente');
define('REPORT3_COL3','Hor�rio de In�cio');
define('REPORT3_COL4','Ativo');
define('REPORT3_COL5','Dura��o');
define('REPORT3_COL6','Aplica��o');
define('REPORT3_COL7','Tipo de Emula��o');
define('REPORT3_COL8','Sess�o');
define('REPORT3_COL9','Plataforma');

?>