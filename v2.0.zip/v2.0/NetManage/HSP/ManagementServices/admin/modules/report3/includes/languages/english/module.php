<?PHP
define('REPORT3_MAIN_TXT','Registered Applications');
define('REPORT3_BACK_BTN','< Back');
define('REPORT3_PRINT_BTN','Print');
define('REPORT3_EXPORT_BTN','Export');
define('REPORT3_COL1','User Name');
define('REPORT3_COL2','Client');
define('REPORT3_COL3','Start Time');
define('REPORT3_COL4','Active');
define('REPORT3_COL5','Duration');
define('REPORT3_COL6','Application');
define('REPORT3_COL7','Emulator Type');
define('REPORT3_COL8','Session');
define('REPORT3_COL9','Platform');

?>