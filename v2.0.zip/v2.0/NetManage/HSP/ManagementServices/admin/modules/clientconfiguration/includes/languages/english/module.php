<?PHP
define('CLNT_SAVE_BTN','Save');
define('CLNT_CLIENTS_LBL','Enable OnWeb Web-to-Host monitoring');
define('CLNT_REQUIRED_TXT','denotes required field');
define('CLNT_SERVER_ADDRESS_LBL','Monitoring server address (address:port):');
define('CLNT_HEARTBEAT_LBL','Keep Alive interval (minutes):');
define('CLNT_HOST_REQUIRED_ERR','Enter a host address.');
define('CLNT_KEEPALIVE_REQUIRED_ERR','Keep Alive interval is missing.');
define('CLNT_KEEPALIVE_NUMERIC_ERR','Keep Alive interval should be a positive integer.');
?>