<?PHP
define('CLNT_SAVE_BTN','Salvar');
define('CLNT_CLIENTS_LBL','Habilitar monitora��o OnWeb Web-to-Host');
define('CLNT_REQUIRED_TXT','verifique os arquivos obrigat�rios');
define('CLNT_SERVER_ADDRESS_LBL','Endere�o do Servidor de Monitora��o (endere�o:porta):');
define('CLNT_HEARTBEAT_LBL','Intervo de Keep Alive (minutos):');
define('CLNT_HOST_REQUIRED_ERR','Informe o endere�o do host.');
define('CLNT_KEEPALIVE_REQUIRED_ERR','Favor informar o intervalo de Keep Alive.');
define('CLNT_KEEPALIVE_NUMERIC_ERR','O intervalo de Keep Alive deve ser um interio positivo.');
?>