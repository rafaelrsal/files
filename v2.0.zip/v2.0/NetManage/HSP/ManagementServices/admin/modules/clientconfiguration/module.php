<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:	Hoter Mickey
  		Udi Zisser
  		Guy Schetrit

  Date Created:	Mars 2004

  Purpose:	Monitoring client configuration module.
  Limitations:	Requires PHP 4.3.4 and up

 ============================================================================*/
require_once('HTML/QuickForm.php');
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');
require_once('Admin/includes/classes/webServiceProxy.php');
require_once('Admin/includes/classes/xmlGenerator.php');

class clientConfiguration extends ModuleBase
{
	var $m_db;
	var $m_checkState;
	var $m_firstTime;
	
	function clientConfiguration($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$this->m_db = &parent::GetDatabase();
		$this->m_db->connect();
	}
	
	function init()
	{
		parent::init("clientConfiguration");
		
		$this->m_firstTime = false;
		
		$enableClients 		= $this->getEnableClients();
		$serverAddress 		= $this->getServerAddress();
		$heartbeat			= $this->getHeartbeatInterval();		
		$this->m_checkState	= $enableClients ? 'checked' : '';		
		
		if ( is_null($serverAddress) )
		{			
			$heartbeat 			= 30;
			$this->m_checkState	= '';
			$this->m_firstTime 	= true; 	//intervals are null in the db only at the fist use

			if (isset($_SERVER['COMPUTERNAME']))
			{
				$serverAddress 	= $_SERVER['COMPUTERNAME'] . ':' . $_SERVER['SERVER_PORT'];
			}
		}

		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('ClientConfigurationForm'); //default is post

		// Build the Configuration form:
		$this->m_form->addElement('text', 'address', CLNT_SERVER_ADDRESS_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()"));
		$this->m_form->addElement('text', 'heartbeat',CLNT_HEARTBEAT_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()",'style' => 'width:40px'));
		$this->m_form->addElement('submit', 'save', CLNT_SAVE_BTN,'class="NewButton" "onclick="onSave();return false;" ShortFixedWidthObjects');
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$this->m_form->setDefaults(array(  	'address'=>$serverAddress,
											'heartbeat'=>$heartbeat ));
	}
	
	function process()
	{
		if ( 'POST' == $_SERVER['REQUEST_METHOD'])
		{
			// get all the POST values
			$formValuesArray = $this->m_form->exportValues();	
	
			$serverAddress	= htmlspecialchars($this->m_form->exportValue('address'));
			$heartbeat		= htmlspecialchars($this->m_form->exportValue('heartbeat'));
			
			$res = $this->onSave($heartbeat, $serverAddress, $this->m_firstTime);
			if ( HSP_SUCCESS != $res )
			{
				$this->m_session->set(SESSION_ERRORS, $res);
			}
			else
			{
				parent::CriaLog(CLNT_SAVE_BTN);
			}
		}
	}
	
	function finalize()
	{
		$arrVars = array(	"enableClients"=>$this->m_checkState, 
							"lblCheckbox"=>CLNT_CLIENTS_LBL,
							"hostRequiredErrorMessage"=>CLNT_HOST_REQUIRED_ERR,
							"keepaliveRequiredErrorMessage"=>CLNT_KEEPALIVE_REQUIRED_ERR,
							"keepaliveNumericErrorMessage"=>CLNT_KEEPALIVE_NUMERIC_ERR);
							
		parent::finalize($arrVars);
	}

	function onSave( $heartbeat, $serverAddress )
	{
		if (isset($_POST['enableClientsChk']) && 'on' == $_POST['enableClientsChk'])
		{
			$enableClients = true;
			$this->m_checkState = 'checked';
		}
		else
		{
			$enableClients = false;
			$this->m_checkState = '';
		}				
		
		if ($this->m_firstTime) //use insert method only if it's the first time
		{
			$this->setData( $enableClients, $serverAddress, $heartbeat);
		}
		else
		{
			$this->updateData( $enableClients, $serverAddress, $heartbeat);
		}
	}

	function getEnableClients()
	{
		$enableMon = 0;
		$sql = 'select enable_mon from ' .  TABLE_CLIENT_CONFIG .';';
		$this->m_db->GetOne($sql, $enableMon);
		return $enableMon;
	}

	function getServerAddress()
	{
		$serverAddress = null;
		$sql = 'select server_address from ' .  TABLE_CLIENT_CONFIG .';';
		$this->m_db->GetOne($sql, $serverAddress);
		return $serverAddress;
	}

	function getHeartbeatInterval()
	{
		$heartbeat_interval = null;
		$sql = 'select heartbeat_interval from ' .  TABLE_CLIENT_CONFIG .';';
		$this->m_db->GetOne($sql, $heartbeat_interval);
		return $heartbeat_interval;
	}

	function setData( $enableMon, $serverAddress, $heartbeat_interval)
	{
		// id field is auto_increment
		$fields_values = array( 'enable_mon' =>$enableMon,
								'server_address' =>$serverAddress,
								'heartbeat_interval' =>$heartbeat_interval );
		return $this->m_db->AutoExecute(TABLE_CLIENT_CONFIG, $fields_values);
	}

	function updateData( $enableClients,  $serverAddress, $heartbeat_interval)
	{
		$fields_values = array( 'enable_mon' =>$enableClients,
								'server_address' =>$serverAddress,
								'heartbeat_interval' =>$heartbeat_interval );
		return $this->m_db->AutoExecute(TABLE_CLIENT_CONFIG, $fields_values, DB_AUTOQUERY_UPDATE);
	}
}
?>