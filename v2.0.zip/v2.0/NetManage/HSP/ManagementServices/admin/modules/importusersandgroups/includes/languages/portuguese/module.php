<?PHP
define('IMPORT_USERS_AND_GROUPS_AVAILABLE_GROUPS_LIST_LBL','Grupos Dispon�veis:');
define('IMPORT_USERS_AND_GROUPS_AVAILABLE_USERS_LIST_LBL','Usu�rios Dispon�veis:');

define('IMPORT_USERS_AND_GROUPS_SAVE_BTN','Pr�ximo >');
define('IMPORT_USERS_AND_GROUPS_BACK_BTN','< Voltar');
define('IMPORT_USERS_AND_GROUPS_CANCEL_BTN','Cancelar');

define('IMPORT_USERS_AND_GROUPS_DIR_TITLE_LBL','Selecionar os grupos e usu�rios para importar em');
define('IMPORT_USERS_AND_GROUPS_RESERVE_RELATEIONS','Preserve o relacionamento entre grupos e usu�rios');
?>