<?PHP
require_once('HTML/QuickForm.php');

define('INTERNALDIR_ID', 'internalDirId');
define('SESSSION_PRESERVE_RELATIONS', 'preserveRelations');

define('SESSSION_IMPORT_GROUP_LIST', 'importGroupList');
define('SESSSION_IMPORT_USER_LIST', 'importUserList');
define('SESSSION_DIRCONFIG_PARAMS','dirConfigParams');

define('SESSSION_IMPORT_CUSTOM_GROUP_LIST', 'importCustomGroupList');
define('SESSSION_IMPORT_CUSTOM_USER_LIST', 'importCustomUserList');


define('SESSSION_IMPORT_GROUPS_INFO', 'importGroupsInfo');
define('SESSSION_IMPORT_USERS_INFO', 'importUserssInfo');

class importUsersAndGroups extends ModuleBase
{
	var $m_availableGroups;
	var $m_availableGroupsDetails;
	var $m_availableUsers;
	var $m_availableUsersDetails;
	
	var $m_customAvailableGroupsList;
	var $m_customAvailableUsersList;

	var $m_dirId;

	function importUsersAndGroups($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		// initializations
		$this->m_dirArray 		= array();
		$this->m_groupsObjArr 	= array();
		
		$this->m_db = &parent::GetDatabase();
		$this->m_db->connect();
		
		// Instantiate the HTML_QuickForm object
		$formName = 'importUsersAndGroupsForm';
		$this->m_form = new HTML_QuickForm($formName); //default is post
		
		$this->m_popup = 'false';
	}
	
	function init()
	{
		parent::init("importUsersAndGroups");
		// get all arrays from session variable

		$this->m_form->addElement('select', 'availableGroups', IMPORT_USERS_AND_GROUPS_AVAILABLE_GROUPS_LIST_LBL, $this->m_availableGroups,'multiple size=15 style="width:200" onchange="enableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
		$this->m_form->addElement('select', 'availableUsers', IMPORT_USERS_AND_GROUPS_AVAILABLE_USERS_LIST_LBL, $this->m_availableUsers,'multiple size=15 style="width:200" onchange="enableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
		
		$this->m_form->addElement('submit', 'next', IMPORT_USERS_AND_GROUPS_SAVE_BTN," class='NewButton ShortFixedWidthObjects'");
		$this->m_form->addElement('button', 'back', IMPORT_USERS_AND_GROUPS_BACK_BTN,"onclick=onBack(); class='NewButton ShortFixedWidthObjects'");
		$this->m_form->addElement('button', 'cancel',	IMPORT_USERS_AND_GROUPS_CANCEL_BTN,	"onclick=onCancel() class='NewButton'");		
		$this->m_form->addElement('hidden', 'buttonClicked','');
		//*************GUILHERME LIMA 14/05/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
	}
	
	function process()
	{
		$availableGroups = array();
		$availableUsers = array();
		
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
		if ( '0' != $directoryDetails['type_dir'] ) //if not a custom directory
		{
			if (isset( $_POST['availableGroups']))
			{
				$this->m_availableGroups = $this->m_session->value(SESSSION_IMPORT_GROUP_LIST );
				$availableGroupsIndex = $_POST['availableGroups'];
				
				foreach ( $availableGroupsIndex as $groupIndex )
				{
					$availableGroups[] = $this->m_availableGroups[$groupIndex];
				}			
			}
			if (isset( $_POST['availableUsers']))
			{
				$this->m_availableUsers = $this->m_session->value(SESSSION_IMPORT_USER_LIST );
				$availableUsersIndex = $_POST['availableUsers'];
				
				foreach ( $availableUsersIndex as $userIndex )
				{
					$availableUsers[] = $this->m_availableUsers[$userIndex];
				}
			}
		}
		else // custom directory
		{
			if (isset( $_POST['availableGroups']))
			{
				$this->m_customAvailableGroupsList = $this->m_session->value(SESSSION_IMPORT_CUSTOM_GROUP_LIST );
				$availableGroupsIndex = $_POST['availableGroups'];
				
				foreach ( $availableGroupsIndex as $groupIndex )
				{
					$availableGroups[] = $this->m_customAvailableGroupsList[$groupIndex];
				}		
			}
			if (isset( $_POST['availableUsers']))
			{
				
				$this->m_customAvailableUsersList = $this->m_session->value(SESSSION_IMPORT_CUSTOM_USER_LIST );
				$availableUsersIndex = $_POST['availableUsers'];
				
				foreach ( $availableUsersIndex as $userIndex )
				{
					$availableUsers[] = $this->m_customAvailableUsersList[$userIndex];
				}
			}
		}
		
		if ( isset($_POST['preserveRelationsChk']) )
		{
			$this->m_session->set( SESSSION_PRESERVE_RELATIONS, $_POST['preserveRelationsChk']);
		}
		else
		{
			$this->m_session->set( SESSSION_PRESERVE_RELATIONS, false);
		}
		
		$this->m_formValuesArray = $this->m_form->exportValues();
		if (array_key_exists("next", $this->m_formValuesArray))
		{
			// get the selected groups
			$this->m_session->set(SESSSION_IMPORT_GROUP_LIST, $availableGroups );
			// get the selected users
			$this->m_session->set(SESSSION_IMPORT_USER_LIST, $availableUsers );	
			
			$preserveRelations = $_POST['preserveRelationsChk'];
			Header("Location: admin.php?module=importConfiguration&preserveRelations=$preserveRelations&roll=".$_POST['roll']);
			exit();
		}
		elseif (isset($_POST['buttonClicked']) && 'back' == $_POST['buttonClicked'])
		{
			Header("Location: admin.php?module=importDirectories&roll=".$_POST['roll']);
			exit();
		}
		
		else 
		{
			$this->m_availableGroups = array();
			$this->m_availableUsers = array();
			
			if ( '0' != $directoryDetails['type_dir'] ) //if not a custom directory
			{			
				$this->getDirectoryGroups();
				natcasesort( $this->m_availableGroups );
				$this->m_session->set(SESSSION_IMPORT_GROUP_LIST, $this->m_availableGroups );
	
				
				$this->getDirectoryUsers();
				natcasesort( $this->m_availableUsers );
				$this->m_session->set(SESSSION_IMPORT_USER_LIST, $this->m_availableUsers );
			}
			else
			{
				$this->getCustomDirectoryUsersAndGroups();
			}
			$this->populateLists();
		}
	}
	
	
	function  finalize()
	{		
		$arrVars = array( 
				'mainTitle'=>IMPORT_USERS_AND_GROUPS_DIR_TITLE_LBL,
				'titleDirName'=>$this->getDirName(),
				'roll'=>$_SESSION['roll'],
				'lblPreserveRelations'=>IMPORT_USERS_AND_GROUPS_RESERVE_RELATEIONS
				);
		
		parent::finalize($arrVars);
	}

	function populateLists()
	{
		$this->m_form->removeElement('availableGroups');
		$this->m_form->addElement('select', 'availableGroups', IMPORT_USERS_AND_GROUPS_AVAILABLE_GROUPS_LIST_LBL,$this->m_availableGroups,'multiple size=15 style="width:200" onchange="enableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
		
		$this->m_form->removeElement('availableUsers');
		$this->m_form->addElement('select', 'availableUsers', IMPORT_USERS_AND_GROUPS_AVAILABLE_USERS_LIST_LBL,$this->m_availableUsers,'multiple size=15 style="width:200" onchange="enableDisableButtons();" onKeyPress="DoDefaultEnterKey(event)"');
	}

	function getDirectoryUsers()
	{
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
		
		if(!extension_loaded(PHP_AUTH_MODULE))
		{
			dl(PHP_AUTH_DLL);
		}
		
		$availableUsersDetails = getdirectoryusersinfo(	$directoryDetails['username'],
														$directoryDetails['password'],
														$directoryDetails['host'],
														$directoryDetails['host'],
														$directoryDetails['type_dir'],
														$directoryDetails['port'],
														$directoryDetails['base_dn'],
														$directoryDetails['group_dn'],
														$directoryDetails['user_dn'],
														$directoryDetails['ldap_user_identifier'] );

		if ( is_array($availableUsersDetails) )	
		{
			foreach ($availableUsersDetails as $user )
			{
				$this->m_availableUsers[] = $user['name'];
				$this->m_availableUsersDetails[$user['name']] = $user;
			}
		}
		$this->m_session->set( SESSSION_IMPORT_USERS_INFO,	$this->m_availableUsersDetails );									
	}
	
	function getDirectoryGroups()
	{
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
		if(!extension_loaded(PHP_AUTH_MODULE))
		{
			dl(PHP_AUTH_DLL);
		}
		
		$availableGroupsDetails = getdirectorygroupsinfo(	$directoryDetails['username'],	
															$directoryDetails['password'],
															$directoryDetails['host'],
															$directoryDetails['host'],
															$directoryDetails['type_dir'],
															$directoryDetails['port'],
															$directoryDetails['base_dn'],
															$directoryDetails['group_dn'],
															$directoryDetails['user_dn'],
															$directoryDetails['ldap_user_identifier'] );


		if ( is_array($availableGroupsDetails) )
		{
			foreach ($availableGroupsDetails as $group )
			{
				$this->m_availableGroups[] = $group['name'];
				$this->m_availableGroupsDetails[$group['name']] = $group;
			}
		}
		$this->m_session->set( SESSSION_IMPORT_GROUPS_INFO,	$this->m_availableGroupsDetails );
	}
	
	function getDirName()
	{	
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		$sql = "SELECT name FROM ".TABLE_CUSTOM_DIRECTORY . " WHERE id=$dirId;";
		
		$this->m_db->GetOne($sql, $name);
		
		return $name;
	}	
	
	
	function getCustomDirectoryUsersAndGroups()
	{
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
		$dirId = $directoryDetails['customDir'];

		$sql = "SELECT name, fullName, description, password, changePassword, disabled, cannotChangePassword FROM " . TABLE_CUSTOM_USERS . " WHERE dirId=$dirId;";
		$this->m_customAvailableUsersList = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		
		foreach ($this->m_customAvailableUsersList as $user )
		{
			$this->m_availableUsers[] = $user['name'];
		}
		
		$sql = "SELECT name, description FROM " . TABLE_CUSTOM_GROUPS . " WHERE dirId=$dirId;";
		$this->m_customAvailableGroupsList = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		
		foreach ($this->m_customAvailableGroupsList as $groups )
		{
			$this->m_availableGroups[] = $groups['name'];
		}
		
		natcasesort($this->m_availableUsers);
		natcasesort($this->m_availableGroups);
		
		$this->m_session->set(SESSSION_IMPORT_CUSTOM_GROUP_LIST, $this->m_customAvailableGroupsList );
		$this->m_session->set(SESSSION_IMPORT_CUSTOM_USER_LIST, $this->m_customAvailableUsersList );
	}
}
?>