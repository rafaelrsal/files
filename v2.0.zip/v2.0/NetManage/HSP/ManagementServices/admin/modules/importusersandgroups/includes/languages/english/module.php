<?PHP
define('IMPORT_USERS_AND_GROUPS_AVAILABLE_GROUPS_LIST_LBL','Available Groups:');
define('IMPORT_USERS_AND_GROUPS_AVAILABLE_USERS_LIST_LBL','Available Users:');

define('IMPORT_USERS_AND_GROUPS_SAVE_BTN','Next >');
define('IMPORT_USERS_AND_GROUPS_BACK_BTN','< Back');
define('IMPORT_USERS_AND_GROUPS_CANCEL_BTN','Cancel');

define('IMPORT_USERS_AND_GROUPS_DIR_TITLE_LBL','Select groups and users to import into');
define('IMPORT_USERS_AND_GROUPS_RESERVE_RELATEIONS','Preserve group and user relationships');
?>