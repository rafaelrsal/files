<?php
class translationArrayClass
{
	var $translationArray = array(
	'P2H'		=>	'Rumba PC to Host',
	'W2HJ'		=>	'Web-to-Host Java Client',
	'W2HP'		=>	'Web-to-Host Pro Client',
	'W2HE'		=>	'Web-to-Host Express Client',
	'VNX'		=>	'ViewNow X Server',
	'OW'		=>	'OnWeb',
	'ASD'		=>	'AS/400 Display',
	'ASP'		=>	'AS/400 Printer',
	'ASF'		=>	'AS/400 File Transfer',
	'MFD'		=>	'Mainframe Display',
	'MFP'		=>	'Mainframe Printer',
	'UXD'		=>	'UNIX Display',
	'HPD'		=>	'HP Display',
	'XWIN'		=>	'X Windows',
	'WIN95'		=>	'Windows 95',
	'WIN98'		=>	'Windows 98',
	'WINME'		=>	'Windows Me',
	'WINSE'		=>	'Windows SE',
	'WINNT'		=>	'Windows NT',
	'WIN2000'	=>	'Windows 2000',
	'WINXP'		=>	'Windows XP',
	'WIN2003'	=>	'Windows 2003',
	'OTH'		=>	'Non-Windows Systems'
	);
}
?>