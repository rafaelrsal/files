<?PHP
define('REPORTS_HEADER_TXT','Reports');
define('REPORTS_FILELIST_LBL','Reports:');
define('REPORTS_FROMDATE_LBL','<b>From</b>&nbsp;&nbsp;&nbsp;date:');
define('REPORTS_TODATE_LBL','<b>To</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;date:');
define('REPORTS_FROMTIME_LBL',' time:');
define('REPORTS_TOTIME_LBL',' time:');
define('REPORTS_GENERATE_BTN', 'Create Report');
define('REPORTS_CLEAR_BTN', 'Reset');
?>