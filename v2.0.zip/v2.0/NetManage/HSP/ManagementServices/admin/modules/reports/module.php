<?PHP
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');
require_once 'HTML/QuickForm/Renderer/ITStatic.php';
require_once('HTML/QuickForm.php');
require_once 'HTML/Template/Sigma.php';

define('START_DATE','2004-01-01');

class reports extends ModuleBase
{
	var $m_db;

	function reports($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
		
		$this->m_form = new HTML_QuickForm('reportsForm'); //default is post		
	}
	function  init()
	{
		parent::init("reports");
		
		$this->m_form->addElement('select', 'reportsList', REPORTS_FILELIST_LBL , $this->getReportsList(),"style='width:218px' onkeypress='DoDefaultEnterKey(event);'");
		$this->m_form->addElement('text', 'fromDate', REPORTS_FROMDATE_LBL, array('size' => 8, 'maxlength' => 8));
		$this->m_form->addElement('text', 'toDate', REPORTS_TODATE_LBL, array('size' => 8, 'maxlength' => 8));
		$this->m_form->addElement('select', 'fromTime', REPORTS_FROMTIME_LBL, $this->getTimeList() );
		$this->m_form->addElement('select', 'toTime', REPORTS_TOTIME_LBL, $this->getTimeList() );
		$this->m_form->addElement('submit', 'generate', REPORTS_GENERATE_BTN,"onclick='showWaitEx()', class='NewButton',style='width:100px'");
		$this->m_form->addElement('submit', 'clear', REPORTS_CLEAR_BTN,"class='NewButton',style='width:100px'");
		//*************GUILHERME LIMA 12/03/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		
		$reportName = $this->m_session->value('reportName');
		$this->m_form->setDefaults(array('reportsList' => $reportName));
		
	}
	function process()
	{
		$formValuesArray = $this->m_form->exportValues();

		if ( array_key_exists("generate", $formValuesArray) )
		{
			$this->m_session->set('fromDate', $_POST['fromDateCal']);
			$this->m_session->set('toDate', $_POST['toDateCal']);
			$this->m_session->set('fromTime', htmlspecialchars($this->m_form->exportValue('fromTime')));
			$this->m_session->set('toTime', htmlspecialchars($this->m_form->exportValue('toTime')));

			$reportName = htmlspecialchars($this->m_form->exportValue('reportsList'));
			$this->doReport($reportName);
		}
		
		if ( array_key_exists("clear", $formValuesArray) )
		{
			// Clear the page, return it back to the default state, and re-navigate to
			// the same page. This is a bypass for the refresh problem in html:
			$this->m_session->set('fromTime', 0);
			$this->m_session->set('toTime', 0);
			$this->m_session->remove('fromDate');
			$this->m_session->remove('toDate');
			$this->m_session->remove('reportName');
			Header('Location: admin.php?module=reports&roll='.$_POST['roll']);
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			exit();
		}

		$fromDate = $this->m_session->value('fromDate');
		$toDate = $this->m_session->value('toDate');

		//set the date
		if (!$fromDate)
		{
			$fromDate = START_DATE;
		}
		if (!$toDate)
		{
			$toDate = $this->formatCurDate();
		}

		$this->m_form->addElement('text', 'default_fromtime',$fromDate);
		$this->m_form->addElement('text', 'default_totime',$toDate);

		// set the time
		$fromTime = $this->m_session->value('fromTime');
		$toTime = $this->m_session->value('toTime');

		if (!$toTime)
		{
			$toTime = $this->formatCurTime()+1;
		}

		$this->m_form->setDefaults(array('fromTime' => $fromTime));
		$this->m_form->setDefaults(array('toTime' => $toTime));				
	}
	function finalize()
	{
		$arrVars = array();
		parent::finalize($arrVars);
	}

	function formatCurDate()
	{
		$date = getdate();
		$toTime = $date['hours'];		
		$day = $date['mday'];
				
		if ($toTime == 23)
		{
			$day = $day + 1;
		}
		
		if ($day < 10 )
		{
			$day = '0'.$day;
		}

		$month = $date['mon'];
		if ($month < 10 )
		{
			$month = '0'.$month;
		}

		$year = $date['year'];

		$toDate = $year.'-'.$month.'-'.$day;

		return $toDate;
	}

	function formatCurTime()
	{
		$date = getdate();
		$toTime = $date['hours'];
		return $toTime;
	}
	function getReportsList()
	{
		$list =  $this->m_db->GetAllAssoc(TABLE_REPORTS);
		return $list;
	}

	function getTimeList()
	{
		$list = array();
		for ($i = 0 ; $i < 24 ; $i++)
		{
			$list[$i] = $i . ':00';
		}

		return $list;

	}

	function doReport($reportName)
	{
		parent::CriaLog(REPORTS_GENERATE_BTN);
		Header('Location: admin.php?module='.$reportName.'&roll='.$_POST['roll']);
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		exit();
	}
}
?>