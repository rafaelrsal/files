<?PHP
define('REPORTS_HEADER_TXT','Relat�rios');
define('REPORTS_FILELIST_LBL','Relat�rios:');
define('REPORTS_FROMDATE_LBL','<b>From</b>&nbsp;&nbsp;&nbsp;data:');
define('REPORTS_TODATE_LBL','<b>To</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;data:');
define('REPORTS_FROMTIME_LBL',' hora:');
define('REPORTS_TOTIME_LBL',' hora:');
define('REPORTS_GENERATE_BTN', 'Criar Relat�rio');
define('REPORTS_CLEAR_BTN', 'Reinicializar');
?>