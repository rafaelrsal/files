<?PHP
/*===========================================================================

        Copyright (c) 2013, Slice TI.  All Rights Reserved.  
 ============================================================================

  Author: Guilherme Lima
  Date Created: April 2013
  Title:            database methods
  Purpose:          methods for db access
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
 require_once('HTML/QuickForm.php');
 require_once('includes/classes/permissions.php');
 
 class rollData extends ModuleBase
 {
	
	var $m_form;
	var $m_permission;
	var $m_type;
	
	//menu itens
	var $m_menu_settings;
	var $m_menu_user_manage;
	var $m_menu_app_manage;
	var $m_menu_monitoring;
	
	//submenu itens
	var $m_sub_conf_db;
	var $m_sub_ie_db;
	var $m_sub_chg_pss;
	var $m_sub_conf_pref;
	var $m_sub_new_user;
	var $m_sub_conf_perm;
	var $m_sub_ger_cstm_dir;
	var $m_sub_dir;
	var $m_sub_group;
	var $m_sub_user;
	var $m_sub_app_tree;
	var $m_sub_perm;
	var $m_sub_user_anon;
	var $m_sub_user_param;
	var $m_sub_conf_serv;
	var $m_sub_conf_cli;
	var $m_sub_relat;
	var $m_sub_stats;
	var $m_sub_port_users;
	var $m_sub_w2h_users;
	
	function rollData($globalObjects)
	{
		parent::ModuleBase($globalObjects);
		$this->m_type = "newMode";
		$this->m_form = new HTML_QuickForm('rollDataForm'); //default is post
		$this->m_permission = new Permission();
		$this->m_permission->initFromFile(CONFIG_XML_PATH . PERMISSION_XML_NAME);
		
		// Menu itens, setados como novo item
		$this->m_menu_settings = 0;
		$this->m_menu_user_manage = 0;
		$this->m_menu_app_manage = 0;
		$this->m_menu_monitoring = 0;
		
		//Submenu itens, setados como novo item
		$this->m_sub_conf_db = 0;
		$this->m_sub_ie_db = 0;
		$this->m_sub_chg_pss = 0;
		$this->m_sub_conf_pref = 0;
		$this->m_sub_new_user = 0;
		$this->m_sub_conf_perm = 0;
		$this->m_sub_ger_cstm_dir = 0;
		$this->m_sub_dir = 0;
		$this->m_sub_group = 0;
		$this->m_sub_user = 0;
		$this->m_sub_app_tree = 0;
		$this->m_sub_perm = 0;
		$this->m_sub_user_anon = 0;
		$this->m_sub_user_param = 0;
		$this->m_sub_conf_serv = 0;
		$this->m_sub_conf_cli = 0;
		$this->m_sub_relat = 0;
		$this->m_sub_stats = 0;
		$this->m_sub_port_users = 0;
		$this->m_sub_w2h_users = 0;
	}
	
	function init()
	{
		parent::init("rollData");
		
		$this->m_form->addElement('submit', 'save', 	ROLLDATA_SAVE_BTN, "class='NewButton' onclick='onSave();return false;'");
		$this->m_form->addElement('button', 'cancel',	ROLLDATA_CANCEL_BTN, "onclick=onBack() class='NewButton'");
		
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);
		$this->m_form->addElement('hidden', 'buttonClicked','');
		
		if ($_SERVER['REQUEST_METHOD'] == 'GET'){
			if(isset($_GET['name'])){
				$this->m_type = "editMode";
				$this->m_form->addElement('text', 'name', ROLLDATA_NOME_LBL, array( 'tabindex' => "1", 'size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects', 'readonly'=>'readonly'));
				$this->setRollParams($_GET['name']);
				$this->m_session->set('mode', 'editMode');	
			}
			else{
				$this->m_form->addElement('text', 'name', ROLLDATA_NOME_LBL, array( 'tabindex' => "1", 'size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects'));
				$this->m_session->set('mode', 'newMode');	
			}
		}
		else{
			$this->m_form->addElement('text', 'name', ROLLDATA_NOME_LBL, array( 'tabindex' => "1", 'size' => 20, 'maxlength' => 255, 'onchange' => "updated()", 'class' => 'FixedWidthObjects'));
		}
	}
	
	function process()
	{
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$res = HSP_SUCCESS;
			$formValuesArray = $this->m_form->exportValues();
			if("save" == $formValuesArray['buttonClicked']){
				$menu = isset($_POST['menu'])?$_POST['menu']: "";
				$submenu = isset($_POST['submenu'])?$_POST['submenu']: "";
				if($this->onSave($formValuesArray['name'], $menu, $submenu)){
					Header('Location: admin.php?module=roll&roll='.$_POST['roll']);
				}
				else{
					$res = HSP_ERR_UNKNOWN_FAILURE;
				}
			}
			elseif("back" == $formValuesArray['buttonClicked']){
				$this->onBack();
			}
			if(HSP_SUCCESS != $res){
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);	
			}
		}
	}
	
	function finalize()
	{
		$language = parent::GetLanguage();
		$strTitle = $this->m_type == "editMode"? ROLLDATA_EDIT_TITLE_LBL : ROLLDATA_NEW_TITLE_LBL ;
		$arrVars = array(	"lblMenuSettings" => ROLLDATA_MENU_SETTINGS,
							"lblMenuUserManage" => ROLLDATA_MENU_USER_MANAGE,
							"lblMenuAppManage" => ROLLDATA_MENU_APPLICATION_MANAGMENT,
							"lblMenuMonitoring" => ROLLDATA_MENU_MONITORING,
							"lblsub_conf_db" =>      ROLLDATA_DATABASE                     ,
							"lblsub_ie_db" =>        ROLLDATA_IMPORTEXPORT                 ,
							"lblsub_chg_pss" =>      ROLLDATA_ADMIN_PASSWORD               ,
							"lblsub_conf_pref" =>    ROLLDATA_GENERAL_CONFIGURATION        ,
							"lblsub_new_user" =>     ROLLDATA_NEW_USER                     ,
							"lblsub_conf_perm" =>    ROLLDATA_PERMISSIONS  ,
							"lblsub_ger_cstm_dir" => ROLLDATA_CUSTOM_DIRECTORIES           ,
							"lblsub_dir" =>          ROLLDATA_SYSTEM_DIRECTORIES           ,
							"lblsub_group" =>        ROLLDATA_GROUPS                       ,
							"lblsub_user" =>         ROLLDATA_USERS                        ,
							"lblsub_app_tree" =>     ROLLDATA_APPLICATION_BUILD            ,
							"lblsub_perm" =>         ROLLDATA_ASSOC_APPLICATIONS           ,
							"lblsub_user_anon" =>    ROLLDATA_APPLICATION_ANONYMOUS        ,
							"lblsub_user_param" =>   ROLLDATA_USER_PARAMETERS,
							"lblsub_conf_serv" =>    ROLLDATA_CONFIGURATION                ,
							"lblsub_conf_cli" =>     ROLLDATA_CLIENTCONFIGURATION          ,
							"lblsub_relat" =>        ROLLDATA_REPORTS     ,
							"lblsub_stats" =>        ROLLDATA_CONCURRENCY ,
							"lblsub_port_users" =>   ROLLDATA_WHOS_ONLINE ,
							"lblsub_w2h_users" =>    ROLLDATA_W2H_ADMIN   ,
							"menu_settings_checked" => $this->m_menu_settings,
							"menu_user_manage_checked" => $this->m_menu_user_manage,
							"menu_app_manage_checked" => $this->m_menu_app_manage,
							"menu_monitoring_checked" => $this->m_menu_monitoring,
							"submenu_conf_db_checked" =>     $this->m_sub_conf_db,
							"submenu_ie_db_checked" =>       $this->m_sub_ie_db,
							"submenu_chg_pss_checked" =>     $this->m_sub_chg_pss,
							"submenu_conf_pref_checked" =>   $this->m_sub_conf_pref,
							"submenu_new_user_checked" =>    $this->m_sub_new_user,
							"submenu_conf_perm_checked" =>   $this->m_sub_conf_perm,
							"submenu_ger_cstm_dir_checked" =>$this->m_sub_ger_cstm_dir,
							"submenu_dir_checked" =>         $this->m_sub_dir,
							"submenu_group_checked" =>       $this->m_sub_group,
							"submenu_user_checked" =>        $this->m_sub_user,
							"submenu_app_tree_checked" =>    $this->m_sub_app_tree,
							"submenu_perm_checked" =>        $this->m_sub_perm,
							"submenu_user_anon_checked" =>   $this->m_sub_user_anon,
							"submenu_user_param_checked" =>  $this->m_sub_user_param,
							"submenu_conf_serv_checked" =>   $this->m_sub_conf_serv,
							"submenu_conf_cli_checked" =>    $this->m_sub_conf_cli,
							"submenu_relat_checked" =>       $this->m_sub_relat,
							"submenu_stats_checked" =>       $this->m_sub_stats,
							"submenu_port_users_checked" =>  $this->m_sub_port_users,
							"submenu_w2h_users_checked" =>   $this->m_sub_w2h_users,
							"name_req_msg" => ROLLDATA_NAME_REQ,
							"lbl_menu" => ROLLDATA_MENU_LBL,
							"lbl_submenu"=> ROLLDATA_SUBMENU_LBL,
							"lblRoll"=> ROLLDATA_ROLL_TITLE_LBL,
							"rollDataForm_required_note"=> ROLLDATA_REQ_TXT,
							"strTitle"=> $strTitle );       
		parent::finalize( $arrVars , 'newUser' );
	}
	
	// Fun��o para popular dados quando type is edit
	// recebe o nome
	function setRollParams($name)
	{
		if($this->m_type == "editMode"){
			$arrParams = $this->m_permission->selectOneRoll($name);
			$this->m_form->setDefaults(array('name'=>$arrParams['nome']));
			$menuPerm = explode(';', $arrParams['menu']);
			$this->checkMenu($menuPerm);
			$subMenuPerm = explode(';', $arrParams['submenu']);
			$this->checkSubMenu($subMenuPerm);
		}
	}
	
	// Fun��o para checar ou n�o um item que j� existia
	// recebe array de permiss�es
	function checkMenu($menus){
		if(is_array($menus)){
			foreach ($menus as $menu){
				switch($menu){
					case 1:
						$this->m_menu_settings = "CHECKED";
						break;
					case 2:
						$this->m_menu_user_manage = "CHECKED";
						break;
					case 3:
						$this->m_menu_app_manage = "CHECKED";
						break;
					case 4:
						$this->m_menu_monitoring = "CHECKED";
						break;
					default:
						break;
				}
			}
		}
	}
	
	// Fun��o para checar ou n�o um subitem que j� existia
	// recebe array de permiss�es
	function checkSubMenu($submenus){
		if(is_array($submenus)){
			foreach ($submenus as $submenu){
				switch($submenu){
					 case 1 :
					$this->m_sub_conf_db      = "CHECKED";
		            break;      
					case 2 :  
						$this->m_sub_ie_db        = "CHECKED";
						break;      
					case 3 :  
						$this->m_sub_chg_pss      = "CHECKED";
						break;      
					case 14 : 
						$this->m_sub_conf_pref    = "CHECKED";
						break;      
					case 19 : 
						$this->m_sub_new_user     = "CHECKED";
						break;      
					case 33 : 
						$this->m_sub_conf_perm    = "CHECKED";
						break;      
					case 4 :  
						$this->m_sub_ger_cstm_dir = "CHECKED";
						break;      
					case 5 :
						$this->m_sub_dir          = "CHECKED";
						break;
					case 6 :
						$this->m_sub_group        = "CHECKED";
						break;
					case 7 :
						$this->m_sub_user         = "CHECKED";
						break;
					case 8 :
						$this->m_sub_app_tree     = "CHECKED";
						break;
					case 9 :
						$this->m_sub_perm         = "CHECKED";
						break;
					case 15 :
						$this->m_sub_user_anon    = "CHECKED";
						break;
					case 17 :
						$this->m_sub_user_param   = "CHECKED";
						break;
					case 10 :
						$this->m_sub_conf_serv    = "CHECKED";
						break;
					case 11 :
						$this->m_sub_conf_cli     = "CHECKED";
						break;
					case 12 :
						$this->m_sub_relat        = "CHECKED";
						break;
					case 13 :
						$this->m_sub_stats        = "CHECKED";
						break;
					case 25 :
						$this->m_sub_port_users   = "CHECKED";
						break;
					case 16 :
						$this->m_sub_w2h_users    = "CHECKED";
						break;
					default:
						break;
				}
			}
		}
	}
	
	function onSave($name, $menu = null, $submenu = null){
		if("editMode" == $_SESSION['mode']){
			if($this->m_permission->UpdateOldRows($name,$menu,$submenu)){
				parent::CriaLog( $_SESSION['mode'] . "_" . ROLLDATA_SAVE_BTN, $name);
				return true;
			}
			return false;
			
		}
		else{
			if($this->m_permission->InsertNewRoll($name,$menu,$submenu)){
				parent::CriaLog( $_SESSION['mode'] . "_" . ROLLDATA_SAVE_BTN, $name);
				return true;
			}
			return false;
		}
	}
	
	function onBack(){
		Header('Location: admin.php?module=roll&roll='.$_POST['roll']);
		exit();
	}
 }
 ?>