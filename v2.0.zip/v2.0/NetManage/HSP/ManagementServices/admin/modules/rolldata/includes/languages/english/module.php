<?PHP
define('ROLLDATA_SAVE_BTN','Save');
define('ROLLDATA_CANCEL_BTN','Cancel');

define('ROLLDATA_NOME_LBL', 'Name:');
define('ROLLDATA_MENU_LBL', 'Menu');
define('ROLLDATA_SUBMENU_LBL', 'Submenu');
define('ROLLDATA_ROLL_TITLE_LBL', 'Permission');
define('ROLLDATA_NEW_TITLE_LBL', 'New');
define('ROLLDATA_EDIT_TITLE_LBL', 'Edit');

define('ROLLDATA_NAME_REQ','The field name is required');
define('ROLLDATA_REQ_TXT', 'Check required fields');


define('ROLLDATA_MENU_SETTINGS','System Configuration');
define('ROLLDATA_DATABASE','Configure Database');
define('ROLLDATA_IMPORTEXPORT','Import / Export Database');
define('ROLLDATA_ADMIN_PASSWORD','Change Password');
define('ROLLDATA_GENERAL_CONFIGURATION','Set Preferences');
define('ROLLDATA_NEW_USER', 'New Manager User');
define('ROLLDATA_PERMISSIONS', 'Set Permissions');
define('ROLLDATA_MENU_MONITORING','Monitoring');
define('ROLLDATA_CONFIGURATION','Configure Server');
define('ROLLDATA_CLIENTCONFIGURATION','Configure Clients');
define('ROLLDATA_REPORTS','Generate Reports');
define('ROLLDATA_CONCURRENCY','Statistics');
define('ROLLDATA_MENU_USER_MANAGE','User Management');
define('ROLLDATA_CUSTOM_DIRECTORIES','Manage Custom Directories');
define('ROLLDATA_SYSTEM_DIRECTORIES','Select Directories');
define('ROLLDATA_GROUPS','Select Groups');
define('ROLLDATA_USERS','Select Users');
define('ROLLDATA_ASSOC_APPLICATIONS','Set Permissions');
define('ROLLDATA_MENU_APPLICATION_MANAGMENT','Application Management');
define('ROLLDATA_APPLICATION_BUILD','Build Application Tree');
define('ROLLDATA_APPLICATION_ANONYMOUS','Set Anonymous User');
define('ROLLDATA_HIDEPATH', 'NetManage - Host Services Platform');
define('ROLLDATA_WHOS_ONLINE', 'Manage Portal Users');
define('ROLLDATA_W2H_ADMIN', 'Manage W2H Users');
define('ROLLDATA_USER_PARAMETERS', 'Manage User Parameters');
?>