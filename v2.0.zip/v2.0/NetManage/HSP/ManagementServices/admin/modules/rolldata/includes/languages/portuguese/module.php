<?PHP
define('ROLLDATA_SAVE_BTN','Salvar');
define('ROLLDATA_CANCEL_BTN','Cancelar');

define('ROLLDATA_NOME_LBL', 'Nome:');
define('ROLLDATA_MENU_LBL', 'Menu');
define('ROLLDATA_SUBMENU_LBL', 'Submenu');
define('ROLLDATA_ROLL_TITLE_LBL', 'Permiss�o');
define('ROLLDATA_NEW_TITLE_LBL', 'Nova');
define('ROLLDATA_EDIT_TITLE_LBL', 'Editar');

define('ROLLDATA_NAME_REQ','Campo nome � obrigat�rio');
define('ROLLDATA_REQ_TXT', 'Verifique campos obrigat�rios');

define('ROLLDATA_MENU_SETTINGS','Configura��o do Sistema');
define('ROLLDATA_DATABASE','Configurar Database');
define('ROLLDATA_IMPORTEXPORT','Importar / Exportar Database');
define('ROLLDATA_ADMIN_PASSWORD','Alterar Senha');
define('ROLLDATA_GENERAL_CONFIGURATION','Configurar Prefer�ncias');
define('ROLLDATA_NEW_USER', 'Novo Usu�rio Administrador');
define('ROLLDATA_PERMISSIONS', 'Configurar Permiss�es');
define('ROLLDATA_MENU_MONITORING','Monitoramento');
define('ROLLDATA_CONFIGURATION','Configurar Servidor');
define('ROLLDATA_CLIENTCONFIGURATION','Configurar Clientes');
define('ROLLDATA_REPORTS','Gerar Relat�rios');
define('ROLLDATA_CONCURRENCY','Estat�stica');
define('ROLLDATA_MENU_USER_MANAGE','Gerenciamento de Usu�rios');
define('ROLLDATA_CUSTOM_DIRECTORIES','Gerenciar Diret�rios Customizados');
define('ROLLDATA_SYSTEM_DIRECTORIES','Selecionar Diret�rios');
define('ROLLDATA_GROUPS','Selecionar Grupos');
define('ROLLDATA_USERS','Selecionar Usu�rios');
define('ROLLDATA_ASSOC_APPLICATIONS','Configurar Permiss�es');
define('ROLLDATA_PORTAL','Portal');
define('ROLLDATA_MENU_APPLICATION_MANAGMENT','Gerenciamento de Aplica��o');
define('ROLLDATA_APPLICATION_BUILD','Criar �rvore de Aplica��o');
define('ROLLDATA_APPLICATION_ANONYMOUS','Configurar Usu�rio Anonymous');
define('ROLLDATA_HIDEPATH', 'NetManage - Host Services Platform');
define('ROLLDATA_WHOS_ONLINE', 'Gerenciar Usu�rios do Portal');
define('ROLLDATA_W2H_ADMIN', 'Gerenciar Usu�rios W2H');
define('ROLLDATA_USER_PARAMETERS', 'Gerenciar Parametro de Usu�rio');
?>