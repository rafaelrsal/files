<?PHP 
require_once('includes/classes/PearDB.php');
require_once('includes/classes/DBConfig.php');

require_once('HTML/QuickForm.php');
require_once('HTML/Table.php');

define('INTERNALDIR_ID', 'internalDirId');
define('SESSSION_DIRCONFIG_PARAMS','dirConfigParams');
define('SESSION_IMPORT_CONFIGURATION_DATA', 'importConfigurationData');
define('SESSSION_PREV_STEP', 'pevStep');

define('SESSSION_IMPORT_GROUP_LIST', 'importGroupList');
define('SESSSION_IMPORT_USER_LIST', 'importUserList');

define('SESSSION_IMPORT_GROUP_INDEX', 'importGroupIndex');
define('SESSSION_PRESERVE_RELATIONS', 'preserveRelations');

define('SESSSION_IMPORT_GROUP_OVERRIDE_PARAMS', 'overrideParams');

define('SESSSION_IMPORT_GROUPS_INFO', 'importGroupsInfo');
define('SESSSION_IMPORT_USERS_INFO', 'importUserssInfo');

class importConfiguration extends ModuleBase
{
	var $m_db;
	
	var $m_groupsInfo; // all groups + desctiption
	var $m_usersInfo; // all users + description 
	
	var $m_changePassSet;
	var $m_disabledSet;
	var $m_cannotChangePassSet;
	var $m_overrideParamsSet;
	
	var $m_mustChangePassChk;
	var $m_disableAccountChk;
	var $m_cannotChangePassword;
	var $m_overrideParams;
	
	var $m_password;
	
	var $m_preserveRelation;
	
	function importConfiguration($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		$this->m_db  = &parent::GetDatabase();
		$this->m_db->connect();
		$this->m_form = new HTML_QuickForm('importConfigurationForm'); //default is post
		
		$this->m_groupsInfo = $this->m_session->value( SESSSION_IMPORT_GROUPS_INFO );
		$this->m_usersInfo = $this->m_session->value( SESSSION_IMPORT_USERS_INFO );		
	}
	
	function init()
	{		
		parent::init("importConfiguration");
		
		// buttons
		$this->m_form->addElement('submit', 'finish',	IMPORT_CONFIGURATION_FINISH_BTN,  	"class='NewButton' onclick='onFinish();showWaitEx();return false;'");
		$this->m_form->addElement('button', 'back',		IMPORT_CONFIGURATION_BACK_BTN,		"onclick=onBack() class='NewButton'");
		$this->m_form->addElement('button', 'cancel',	IMPORT_CONFIGURATION_CANCEL_BTN,	"onclick=onCancel() class='NewButton'");
		
		// text
		$this->m_form->addElement('text', 'password', IMPORT_CONFIGURATION_PASSWORD_LBL, array('size' => 20, 'maxlength' => 255,'onchange' => "updated()"));		
		
		// hiddens
		$this->m_form->addElement('hidden', 'buttonClicked','');
		//*************GUILHERME LIMA 14/05/2013 ****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);	
		
		$this->m_preserveRelation = false;
    }

	function process()
	{	
		$this->setUserParams();
		
		$this->m_preserveRelation = $this->m_session->value( SESSSION_PRESERVE_RELATIONS);

		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$formValuesArray = $this->m_form->exportValues();
			$this->m_mustChangePassChk = false;
			if (isset($_POST['mustChangePassChk']) && 'on' == $_POST['mustChangePassChk'])
			{
				$this->m_mustChangePassChk = true;
			}
			
			$this->m_disableAccountChk = false;
			if (isset($_POST['disableAccountChk']) && 'on' == $_POST['disableAccountChk'])
			{
				$this->m_disableAccountChk = true;
			}
			
			$this->m_cannotChangePassword = false;
			if (isset($_POST['cannotChangePassChk']) && 'on' == $_POST['cannotChangePassChk'])
			{
				$this->m_cannotChangePassword = true;
			}
			
			$this->m_overrideParams = false;
			if (isset($_POST['overrideChk']) && 'on' == $_POST['overrideChk'])
			{
				$this->m_overrideParams = true;
				$this->m_session->set(SESSSION_IMPORT_GROUP_OVERRIDE_PARAMS, true );
			}
			else
			{
				$this->m_session->set(SESSSION_IMPORT_GROUP_OVERRIDE_PARAMS, false );
			}

			$this->m_password = $formValuesArray['password'];
			  
			if (isset($_POST['buttonClicked']) && 'finish' == $_POST['buttonClicked'])
			{
				$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
				if ( '0' == $directoryDetails['type_dir'] ) //if custom directory
				{
					$this->importDirectory();
					parent::CriaLog(IMPORT_CONFIGURATION_FINISH_BTN);
					Header("Location: admin.php?module=customDirectories&roll=".$_POST['roll']);
					exit();	
				}
				else
				{
					$prevStep = $this->m_session->value(SESSSION_PREV_STEP);
					$this->importDirectoryEx();
				}
			}			
			elseif (isset($_POST['buttonClicked']) && 'back' == $_POST['buttonClicked'])
			{	
				$this->onBack();
				Header("Location: admin.php?module=importUsersAndGroups&prevModule=importConfiguration&roll=".$_POST['roll']);
				exit();	
			}
		}
		else
		{
			$this->m_overrideParams = $this->m_session->value(SESSSION_IMPORT_GROUP_OVERRIDE_PARAMS);

			$prevStep = $this->m_session->value(SESSSION_PREV_STEP);
			if ( 'getUsers' == $prevStep )
			{
				$this->importDirectoryEx($prevStep);	
			}
			elseif ( 'getGroups' == $prevStep || 'doCross' == $prevStep  )
			{
				$this->m_session->set(SESSSION_PREV_STEP, 'doCross');
				
				$importGroupList = $this->m_session->value(SESSSION_IMPORT_GROUP_LIST);
				$nextGroupIndex = $this->m_session->value(SESSSION_IMPORT_GROUP_INDEX);
				
				$this->prepareGroupNameForImport( $importGroupList, $nextGroupIndex );
			}
		}
	}
	
	function finalize()
	{
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);		
		$dirType = $directoryDetails['type_dir']?'true':'false';
		
		$this->m_changePassSet = $this->m_mustChangePassChk?$this->m_changePassSet:'checked';
		
		$arrVars = array( 	
					        "lblmustChangePass"=>IMPORT_CONFIGURATION_MUST_CHANGE_PASS_LBL,
					        "lbldisableAccountChk"=>IMPORT_CONFIGURATION_ACCOUT_DISABLED_LBL,
					        "lblcannotChangePassChk"=>IMPORT_CONFIGURATION_CANNOTCHANGEPASS_LBL,
					        "changePassSet"=>$this->m_changePassSet,
					        "disabledSet"=>$this->m_disabledSet,
					        "cannotChangePassSet"=>$this->m_cannotChangePassSet,
					        "overrideParamsSet"=>$this->m_overrideParamsSet,
					        "lbloverrideChk"=>IMPORT_OVERWRITE_LBL,
					        "password_req_msg"=>IMPORT_CONFIGURATION_PASSWORD_REQ_MSG_TXT,
					        "msgPageChanged"=>MENUITEM_CHANGES,
                            "importConfigurationForm_required_note"=>CUSTOM_DIR_REQUIRED_TXT,
                            "strTitle"=>IMPORT_CONFIGURATION_LBL,
                            "titleDirName"=>$this->getDirName(),
							"roll"=>$_SESSION['roll'],
                            "dirType"=>$dirType);
                            
		parent::finalize($arrVars, "importConfiguration");
	}
	
	function insertDBCrossReference( $groupId, $userIds)
	{
		// insert new cross reference
		foreach( $userIds as $userId )
		{			
            $this->insertUserGroupCrossRefer( $groupId, $userId);
		}
    }
	
	function onSaveUser($userName)	
	{
		$ret = HSP_SUCCESS;
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		
		$fullName = $this->m_usersInfo[$userName]['fullName'];
		$description = $this->m_usersInfo[$userName]['description'];
		
		if(!extension_loaded('HSPSecurModule'))
		{
			dl('php_HSPSecurModule.dll');
		}
		
		$_userName = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;", "'"), array(">", "<", "\"", "&", "\'"), $userName);
		
		$fields_values = array(	'dirID'=>$dirId,
								'name'=>$userName,
								'fullName'=>$fullName,
								'description'=>$description,
								'password'=>encrypt_str($this->m_password),
								'changePassword'=>$this->m_mustChangePassChk,
								'disabled'=>$this->m_disableAccountChk,
								'cannotChangePassword'=>$this->m_cannotChangePassword
								);
								
		$sql = "SELECT id FROM ".TABLE_CUSTOM_USERS . " WHERE name=\"$_userName\" AND dirId=$dirId;";
		$this->m_db->GetOne( $sql, $userId);
		
		if ( !$userId )
		{	
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_USERS, $fields_values );
		}
		elseif ( $this->m_overrideParams ) 
		{
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_USERS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$userId.';' );
			
			$sql = "DELETE FROM ".TABLE_CUSTOM_CROSS . " WHERE userId={$userId};";
			$ret = $this->m_db->Query($sql);
		}
		
		return $ret;								
	}

	function onSaveGroup( $groupName )	
	{		
		$ret = HSP_SUCCESS;
		$destinationDirId = $this->m_session->value(INTERNALDIR_ID);
		
		$_groupName = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;", "'"), array(">", "<", "\"", "&", "\'"), $groupName);
		
		$fields_values = array(	'dirID'=>$destinationDirId,
								'name'=>$groupName,
								'description'=> $this->m_groupsInfo[$groupName]['description'] );
								
		$sql = "SELECT id FROM ".TABLE_CUSTOM_GROUPS . " WHERE name=\"$_groupName\" AND dirId=$destinationDirId;";
		$this->m_db->GetOne( $sql, $groupId);
		
		if ( !$groupId )
		{
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_GROUPS, $fields_values );
		}
		elseif ( $this->m_overrideParams )
		{
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_GROUPS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$groupId.';' );
			
			$sql = "DELETE FROM ".TABLE_CUSTOM_CROSS . " WHERE groupId={$groupId};";
			$ret = $this->m_db->Query($sql);
		}
		
		return $ret;
	}
	
	function onSaveCustomUser( $userDetails )
	{
		$ret = HSP_SUCCESS;
		$dirId = $this->m_session->value(INTERNALDIR_ID);		
		$userName = $userDetails['name'];
								
		$sql = "SELECT id FROM ".TABLE_CUSTOM_USERS . " WHERE name=\"$userName\" AND dirId=$dirId;";
		$this->m_db->GetOne( $sql, $userId);
		
		$fields_values = array(	'dirID'=>$dirId,
								'name'=>$userDetails['name'],
								'fullName'=>$userDetails['fullName'],
								'description'=>$userDetails['description'],
								'password'=>$userDetails['password'],
								'changePassword'=>$userDetails['changePassword'],
								'disabled'=>$userDetails['disabled'],
								'cannotChangePassword'=>$userDetails['cannotChangePassword']);
		
		if ( !$userId )
		{				
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_USERS, $fields_values );
		}
		elseif ( $this->m_overrideParams ) 
		{			
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_USERS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$userId.';' );
			
			$sql = "DELETE FROM ".TABLE_CUSTOM_CROSS . " WHERE userId={$userId};";
			$ret = $this->m_db->Query($sql);
		}
		
		return $ret;								
	}

	function onSaveCustomGroup( $groupDetails )
	{
		$ret = HSP_SUCCESS;
		$destinationDirId = $this->m_session->value(INTERNALDIR_ID);
		$groupName = $groupDetails['name'];
		
		$sql = "SELECT id FROM ".TABLE_CUSTOM_GROUPS . " WHERE name=\"$groupName\" AND dirId=$destinationDirId;";
		
		$this->m_db->GetOne( $sql, $groupId);
		
		$fields_values = array(	'dirID'=>$destinationDirId,
								'name'=>$groupDetails['name'],			
								'description'=>$groupDetails['description'] );
								
		if ( !$groupId )
		{			
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_GROUPS, $fields_values );
			$sql = "SELECT MAX( id ) FROM " . TABLE_CUSTOM_GROUPS .";";
			$this->m_db->GetOne( $sql, $groupId);
		}
		elseif ( $this->m_overrideParams )
		{
			$ret = $this->m_db->AutoExecute( TABLE_CUSTOM_GROUPS, $fields_values, DB_AUTOQUERY_UPDATE,'id='.$groupId.';' );
			
			$sql = "DELETE FROM ".TABLE_CUSTOM_CROSS . " WHERE groupId={$groupId};";
			$ret = $this->m_db->Query($sql);
		}
		
		if ( 'on' == $this->m_preserveRelation )
		{
			$this->populateGroupsUsersCross( $groupName, $groupId );
		}
		
		return $ret;
	}
	
	function insertUserGroupCrossRefer($groupId, $userId)
	{
		$fields_values = array( 'userId'=>$userId, 'groupId'=>$groupId );
		
		$this->m_db->AutoExecute( TABLE_CUSTOM_CROSS, $fields_values );
	}
	
	function setUserParams()
	{	
		$userDetails = $this->m_session->value(SESSION_IMPORT_CONFIGURATION_DATA);

		if (is_array($userDetails))
		{
			$this->m_form->setDefaults(array('password'=>$userDetails['password']));		
			$this->m_changePassSet = $userDetails['changePassword']?'checked':0;
			$this->m_disabledSet = $userDetails['disabled']?'checked':0;
			$this->m_cannotChangePassSet = $userDetails['cannotChangePassword']?'checked':0;
			$this->m_overrideParamsSet = $userDetails['overrideParams']?'checked':0;
			
			$this->m_password = $userDetails['password'];
		}
	}
	
	function getDirName()
	{	
		$dirId = $this->m_session->value(INTERNALDIR_ID);
		$sql = "SELECT name FROM ".TABLE_CUSTOM_DIRECTORY . " WHERE id=$dirId;";
		
		$this->m_db->GetOne($sql, $name);
		
		return $name;
	}	
	
	function onBack()
	{
		$importConfigurationParams = array( 'password'=>$this->m_password,
											'changePassword'=>$this->m_mustChangePassChk,
											'disabled'=>$this->m_disableAccountChk, 
											'cannotChangePassword'=>$this->m_cannotChangePassword, 
											'overrideParams'=>$this->m_overrideParams );
											
		$this->m_session->set( SESSION_IMPORT_CONFIGURATION_DATA, $importConfigurationParams );
	}
	
	
	function importDirectoryEx( $prevStep=null )
	{
		if ( 'getUsers' == $prevStep )
		{
			$groups = $this->m_session->value(SESSSION_IMPORT_GROUP_LIST);
			
			foreach ($groups as $groupName)
			{
				$this->onSaveGroup( $groupName );
			}
			
			if ( !count($groups) )
			{
				$this->m_session->set(SESSSION_PREV_STEP, 'lastStep');
				parent::CriaLog(IMPORT_CONFIGURATION_FINISH_BTN);
				Header("Location: admin.php?module=customDirectories&roll=".$_POST['roll']);
				exit();
			}
			
			$this->m_session->set(SESSSION_IMPORT_GROUP_LIST, $groups );
			$this->m_session->set(SESSSION_IMPORT_GROUP_INDEX, 0 );
			
			$this->m_session->set(SESSSION_PREV_STEP, 'getGroups');
		}
		else
		{
			$users = $this->m_session->value(SESSSION_IMPORT_USER_LIST);
			//$this->getDirectoryUsers( $users );
			foreach ($users as $userName)
			{
				$this->onSaveUser( $userName );
			}
			$this->m_session->set(SESSSION_PREV_STEP, 'getUsers');
		}
		
		parent::CriaLog(IMPORT_CONFIGURATION_FINISH_BTN);
		Header("Location: admin.php?module=importConfiguration&roll=".$_POST['roll']);
		exit();
	}
	
	function importDirectory()
	{
		$users = $this->m_session->value(SESSSION_IMPORT_USER_LIST);
		$groups = $this->m_session->value(SESSSION_IMPORT_GROUP_LIST);
		
		foreach ($users as $userDetails)
		{
			$this->onSaveCustomUser( $userDetails );
		}
		
		foreach ($groups as $groupDetails)
		{
			$this->onSaveCustomGroup( $groupDetails );
		}
	}
	
	function getDirectoryUsers( &$users )
	{
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
		
		if(!extension_loaded(PHP_AUTH_MODULE))
		{
			dl(PHP_AUTH_DLL);
		}
		
		$users = getdirectoryusers(	$directoryDetails['username'],
									$directoryDetails['password'],
									$directoryDetails['host'],
									$directoryDetails['host'],
									$directoryDetails['type_dir'],
									$directoryDetails['port'],
									$directoryDetails['base_dn'],
									$directoryDetails['group_dn'],
									$directoryDetails['user_dn'],
									$directoryDetails['ldap_user_identifier'] );
	}
	
	function prepareGroupNameForImport( $importGroupList, $nextGroupIndex )
	{
		if ( !count($importGroupList ) ||  $nextGroupIndex >= count( $importGroupList ) ) 
		{
			$this->m_session->set(SESSSION_PREV_STEP, 'lastStep');
			Header("Location: admin.php?module=customDirectories&roll=".$_POST['roll']);
			exit();
		}
		
		if ( 'on' == $this->m_preserveRelation )
		{
			$this->populateGroupsUsersCrossEx( $importGroupList[$nextGroupIndex] );
		}
		$this->m_session->set(SESSSION_IMPORT_GROUP_INDEX, $nextGroupIndex+1 );
		
		Header("Location: admin.php?module=importConfiguration&roll=".$_POST['roll']);
		exit();
	}
	
	function populateGroupsUsersCrossEx( $groupName )
	{
		$destinationDirId = $this->m_session->value(INTERNALDIR_ID);
		$sql = "SELECT id FROM ".TABLE_CUSTOM_GROUPS . " WHERE name=\"$groupName\" AND dirId=$destinationDirId;";		
		$this->m_db->GetOne( $sql, $destinationGroupId);

		// source directory from which we imported the groups and users
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);		
		
		$destinationUserIds = array();
		
		if ( '0' != $directoryDetails['type_dir'] ) //if not custom directory
		{
			if(!extension_loaded(PHP_AUTH_MODULE))
			{
				dl(PHP_AUTH_DLL);
			}
				
			$users = getgroupmembers(	$directoryDetails['username'],
										$directoryDetails['password'],
										$directoryDetails['host'],
										$directoryDetails['host'],
										$directoryDetails['type_dir'],
										$directoryDetails['port'],
										$directoryDetails['base_dn'],
										$directoryDetails['group_dn'],
										$directoryDetails['user_dn'],
										$directoryDetails['ldap_user_identifier'],
										$groupName );

			if ( is_array($users) && count($users) ) 
			{
				$destinationUserIds = $this->getDestinationMemberIds($users);
			}
		}
		else
		{			
			$sourceCustomDirId = $directoryDetails['customDir'];
			$sql = "SELECT id FROM " . TABLE_CUSTOM_GROUPS . " WHERE name=\"$groupName\" AND dirId=$sourceCustomDirId;";
			$this->m_db->GetONe( $sql, $sourceGroupId);
			
			$sourceUserNames 	= $this->getSourceCustomMemberNames( $sourceGroupId );
			if ( is_array($sourceUserNames) && count($sourceUserNames) ) 
			{
				$destinationUserIds = $this->getDestinationCustomMemberIds( $sourceUserNames );
			}
		}
		
		if ( is_array($destinationUserIds) && count($destinationUserIds))
		{
			$this->insertDBCrossReference( $destinationGroupId, $destinationUserIds );
		}
		
	}
	
	function populateGroupsUsersCross( $groupName, $destinationGroupId )
	{
		// source directory from which we imported the groups and users
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);		
		
		$destinationUserIds = array();
		
		if ( '0' != $directoryDetails['type_dir'] ) //if not custom directory
		{
			if(!extension_loaded(PHP_AUTH_MODULE))
			{
				dl(PHP_AUTH_DLL);
			}
				
			$users = getgroupmembers(	$directoryDetails['username'],
										$directoryDetails['password'],
										$directoryDetails['host'],
										$directoryDetails['host'],
										$directoryDetails['type_dir'],
										$directoryDetails['port'],
										$directoryDetails['base_dn'],
										$directoryDetails['group_dn'],
										$directoryDetails['user_dn'],
										$directoryDetails['ldap_user_identifier'],
										$groupName );

			if ( is_array($users) && count($users) ) 
			{
				$destinationUserIds = $this->getDestinationMemberIds($users);
			}
		}
		else
		{			
			$sourceCustomDirId = $directoryDetails['customDir'];
			$sql = "SELECT id FROM " . TABLE_CUSTOM_GROUPS . " WHERE name=\"$groupName\" AND dirId=$sourceCustomDirId;";
			$this->m_db->GetONe( $sql, $sourceGroupId);
			
			$sourceUserNames 	= $this->getSourceCustomMemberNames( $sourceGroupId );
			if ( is_array($sourceUserNames) && count($sourceUserNames) ) 
			{
				$destinationUserIds = $this->getDestinationCustomMemberIds( $sourceUserNames );
			}
		}
		
		if ( is_array($destinationUserIds) && count($destinationUserIds))
		{
			$this->insertDBCrossReference( $destinationGroupId, $destinationUserIds );
		}
		
	}
	
	function getCustomDirectoryUsers()
	{
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
		$dirId = $directoryDetails['customDir'];
		
		$sql = "SELECT name, fullName, description, password, changePassword, disabled, cannotChangePassword FROM " . TABLE_CUSTOM_USERS . " WHERE dirId=$dirId;";
		return $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
	}
			
	function getCustomDirectoryGroups()
	{
		$directoryDetails = $this->m_session->value(SESSSION_DIRCONFIG_PARAMS);
		$dirId = $directoryDetails['customDir'];
		
		$sql = "SELECT name, description FROM " . TABLE_CUSTOM_GROUPS . " WHERE dirId=$dirId;";
		return $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);

	}
	
	function getSourceCustomMemberNames( $sourceGroupId )
	{
		$sql = 	"SELECT " . TABLE_CUSTOM_USERS . ".name FROM " . TABLE_CUSTOM_USERS . ", " . TABLE_CUSTOM_CROSS . 
					" WHERE " . TABLE_CUSTOM_USERS . ".id = ".TABLE_CUSTOM_CROSS.".userId AND " . 
					TABLE_CUSTOM_CROSS . ".groupId=$sourceGroupId";
		return $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
	}
	
	
	function getDestinationMemberIds( $sourceUserNames )
	{
		$destinationDirId = $this->m_session->value(INTERNALDIR_ID);
		
		$sql = "SELECT id FROM " .TABLE_CUSTOM_USERS . " WHERE (";
		
		$firstTime = true;
		
		foreach ( $sourceUserNames as $userName )
		{
			$userName = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $userName);
			if ($firstTime)
			{
				$firstTime = false;
			}
			else
			{
				$sql .= " OR ";
			}
			$sql .= "name=\"$userName\"";
		}
		
		$sql .= ") AND dirId=$destinationDirId;";

		$rec = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		
		$userIds = array();
		foreach ( $rec as $userId )
		{
			$userIds[] = $userId['id'];
		}
		
		return $userIds;
	}

	function getDestinationCustomMemberIds( $sourceUserNames )
	{
		$destinationDirId = $this->m_session->value(INTERNALDIR_ID);
		
		$sql = "SELECT id FROM " .TABLE_CUSTOM_USERS . " WHERE (";
		
		$firstTime = true;
		
		foreach ( $sourceUserNames as $userName )
		{
			if ($firstTime)
			{
				$firstTime = false;
			}
			else
			{
				$sql .= " OR ";
			}
			$sql .= "name=\"" . $userName['name'] . "\"";
		}
		
		$sql .= ") AND dirId=$destinationDirId;";

		$rec = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		
		$userIds = array();
		
		foreach ( $rec as $userId )
		{
			$userIds[] = $userId['id'];
		}
		
		return $userIds; // newlly created user ids
	}
}
?>