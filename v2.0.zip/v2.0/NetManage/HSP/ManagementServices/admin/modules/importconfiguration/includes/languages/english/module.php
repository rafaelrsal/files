<?PHP
define('IMPORT_CONFIGURATION_FINISH_BTN','Finish');
define('IMPORT_CONFIGURATION_BACK_BTN','< Back');
define('IMPORT_CONFIGURATION_CANCEL_BTN','Cancel');

define('IMPORT_CONFIGURATION_PASSWORD_LBL','Default password:');
define('IMPORT_CONFIGURATION_MUST_CHANGE_PASS_LBL','User must change password at next logon');
define('IMPORT_CONFIGURATION_ACCOUT_DISABLED_LBL','Account is disabled');
define('IMPORT_CONFIGURATION_CANNOTCHANGEPASS_LBL','User cannot change password');
define('IMPORT_CONFIGURATION_PASSWORD_REQ_MSG_TXT','Password  is required');

define('CUSTOM_DIR_REQUIRED_TXT' ,'denotes required field');
define('IMPORT_CONFIGURATION_LBL' ,'Import preferences');
define('IMPORT_OVERWRITE_LBL' ,'Override existing users and groups');

?>