<?PHP
define('IMPORT_CONFIGURATION_FINISH_BTN','Fim');
define('IMPORT_CONFIGURATION_BACK_BTN','< Voltar');
define('IMPORT_CONFIGURATION_CANCEL_BTN','Cancelar');

define('IMPORT_CONFIGURATION_PASSWORD_LBL','Senha padr�o:');
define('IMPORT_CONFIGURATION_MUST_CHANGE_PASS_LBL','O Usu�rio deve alterar a senha no pr�ximo logon');
define('IMPORT_CONFIGURATION_ACCOUT_DISABLED_LBL','Conta desabilitada');
define('IMPORT_CONFIGURATION_CANNOTCHANGEPASS_LBL','Usu�rio n�o pode alterar a senha');
define('IMPORT_CONFIGURATION_PASSWORD_REQ_MSG_TXT','Senha � obrigat�ria');

define('CUSTOM_DIR_REQUIRED_TXT' ,'verifique os campos obrigat�rios');
define('IMPORT_CONFIGURATION_LBL' ,'Importar preferencias');
define('IMPORT_OVERWRITE_LBL' ,'Sobrescrever usu�rios e grupos existentes');

?>