<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created: Mars 2004
  Title: applicationsDataTbl.php
  Purpose: Controlling all DB connectivity for the applicationsTree module.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
class applicationsDataTbl
{
	var $m_pearDB;
	
	function applicationsDataTbl($peardb)	
	{
		$this->m_pearDB = $peardb;
		$this->m_pearDB->connect();
	}
	
	function getMaxEntryID($tableName, $id_text, &$arrRes)
	{
		return $this->m_pearDB->GetMaxID($tableName, $id_text, $arrRes);
	}
	
	function GetRowForField($tablename, $fieldname, $value, &$arrRes)
	{
		return $this->m_pearDB->GetRowForField($tablename, $fieldname, $value, $arrRes);
	}
	
	function insertToHSPTree($parentId, $appID, $appType, $name, $icon, $description, $appBehavior, $mobile )
	{
		// Get the orderfield number for the node to be entered (under the same father node):
		$orderQuery = "select max(orderfield) from hsp_tree where parent_id = $parentId";
		$maxOrder = $this->GetAllEx($orderQuery);
		
		if(!is_array($maxOrder) || null==$maxOrder)
		{
			return HSP_ERR_DB_ERROR;
		}

		$order = ++$maxOrder[0][0];
		
		if (!$appBehavior) //in order to make sure we insert a null to the db and not zero
		{
			$appBehavior = null;
		}
		
		$fields_values = array(	'parent_id' => $parentId,
								'appID' => $appID,
								'application' => $appType,
								'text' => $name,
								'icon' => $icon,
								'orderfield' => $order,
								'newWindow' => $appBehavior,
								'mobile' => $mobile,
								);

		if(($description != '') && (!is_null($description)))
		{
			$fields_values['title'] = $description;
		}
		
		return $this->m_pearDB->AutoExecute(TABLE_TREE, $fields_values);
	}


	function updateTree($id, &$arrParams)
	{
		if(key_exists("title", $arrParams))
		{
			$x = trim($arrParams['title']);
			
			if($x == '')
			{
				$arrParams['title'] == null;
			}
		}
		
		$strParams = $this->implode_with_keys(',', $arrParams);
		
		$sql = "UPDATE hsp_tree SET $strParams WHERE id = $id;";
		$ret = $this->m_pearDB->Query($sql);
		
		if (HSP_ERR_DB_SQL_ERROR == $ret)
		{
			return ret;
		}
	}
	
	function implode_with_keys($glue, $array) {
       $output = array();
       foreach( $array as $key => $item )
       {
       		if("" == $item)
       		{
       			// Implenting null instead of "":
       			$output[] = $key . "=NULL";
       		}
       		else
       		{
       			$output[] = $key . '="'. $item.'"';
       		}
       }

       return implode($glue, $output);
	} 

	
	function remove($tableName, $idName, $idVal)
	{
		$sql = "DELETE FROM ".$tableName. " WHERE $idName=$idVal;";
		$ret = $this->m_pearDB->Query($sql);
		if (HSP_ERR_DB_SQL_ERROR != $ret)
			return HSP_SUCCESS;
		return $ret;
	}

	function GetAllEx($query)
	{
		return $this->m_pearDB->GetAllEx($query);
	}	
	
}
?>