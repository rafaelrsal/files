function initPopup()
{
	var ListOldPermission = win.document.getElementById('description').value; // permiss�es j� existentes separadas por ;
	var arrListOldPermission = ListOldPermission.split(";"); // array das permiss�es
	var flagChecked; // est� checkado
	
	document.getElementById('popupErrors').innerHTML = '&nbsp;';
	// GUILHERME LIMA 02/04/2013
	var documento = document.getElementById('permission'); // div para inclus�o do checkbox
	
	//zerar documento
	documento.innerHTML = ""; 
	
	if(ListOldPermission != "")
	{// existe alguma permiss�o j� atribuida?
		// loop para rodas todas permis�es possiveis
		for (var i = 0; i < permission.length; i++)
		{
			flagChecked = false; // come�a como n�o checkado
		
			// loop para verificar permiss�es j� existentes
			for(var j = 0; j < arrListOldPermission.length ; j++)
			{
				if(permission[i].nome == arrListOldPermission[j])
				{ // permiss�o igual a corrente?
					documento.innerHTML = documento.innerHTML + '<input type="checkbox" name="permissions" value='+ permission[i].nome +' checked="checked"/> '+ permission[i].nome +'<br/>';// exibe permiss�o checkada
					flagChecked = true; // checka
					break;
				}// end if
			} // end for
			if( flagChecked == false)
			{ // n�o existe est� permiss�o ainda?
				documento.innerHTML = documento.innerHTML + '<input type="checkbox" name="permissions" value='+ permission[i].nome +' /> '+ permission[i].nome +'<br/>';// exibe permiss�o n�o checkada
			} // end if
			
		} // end for
	} // end if
	else
	{ //sen�o
		// loop para rodas todas permis�es possiveis
		for (var i = 0; i < permission.length; i++)
		{
			documento.innerHTML = documento.innerHTML + '<input type="checkbox" name="permissions" value='+ permission[i].nome +' /> '+ permission[i].nome +'<br/>';// exibe permiss�o n�o checkada
		} // end for
	} // end else
	// *************************************	
}

function finalizePopup()
{			    
	SetPermissions()
}

function SetPermissions()
{
	var newPermission = document.getElementsByName('permissions');
	var currentValue = win.document.getElementById('description');
	currentValue.value = "";
	
	for(var i = 0; i < newPermission.length; i++)
	{
		if(newPermission[i].checked == true)
		{
			if(currentValue.value != "")
			{ // ja foi populado com alguma permiss�o?
				currentValue.value = currentValue.value + ";"+ newPermission[i].value;
			}
			else
			{ // senao
				currentValue.value = newPermission[i].value;
			}
		}
	}
	window.close();
}


