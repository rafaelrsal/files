<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: applicationsTree.php
  Purpose: ApplicationsTree module - building the HSP tree of applications.
  Limitations: Requires PHP 4.3.4 and up.


 ============================================================================*/
?>

<?PHP
require_once('HTML/QuickForm.php');
require_once('admin/modules/applicationsData/includes/applicationsDataTbl.php');

class applicationsData extends ModuleBase
{
	var $m_appDataTbl;
	var $m_requestMode;
	var $m_nodeID;
	var $m_fromBck;
	var $m_mobileGeneral;
	
	function applicationsData($globalobjects)
	{
		parent::ModuleBase($globalobjects);

		$db  = &parent::GetDatabase();
		$this->m_appDataTbl = new applicationsDataTbl($db);
		$this->m_mobileGeneral = null;
	}

	function init()
	{
		parent::init("applicationsData");

		$appTypeArr = array(
			'folder'=>APPSDATA_APP_TYPE_TXT, /* A user did not selected no application - it will be folder*/
			'onWeb' =>APPSDATA_ONWEB_TXT,
			'w2h' =>APPSDATA_W2H_TXT,
			'url'=>APPSDATA_LINK_TXT
		);
		
		$appTypeMobileArr = array(			
			'onWeb' =>APPSDATA_ONWEB_TXT,			
			'url'=>APPSDATA_LINK_TXT
		);
		
		
		$appPlatformTypeArr = array(		
			'desktop'=>APPSDATA_PLATFORM_DESKTOP_TXT,
			'mobile'=>APPSDATA_PLATFORM_MOBILE_TXT
		);
		
		// Instantiate the HTML_QuickForm object
		$this->m_form = new HTML_QuickForm('appsDataForm'); //default is post

		// Build the application tree form:
		$this->m_form->addElement('text', 'name',  APPSDATA_NAME_LBL, array('maxlength' => 255,'style="width: 140px;"', 'onchange' => "updated()"));
		$this->m_form->addElement('select', 'icon', APPSDATA_ICON_LBL,$this->getIconList($this->m_session->value(SESSION_NODE_ICON)),'style="width: 140px;" onchange="updated()" onKeyPress="DoDefaultEnterKey(event)"');
		$this->m_form->addElement('text', 'description', APPSDATA_DESC_LBL,'style="width: 240px;"  onchange="updated()" readonly="true"');
		$this->m_form->addElement('select', 'platformType', APPSDATA_APP_PLATFORM_TYPE_LBL ,$appPlatformTypeArr, 'onchange=togglePlatform() style="width: 140px;" onKeyPress="DoDefaultEnterKey(event)"');
		$this->m_form->addElement('select', 'apptype', APPSDATA_APP_TYPE_LBL ,$appTypeArr, 'onchange=toggleButtons() style="width: 140px;" onKeyPress="DoDefaultEnterKey(event)"');
		$this->m_form->addElement('select', 'apptypeMobile', APPSDATA_APP_TYPE_LBL ,$appTypeMobileArr, 'onchange=toggleButtons() style="width: 140px;" onKeyPress="DoDefaultEnterKey(event)"');
		$this->m_form->addElement('button', 'back', APPSDATA_BACK_BTN,'onclick=onBack() class="NewButton"');
		$this->m_form->addElement('button', 'insert', APPSDATA_INSERT_PERMISSION, 'onclick=onInsert() class="NewButton"');
		$this->m_form->addElement('button', 'remove', APPSDATA_REMOVE_PERMISSION, 'onclick=onRemove() class="NewButton"');
		$this->m_form->addElement('radio', 'appRadio', '',APPSDATA_DEFAULT_LBL,0,'onchange="updated()"');
		$this->m_form->addElement('radio', 'appRadio', '',APPSDATA_NEW_WINDOW_LBL,1,'onchange="updated()"');
		$this->m_form->addElement('radio', 'appRadio', '',APPSDATA_NEW_TAB_LBL,2,'onchange="updated()"');		
		$this->m_form->addElement('submit', 'save', APPSDATA_SAVE_BTN,'onclick="onSave();return false;" class="NewButton"');
		$this->m_form->addElement('submit', 'next', APPSDATA_NEXT_BTN,'onclick="onNext();return false;" class="NewButton"');
		$this->m_form->addElement('hidden', 'button_clicked', "none");
		//*************GUILHERME LIMA 12/03/2013*****************
		$this->m_form->addElement('hidden', 'roll', $_SESSION['roll']);

		//*************GUILHERME LIMA 02/04/2013*****************
		$this->m_form->addElement('button', 'cancel', APPSDATA_CANCEL_BTN,  "class='NewButton' onclick='self.close();'");

		//*************GUILHERME LIMA 03/04/2013*****************
		$this->m_form->addElement('button','setPermission', APPSDATA_SET_PERMISSION_BTN,"class='NewButton' onclick='setContent();return false;'");
		
		$this->m_fromBck = false;
	}
	
	function process()
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$appType = null;
		$arrRes = null;

		$this->m_requestMode = 	$this->m_session->value(SESSION_NEW_NODE);
		$this->m_nodeID = $this->m_session->value(SESSION_NODE_ID);

		$appWindow = $this->m_session->value(SESSION_APP_BEHAVIOR);
		
		$this->m_mobileGeneral = $this->m_session->value(SESSION_APP_MOBILE);
		
		if ( 'newWindow' == $appWindow )
		{
			$appRadio = 1;
		}
		elseif ( 'newTab' == $appWindow )
		{
			$appRadio = 2;
		}
		else
		{
			$appRadio = 0;
		}
		
		// GET is when be came here through mavigation from another page:
		if ($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			// Check where did we come from:
			$origin = $this->m_session->value(SESSION_PREV_MODULE);
			$mobileDefault  = $this->m_mobileGeneral?'mobile':'desktop';
			if('applicationsTree' == $origin)
			{
				if('edit' == $this->m_requestMode)
				{
					
					// In edit mode retrieve all information of a node, and present it:
					$this->m_form->setDefaults(array("name"=>$this->m_session->value(SESSION_NODE_NAME),
													 "icon"=>$this->m_session->value(SESSION_NODE_ICON),
													 "description"=>$this->m_session->value(SESSION_NODE_DESC),
													 "platformType"=>$mobileDefault,
													 "apptype"=>$this->m_session->value(SESSION_NODE_APPTYPE),
													 "apptypeMobile"=>$this->m_session->value(SESSION_NODE_APPTYPE),
													 "appRadio"=>$appRadio
													 ));
				}
			}
			else
			{
				$this->m_fromBck = true;
				$appIcon = 	$this->m_session->value(SESSION_NODE_ICON);
				if((W2H_ICON == $appIcon) || (ONWEB_ICON == $appIcon) || (LINK_ICON == $appIcon) || (PROTECTED_LINK_ICON == $appIcon))
				{
					// Don't show the deafult name:
					$appIcon = "default";
				}
				
				// In edit mode retrieve all information of a node, and present it:
				$this->m_form->setDefaults(array("name"=>$this->m_session->value(SESSION_NODE_NAME),
												 "icon"=>$appIcon,
												 "description"=>$this->m_session->value(SESSION_NODE_DESC),
												 "platformType"=>$mobileDefault,
												 "apptype"=>$this->m_session->value(SESSION_NODE_APPTYPE),
												 "apptypeMobile"=>$this->m_session->value(SESSION_NODE_APPTYPE),
												 "appRadio"=>$appRadio
												 ));
			}
		}
		else if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$appPlatformType = htmlspecialchars($this->m_form->exportValue('platformType'));
			
			if ( $appPlatformType == 'desktop' )
			{
				$appType = htmlspecialchars($this->m_form->exportValue('apptype'));
			}
			else 
			{
				$appType = htmlspecialchars($this->m_form->exportValue('apptypeMobile'));
			}			
			
			if ( $appPlatformType == 'mobile' )
			{
				$this->m_mobileGeneral = true;
			}
			else 
			{
				$this->m_mobileGeneral = false;
			}
			
			$this->m_session->set(SESSION_APP_MOBILE, $this->m_mobileGeneral);
		}
	
		if((isset($_POST['button_clicked'])) && ("back" == $_POST['button_clicked']))
		{
			// Go back to 'applicationsTree' page:
			// Let the next screen know who called it:
			$module = 'applicationsData';
			$this->m_session->set(SESSION_PREV_MODULE, $module);
			Header('Location: admin.php?module=applicationsTree&roll='.$_POST['roll']);
			exit();
		}

		$appRadio = htmlspecialchars($this->m_form->exportValue('appRadio'));
		
		$appBehavior = null;
		
		if ( $appRadio == 1 )
		{
			$appBehavior = 'newWindow';
		}
		else if ( $appRadio == 2 )
		{
			$appBehavior = 'newTab';
		}
		
		$this->m_session->set(SESSION_APP_BEHAVIOR, $appBehavior);		
		
		if((isset($_POST['button_clicked'])) && ("save" == $_POST['button_clicked']))
		{
			$save = "";

			$arrParms = null;

			// Get all the POST values
			$name = htmlspecialchars($this->m_form->exportValue('name'));
			$icon= htmlspecialchars($this->m_form->exportValue('icon'));
			$description = htmlspecialchars($this->m_form->exportValue('description'));			
			
			$icon = strlen($icon)?$icon:'default';
			
			if('edit' == $this->m_requestMode)
			{
				$bNameOK = true;
				
				// If the name equals the old name than it's fine. Otherwise we need to validate there
				// is no other node with the same name under the parent:
				if($name != $this->m_session->value(SESSION_NODE_NAME))
				{
					// Validate name:
					$res = $this->validateName_EditMode($this->m_nodeID, $name);
					if(HSP_SUCCESS != $res)
					{
						$bNameOK = false;
					}
				}
				
				if(true == $bNameOK)
				{
					// Get apptype as appears in the database.
					// If app changed than we got missing paramters.
					$sql = "select appID,application from hsp_tree where id=$this->m_nodeID";
					$arrRes = $this->m_appDataTbl->GetAllEx($sql);
					if(is_array($arrRes) && count($arrRes)>0)
					{						
						$orign_app = $arrRes[0][1];							
						if('folder' == $appType)
						{

							if('' == $orign_app)
							{
								// The user didn't change the app type as a folder
								$arrParms = array("text"=>$name, "title"=>$description, "icon"=>$icon, "newWindow"=>null, "mobile"=>$this->m_mobileGeneral );
								$res = $this->m_appDataTbl->updateTree($this->m_nodeID, $arrParms);
							}
							else
							{
								$oldApp = null;
								$res = $this->getPreveApp($this->m_nodeID, & $oldApp);
								if(HSP_SUCCESS == $res)
								{
									// The application type was changed to a folder:
									$res = $this->replaceNode($name, $icon, $description, $oldApp, null);
								}
								
							}
						}
						else
						{
							// Interested in saving an application type:
							if($appType == $orign_app)
							{
								if($icon == 'default')
								{
									if("w2h" == $appType)
									{
										// Make a default -- TEMPORARY!
										$icon = W2H_ICON;
									}
									elseif ("onWeb" == $appType)
									{
										$icon = ONWEB_ICON;
									}
									elseif ("url" == $appType)
									{
										$this->updateMobileURL($arrRes[0][0],$appPlatformType); 
										
										if( $appPlatformType == 'desktop' && "protected" == $this->m_session->value(SESSION_LINK_PROTECTED))
										{
											$icon = PROTECTED_LINK_ICON;
											// Clear session cache:
											$this->m_session->remove(SESSION_LINK_PROTECTED);
										}
										else 
										{
											$icon = LINK_ICON;
										}
									}
								}
							
								// The user didn't change the application type:
								$arrParms = array("text"=>$name, "title"=>$description, "icon"=>$icon , "newWindow"=>$appBehavior, "mobile"=>$this->m_mobileGeneral );
								$res = $this->m_appDataTbl->updateTree($this->m_nodeID, $arrParms);
							}
							else
							{
								// Cannot complete the request. The Next button should have been clicked:
								$res = HSP_ERR_MISSING_APP_SETTINGS;
							}
						}
					}
					else 
					{
						$res = HSP_ERR_DB_ERROR;
					}
				}
			}
			else
			{
				// New node. Only if it is a folder (no app selected) allow action:
				if('folder'==$appType)
				{
					// Make sure the node doesn't get an existing name:
					$res = $this->validateName($this->m_session->value(SESSION_NODE_ID), $name);
				
					if(HSP_SUCCESS == $res)
					{
						// Allow saving:
						$res = $this->saveNode($name, $icon, $description, $this->m_appDataTbl,
												 $this->m_session->value(SESSION_NODE_ID),null );
						$save = "&clicked=finish";
					}
				}
				else
				{
					// Cannot press the 'save' when did not enter app data.
					// The user should have pressed the 'Next' button:
					$res = HSP_ERR_MISSING_APP_SETTINGS;
				}
			}

			if(HSP_SUCCESS != $res)
			{
				$errorCode = array($res);
				$this->m_session->set(SESSION_ERRORS, $errorCode);
			}
			else
			{
				// Succces  --- retuen to the tree:
				// Let the next screen know who called it:
				$module = 'applicationsData';
				$this->m_session->set(SESSION_PREV_MODULE, $module);
				parent::CriaLog($this->m_requestMode . "_" . APPSDATA_SAVE_BTN);
				Header("Location: admin.php?module=applicationsTree$save&roll=".$_POST['roll']);
				exit();
			}
			
		}

		if((isset($_POST['button_clicked'])) && ("next" == $_POST['button_clicked']))
		{
			// Get all the POST values
			$name = htmlspecialchars($this->m_form->exportValue('name'));
			$name = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $name);
			$icon= htmlspecialchars($this->m_form->exportValue('icon'));
			$description = htmlspecialchars($this->m_form->exportValue('description'));
			$description = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $description);
			
			$bNameOK = true;
			
			// Validate a possible name:
			if('new' == $this->m_requestMode)
			{
				// Make sure the node doesn't get an existing name:
				$res = $this->validateName($this->m_session->value(SESSION_NODE_ID), $name);
				
				if(HSP_SUCCESS != $res)
				{
					$bNameOK = false;
				}
			}
			else 
			{
				// Edit mode:
				// If the name equals the old name than it's fine. Otherwise we need to validate there
				// is no other node with the same name under the parent:
				if($name != $this->m_session->value(SESSION_NODE_NAME))
				{
					// Validate name:
					$res = $this->validateName_EditMode($this->m_nodeID, $name);
					if(HSP_SUCCESS != $res)
					{
						$bNameOK = false;
					}
				}
			}

			if(true == $bNameOK)
			{
				// Navigate to the next data page, according to the application
				// whilst saving the new data:
				$this->m_session->set(SESSION_NODE_NAME, $name);

				if($icon == 'default')
				{
					if("w2h" == $appType)
					{
						// Make a default -- TEMPORARY!
						$icon = W2H_ICON;
					}
					elseif ("onWeb" == $appType)
					{
						$icon = ONWEB_ICON;
					}
					// Leave URL as "default"
				}

				$this->m_session->set(SESSION_NODE_ICON, $icon);
				$this->m_session->set(SESSION_NODE_DESC, $description);

				$oldApp = null;
				$res = $this->getPreveApp($this->m_nodeID, & $oldApp);
				if(HSP_SUCCESS == $res)
				{
					$this->m_session->set(SESSION_NODE_PREV_APPTYPE, $oldApp);
					// Let the next screen know where to go back to:
					$module = 'applicationsData';
					$this->m_session->set(SESSION_PREV_MODULE, $module);
					
					if($appType == 'url')
					{
						Header("Location: admin.php?module=applicationsURL&roll=".$_POST['roll']);
						exit();
					}
					elseif ($appType == 'w2h')
					{
						Header("Location: admin.php?module=applicationsW2H&roll=".$_POST['roll']);
						exit();
					}
					elseif ($appType == 'onWeb')
					{
						Header("Location: admin.php?module=applicationsOnWeb&roll=".$_POST['roll']);
						exit();
					}
				}
			}
			// Reaching this code means error:
			$errorCode = array($res);
			$this->m_session->set(SESSION_ERRORS, $errorCode);
		}
	}
	
	function finalize()
	{
		$bEditMode = "false";
		$setNextDisabled = "true";
		$setSaveDisabled = "false";
		
		$appPlatformType = htmlspecialchars($this->m_form->exportValue('platformType'));
		
		if ( $appPlatformType == 'desktop' )
		{
			$appType = htmlspecialchars($this->m_form->exportValue('apptype'));
		}
		else 
		{
			$appType = htmlspecialchars($this->m_form->exportValue('apptypeMobile'));
		}

		
		
		if(( '' != $appType ) && ('folder' != $appType ))
		{
			// Show the Next button when interested in application:
			$setNextDisabled = "false";
		}
		
		if('edit' == $this->m_requestMode)
		{
			$bEditMode = "true";
			if($this->m_fromBck)
			{
				// Check if the application was changed 
				$sql = "select application from hsp_tree where id=$this->m_nodeID";
				$arrRes = $this->m_appDataTbl->GetAllEx($sql);
				if(is_array($arrRes) && count($arrRes)>0)
				{						
					if($appType != $arrRes[0][0])
					{
						// Don't enable the save button:
						$setSaveDisabled = "true";
						$appType = $arrRes[0][0];
					}
				}
			}
		}
		else
		{
			if($this->m_fromBck)
			{
				$setSaveDisabled = "true";
			}
		}

		if("" == ($strNodeName = $this->m_session->value(SESSION_NODE_NAME)))
		{
			$strNodeName=APPSDATA_NEW_ITEM_TXT;			
		}
		
		$arrVars = array(  "strNodeName"=>$strNodeName,
						   "next_disabled"=>$setNextDisabled,
						   "save_disabled"=>$setSaveDisabled,
						   "isEditMode"=>$bEditMode,
						   "originalAPP"=>$appType,
						   "moduleName"=>$this->m_moduleName,
						   "lblInsert"=>rawurlencode(APPSDATA_INSERT_POPUP),
						   "appsDataForm_required_note"=>APPSDATA_REQUIRED_TXT,
						   "missing_name_error"=>APPSDATA_NAME_REQ_MSG						   						   
						   );
		
	   parent::finalize($arrVars);
	}

	function saveNode($name, $icon, $description,  $db, & $parentID, $appBehavior, $mobileGeneral, $insideCall = true)
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$arrRes = null;

		if(false == $insideCall)
		{
			// Called from outside:
			$db = new applicationsDataTbl($db);
		}

		/////// HANDLE INSERTING A NEW NODE//////
		/////////////////////////////////////////
		
		$res = $db->insertToHSPTree($parentID, null, null, $name, $icon, $description, $appBehavior, $mobileGeneral );
		if(HSP_SUCCESS == $res)
		{
			// Get the id of the recently entered node:
			$res = $db->getMaxEntryID(TABLE_TREE, 'id', $arrRes);

			// Update the url(==href) field of the recently inserted node in hsp_tree:
			$paramArr = array("href" => "navigate($arrRes[0])");
			$res = $db->updateTree( $arrRes[0], $paramArr );
			
			if(HSP_SUCCESS == $res)
			{
				// Update the father the he has a new baby born: he is no longer a "leaf":
				$paramArr2 = array("status" => "1");
				$res = $db->updateTree( $parentID, $paramArr2 );
			}

			if(true == $insideCall)
			{
				// Update the node id:
				$this->m_session->set(SESSION_NODE_ID, $arrRes[0]);
			}
			else
			{
				// Update the parentID:
				$parentID = $arrRes[0];
			}
		}

		return $res;
	}


	function replaceNode($name,$icon,$description, $oldAppType, $appBehavior)
	{
		$res = HSP_ERR_UNKNOWN_FAILURE;
		$arrTreeRes = null;
		$appTable = null;
		
		// Get the application ID for the modified node:
		$res = $this->m_appDataTbl->GetRowForField(TABLE_TREE, 'id', $this->m_nodeID, $arrTreeRes);
		if(HSP_SUCCESS == $res)
		{
			// Remove the right application table:
			if('url' == $oldAppType)
				$appTable = TABLE_APPS_LINKS;
			elseif ('w2h' == $oldAppType)
				$appTable = TABLE_APPS_W2H;
			elseif ('onWeb' == $oldAppType)
				$appTable = TABLE_APPS_ONWEB;

			$res = $this->m_appDataTbl->remove($appTable, "appID", $arrTreeRes[2]/*appID*/);
			if(HSP_SUCCESS == $res)
			{
				// update new data and get rid of the app data:
				$arrParms = array("appID"=>"", "application"=>"", "text"=>$name, "title"=>$description, "icon"=>$icon, "newWindow"=>$appBehavior);
				$res = $this->m_appDataTbl->updateTree($this->m_nodeID, $arrParms);
			}
		}

		return  $res;
	}

	function getIconList()
	{
		$dirpath = LMENU_IMAGES_DIR;
    		$dh = opendir($dirpath);
    		$fileList = array();
    		$fileList['default'] = APPSDATA_DEFAULT_ICON_TXT;
       		while (false !== ($file = readdir($dh)))
       		{
			//Don't list subdirectories
          			if (!is_dir("$dirpath/$file"))
          			{
				//Truncate the file extension and capitalize the first letter
           				$fileList[$file] = htmlspecialchars($file);
   			}
		}
     		closedir($dh);
     		return $fileList;
	}
	
	function validateName($parentID, $name)
	{
		// Find if there is already a node with that name under the parent:
		$sql = "select id from hsp_tree where parent_id = $parentID and text=\"$name\"";	

		$arrRes = $this->m_appDataTbl->GetAllEx($sql);

		if(count($arrRes) > 0)
		{
			// Found:
			return HSP_ERR_NAME_ALREADY_EXISTS;
		}
		
		// Valide name:
		return HSP_SUCCESS;	
	}
	
	function validateName_EditMode($nodeID, $newNodeName)
	{
			
		$sql = "select parent_id from hsp_tree where id=$nodeID";
		$arrRes = $this->m_appDataTbl->GetAllEx($sql);
		if(is_array($arrRes))
		{
			if(count($arrRes)>0)
			{
				$parent_id = $arrRes[0][0];
				$sql  = "select id from hsp_tree where text=\"$newNodeName\" and parent_id = $parent_id";
				$arrRes = $this->m_appDataTbl->GetAllEx($sql);
				if(is_array($arrRes))
				{
					if(count($arrRes) > 0)
					{
						// Found:
						return HSP_ERR_NAME_ALREADY_EXISTS;
					}
					else
					{
						return HSP_SUCCESS;
					}
				}
			}
		}

		return $arrRes;
	}
	
	function getPreveApp($nodeID, & $oldApp)
	{
		$sql = "select application from hsp_tree where id=$nodeID";
		$arrRes = $this->m_appDataTbl->GetAllEx($sql);
		if(is_array($arrRes))
		{
			if(count($arrRes)>0)
			{
				$oldApp = $arrRes[0][0];
				return HSP_SUCCESS;
			}
		}

		return $arrRes;

	}
	
	function updateMobileURL( $appID , $platform )
	{
		if ( $platform == 'mobile' )
		{
			$fields_values = array(	'protected'=>0 );	
		}
		else 
		{
			$fields_values = array(	"mobileApp"=>null );
		}
		return $this->m_appDataTbl->m_pearDB->AutoExecute(TABLE_APPS_LINKS , $fields_values, DB_AUTOQUERY_UPDATE,'appID="'.$appID.'";');
	}
	
}
?>