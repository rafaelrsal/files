<?PHP
define('APPSDATA_NAME_LBL','Node name:');
define('APPSDATA_ICON_LBL','Icon file:');
define('APPSDATA_DESC_LBL','Description:');
define('APPSDATA_APP_TYPE_LBL','Application type:');
define('APPSDATA_APP_TYPE_TXT','None');
define('APPSDATA_W2H_TXT','OnWeb Web-to-Host');
define('APPSDATA_ONWEB_TXT','OnWeb application');
define('APPSDATA_LINK_TXT','URL');
define('APPSDATA_NEXT_BTN','Next >');
define('APPSDATA_BACK_BTN','< Back');
define('APPSDATA_SAVE_BTN','Save');
define('APPSDATA_CLEAR_BTN','Clear');
define('APPSDATA_HELP_LNK','Help');
define('APPSDATA_REQUIRED_TXT','denotes required field');
define('APPSDATA_NAME_REQ_MSG','Enter a name');
define('APPSDATA_DEFAULT_ICON_TXT','Default Icon');
define('APPSDATA_NEW_ITEM_TXT','New Item');
define('APPSDATA_NEW_WINDOW_LBL','Open in a new window');
define('APPSDATA_NEW_TAB_LBL','Open in a new tab');
define('APPSDATA_DEFAULT_LBL','Default application behavior');
define('APPSDATA_MOBILE_APPLICATION_TXT','Mobile application');
define('APPSDATA_PLATFORM_DESKTOP_TXT','Desktop');
define('APPSDATA_PLATFORM_MOBILE_TXT','Mobile');
define('APPSDATA_APP_PLATFORM_TYPE_LBL','Platform:');
define('APPSDATA_INSERT_PERMISSION','Insert');
define('APPSDATA_REMOVE_PERMISSION','Clean');
define('APPSDATA_INSERT_POPUP','Set Permissions');
define('APPSDATA_CANCEL_BTN', 'Cancel');
define('APPSDATA_SET_PERMISSION_BTN', 'Set');

?>