<?php
// Admin Global Defines
	define('LANG_DIR' , 'admin/includes/languages/');
	define('CLASSES_DIR' , 'admin/includes/classes/');	
	define('IMAGES_DIR' , 'admin/includes/images/');	
	define('BACKUP_DIR','data/backup/');
	define('MENUITEM_CHANGES','Existem altera��es n�o salvas nesta p�gina. OK para ignorar altera��es?');
	
// Session Defines
	define('SESSION_LANGUAGE','language');
	define('SESSION_MODULE','module');
	define('SESSION_CENTER','center');
	define('SESSION_LEFT','left');
	define('SESSION_RIGHT','right');
	define('SESSION_ERRORS','errors');
	define('SESSION_MESSAGES','messages');
	define('SESSION_INIT_CONFIG','initconfig');
	define('SESSION_DBCONFIG','dbconfig');
	define('SESSION_DATABASE','database');
	define('SESSION_NODE_ID','nodeID');
	define('SESSION_NODE_NAME', 'nodeName');
	define('SESSION_NODE_ICON', 'nodeIcon');
	define('SESSION_NODE_DESC', 'nodeDesc');
	define('SESSION_NODE_APPTYPE', 'nodeAppType');
	define('SESSION_NODE_PREV_APPTYPE', 'prevNodeAppType');
	define('SESSION_NEW_NODE','newNode');
	define('SESSION_PREV_MODULE','prevmodule');
	define('SESSION_AUTH_DIR_ID','authDirID');
	define('SESSION_AUTH_DIR_NAME','authDirName');	
	define('SESSION_ADMIN_AUTH_FLAG', 'adminAuthFlag');
	define('SESSION_SELECTED_NODES_LIST', 'selectedNodesList');
	define('SESSION_GROUP_TREE_BUILD', 'groupTreeBuild');
	define('SESSION_ENTITY_NAME', 'entityName');
	define('SESSION_ENTITY_ID', 'entityID');
	define('SESSION_ONWEB_APPS', 'onwebapps');
	define('SESSION_DIR_AUTH_CACHE' , 'dirAuthCache' );
	define('SESSION_TRUSTEDDOMAINS_CACHE','trusteddomains');
	define('SESSION_PAGECHANGED','pageChanged');
	define('SESSION_DIR_DISPLAY_NAME','dirname');
	define('SESSION_NODE_TO_CUT','nodetocut');
	define('SESSION_NODE_TO_COPY','nodetocopy');
	define('SESSION_SORT_OPTION','sort_option');
	define('SESSION_ANONYMOUS_STATUS','anon_status');
	define('SESSION_RECENT_LIST_VIEW','recent_list_view');
	define('SESSION_LINK_PROTECTED','link_protected');
	define('SESSION_ONWEB_PREV_APP','prev_app');
	define('SESSION_ONWEB_PREV_URL','prev_url');
	define('SESSION_NODE_TREE_POSITION','node_position');
	define('SESSION_APP_BEHAVIOR', 'appBehavior');
	define('SESSION_APP_MOBILE', 'appMobile');
	
?>