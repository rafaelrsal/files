var objPreviousSelectedItem;

var strClassItem='UnSelectedRow';
var strClassHover='ItemHover';
var strClassSelected='SelectedRow';

function MouseOverItem(prmItem)
{
	if(prmItem.className!=strClassSelected)
	{
		prmItem.className=strClassHover;
	}
}
function MouseOutOfItem(prmItem)
{
	if(prmItem.className!=strClassSelected)
	{
		prmItem.className=strClassItem;
	}
}
function ItemClick(prmItem)
{
	//var intRow= prmItem.parentElement.rowIndex;
	//var intColumn=prmItem.cellIndex;
	//var strInnerHTML=prmItem.innerHTML;
	//alert("Row=" + intRow + " Column=" + intColumn + " innerHTML=" + strInnerHTML);
	
	if( objPreviousSelectedItem != null )
	{
		objPreviousSelectedItem.className=strClassItem;    
	}
	
	prmItem.className=strClassSelected;
	objPreviousSelectedItem=prmItem;
}
function FilterByCellValue(prmHTMLTable,prmCellIndex,prmValue,prmStartRow)
{
	var intRowCount;

	for(intRowCount=prmStartRow;intRowCount<prmHTMLTable.rows.length;intRowCount++)
	{
		var objTableRow;
		objTableRow=prmHTMLTable.rows(intRowCount);
		//alert (objTableRow.cells(prmCellIndex).innerHTML + "-" + prmValue);
		if(objTableRow.cells(prmCellIndex).innerHTML!=prmValue)
		{
			objTableRow.style.display="none";
		}
		else
		{
			objTableRow.style.display="";
		}
	}
}

function GetSelectedRowNumber(prmHTMLTable)
{
	var intRowCount;

	for(intRowCount=1;intRowCount<prmHTMLTable.rows.length;intRowCount++)
	{
		var objTableRow;
		objTableRow=prmHTMLTable.rows(intRowCount);
		//alert (objTableRow.cells(prmCellIndex).innerHTML + "-" + prmValue);
		if(objTableRow.className==strClassSelected)
		{
			return intRowCount;
		}
	}
    return -1;
}