//e is event object passed from function invocation
function CheckEnter(e)
{ 
	var characterCode //literal character code will be stored in this variable

	//if which property of event object is supported (NN4)
	if(e && e.which)
	{
		e = e
		characterCode = e.which //character code is contained in NN4's which property
	}
	else
	{
		e = event
		characterCode = e.keyCode //character code is contained in IE's keyCode property
	}

	if(characterCode == 13) //if generated character code is equal to ascii 13 (if enter key)
	{ 
		return true 
	}
	else
	{
		return false 
	}

}

function isEmpty( elementId )
{
	var str = trim( document.getElementById( elementId ).value);
	if ( !str.length )
	{
		return true;
	}
	return false;
}

function trim(inputString) 
{
	// Removes leading and trailing spaces from the passed string. Also removes
	// consecutive spaces and replaces it with one space. If something besides
	// a string is passed in (null, custom object, etc.) then return the input.
	if (typeof inputString != "string") 
	{ 
		return inputString; 
	}
	var retValue = inputString;
	var ch = retValue.substring(0, 1);
	
	while (ch == " ") 
	{ 
		// Check for spaces at the beginning of the string
		retValue = retValue.substring(1, retValue.length);
		ch = retValue.substring(0, 1);
	}
	
	ch = retValue.substring(retValue.length-1, retValue.length);
	
	while (ch == " ") 
	{ 
		// Check for spaces at the end of the string
		retValue = retValue.substring(0, retValue.length-1);
		ch = retValue.substring(retValue.length-1, retValue.length);
	}
	
	while (retValue.indexOf("  ") != -1) 
	{ 
		// Note that there are two spaces in the string - look for multiple spaces within the string
		retValue = retValue.substring(0, retValue.indexOf("  ")) + retValue.substring(retValue.indexOf("  ")+1, retValue.length); // Again, there are two spaces in each of the strings
	}
	return retValue; // Return the trimmed string back to the user
} // Ends the "trim" function

function validatePort()
{
	var port = document.getElementById('port').value;

	if ( isNumeric( port ))
	{
		if (port < 0 || port > 65536)
		{
			return false;
		}
	}
	else
	{
		return false;
	}
	return true;
}

function isNumeric(strString)
//  check for valid numeric strings	
{
	var strValidChars = "0123456789";
	var strChar;
	var blnResult = true;

	if (strString.length == 0)
	{
		return false;
	}

	//  test strString consists of valid characters listed above
	for (i = 0; i < strString.length && blnResult == true; i++)
	{
		strChar = strString.charAt(i);
		if (strValidChars.indexOf(strChar) == -1)
		{
			blnResult = false;
		}
	}
	return blnResult;
}
function validateNumber( value , minValue, maxValue )
{
	if ( isNumeric( value))
	{
		if ( value < minValue || value > maxValue )
		{
			return false;
		}
	}
	else
	{
		return false;
	}
	return true;
}