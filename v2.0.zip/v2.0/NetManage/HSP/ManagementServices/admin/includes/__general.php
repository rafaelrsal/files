<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created: Mars 2004
  Title: general.php
  Purpose: Global functions for db backup and restore
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
function doBackup( $db , $filename, $description, $download=false )
	{
		if (!get_cfg_var('safe_mode')) 
		{
			set_time_limit(0);
		}
		
		if ( empty($filename) || $filename == '.hql')
		{
			$filename = 'db_' . date('d_m_Y_His') . '.hql';
		}
		
        		$backup_file = BACKUP_DIR . $filename;
        		$fp = @fopen($backup_file, 'w');

				if(null == $fp)
				{
					return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;					
				}
	
        		//////////////////////////////////////// details -- added by mhoter July04
        		
        		$details = "mysql&&$description&&\n";
        		fputs($fp, $details);
        		
        		///////////////////////////////////////

        		$schema = 	   '# Database Backup For HSP ' .  "\n" .			              
			                  '# Backup Date: ' . date('d/m/Y H:i:s') . "\n" .
			                  '##################################' . "\n\n";
        		fputs($fp, $schema);
		$tables = array();
        		$tablesArr = $db->GetAllEx('show tables',null,DB_FETCHMODE_ASSOC);
        		foreach($tablesArr as $tableArr)
        		{
        			foreach($tableArr as $tableName)
        			{
        				$tables[] = $tableName;
        			}
        		}
        		
		foreach($tables as $table)
        		{
          			//list(,$table) = each($tables);

          			$schema = 'drop table if exists ' . $table . ';' . "\n" .
                    		'create table ' . $table . ' (' . "\n";
          			$table_list = array();
          			$fields_query = $db->Query("show fields from " . $table);
          			while ($fields = $db->Fetch(DB_FETCHMODE_ASSOC)) 
          			{
            				$table_list[] = $fields['Field'];
            				$schema .= '  ' . $fields['Field'] . ' ' . $fields['Type'];
            				if (strlen($fields['Default']) > 0) 
            				{
            					$schema .= ' default \'' . $fields['Default'] . '\'';
            				}

            				if ($fields['Null'] != 'YES') 
            				{
            					$schema .= ' not null';
            				}

            				if (isset($fields['Extra'])) 
            				{
            					$schema .= ' ' . $fields['Extra'];
            				}

            				$schema .= ',' . "\n";
          			}
          			
          			$schema = ereg_replace(",\n$", '', $schema);

			// add the keys
          			$index = array();
          			$keys_query = $db->Query("show keys from " . $table);
          			
          			while ($keys = $db->Fetch(DB_FETCHMODE_ASSOC)) 
          			{
            				$kname = $keys['Key_name'];
            				if (!isset($index[$kname])) 
            				{
              					$index[$kname] = array('unique' => !$keys['Non_unique'], 'columns' => array());
            				}
	            			
            				$index[$kname]['columns'][] = $keys['Column_name'];
          			}

          			while (list($kname, $info) = each($index)) 
          			{
            				$schema .= ',' . "\n";
            				$columns = implode($info['columns'], ', ');

            				if ($kname == 'PRIMARY') 
            				{
              					$schema .= '  PRIMARY KEY (' . $columns . ')';
            				} 
            				elseif ($info['unique']) 
            				{
              					$schema .= '  UNIQUE ' . $kname . ' (' . $columns . ')';
            				}
            				else 
            				{
            					$schema .= '  KEY ' . $kname . ' (' . $columns . ')';
            				}
          			}

          			$schema .= "\n" . ');' . "\n\n";
          			fputs($fp, $schema);

			// dump the data
          			$rows_query = $db->Query("select " . implode(',', $table_list) . " from " . $table);
          			while ($rows = $db->Fetch(DB_FETCHMODE_ASSOC))
          			{
            				$schema = 'insert into ' .  $table . ' (' . implode(', ', $table_list) . ') values (';
            				reset($table_list);
            				while (list(,$i) = each($table_list)) 
            				{
              					if (!isset($rows[$i]))
              					{
                					$schema .= 'NULL, ';
              					}
              					elseif (!is_null($rows[$i]))
              					{
                					$row = addslashes($rows[$i]);
                					$row = ereg_replace("\n#", "\n".'\#', $row);
                					$schema .= '\'' . $row . '\', ';
              					} 
              					else 
              					{
              						$schema .= '\'\', ';
              					}
            				}

            				$schema = ereg_replace(', $', '', $schema) . ');' . "\n";
            				fputs($fp, $schema);

          			}
        		}

        		fclose($fp);
        		if ( $download )
        		{
        			  if ($fp = fopen($backup_file, 'rb')) 
        			  {
			  
        			  	$buffer = fread($fp, filesize($backup_file));
            				fclose($fp);

			            	header('Content-type: application/x-octet-stream');
			            	header('Content-disposition: attachment; filename=' . $backup_file);

			            	echo $buffer;
        			  }				
        		}
	}
	
	function doRestore( $db, $fileName, $dbtype, $bInitialDump  )
	{		
		$restore_from = $fileName;
		$remove_raw = false;
          

		if(file_exists($restore_from))
		{
			$handle = @fopen($restore_from, "rb");
			if($handle)
			{
				$restore_query = fread($handle, filesize($restore_from));
				fclose($handle);
			}
			else
				return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
		}
		else 
			return HSP_ERR_FILE_NOT_FOUND;
			
  		//////////////////////////////////////// remove details from query -- added by mhoter July04
		if( $bInitialDump === false)
		{
			// Restoring a file that we are trying to import:
			if(0 < strpos($restore_query, "&&"))
			{
		  		// A backed up file (file that was exported) contains data that should be removed before
		  		// executing the sql query:

				list($type, $decription, $extra) = @split("&&", $restore_query, 3);
				
		  		if(!is_null($extra ))
		  		{
		  			$restore_query = $extra;
		  		}
			}
			else
				// Wrong back-up file:
				return HSP_ERR_INCONGRUENT_FILE;
		}
  		
        ///////////////////////////////////////
			
       	if("mysql" == $dbtype)
		{
	        if (isset($restore_query))
	        {
	        	$sql_array = array();
				$sql_length = strlen($restore_query);
				$pos = strpos($restore_query, ';');
		          		
				for ($i=$pos; $i<$sql_length; $i++) 
				{
        			if ($restore_query[0] == '#') 
        			{
              			$restore_query = ltrim(substr($restore_query, strpos($restore_query, "\n")));
              			$sql_length = strlen($restore_query);
              			$i = strpos($restore_query, ';')-1;
              			continue;
        			}
		
        			if ($restore_query[($i+1)] == "\n") 
        			{
          				for ($j=($i+2); $j<$sql_length; $j++) 
          				{
            				if (trim($restore_query[$j]) != '') 
            				{
              					$next = substr($restore_query, $j, 6);
              					if ($next[0] == '#') 
              					{
						// find out where the break position is so we can remove this line (#comment line)
                						for ($k=$j; $k<$sql_length; $k++) 
                						{
                  							if ($restore_query[$k] == "\n") 
                  								break;
                						}
                					
                						$query = substr($restore_query, 0, $i+1);
                						$restore_query = substr($restore_query, $k);
						// join the query before the comment appeared, with the rest of the dump
                						$restore_query = $query . $restore_query;
                						$sql_length = strlen($restore_query);
                						$i = strpos($restore_query, ';')-1;
                						continue 2;
              					}
              					break;
            				}
          				}
          				
          				if ($next == '') 
          				{ // get the last insert query
            				$next = 'insert';
          				}
          				
          				if ( (eregi('create', $next)) || (eregi('insert', $next)) || (eregi('drop t', $next)) ) 
          				{
            				$next = '';
			                $sql_array[] = substr($restore_query, 0, $i);
			                $restore_query = ltrim(substr($restore_query, $i+1));
			                $sql_length = strlen($restore_query);
			                $i = strpos($restore_query, ';')-1;
          				}
        			}
          		}

          		for ($i=0, $n=sizeof($sql_array); $i<$n; $i++) 
          		{
        			$res = $db->Query($sql_array[$i]);
        			if(HSP_ERR_DB_SQL_ERROR == $res)
        				return $res;
          		}

          		if (isset($remove_raw) && ($remove_raw == true)) 
          		{
            			unlink($restore_from);
          		}
			}
		}
		elseif ("mssql" == $dbtype)
		{
			$res = $db->Query($restore_query);
		}
		
		if($res != HSP_ERR_DB_SQL_ERROR)
			$res = HSP_SUCCESS;
			
		return $res;			
	}

	
	function doBackup_MSSQL($db , $filename, $description)
	{
		$strOutPut = ""; // String containing the sql dump.
		
		$dbtype = "mssql";
		$targetType = $dbtype; // the default is to mssql/mysql
		$dumpTablesPattern = ""; // default - copy all tables
		$addReconnect = false;
		//$reconnectInverval = max(5, @$HTTP_POST_VARS["reconnectInterval"]);
		$addDropTables = true;
		$addFulltextIndex = false;
		
		$db = $db->GetDBObj();
		
		$db->setFetchMode(DB_FETCHMODE_ASSOC);
		if ($targetType==$dbtype) 
		{
		  $tdb = $db;
		} 
		else 
		{
		  $tdb = DB::factory($targetType);
		}
		// PEAR DB library Bug workaround
		// DB::mysql::quoteSmart() does not work without a connection
		$qdb = ($targetType=="mysql" ? $db : $tdb);
		
		$prepSql = array();
		$postSql = array();
		if ($targetType=="mssql") {
		  $prepSql[] = "SET DATEFORMAT ymd";
		  $prepSql[] = "SET ANSI_NULLS ON";
		  $prepSql[] = "SET ANSI_NULL_DFLT_ON ON";
		  $prepSql[] = "SET ANSI_PADDING ON";
		  //  $postSql[] = "COMMIT TRAN";
		}
		if ($dbtype=="mssql") {
		  $db->query("SET DATEFORMAT ymd");
		}

		// Get list of tables
		switch($dbtype) {
		  case "mssql":
		    $dbres = $db->query("EXEC sp_tables @table_type=\"'TABLE'\"");
		    if (DB::isError($dbres)) {
		       die("SQL error: ".$dbres->getDebugInfo()."\n");
		    }
		    $tblNames = array();
		    while($dbres->fetchInto($tblrec)) {
		      if ($tblrec["TABLE_NAME"] != "dtproperties") {
		        $tblNames[] = $tblrec["TABLE_NAME"];
		      }
		    }
		    break;
		  case "mysql":
		    $tblNames = $db->getCol("SHOW TABLES");
		    if (DB::isError($tblNames)) {
		       die("SQL error: ".$tblNames->getDebugInfo()."\n");
		    }
		    break;
		  default:
		    die("Unknown database type $dbtype");
		}
		
		// Dump each table
		$constraintNames=array();
		foreach($tblNames as $tblName) 
		{
		  // fetch info about table to write the CREATE command for this table
		  $tblInfo = $db->tableInfo("$tblName");
		  if (DB::isError($tblInfo)) //gschetrit - use error handling!!!
		  {
			return 	HSP_ERR_DB_SQL_ERROR;		  	
		  }
		  $tblHasIncrementingKey = 0;
		  $colDefinitions = array();
		  $colList = array();
		  $multikeys = array();
		  $datefields = array();
		  $tblNameQuoted = $tdb->quoteIdentifier($tblName);
		  $primaryConstraint = "";
		  foreach($tblInfo as $colInfo) 
		  {
		    // get info about column
		    $colName = $colInfo["name"];
		    $colList[] = $tdb->quoteIdentifier($colName);
		    $colType = mapType($colInfo["type"]);
		    $colLength = $colInfo["len"];
		    $colAllowsNull = ! preg_match("/not_null/i", $colInfo["flags"]);
		    $colIsIncrementing = preg_match("/increment/i", $colInfo["flags"]);
		    $tblHasIncrementingKey = $tblHasIncrementingKey || $colIsIncrementing;
		    $colIsUnique = false;
		    if (preg_match("/primary/i", $colInfo["flags"])) 
		    {
		      $multikeys["PRIMARY KEY"][] = $colName;
		    }
		    elseif (preg_match("/unique/i", $colInfo["flags"])) 
		    {
		       if (preg_match("/multiple/i", $colInfo["flags"])||$targetType=="mysql")
		       {
		       		$multikeys["UNIQUE"][] = $colName;
		       } 
		       else 
		       {
			       $colIsUnique = true;
		       }
		    } elseif ((preg_match("/multiple/i", $colInfo["flags"]) || $colIsIncrementing) && $targetType=="mysql") {
		      $multikeys["KEY"][] = $colName;
		    }
		    if (preg_match("/date/i", $colType)) {
		      $datefields[] = $colName;
		    }
		    if ($colIsIncrementing) {
		      $colDefault = "";
		    } elseif ($colAllowsNull) {
		      $colDefault = "NULL";
		    } else {
		      $colDefault = typeDefault($colType, $targetType, $qdb);
		    }
		    $colDefinitions[] = $tdb->quoteIdentifier($colName)
		      . " " . $colType
		      . ($colType=="VARCHAR"||$colType=="CHAR" ? "($colLength)" : "")
		      . ($colAllowsNull ? " NULL" : " NOT NULL")
		      . ($colIsIncrementing ? 
		          ($targetType=="mssql"?" IDENTITY":" AUTO_INCREMENT") : "")
		      . ($colIsUnique ? " UNIQUE" : "")
		      . ($colDefault!="" ? " DEFAULT $colDefault" : "");
		  }
		  if (count($multikeys)>0) {
		    // Add primary- and multiple-key constraints
		    foreach($multikeys as $multitype => $multikey) {
		      $multiname = join("_", $multikey).(count($multikey)==1?"_constraint":"");
		      $postfix = "";
		      // Make sure every constraint has a unique name
		      while (in_array($multiname.$postfix, $constraintNames)) {
		        $postfix++;
		      }
		      $multiname.=$postfix;
		      $constraintNames[] = $multiname;
		      if ($multitype=="PRIMARY KEY") {
		        $primaryConstraint = $multiname;
		      }
		      $multiname = $tdb->quoteIdentifier($multiname);
		      $multikey2 = array();
		      foreach ($multikey as $multikeyfield) {
		        $multikey2[] = $tdb->quoteIdentifier($multikeyfield);
		      }
		      //mhoter & gschetrit - 	removed the constaint from the backup process to support
		      // 						mssql (caused troubles when restoring the database)
		      /*$colDefinitions[] = 
		          ($targetType=="mssql" ? "CONSTRAINT $multiname $multitype"
		          : "$multitype $multiname") . " (" . join(", ", $multikey2) . ")";*/
		      $colDefinitions[] = "$multitype" . " (" . join(", ", $multikey2) . ")" ;
		    }
		  }
		  if ($addDropTables) {
		    $strOutPut .= "DROP TABLE $tblNameQuoted";
		  }
		  $strOutPut .="CREATE TABLE $tblNameQuoted (\n  "
		      . join(",\n  ", $colDefinitions) . "\n)";
		  $strOutPut .= "\n";
		  // Add fulltext indexes/catalogs
		  $fulltext = array();
		  $fulltextname = "";
		  if ($addFulltextIndex) {
		    if ($dbtype == "mysql") {
		      foreach($db->getAll("SHOW INDEX FROM $tblName") as $colInfo) {
		        if ($colInfo["Index_type"]=="FULLTEXT") {
		          $fulltext[] = $colInfo["Column_name"];
		          $fulltextname = $colInfo["Key_name"];
		        }
		      }
		    }
		  }
		  if (count($fulltext)>0) {
		    if ($targetType == "mysql") {
		      $fulltextQuoted = array();
		      foreach($fulltext as $colName) {
		        $fulltextQuoted = $tdb->quoteIdentifier($colName);
		      }
		      $strOutPut .="ALTER TABLE $tblNameQuoted"
		         ." ADD FULLTEXT ".$tdb->quoteIdentifier($fulltextname)
		         ." (".join(", ", $fulltextQuoted).")";
		    } else {
		      // MSSQL full text indices are a bit more work
		      $strOutPut .="EXEC sp_fulltext_catalog "
		          . $qdb->quoteSmart($fulltextname).", "
		          . $qdb->quoteSmart('create');
		      $strOutPut .="EXEC sp_fulltext_table "
		          . $qdb->quoteSmart($tblName).", "
		          . $qdb->quoteSmart('create').", "
		          . $qdb->quoteSmart($fulltextname).", "
		          . $qdb->quoteSmart($primaryConstraint);
		      foreach($fulltext as $colName) {
		        $strOutPut .="EXEC sp_fulltext_column "
		          . $qdb->quoteSmart($tblName).", "
		          . $qdb->quoteSmart('add');
		      }
		      $strOutPut .="EXEC sp_fulltext_table "
		          . $qdb->quoteSmart($tblName).", "
		          . $qdb->quoteSmart('activate');
		      $strOutPut .="EXEC sp_fulltext_table "
		          . $qdb->quoteSmart($tblName).", "
		          . $qdb->quoteSmart('start_full');
		      $strOutPut .="EXEC sp_fulltext_table "
		          . $qdb->quoteSmart($tblName).", "
		          . $qdb->quoteSmart('start_background_updateindex');
		    }
		  }
		
		  if (empty($dumpTablesPattern) || preg_match("/(?:$dumpTablesPattern)/i", $tblName)) 
		       { 
		    // Dump the contents of the table (if any)
		    $tblres=$db->query("SELECT * FROM $tblName");
		    if ($tblres->fetchInto($tblrow)) 
		    {
		      if ($tblHasIncrementingKey && $targetType=="mssql") {
		        $strOutPut .="SET IDENTITY_INSERT $tblNameQuoted ON ";
		        $prepSql[] = "SET IDENTITY_INSERT $tblNameQuoted ON ";
		        $postSql[] = "SET IDENTITY_INSERT $tblNameQuoted OFF ";
		      }
		      do {
		        if (count($datefields)>0 && $targetType!=$dbtype) {
		          if ($targetType=="mysql") {
		            // Reformat date fields mssql=>mysql
		            foreach ($datefields as $fld) {
		              $tblrow[$fld] = strftime("%Y-%m-%d %H:%M:%S",
		                  strtotime($tblrow[$fld]));
		            }
		          } else  {
		            // Reformat date fields mysql=>mssql
		            foreach ($datefields as $fld) {
		              if (preg_match("/^(\d\d\d\d)(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/",
		                  $tblrow[$fld], $match)) {
		                $tblrow[$fld] = sprintf("%04d-%02d-%02d %02d:%02d:%02d",
		                    $match[1], $match[2], $match[3],
		                    $match[4], $match[5], $match[6]);
		              }
		            }
		          }
		        }
		        $valuesQuoted = array();
		        foreach ($tblrow as $i => $value) {
		          $valuesQuoted[] = $qdb->quoteSmart($value);
		        }
		        $strOutPut .="INSERT INTO $tblNameQuoted\n  ("
		            .join(", ", $colList) .")\n"
		            . "  VALUES (".join(", ", $valuesQuoted).")";
		      } while($tblres->fetchInto($tblrow));
		      if ($tblHasIncrementingKey && $targetType=="mssql") {
		        $strOutPut .="SET IDENTITY_INSERT $tblNameQuoted OFF ";
		        array_pop($prepSql);
		        array_pop($postSql);
		      }
		      $strOutPut .= "\n\n";
		    }
		    $strOutPut .= "\n";
		  }
		
		}
		//$strOutPut .="END";
		
		// Insert to a file:
		if (!get_cfg_var('safe_mode')) 
		{
			set_time_limit(0);
		}
		
		if ( empty($filename) || $filename == '.hql' )
		{
			$filename = 'db_' . date('d_m_Y_His') . '.hql';
		}
		
		$handle = @fopen(BACKUP_DIR . $filename, "w");
		if($handle)
		{
       		//////////////////////////////////////// details -- added by mhoter July04
        		
        	$details = "mssql&&$description&&\n";
        	fputs($handle, $details);
        		
        	///////////////////////////////////////			
			
			$res = fwrite($handle, $strOutPut);
			fclose($handle);
			if(false != $res)
				return HSP_SUCCESS;
			return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
		}

		return 	HSP_ERR_FILE_NOT_FOUND;		
	}

	////// gschetrit - added MSSQL ODBC support
	function doBackup_MSSQLODBC($db , $filename, $description)
	{
		$strOutPut = ""; // String containing the sql dump.
		
		$dbtype = "mssql";
		$targetType = $dbtype; // the default is to mssql/mysql
		$addReconnect = false;
		$addDropTables = true;
		$addFulltextIndex = false;
		
		$db = $db->GetDBObj();
		$db->setFetchMode(DB_FETCHMODE_ASSOC);
		
		//$qdb = $db;
		
		$db->query("SET DATEFORMAT ymd");
		$db->query("SET DATEFORMAT ymd");

		// Get list of tables
	    $dbres = $db->query("EXEC sp_tables @table_type=\"'TABLE'\"");
	    if (DB::isError($dbres)) 
	    {
	    	return 	HSP_ERR_DB_SQL_ERROR;
	    }
	    $tblNames = array();
	    while($dbres->fetchInto($tblrec)) 
	    {
	    	if ($tblrec["TABLE_NAME"] != "dtproperties") 
	    	{
	        	$tblNames[] = $tblrec["TABLE_NAME"];
	    	}
	    }
		
		// Dump each table
		$constraintNames=array();
		$dropTable = '';
		
		foreach($tblNames as $tblName) 
		{
			// Dump the contents of the table (if any)
			$tblres=$db->query("SELECT * FROM $tblName");
			
			if ($tblres->fetchInto($tblrow)) 
			{
				$colList = array_keys($tblrow);
				
				do 
				{
					$valuesQuoted = array();
					foreach ($tblrow as $i => $value) 
					{
						$valuesQuoted[] = $db->quoteSmart($value);
					}
					
					//add set identity only to tables containing auto incremental fields
					if ($tblName == TABLE_CUSTOM_CROSS || 
						$tblName == TABLE_GAT_UAT || 
						$tblName == TABLE_GENERAL ||
						$tblName == TABLE_CLIENT_CONFIG || 
						$tblName == TABLE_CONNECTION_INFO || 
						$tblName == TABLE_REGISTRATION_INFO || 
						$tblName == TABLE_REPORTS || 
						$tblName == TABLE_SERVICE_CONFIG || 
						$tblName == TABLE_USER_PARAMETER || 
						$tblName == TABLE_W2HWHOS_ONLINE ||
						$tblName == TABLE_WHOS_ONLINE)
					{
						$strOutPut .="INSERT INTO $tblName (" .join(", ", $colList) .") " . "  VALUES (".join(", ", $valuesQuoted).");";
					}
					else
					{
						$strOutPut .="SET IDENTITY_INSERT $tblName ON INSERT INTO $tblName (" .join(", ", $colList) .") " . "  VALUES (".join(", ", $valuesQuoted).") SET IDENTITY_INSERT $tblName OFF;";
					}
					$strOutPut .= "\n";
					
				} while($tblres->fetchInto($tblrow));
				$strOutPut .= "\n";
			}
			
			$dropTable .= "DROP TABLE $tblName \n";
		}
		
		// Insert to a file:
		if (!get_cfg_var('safe_mode')) 
		{
			set_time_limit(0);
		}
		
		if ( empty($filename) || $filename == '.hql' )
		{
			$filename = 'db_' . date('d_m_Y_His') . '.hql';
		}
		
		$hsp_mssql = generateTablesString();
		
		if ( !empty($hsp_mssql) )
		{
			$handle = @fopen(BACKUP_DIR . $filename, "w");
			if($handle)
			{
	        	$details = "mssql&&$description&&\n";
	        	fwrite($handle, $details);
	        		
	        	fwrite($handle, $dropTable . "\n");
				fwrite($handle, $hsp_mssql . "\n");
				
				$res = fwrite($handle, $strOutPut);
				fclose($handle);
				if(false != $res)
				{
					return HSP_SUCCESS;
				}
				return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
			}
		}
		return 	HSP_ERR_FILE_NOT_FOUND;		
	}
	
	function generateTablesString()
	{
		$str = '';
		$lines = file('includes/config/hsp_mssql.sql');
		foreach ($lines as $line) 
		{
			if ( !strstr ( $line, "INSERT" ) )
			{
	   			$str .= $line;
			}
		}
		return $str;
	}
	
	function mapType($colType) 
	{
	  //global $targetType, $dbtype; //gschetrit - using only mssql
	  $colType = strtoupper($colType);
	  //if ($targetType=="mssql") {
	    switch($colType) 
	    {
	      case "MEDIUMINT":
	        return "INT";
	      case "TIMESTAMP":
	        //return ($dbtype=="mysql" ? "DATETIME" : "TIMESTAMP");
	        return "TIMESTAMP";
	      case "DATE":
	      case "TIME":
	      case "YEAR":
	        return "DATETIME";
	      case "BLOB":
	      case "TINYBLOB":
	      case "MEDIUMBLOB":
	      case "LONGBLOB":
	        return "TEXT";
	      case "TEXT":
	      case "TINYTEXT":
	      case "MEDIUMTEXT":
	      case "LONGTEXT":
	        return "TEXT";
	      case "ENUM":
	      case "STRING":
	      case "CHAR":
	        return "VARCHAR";
	      default:
	      	return $colType;
	    }
	  /*} elseif ($targetType=="mysql") { //gschetrit - using only mssql
	    switch($colType) {
	      case "BIT":
	        return "TINYINT";
	      case "MONEY":
	        return "BIGINT";
	      case "SMALLMONEY":
	        return "INT";
	      case "SMALLDATETIME":
	        return "DATETIME";
	      case "NTEXT":
	        return "TEXT";
	      case "BINARY":
	      case "VARBINARY":
	        return "BLOB";
	      case "IMAGE":
	        return "LONGBLOB";
	      case "STRING":
	      case "CHAR":
	        return "VARCHAR";
	    }
	  }
	  return $colType;*/
	}


	function typeDefault($colType, $targetType, $qdb) {
	  //global $targetType, $dbtype, $qdb;
	  switch($colType) {
	    case "INT":
	    case "TINYINT":
	    case "SMALLINT":
	    case "MEDIUMINT":
	    case "BIGINT":
	    case "FLOAT":
	    case "DOUBLE":
	    case "DECIMAL":
	    case "NUMERIC":
	    case "BIT":
	    case "MONEY":
	    case "SMALLMONEY":
	      return $qdb->quoteSmart(0);
	    case "DATETIME":
	    case "SMALLDATETIME":
	      return $targetType=="mssql" ? "CURRENT_TIMESTAMP" : "";
	    case "VARCHAR":
	    case "CHAR":
	    case "TEXT":
	    case "NATIONAL CHAR":
	    case "NATIONAL VARCHAR":
	    case "NATIONAL TEXT":
	    case "BINARY":
	    case "VARBINARY":
	    case "IMAGE":
	    case "TINYBLOB":
	    case "TINYTEXT":
	    case "BLOB":
	    case "TEXT":
	    case "MEDIUMBLOB":
	    case "MEDIUMTEXT":
	    case "LONGBLOB":
	    case "LONGTEXT":
	    case "ENUM":
	      return  $qdb->quoteSmart("");
	    default:
	      return "";
	  }
	}
	
?>