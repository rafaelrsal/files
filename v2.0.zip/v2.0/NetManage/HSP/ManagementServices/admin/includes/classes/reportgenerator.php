<?PHP
require_once('HTML/Table.php');
require_once('includes/classes/PearDB.php');
require_once('includes/classes/stringTranslation.php');
class reportGenerator
{
	var $m_table;
	var $m_tableArr;
	var $m_tableInfoArr;
	var $m_csvStr;
	var $m_strReportName;
	var $m_stringTranslation;
	var $m_headerTxt;
	
	function reportGenerator( $name, $langObj, $moduleName, $tableAttrs=null)
	{
		$this->m_csvStr = '';
		$this->m_strReportName = $name;

		if (is_null($tableAttrs) || !is_array($tableAttrs))
		{
			$tableAttrs = array('width="100%" id="tblBackups" border="1" class="DataTable" bordercolor="black""');
		}

		$this->m_table = new HTML_Table($tableAttrs);
		$langObj->RequireLangFile( 'stringTranslation.php' , $moduleName );
		$this->m_stringTranslation = new stringTranslation();
	}

	function createTable(&$db, $tableName, $columsNamesArr , $sql=null)
	{

		if (is_null($sql))
		{
			$this->m_tableArr = $db->GetAll($tableName);
			$this->m_tableInfoArr = $columsNamesArr;
		}
		else
		{
			$this->m_tableArr = $db->GetAllEx($sql);
			$this->m_tableInfoArr = $columsNamesArr;
		}
		$this->m_table ->setAutoGrow(true);
		$this->m_table ->setAutoFill("&nbsp;");

		for($nr = 0; $nr < count($this->m_tableArr); $nr++)
		{
			//$this->m_table -> setHeaderContents( $nr+1, 0, (string)$nr);
		 	for($i = 0; $i < count($this->m_tableInfoArr); $i++)
		 	{
		 		$this->m_table -> setCellContents( $nr+1, $i, $this->m_stringTranslation->translate( $this->m_tableArr[$nr][$i]));
		 	}
		}

		$altRow = array("class"=>"ReportData");
		$this->m_table -> altRowAttributes(0, null, $altRow);
		$this->m_table -> altRowAttributes(1, null, $altRow);

		$this->m_table -> setHeaderContents(0, 0, "");

		for($i = 0; $i < count($this->m_tableInfoArr); $i++)
		{
			$this->m_table -> setHeaderContents(0, $i, $this->m_tableInfoArr[$i]);
		}
		$hrAttrs = array("class" => "ReportRowHeader");

		$this->m_table -> setRowAttributes(0, $hrAttrs, true);
		$this->m_table -> setRowAttributes(0, "class='TableCellHeader'", false);
		
		$this->m_table -> setColAttributes(0, "class='TableCellHeader'");

		return $this->m_table;
	}

	function createCSV()
	{
		$this->m_csvStr .= $this->m_headerTxt . "\n";
		for($i = 0; $i < count($this->m_tableInfoArr); $i++)
		{
			$this->m_csvStr .= $this->m_stringTranslation->translate($this->m_tableInfoArr[$i]) . ",";
		}
		$this->m_csvStr .= "\n";



		for($nr = 0; $nr < count($this->m_tableArr); $nr++)
		{
		 	for($i = 0; $i < count($this->m_tableInfoArr); $i++)
		 	{
		 		$this->m_csvStr .= $this->m_stringTranslation->translate($this->m_tableArr[$nr][$i]) . ",";
		 	}
		 	$this->m_csvStr .= "\n";
		}

		return $this->m_csvStr;
	}

	function downloadCSV()
	{
		$this->createCSV();

		ob_clean();

		$filename = $this->m_strReportName .'.csv';

		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");

		//To force a download on MSIE for Windows, you don't have to use "attachment", but you need it for all other browsers.
		$user_agent = strtolower ($_SERVER["HTTP_USER_AGENT"]);
		if ((is_integer (strpos($user_agent, "msie"))) && (is_integer (strpos($user_agent, "win"))))
		{
			header("Content-Disposition: filename=".basename($filename).";");
		}
		else
		{
			header("Content-Disposition: attachment; filename=".basename($filename).";");
		}

		header("Content-Transfer-Encoding: binary");

		//file size
		$size = array_sum(count_chars ($this->m_csvStr));

		header("Content-Length: ".$size);
		//ob_end_flush();
		echo $this->m_csvStr;
		exit();
	}

	function prepareReportPage()
	{
		// Prepare the file code:
		$strFileContent = '<HTML><HEAD><TITLE>HSP Report '.$this->m_strReportName.'</TITLE><META HTTP-EQUIV="Pragma" CONTENT="no-cache"><META HTTP-EQUIV="Expires" CONTENT="-1">';
        $strFileContent .= '<link rel="stylesheet" type="text/css" href="/hsp/includes/stylesheets/hsp.css"></HEAD><body>';
		//$strFileContent .= $this->m_headerTxt;		
        $strFileContent .= $this->m_table->toHTML();
		$strFileContent .= '</BODY><HEAD><META HTTP-EQUIV="Pragma" CONTENT="no-cache"><META HTTP-EQUIV="Expires" CONTENT="-1"></HEAD></HTML>';

		$fileName = "data/reportPrint.html";

		if(file_exists($fileName))
		{
			// Avoid php warnings:
			if(is_writable($fileName) == false)
				return 	HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
		}

		// Running over the old file whether exists or not:
		$handle = fopen($fileName, "w");
		if($handle)
		{
			$res = fwrite($handle, $strFileContent);
			fclose($handle);
			if(false != $res)
				return HSP_SUCCESS;
		}
	}

	function getReportAsIFrame()
	{
		return '<IFRAME SRC="data/reportPrint.html" name="report" FRAMEBORDER=0 width="100%" height="380px"></IFRAME>';
	}

	function createHeaderTxt($title,$fromDate, $toDate, $fromTime, $toTime)
	{
		$this->m_headerTxt = $title . "\n";
		$this->m_headerTxt .= REPORT_FROM_TXT . " " . REPORT_DATE_LBL . $fromDate . "   " . REPORT_TIME_LBL . $fromTime.':00:00' . "\n"; 
		$this->m_headerTxt .= REPORT_TO_TXT . "     " . REPORT_DATE_LBL . $toDate . "   " . REPORT_TIME_LBL . $toTime.':00:00' . "\n";		
	}	
}
?>