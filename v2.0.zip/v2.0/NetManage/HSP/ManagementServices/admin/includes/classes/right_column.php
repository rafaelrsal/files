<?PHP
require_once('frameElement.php');

class  Right_Column extends frameElement 
{
	var $m_ModulesArr = array();
	function Right_Column($globalobjects,$modules)
	{
		foreach ($modules as $module)
		{
			if(!include_once( 'admin/modules/'.$module.'/module.php'))
				include_once( 'includes/modules/'.$module.'/module.php');
			$this->m_ModulesArr[] = new $module($globalobjects);			
		}
	}
	
	function setContent()
	{
		foreach ($this->m_ModulesArr as $module)
		{
			$this->m_Content[] = $module->GetContent();
		}	 
	}
	
	
}
?>