<?PHP
require_once('admin/includes/nusoap.php');
define('SOUP_ENCAPSULATION_HEADER', "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:netmanagehspmonitor=\"urn:netmanagehspmonitor\"><SOAP-ENV:Body id=\"_0\">");
define('SOUP_ENCAPSULATION_FOOTER', "</SOAP-ENV:Body></SOAP-ENV:Envelope>");

class webServiceProxy
{
	var $m_webService = '';
	var $m_client;
	function webServiceProxy($webService)
	{
		$this->m_webService = $webService;
	}
	
	function initProxy()
	{
		$response = 0;
		$this->m_client = new soapclient($this->m_webService); 
		if ($this->m_client->fault) 
		{ 
			$response = -1;
		}
		return $response;
	}
	
	function activateServer($activate)
	{
		$soapmsgActivateServer = SOUP_ENCAPSULATION_HEADER . "	<netmanagehspmonitor:ActivateServer>
																	<netmanagehspmonitor:nActivate>$activate</netmanagehspmonitor:nActivate>
																	<netmanagehspmonitor:pReservedInfo>
																		<netmanagehspmonitor:nSize>12</netmanagehspmonitor:nSize>
																		<netmanagehspmonitor:nVersion>0</netmanagehspmonitor:nVersion>
																	</netmanagehspmonitor:pReservedInfo>
																</netmanagehspmonitor:ActivateServer>" . SOUP_ENCAPSULATION_FOOTER;
		
		$response = $this->m_client->call('netmanagehspmonitor:ActivateServer', $soapmsgActivateServer);
		
		if (is_array($response) && !$response['nResult'])	
		{
			return 0;
		}
		else
		{
			return -1;
		}
	}
	
	function getServerCfg(&$xmlCfg)
	{
		$soapmsgGetServerCfg = SOUP_ENCAPSULATION_HEADER . "<netmanagehspmonitor:GetServerCfg>
																<netmanagehspmonitor:pReservedInfo>
																		<netmanagehspmonitor:nSize>12</netmanagehspmonitor:nSize>
																		<netmanagehspmonitor:nVersion>0</netmanagehspmonitor:nVersion>
																</netmanagehspmonitor:pReservedInfo>
															</netmanagehspmonitor:GetServerCfg>" . SOUP_ENCAPSULATION_FOOTER;
		
		$response = $this->m_client->call('netmanagehspmonitor:GetServerCfg', $soapmsgGetServerCfg);		
		if (is_array($response) && !$response['nResult'])	
		{
			$xmlCfg = $response['pszServerCfg'];
			return 0;
		}
		else
		{
			return -1;
		}
	}
	
	function configureServer($xmlCfg)
	{
		$soapmsgConfigureServer = SOUP_ENCAPSULATION_HEADER . "	<netmanagehspmonitor:ConfigureServer>	
																	<netmanagehspmonitor:pszCfgStream>$xmlCfg</netmanagehspmonitor:pszCfgStream>
																	<netmanagehspmonitor:pReservedInfo>
																		<netmanagehspmonitor:nSize>12</netmanagehspmonitor:nSize>
																		<netmanagehspmonitor:nVersion>0</netmanagehspmonitor:nVersion>
																	</netmanagehspmonitor:pReservedInfo>
																</netmanagehspmonitor:ConfigureServer>" . SOUP_ENCAPSULATION_FOOTER;
		
		$response = $this->m_client->call('netmanagehspmonitor:ConfigureServer', $soapmsgConfigureServer);		
		
		if (is_array($response) && 168230913 == $response['nResult'])
		{
			return 0;
		}
		else
		{
			return -1;
		}		
	}
	
	function getServerStatus()
	{
		$soapmsgGetServerStatus = SOUP_ENCAPSULATION_HEADER . "<netmanagehspmonitor:GetServerStatus></netmanagehspmonitor:GetServerStatus>" . SOUP_ENCAPSULATION_FOOTER;
		$response = $this->m_client->call('netmanagehspmonitor:GetServerStatus', $soapmsgGetServerStatus);		

		if ( is_array($response) )
		{
			return $response['nStatus'];
		}
	}
}

?>