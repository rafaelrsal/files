<?PHP
class frameElement
{	
	var $m_Content=array();
	
	function frameElement()
	{
	}
	
	function Show()
	{
		foreach ($this->m_Content as $content)
		{
			echo $content;
		}
	}
	
	function GetContent()
	{
		return $this->m_Content;
	}
	
}
?>