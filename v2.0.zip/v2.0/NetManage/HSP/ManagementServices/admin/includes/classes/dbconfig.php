<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           Hoter Mickey & Udi Zisser
  Date Created:     Mars 2004

  Title:            DBConfig.php
  Purpose:          To allow setting and getting the initial HSP DB 
  					configuration, using serialization.

  Limitations:		Requires PHP 4+

 ============================================================================*/

class DBConfig
{
	var $m_arrDBData = array(); // Holding data for database connection.
	
	var $filePath = 'includes/config/';
	var $fileName = 'dbconfig'; // No suffix for a serialized oobject file.

	
	function setDBData($hostName,$userName, $password, $port = 44)
	{
		$this->m_arrDBData['hostName'] = $hostName;
		$this->m_arrDBData['port'] = $port;
		$this->m_arrDBData['userName'] = $userName;
		$this->m_arrDBData['password'] = $password;

		// Serialaizing the configuration data into a file:
		$serDBData = serialize($this->m_arrDBData);

		$fp = fopen($this->filePath.$this->fileName, "wb");
		if(true == $fp)
		{
			if(fputs($fp, $serDBData))
			{
				fclose($fp);				
				return HAP_SUCCESS;
			}
		}
			
		return HSP_ERR_INSUFFICIENT_FILE_PERMISSIONS;
	}
	
	function getDBData()
	{
		// Desrializing the file into DBData object and pulling config data:
		$arrRes = @file($this->filePath.$this->fileName);
		if(false == $arrRes)
			return HSP_ERR_FILE_NOT_FOUND;// or file insufficient rights??
		
		$s = implode("", $arrRes);
		
  		$this->m_arrDBData = unserialize($s);
  		
		return $this->m_arrDBData; 
	}
}

?>