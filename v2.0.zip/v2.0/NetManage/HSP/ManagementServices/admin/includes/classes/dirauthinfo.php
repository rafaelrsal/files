<?PHP
class DirAuthInfo
{	
	var $m_userName;
	var $m_Password;

	function DirAuthInfo($name, $pass=null)
	{
		$this->m_userName = $name;
		$this->m_Password = $pass;
	}
}
?>
