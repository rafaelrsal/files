<?PHP
require_once('frameElement.php');

class Center extends frameElement 
{
	var $m_ModulesArr = array();
	function Center($globalobjects,$modules)
	{
		foreach ($modules as $module)
		{
			if (!include_once( 'admin/modules/'.$module.'/module.php'))
				include_once( 'includes/modules/'.$module.'/module.php');
			$this->m_ModulesArr[] = new $module($globalobjects);

			
			$session = $globalobjects->GetSession();

			if ($session->exists(SESSION_ERRORS)) 
			{
				// insert the errorHandler module at the top of the center pane
				include_once( 'includes/modules/errorHandler/module.php');
				array_unshift($this->m_ModulesArr , new errorHandler($globalobjects));
			}

			if ($session->exists(SESSION_MESSAGES)) 
			{
				// insert the messageHandler module at the top of the center pane
				include_once( 'includes/modules/messageHandler/module.php');
				array_unshift($this->m_ModulesArr , new messageHandler($globalobjects));
				
			}
			
		}
	}
	
	function setContent()
	{
		foreach ($this->m_ModulesArr as $module)
		{
			$this->m_Content[] = $module->GetContent();
		}
	}	
}
?>