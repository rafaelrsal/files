<?PHP
require_once('admin/includes/nusoap.php');
require_once('Admin/includes/classes/webServiceProxy.php');
require_once('includes/classes/xmlWrapper.php');
//1000* (msec in a second) 60* (seconds in a minute) 60* (minutes in an hour) 24*(hours a day)
define( 'MSEC_A_DAY', '86400000');

class xmlGenerator
{
	var $m_xmlString = '';
	function xmlGenerator()
	{
		
	}
	
	function getXml()
	{
		return $this->m_xmlString;
	}
	
	// $connType , 0 - odbc, 1 - detailed
	function generateXML($connType, $interval , $DBConnectArr )
	{
		$wrapper = new xmlWrapper();
				
		if (!$wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME))
		{
			return null;
		}
		
		$intervalMsec = $interval*MSEC_A_DAY; //translate interval to msec
		
		switch ($connType)
		{
			case 0:
			{
				$wrapper->setODBCParams($DBConnectArr);
				$DBDllName = 'hspODBC.dll'; 
				break;
			}
			case 1:
			{
				$arr = array();
		
				$arr['rdbms_type']	= $DBConnectArr['phptype'];
				$arr['rdbms_address'] 	= $DBConnectArr['address'];
				$arr['rdbms_port'] 	= $DBConnectArr['port'];
				$arr['rdbms_name'] 	= $DBConnectArr['name'];
				$arr['rdbms_username']= $DBConnectArr['username'];
				$arr['rdbms_password']	= $DBConnectArr['password'];
				$arr['version']		= '0';
				$wrapper->setRDBMSParams($arr);
				
				
				if ( $DBConnectArr['phptype'] == 'mysql' )
				{
					$DBDllName = 'hspMySQL.dll'; 
				}
				elseif( $DBConnectArr['phptype'] == 'mssql' )
				{
					$DBDllName = 'hspODBC.dll';
				}
				
				break;
			}
			default:
			{
				$DBDllName = 'dll';
				$intervalMsec = 'interval';
			}
		}

		$wrapper->setDBDll($DBDllName);
		$wrapper->setMaintenanceInterval($intervalMsec);
		
		
		$this->m_xmlString = $wrapper->toString();
		
		return $this->m_xmlString;
	}	
}

?>