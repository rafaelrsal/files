<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Aug 2004
  Title: authentication.php
  Purpose: authenticate a directory user
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
class authentication
{
	var $m_db;
	var $m_session;
	
	function authentication( &$db , $session )
	{
		$this->m_db = $db;
		$this->m_db->connect();
		$this->m_session = $session;
	}
	
	function authenticateByParams( $authParamsArr )
	{
		if(!extension_loaded(PHP_AUTH_MODULE))
		{
			dl(PHP_AUTH_DLL);
		}
		
		return authenticateuser(	$authParamsArr['username'],
									$authParamsArr['password'],
									$authParamsArr['host'],
									$authParamsArr['host'],
									$authParamsArr['type_dir'],
									$authParamsArr['port'],
									$authParamsArr['base_dn'],
									$authParamsArr['group_dn'],
									$authParamsArr['user_dn'],
									$authParamsArr['ldap_user_identifier']);
	}
	
	function authenticate( $user, $pass, $dirId )
	{
		if(!extension_loaded(PHP_AUTH_MODULE))
		{
			dl(PHP_AUTH_DLL);
		}

		$user = stripslashes($user);

		$sql = "SELECT type_dir,port,base_dn,host,group_dn,user_dn,ldap_user_identifier FROM ".TABLE_DIRECTORIES." WHERE id=$dirId;";
		$recSet = $this->m_db->GetAllEx($sql,null,DB_FETCHMODE_ASSOC);

		if ( is_array($recSet) )
		{
			if (1 == authenticateuser(	$user,
							$pass,
							$recSet[0]['host'],
							$recSet[0]['host'],
							$recSet[0]['type_dir'],
							$recSet[0]['port'],
							$recSet[0]['base_dn'],
							$recSet[0]['group_dn'],
							$recSet[0]['user_dn'],
							$recSet[0]['ldap_user_identifier'])) // authentication succeeded
			{
				//authentication succeeded
				$this->addToDirAuthCache($dirId,$user,$pass);

				return HSP_SUCCESS;
			}
			else
			{
				// authentication failed				
				return HSP_ERR_AUTHENTICATION_ERROR;
			}
		}
		else
		{			
			return HSP_ERR_DB_SQL_ERROR;
		}
	}

	
	/**
		we need to cache the username and password for each system directory.
		we maintain an array of dir items as a session var.
		when starting a new session none of the dir's are authenticated and
		so the admin will have to get here to perform the authentication.
		later (for ex in groups module) if the dir is already authenticated
		we can get the credentials from the cached array.

	*/
	function addToDirAuthCache( $id, $username, $password)
	{
		if (!$this->m_session->exists( SESSION_DIR_AUTH_CACHE ))
		{ // session var does not exists...
			$dirAuthCache = array();
		}
		else
		{
			$dirAuthCache = $this->m_session->value( SESSION_DIR_AUTH_CACHE );
		}

		$dirAuthCache[$id] = new DirAuthInfo( $username , $password );
		$this->m_session->set( SESSION_DIR_AUTH_CACHE , $dirAuthCache );
	}

	function getUserPass($id)
	{
		if ($this->m_session->exists( SESSION_DIR_AUTH_CACHE ))
		{ // session var does not exists...
			$dirAuthCache = $this->m_session->value( SESSION_DIR_AUTH_CACHE );

			if ( array_key_exists($id, $dirAuthCache))
			{
				$results = array();
				$results['username'] = $dirAuthCache[$id]->m_userName;
				$results['password'] = $dirAuthCache[$id]->m_Password;
				return $results;
			}
		}
	}	
}
?>