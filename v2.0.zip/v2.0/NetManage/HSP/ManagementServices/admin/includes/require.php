<?php
	require_once('defines.php');
?>