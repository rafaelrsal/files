<?PHP
	define('TXT_FOOTER1' , 'Host Services Platform Administrator');
?>
