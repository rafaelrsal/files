<?PHP	
	define('TXT_HEADER1' , 'Host Services Platform Administrator');

	//*********** texto de logout ***************
	define('ADMIN_LOGOUT','Logout');
	define('ADMIN_AJUDA', 'Help');
?>
