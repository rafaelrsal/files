<?PHP
	define('TXT_FOOTER1' , 'Administra��o da Plataforma de Acesso aos Hosts');
?>
