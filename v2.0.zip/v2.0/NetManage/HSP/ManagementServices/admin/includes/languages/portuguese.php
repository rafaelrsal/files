<?PHP
// Global entries for the <html> tag
define('HTML_PARAMS','dir="LTR" lang="pt"');

// charset for web pages and emails
define('CHARSET', 'iso-8859-1');

// page title
define('TXT_TITLE', 'HSP');


define('REPORT_FROM_TXT','From: ');
define('REPORT_TO_TXT','To: ');
define('REPORT_DATE_LBL','Date: ');
define('REPORT_TIME_LBL','Time: ');
define('REPORT_NO_TXT','No ');
define('REPORT_YES_TXT','Yes');


?>