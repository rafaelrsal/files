<?PHP	
	define('TXT_HEADER1' , 'Administra��o da Plataforma de Acesso aos Hosts');
	//*********** texto de logout ***************
	define('ADMIN_LOGOUT','Sair');
	define('ADMIN_AJUDA', 'Ajuda');
?>
