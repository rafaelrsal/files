<?PHP
define('IMAGE_NM_BANNER','logo_itau2.png');
define('W2H_ICON','asd_icon_small.gif'); // The default icon for a w2h application in the HAT
define('ONWEB_ICON','nmlogo.png'); // The default icon for a w2h application in the HAT
define('LINK_ICON','link.png'); // The default icon for a link in the HAT
define('PROTECTED_LINK_ICON','secured_url.gif'); // The icon for a protected link in the HAT
define('INSERT_ICON','button_insert.png'); // Icon for adding GAT/UAT
define('EDIT_ICON','button_edit.png'); // Icon for editing GAT/UAT
define('DELETE_ICON','button_drop.png'); // Icon for removing GAT/UAT
?>