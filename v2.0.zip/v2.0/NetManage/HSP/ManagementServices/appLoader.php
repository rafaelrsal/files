<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created: Mars 2004
  Title: appLoader.php
  Purpose: load application into html
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
// SESSION HANDLING SECTION - MUST COME BEFORE ANY CODE!!!
ini_set("include_path", ".;includes/pear;includes/xmlparser" );
define('GLOBAL_CONTEXT','portal');
require_once('Portal/includes/dbConnection.php');
require_once('Portal/includes/portalUser.php');
require_once('includes/classes/whosOnline.php');
session_start();


//require_once('includes/global_require.php');
//require_once('includes/classes/PearDB.php');
//require_once('includes/classes/DBConfig.php');
//include_once("DB/mysql.php");


header("Cache-control: private"); // IE6 Fix
define('START_TAG', '<hsp_');
define('END_TAG', '>');
define("ONWEB_RULE", "?ONWEB_InfoRule=_HSP.LaunchApp(_ONWEB_CGIDATA_)&appName=");

$sessionID = null;
$pageContents = null;
$prevPage = '';

if ( isset(  $_GET['sid'] ))
{
	$sessionID = $_GET['sid'];
}

validateSession($sessionID);
function validateSession($sessionID)
{
	if ( $sessionID != session_id() )	
	{			
		$_SESSION['errorCode'] = 3;// you are not authorized to view this page!
		include_once('hspError.php');
		exit();
	}
}

/**
	This function is responsible for parsing a URL with tags and repalcing each tag with
	the relevant value.
*/
function parseParamters($theURL, $arrParams)
{
	$iSize = count($arrParams);
	
	for($i=0; $i<$iSize; ++$i)
	{
		// Search for a tag in the following form: <hsp_paramname>
		$searchParam = START_TAG.$arrParams[$i]['paramName'].END_TAG;
		
		// Replace tag with real value:	
		$theURL = str_replace($searchParam, $arrParams[$i]['paramValue'], $theURL);
	}	

	// Return the URL with the paramter values:
	return $theURL;
}

if ( $_SERVER['REQUEST_METHOD'] == 'GET' )
{ 
	if ( isset($_GET['nodeID']) )
	{			
		$pageContents = getApp($_GET['nodeID']);
	}	
}

function getApp( $nodeID )
{	
	$app = null;
	$userObj = $_SESSION['userObject'];	
	$dbObj = new dbConnection();
	
	$db = $dbObj->getDb();
	
	if ( null == $db )
	{
		$_SESSION['errorCode'] = 2;// Application cannot be found
		include_once('hspError.php');
		exit();
	}
	
	$whos = new whosOnline($db);
	$whos->register($nodeID);
	
	$sql = "SELECT appID,application FROM " . TABLE_TREE." WHERE id=$nodeID";	
	$recSet = $db->GetAllEx( $sql );
	if (!$recSet)
	{
		$_SESSION['errorCode'] = 2;//Application cannot be found
		include_once('hspError.php');
		exit();
	}
		
	$appID = $recSet[0][0];
	$appType = $recSet[0][1];
	
	if ( 'url' == $appType )
	{
		$sql = "SELECT * FROM ".TABLE_APPS_LINKS." WHERE appID=$appID";		
		$result = $db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		$app = $result[0]['url'];
		
		if(1 == $result[0]['parameterized'])
		{
			// Get user params and values:
			$userID = $userObj->getUserId();
			$sql = "SELECT paramName,paramValue FROM ".TABLE_USER_PARAMETER." WHERE userID=$userID;";
			$arrParamVal = $db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
			if(is_array($arrParamVal) && count($arrParamVal)>0)
			{
				// The URL expects paramters, parse according to user pramters:
 				$app = parseParamters($app, $arrParamVal);			
			}
			else
			{
				// Cannot run the url: should we present a message or leave to the dogs?
			} 
		}
		if ( $result[0]['protected'] )
		{			
			$buffer = '<BASE HREF="'.$app.'">';	
				
			$UrlBuffer = @file_get_contents($app);				
			if (!$UrlBuffer)
			{	
				$_SESSION['errorCode'] = 2;// Application cannot be found
				include_once('hspError.php');
				exit();
			}
						   		
		   	return $buffer . $UrlBuffer;
		   						
		}
		else
		{	
			header("Location: $app");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		}
	}
	elseif ( 'w2h' == $appType )
	{
		$serverAddress = ''; // leave as empty for disable clients.
		$heartbeat = null;
		$enableClients = null;
		$sql = "SELECT paramStr,hostURL,version,subType FROM ".TABLE_APPS_W2H." WHERE appID=$appID";
		$result = $db->GetAllEx($sql);
		
		$sql1 = "SELECT * FROM " . TABLE_CLIENT_CONFIG;
		$monResults = $db->GetAllEx($sql1, null, DB_FETCHMODE_ASSOC);
		if ( count($monResults) )
		{
			$enableClients = $monResults[0]['enable_mon'];		
			$heartbeat = $monResults[0]['heartbeat_interval'];
			
			if ( $enableClients )
			{
				$serverAddress = $monResults[0]['server_address'];
			}
		}		
		
		if(!extension_loaded('W2HPhPExtension'))
		{
			dl('php_W2HPhPExtension.dll');
		}
		
		$htplPath = getHtplPath( $result[0][2], $result[0][3] );		
		$app = getsessionhtml( $result[0][0], $result[0][1], $htplPath, $result[0][3], $serverAddress, $heartbeat);
		return $app;
	}
	elseif ('onWeb' == $appType )
	{
		$sql = "SELECT hostURL,name,appURL FROM ".TABLE_APPS_ONWEB." WHERE appID=$appID ";
		$result = $db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
		
		
		$hostURL = $result[0]['hostURL'];
		$rule = ONWEB_RULE.$result[0]['name'];
		$userNameParm = "&HSPUser=".$userObj->getUsername();
		$appURLParm = $result[0]['appURL'].'&';
		
		// Should look like the following:
		// |---------------------------$hostURL----------------------------------------------|-$userNameParm-|----$appURLParm------|
		// http://OnWebIP:port/?ONWEB_InfoRule=_HSP.LaunchApp(_ONWEB_CGIDATA_)&appName=myHPApp&HSPUser=testusr&startPage=myHPApp.htm&
		$assembliedApp = $hostURL.$rule.$userNameParm.$appURLParm;
		
		header("Location: $assembliedApp");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	}
	$db->Disconnect();
}

function getHtplPath( $version , $subType )
{
	$pathTranslated = $_SERVER['PATH_TRANSLATED'];
	$slashPos = strrpos($pathTranslated,'\\');
	$htplPath = substr($pathTranslated,0,$slashPos+1);
	$htplPath = stripslashes($htplPath);
	$htplFileName = '';
	if ( $subType == 0 )
	{
		$htplFileName = 'express.htpl';
	}
	elseif ( $subType == 1 )
	{
		$htplFileName = 'javaclient.htpl';
	}
	elseif ( $subType == 2 )
	{
		$htplFileName = 'hostproclient.htpl';
	}
	elseif ( $subType == 3 )
	{
		$htplFileName = 'hostftpclient.htpl';
	}
	
	$htplPath .= "data\\w2h\\htpl\\$version\\$htplFileName";
	return $htplPath;
}
?>

<script type="text/javascript" src="includes/js/keyHandlers.js"></script>
<script language="javascript">
/* catch ctrl+n , F11 , right-click (view source) */
document.onkeydown = checkKP;
document.oncontextmenu=new Function("return false");
</script>
<?php echo $pageContents; ?>