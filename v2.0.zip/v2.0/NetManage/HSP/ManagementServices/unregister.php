<?php
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: unregister.php
  Purpose: remove the current session from hsp_whos_online table when user closes the browser
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
ini_set("include_path", ".;includes/pear;includes/xmlparser" );
require_once('Portal/includes/portalUser.php');
require_once('includes/classes/PearDB.php');
session_start();
header("Cache-control: private"); // IE6 Fix
define('GLOBAL_CONTEXT','portal');
require_once('includes/global_require.php');
require_once('includes/classes/whosOnline.php');

if ( isset($_SESSION['authenticatedUserType']) && $_SESSION['authenticatedUserType'] )
{
	$whos = new whosOnline();
	$whos->init();
	$whos->unregister(session_id());	
}
?>