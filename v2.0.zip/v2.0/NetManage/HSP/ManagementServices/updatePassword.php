<?PHP
session_start();
header("Cache-control: private"); // IE6 Fix
ini_set("include_path", ".;includes/pear;includes/xmlparser" );
define('GLOBAL_CONTEXT','admin');
require_once('includes/global_require.php');
require_once('includes/classes/DBConfig.php');
require_once('includes/classes/PearDB.php');

	if ( !isset($_SESSION['authenticatedUserType'])	)
	{		
		exit();	
	}

	if ( 	!isset($_GET['username'] ) || 
			!isset($_GET['newPassword'] ) || 
			!isset($_GET['oldPassword'] ) ||
			!isset($_GET['customDirID'] ))
	{
		exit();
	}
	
	if(!extension_loaded('HSPSecurModule'))
	{
        dl('php_HSPSecurModule.dll');
	}
	
	$username 		= stripslashes($_GET['username']);
	$newPassword 	= encrypt_str(stripslashes($_GET['newPassword']));
	$oldPassword 	= encrypt_str(stripslashes($_GET['oldPassword']));
	$customDirID 	= $_GET['customDirID'];
	
	$db = DBConnection();
				
	$fields_values = array( 'password' =>$newPassword);
	
	$ret = $db->AutoExecute(TABLE_CUSTOM_USERS, $fields_values, DB_AUTOQUERY_UPDATE, "dirID=$customDirID AND name=\"$username\" AND password=\"$oldPassword\";");
	
	function DBConnection()
	{
		$database = null;
		$dbconfig = new DBConfig();
		$dbconfig->init();
		$errCode = $dbconfig->DBDeserialize();
		
		if($errCode != 0)
		{
			return null;
		}			
		else
		{
			$database = new PearDB();
			$database->SetDSNArray($dbconfig->getDBData());			
			$ret = $database->Connect();
			if ( $ret != 0 )
			{ 
				return null;
			}			
		}
		
		return $database;
	}
?>
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">