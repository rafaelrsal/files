<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:           Guy Schetrit, Hoter Mickey, Udi Zisser
  Date Created:     August 2004
  Title:            popup.php
  Purpose:          A wrapper for popup windows
  Limitations:		Requires PHP 4.3.x and up (but not 5.x... yet)
 ============================================================================*/ 
 $popupDiv = '';
 if ( isset($_GET['popupDiv']))
 {
 	$popupDiv = $_GET['popupDiv'];
 }
 ?>

<SCRIPT language="javascript">
var win = window.dialogArguments;
var popupDiv = '<?php echo $popupDiv; ?>';
function getContent()
{	
	if ( '' == popupDiv )
	{
		document.getElementById('popupContent').innerHTML = win.document.getElementById('popupContent').innerHTML;	
	}
	else
	{
		document.getElementById('popupContent').innerHTML = win.document.getElementById(popupDiv).innerHTML;	
	}
	initPopup();
}

function setContent()
{
	win.document.getElementById('popupContent').innerHTML = document.getElementById('popupContent').innerHTML;
	finalizePopup();
}

document.onkeydown = checkKP;
		
function checkKP(e) 
{			

	if (event.keyCode == 27)
	{
		window.close();
	}
}

</SCRIPT>
<html>
	<head>
		<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
		<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
		<META HTTP-EQUIV="EXPIRES" CONTENT="Mon, 22 Jul 2002 11:12:01 GMT">
		<title><?php echo $_GET['Title'] ?></title>
		<script language="JavaScript" src="includes/config/permission.js?v=<?php clearstatcache();echo filemtime('includes/config/permission.js');?>"></script>
		<?PHP
			if ( isset( $_GET['moduleName'] ) )
			{
				$moduleName = $_GET['moduleName'];
				echo "<script language=\"JavaScript\" src=\"admin/modules/$moduleName/includes/module.js\"></script>";
			}
		?>
		<script language="JavaScript" src="admin/includes/js/misc.js"></script>
		<link rel="stylesheet" type="text/css" href="includes/stylesheets/hsp.css">
	</head>
	<?PHP 
		if ( isset($_GET['moduleName'] ) )
		{
			if (isset($_GET['scrollbars']))
			{
				$scrollbars = $_GET['scrollbars'];
				echo "<body onload='javascript:getContent();' scroll=$scrollbars>";
			}
			else
			{
				echo "<body onload='javascript:getContent();'>";
			}
		}
	?>
		<div id="popupContent"></div>	
	</body>
</html>