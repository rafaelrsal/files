<?PHP

/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:           Schetrit Guy
  					Hoter Mickey
  					Udi Zisser

  Date Created:     Mars 2004

  Title:            admin.php
  Purpose:          Entry point for using the HSP administration console options.
  Limitations:		Requires PHP 4.3.4 - 

 ============================================================================*/

 	// NOTICE --Using ob_start(), enables us to navigate between our pages, without getting header
  	// warnings. This means we buffer output until we call frame->show(), and there
  	// we call ob_end_flush()! - mhoter
 	ob_start();
 	///////////////

 	// NOTICE --The following is required in order to include the path to the pear:
 	//			in unix it should be like this ->
 	//			ini_set("include_path", ".:includes/pear" );
	ini_set("include_path", ".;includes/pear;includes/xmlparser" );
	//////////////
 	define('GLOBAL_CONTEXT','admin');
	
	require_once('includes/global_require.php');
	
	require_once(GLOBAL_CLASSES_DIR . 'frame.php');

	$GlobalObjs = new GlobalObjects();
	$language = $GlobalObjs->GetLanguage();
	$session = $GlobalObjs->GetSession();
	
	
	;
?>
<script type="text/javascript" src="includes/js/keyHandlers.js"></script>
<script language="javascript" >

	window.history.forward();
	function updated()
	{
		isChanged = true;	
	} 

	var serverBusy = false;
	
	function disableFormElements()
	{
		serverBusy = true; // so no navigation to other menu items in middle of submit action.

		// This function is called on before unload, in order to disable all
		// form fields on submit/navigate out:
		for(i=0; i<document.forms[0].elements.length; ++i)
		{
			document.forms[0].elements[i].disabled=true;	
		}
	}
	
	function doNothing() //used to override the onbeforeunload call
	{
	}
	
	document.onkeydown = checkKP;
	document.oncontextmenu=new Function("return false");
	

</script>
<script language="javascript" for="window" event="onbeforeunload">
	disableFormElements();
</script>

<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>"/>
<title><?php echo TXT_TITLE; ?></title>
<link rel="stylesheet" type="text/css" href="includes/stylesheets/hsp.css">
</head>
<body leftmargin=0 bottommargin=0 rightmargin=0 topmargin=0 id="bodMainBody">
<?PHP
	// create the global objects. we need to pass down this obj to all classes, see frame()...
	$CenterModules = 'login';
	$LeftModules = 'vlmenu'; // tobe removed....
	//$RightModules='clock,favorites';
	$RightModules=null;

	if (!$session->exists(SESSION_RIGHT))
	{
		$session->set(SESSION_RIGHT, $RightModules);
	}
	
	if (!$session->exists(SESSION_LEFT))
	{
		$session->set(SESSION_LEFT, $LeftModules);
	}


	if ($_SERVER['REQUEST_METHOD'] == 'GET')
	{
		if (isset($_GET['module']))
		{	
			$CenterModules = $_GET['module'];			
			if ($CenterModules == 'logout')
			{
				$CenterModules = 'login';
				$session->session_unset();
				$session->destroy();
				unset($GlobalObjs);
				unset($language);
				unset($session);
				$GlobalObjs = new GlobalObjects();
				$language = $GlobalObjs->GetLanguage();
				$session = $GlobalObjs->GetSession();
			}

			$session->set(SESSION_CENTER, $CenterModules);
		}		
	}
	else // POST
	{
	}

	if ($session->exists(SESSION_CENTER))
	{
		$CenterModules = &$session->value(SESSION_CENTER);
	}
	if ($session->exists(SESSION_LEFT))
	{
		$LeftModules = &$session->value(SESSION_LEFT);
	}
	if ($session->exists(SESSION_RIGHT))
	{
		$RightModules = &$session->value(SESSION_RIGHT);
	}

	if (!$session->exists(SESSION_ADMIN_AUTH_FLAG) || !$session->value(SESSION_ADMIN_AUTH_FLAG))
	{
		$CenterModules = 'login';
	}

	// On initialization or login page - show only center of table:
	$bisInit = $session->value(SESSION_INIT_CONFIG);

	if(( 'login' == $CenterModules ) || ($bisInit))
	{
		$leftModulsArr = null;
		$rightModulsArr = null;
	}
	else
	{		
		if ( !is_null($LeftModules) )
		{
			$leftModulsArr = explode(',',$LeftModules);
		}
		else
		{
			$leftModulsArr = null;
		}

		if ( !is_null($RightModules) )
		{
			$rightModulsArr = explode(',',$RightModules);
		}
		else
		{
			$rightModulsArr = null;
		}
	}

	$centerModulsArr = explode(',',$CenterModules);
	
	
	$frame = new Frame($GlobalObjs,$centerModulsArr,$leftModulsArr,$rightModulsArr);
	$frame->show();
?>

</body>
</html>