<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Mars 2004
  Title: treePreview.php
  Purpose: Presenting user/group tree in a separate bwroser page.
  Limitations: Requires PHP 4.3.4 and up.
  TODO:(mhoter)
			1. Do we really have to read from a file?
			2. Insert error handler coordinance.
			3. Improve look and feel.
			4. use langauge file

 ============================================================================*/
 session_start();
 header("Cache-control: private"); // IE6 Fix
 ini_set("include_path", ".;includes/pear;" );

if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
	include_once( 'Portal/modules/tree/module.php');

	$res = null;
	$treeObj = null;

	// Save file:
	$strFile = null;

	// This file is used for testing preview purposes only:
	$fileName = "tree.preview";
	$path = "data/apptrees/"; // TODO: the path should be a general define.


	if(file_exists($path.$fileName))
	{
		$fileSize = filesize($path.$fileName);
		if(0 === $fileSize)
		{
			$res = "";
		}
		else
		{ 
			$handle = fopen($path.$fileName, "r");
			if($handle)
			{
				$strFile = fread($handle, filesize($path.$fileName));
				fclose($handle);
			}
			else
				$res = "insufficient rights";
		}
	}
	else
		$res = "<h1>missing file</h1>";


	if(null != $strFile)
		$treeObj = new tree($strFile);
	else
		echo $res;
}

?>

<HTML>
<HEAD>
<link rel="stylesheet" type="text/css" href="includes/stylesheets/hsp.css">
<script language="JavaScript" src="admin/includes/js/Misc.js"></script>
<script language="javascript">

	document.onkeydown = checkKP;
		
	function checkKP(e) 
	{			
	
		if (event.keyCode == 27) //check ESC key press
		{
			window.close();
		}
	}
	
	function DoDefaultEnterKey(e)
	{
		if(CheckEnter(e))
	   {
			parent.document.getElementsByName('btnClose').item(0).click();
	   }

	}

</script>

</HEAD>
<BODY onKeyPress="DoDefaultEnterKey(event)">
<br>
<!--H3 align="center" class="HomeHeader"> Host Application Tree </H3-->
<TABLE width="100%">	
	<tr>
		<TD class="HomeHeader"><?PHP echo $_SESSION['print_preview_header'];?></TD>
	</tr>
	<tr>
		<TD class="HomeHeader"><?PHP echo date("F j, Y, g:i a");?></TD>
	</tr>
	<tr>
		<td colspan=5>		
			<hr>
		</td>
	</tr>
</TABLE>
<?PHP
	if(null != $treeObj)
	{
		$treeObj->show();
	}
?>
</BODY>
</HTML>