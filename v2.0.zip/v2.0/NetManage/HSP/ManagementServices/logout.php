<?php
	ini_set("include_path", ".;includes/pear;includes/xmlparser" );
	define('GLOBAL_CONTEXT','portal');
	require_once('includes/classes/whosOnline.php');
	require_once('Portal/includes/dbConnection.php');	
	require_once('Portal/includes/portalUser.php');
	require_once('includes/classes/PearDB.php');
	
	session_start();		
	
	
	
	$db = new dbConnection();
	if ( is_null($db->getDb()) )
	{		
		redirectToErrorPage( 7 );// General database error
	}
	
	$whosOnlineObj = new whosOnline($db->getDb());

	
	if ( isset($_SESSION) )
	{			
		$whosOnlineObj->unregister(session_id());
		$_SESSION = array();
	}

?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="portal/style/default/hsp.css">
<META NAME="ROBOTS" CONTENT="NOINDEX">
<title>HSP logout</title>
</head>
<body>
<table align="center" border="0">
	<tr>
	   	<td height="10px"></td>
	</tr>
    <tr>    
        <td align="left" valign="middle">
	        <h1 style="COLOR:000000; FONT: 13pt/15pt verdana">
	        Voc� foi desconectado do Portal de Acesso Externo aos Hosts
	        </h1>
        </td>
    </tr>
	<tr>    
        <td align="left" valign="middle">
	        <h1 style="COLOR:000000; FONT: 13pt/15pt verdana">
	        You are desconnected from Portal of External Access to Hosts
	        </h1>
        </td>
    </tr>
    <tr>
        <td colspan="2">
	        <font style="COLOR:000000; FONT: 8pt/11pt verdana">
	        <hr color="#C0C0C0" noshade>
        </td>
    </tr>
</body>
</html>