<?PHP
session_start();
header("Cache-control: private"); // IE6 Fix
$redirectToErrorPage = 'false';
$errorCode = '3';
$sessionID = null;
$prevPage = '';
$lang = 'english';

if ( isset( $_SESSION['language']) )
{
	$lang = $_SESSION['language'];
}
require_once('includes/global_defines.php');
require_once("Portal/includes/languages/".CURRENT_LANG."/index.php");

if ( !isset($_GET['nodeID']) || !isset($_GET['sid']) )
{
	$redirectToErrorPage = 'true';
	$errorCode = '2';
}

if ($redirectToErrorPage != 'true')
{	
	validateSession($_GET['sid']);
}

function validateSession($sessionID)
{
	if ( $sessionID != session_id() )
	{
		$redirectToErrorPage = 'true';
		$errorCode = '3';
	}
}

$_SESSION['errorCode'] = $errorCode;

?>
<script type="text/javascript" src="includes/js/keyHandlers.js"></script>
<script type="text/javascript" src="Portal/includes/js/cookies.js"></script>
<script type="text/javascript" src="data/portalConfiguration.js"></script>	
<script type="text/javascript">

var expDays = 30;
var exp = new Date();
exp.setTime(exp.getTime() + (expDays*30*24*60*60*1000));
var redirect2Error = <?php echo $redirectToErrorPage; ?>;
var errorCode = <?php echo $errorCode;?>;

function bunload()
{
	var openWindowCount = getCookie('windowCount'  + '<?PHP echo session_id(); ?>');
	
	if ( null != openWindowCount && openWindowCount > 0 )
	{
		setCookie ('windowCount' + '<?PHP echo session_id(); ?>', --openWindowCount, exp);
	}
}

function setSessionCount()
{	
	document.all.frame1.setAttribute("src", getApplicationPath());
	if (!redirect2Error)
	{
		var openWindowCount = getCookie('windowCount' + '<?PHP echo session_id(); ?>');
	
		if ( null == openWindowCount)
		{
			setCookie ('windowCount' + '<?PHP echo session_id(); ?>', 1, exp); 
		}
		else
		{
			setCookie ('windowCount'  + '<?PHP echo session_id(); ?>', ++openWindowCount, exp); 
		}
	}
}

function validatePrevPage()
{	
	var validateNodeId = <?php echo isset($_GET['nodeID']); ?>;
	var validateSessionId = <?php echo isset($_GET['sid']); ?>;
	
	if ( !validateNodeId || !validateSessionId )
	{
		redirect2Error = true;
		errorCode = 2;
	}
}
	
function getApplicationPath()
{	
	if ( redirect2Error || !<?php echo isset($_GET['nodeID']) ?> || !<?php echo isset($_GET['sid']) ?>)
	{	
		return 'hspError.php';
	}
	
	
	return "appLoader.php?nodeID=<?php echo $_GET['nodeID'];?>&sid=<?php echo $_GET['sid'];?>";
	
}


window.onbeforeunload = bunload;
document.onkeydown = checkKP;
document.oncontextmenu = disableContextMenu;

	function disableContextMenu()
	{
		return false;
	}

	validatePrevPage();

</script>
<HTML>
<HEAD>	
	<TITLE><?PHP echo INDEX_TITLE;?></TITLE>
</HEAD>

<FRAMESET onload="setSessionCount();">
    <FRAME name="frame1" src="" >
</FRAMESET>
</HTML>