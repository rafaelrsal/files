<?php
ini_set("include_path", ".;includes/pear;includes/xmlparser" );
require_once('Portal/includes/portalUser.php');
require_once('includes/classes/PearDB.php');
session_start();
define('GLOBAL_CONTEXT','portal');
require_once('includes/global_require.php');
require_once('Portal/includes/dbConnection.php');
require_once('Portal/includes/pclzip.lib.php');
require_once('Portal/includes/Languages/'.CURRENT_LANG.'/localstart.php');


$save_path = ini_get('session.save_path');

define('LOCALSTART_DIR' , 'data/localstart');
define('LOCALSTART_DIR_SESSION' , $save_path . '/' . session_id() );
define('LOCALSTART_DIR_FOLDER' , LOCALSTART_DIR_SESSION . '/hsplocalstart');
define('LOCALSTART_DIR_FILES' , LOCALSTART_DIR_FOLDER . '/files');

define('LOCALSTART_FRAME','localstartframe.html');

define('START_TAG', '<hsp_');
define('END_TAG', '>');

define("ONWEB_RULE", "?ONWEB_InfoRule=_HSP.LaunchApp(_ONWEB_CGIDATA_)&appName=");

$sessionID = null;
$pageContents = null;
$prevPage = '';
if ( isset(  $_GET['sid'] ))
{
	$sessionID = $_GET['sid'];
}

validateSession($sessionID);
function validateSession($sessionID)
{
	if ( $sessionID != session_id() )	
	{			
		$_SESSION['errorCode'] = 3;// you are not authorized to view this page!
		include_once('hspError.php');
		exit();
	}
}

if (isset($_POST['buttonClicked']))
{
	createLocalstart();
}
	
	function createLocalstart()
  	{
  		$db = new dbConnection();
  		
  		$appData = populateApplicationData( $db->getDb() , $_SESSION['megredList'] );
		createLocalApplications( $db->getDb() , $appData );
		createZip();
		download();
  	}
	
	function populateApplicationData( $db , $nodeIds )	
	{	
		$applicationTreeData = array();
		
		$sql = "SELECT * FROM " . TABLE_TREE .";";
		$tree = $db->GetAllEx( $sql, null, DB_FETCHMODE_ASSOC );
		if ( isset($tree[0]) )
		{	
			foreach ( $nodeIds as $nodeId )
			{
				foreach ( $tree as $treeNode )
				{
					if ( $treeNode['id'] == $nodeId )
					{
						$applicationTreeData[$nodeId] = $treeNode;
						break;						
					}
				}
			}
			
			$tmpArr = $nodeIds;							
			
			for ( $i = 0 ; $i < count($tmpArr) ; $i++ )
			{								
				foreach ( $tree as $treeNode )
				{
					if ( $treeNode['parent_id'] == $tmpArr[$i] )
					{
						$applicationTreeData[$treeNode['id']] = $treeNode;
						$tmpArr[] = $treeNode['id'];
					}
				}
			}
		}

		return $applicationTreeData;
	}

	function getApplicationData( $db , $applicationID, $applicationType )
	{
		if ( 'url' == $applicationType )
		{
			$sql =   "SELECT * FROM " . TABLE_APPS_LINKS . " WHERE appID=$applicationID;";
		}
		elseif ( 'onWeb' == $applicationType )
		{
			$sql =   "SELECT * FROM " . TABLE_APPS_ONWEB . " WHERE appID=$applicationID;";
		}
		elseif ( 'w2h' == $applicationType )
		{
			$sql =   "SELECT * FROM " . TABLE_APPS_W2H . " WHERE appID=$applicationID;";
		}
	
		$res = $db->GetAllEx( $sql, null, DB_FETCHMODE_ASSOC );
		return $res;	
	}
	
	function createLocalApplications( $db, $applicationTreeData )
	{
		$userObj = $_SESSION['userObject'];	
		$app = null;
		
		if ( !is_dir( LOCALSTART_DIR_SESSION ) )
		{
			mkdir( LOCALSTART_DIR_SESSION );
		}
		
		if ( !is_dir( LOCALSTART_DIR_FOLDER ) )
		{
			mkdir( LOCALSTART_DIR_FOLDER );
		}
		
		if ( !is_dir( LOCALSTART_DIR_FILES ) )
		{
			mkdir( LOCALSTART_DIR_FILES );
		}
		
		$fpLocalstart = fopen( LOCALSTART_DIR_FILES . '/localstart.html' , 'a' );
		foreach( $applicationTreeData as $appID=>$application )
		{
			if ( $application['application'] != null )
			{
				$result = getApplicationData( $db, $application['appID'] , $application['application'] );
				
				if ( 'url' == $application['application'] )
				{
					$app = $result[0]['url'];
			
					if(1 == $result[0]['parameterized'])
					{
						// Get user params and values:
						$userID = $userObj->getUserId();
						$sql = "SELECT paramName,paramValue FROM ".TABLE_USER_PARAMETER." WHERE userID=$userID;";
						$arrParamVal = $db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
						if(is_array($arrParamVal) && count($arrParamVal)>0)
						{
							// The URL expects paramters, parse according to user pramters:
			 				$app = parseParamters($app, $arrParamVal);			
						}
						else
						{
							// Cannot run the url: should we present a message or leave to the dogs?
						} 
					}
					
					$template = file_get_contents( LOCALSTART_DIR . '/templates/urlTemplate.html');
					$template = str_replace( '{localstartUrl}' , $app , $template );
					
					$fp = fopen( LOCALSTART_DIR_FILES .'/'. $appID.'.html' , 'w' );					
					fputs( $fp, $template );
					fclose($fp);
				}
				elseif ( 'onWeb' == $application['application'] )
				{
					$hostURL = $result[0]['hostURL'];
					$rule = ONWEB_RULE.$result[0]['name'];
					$userNameParm = "&HSPUser=".$userObj->getUsername();
					$appURLParm = $result[0]['appURL'].'&';
					
					// Should look like the following:
					// |---------------------------$hostURL----------------------------------------------|-$userNameParm-|----$appURLParm------|
					// http://OnWebIP:port/?ONWEB_InfoRule=_HSP.LaunchApp(_ONWEB_CGIDATA_)&appName=myHPApp&HSPUser=testusr&startPage=myHPApp.htm&
					$assembliedApp = $hostURL.$rule.$userNameParm.$appURLParm;
					
					$template = file_get_contents( LOCALSTART_DIR . '/templates/urlTemplate.html');
					$template = str_replace( '{localstartUrl}' , $assembliedApp , $template );
					
					$fp = fopen( LOCALSTART_DIR_FILES .'/'. $appID.'.html' , 'w' );					
					fputs( $fp, $template );
					fclose($fp);
				}
				elseif ( 'w2h' == $application['application'] )
				{
					$sql = "SELECT enable_mon FROM " . TABLE_CLIENT_CONFIG;
					$db->GetOne($sql, $enableClients);
					
					if ($enableClients)
					{
						$sql = "SELECT server_address FROM " . TABLE_CLIENT_CONFIG;
						$db->GetOne($sql, $serverAddress);
					}
					else
					{
						$serverAddress = '';
					}
					
					$sql = "SELECT heartbeat_interval FROM ". TABLE_CLIENT_CONFIG;
					$db->GetOne($sql, $heartbeat);
					
					if(!extension_loaded('W2HPhPExtension'))
					{
						dl('php_W2HPhPExtension.dll');
					}
			
					
					$htplPath = getHtplPath($result[0]['version'], $result[0]['subType']);		
					$app = getsessionhtml( $result[0]['paramStr'], $result[0]['hostURL'], $htplPath, $result[0]['subType'], $serverAddress, $heartbeat);				
					
					$template = file_get_contents( LOCALSTART_DIR . '/templates/w2hTemplate.html');
					$template = str_replace( '{localstartW2H}' , $app , $template );
					
					$fp = fopen( LOCALSTART_DIR_FILES .'/'. $appID.'.html' , 'w' );					
					fputs( $fp, $template );
					fclose($fp);
					
				}
				
				
				// write to localstart.html which is the left side menu frame			
				fwrite( $fpLocalstart , '<a href="'.$appID.'.html'.'" target="appPane">'.$application['text'].'</a>' );
				fwrite( $fpLocalstart, "<br>" );
				
			}			
		}
		fclose( $fpLocalstart );
		
		
		$folder = opendir( LOCALSTART_DIR );
		while($file = readdir($folder))
		{
			if ($file == '.' || $file == '..' || is_dir( LOCALSTART_DIR.'/'.$file) ) 
			{
				continue;
			}
			copy(LOCALSTART_DIR .'/'. $file, LOCALSTART_DIR_FILES .'/'.$file);
		}
		
		closedir($folder);
	}
	function getHtplPath( $version , $subType )
	{
		$pathTranslated = $_SERVER['PATH_TRANSLATED'];
		$slashPos = strrpos($pathTranslated,'\\');
		$htplPath = substr($pathTranslated,0,$slashPos+1);
		$htplPath = stripslashes($htplPath);
		$htplFileName = '';
		if ( $subType == 0 )
		{
			$htplFileName = 'express.htpl';
		}
		elseif ( $subType == 1 )
		{
			$htplFileName = 'javaclient.htpl';
		}
		elseif ( $subType == 2 )
		{
			$htplFileName = 'hostproclient.htpl';
		}
		elseif ( $subType == 3 )
		{
			$htplFileName = 'hostftpclient.htpl';
		}
		
		$htplPath .= "data\\w2h\\htpl\\$version\\$htplFileName";
		return $htplPath;
	}
	
	function createZip()
	{
        $serverAddress = $_SERVER['HTTP_REFERER'];
		$slashPos = strrpos($serverAddress,'/');
		$serverAddress = substr($serverAddress,0,$slashPos);
		$serverAddress = stripslashes($serverAddress);
		
		$template = file_get_contents( LOCALSTART_DIR . '/templates/' . LOCALSTART_FRAME );
		$template = str_replace( '{serveraddress}' , $serverAddress , $template );
		$fp = fopen( LOCALSTART_DIR_FOLDER . '/localstartframe.html' , 'w');
		fputs( $fp, $template );
		fclose($fp);
		
        $new_zip= new PclZip( LOCALSTART_DIR_SESSION . "/localstart.zip");
		$file_list = $new_zip->create( LOCALSTART_DIR_FOLDER , PCLZIP_OPT_REMOVE_PATH , LOCALSTART_DIR_SESSION );
	}
	
	function download()
	{		
		$filename = LOCALSTART_DIR_SESSION .'/localstart.zip';       

		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");

		//To force a download on MSIE for Windows, you don't have to use "attachment", but you need it for all other browsers.
		$user_agent = strtolower ($_SERVER["HTTP_USER_AGENT"]);
		if ((is_integer (strpos($user_agent, "msie"))) && (is_integer (strpos($user_agent, "win"))))
		{
			header("Content-Disposition: filename=".basename($filename).";");
		}
		else
		{
			header("Content-Disposition: attachment; filename=".basename($filename).";");
		}

		header("Content-Transfer-Encoding: binary");
		header("Content-Length: ".filesize($filename));
		readfile($filename);
		deleteFiles( LOCALSTART_DIR_SESSION );
		
	}
	
	function deleteFiles( $target )
	{
	   $sourcedir = opendir( $target );
	   while( false !== ( $filename = readdir( $sourcedir ) ) )
	   {
			if ($filename == '.' || $filename == '..' ) 
			{
				continue;
			}
			
			if(is_dir($target."/".$filename))
			{
				// recurse subdirectory; call of function recursive
				deleteFiles($target."/".$filename );
			}
			else if(is_file($target."/".$filename))
			{
				// unlink file
				unlink($target."/".$filename);
			}	
	   }
	   
	   closedir($sourcedir);
	   rmdir($target);
	}
?>
<script language="javascript">
function onStart()
{
	document.localstartForm.localstart.disabled=true;
	document.localstartForm.buttonClicked.value = "start";
	document.localstartForm.submit();
}
</script>
<html>
<head>
<link rel="stylesheet" type="text/css" href="portal/style/default/hsp.css">
</head>
<body bgcolor="eff3ff">	
	<center>
	<br>
	<br>
	<br>
			<b><?php 			
				echo LOCALSTART_TXT; 
				?>
			</b><br>
			<br>
			<form name="localstartForm" action="" method="POST">
				<INPUT type="button" id="localstart" name="localstart" value="Start" class="NewButton ShortFixedWidthObjects" onclick="onStart()"> 
				<input type="hidden" name="buttonClicked">
			</form>
	</center>
</body>
</html>