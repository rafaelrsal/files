<TABLE border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" width=100%>
	<TR>
		<TD>
			<img src="Portal/includes/images/logo_itau2.png" border="0" alt="">
		</TD>
	</TR>
	<TR>
		<TD align=right>
		<a href=# onClick=logout();><img border=0 src='Portal/includes/images/Logout.gif'></a>
		</TD>
	</TR>	
</TABLE>

<script language="javascript">
var logoutPressed;

function logout()
{	
	location.href = 'logout.php';
}
</script>