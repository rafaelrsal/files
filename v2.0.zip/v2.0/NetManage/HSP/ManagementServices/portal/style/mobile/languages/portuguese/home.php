<?PHP
define('HOME_STATUS','Micro Focus - Host Services Platform');
define('HOME_APPLICATION_TREE_TXT','�rvore de Aplica��es');
define('HOME_DB_FATAL_ERROR','Erro Fatal: N�o foi poss�vel conectar no database.');
define('HOME_HTML_APPLICATION', "Aplica��es HTML");
define('HOME_INSTALL_APPLICATION', "Aplicativos Instal�veis");
?>