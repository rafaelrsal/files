<?PHP	
	include_once('Portal/style/' . $userObj->getUserStyle() . '/languages/'. $_SESSION['language'].'/home.php');

	require_once('Portal/includes/dbConnection.php');
	require_once('Portal/includes/applicationProcess.php');
	require_once('Portal/includes/applicationList.php');
?>

<HTML>
<HEAD>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	
	<link rel="stylesheet" type="text/css" href="Portal/style/<?PHP echo $userObj->getUserStyle();?>/hsp.css">
	<link id="tabstyle" type="text/css" rel="stylesheet" href="Portal/includes/css/tab.style.css" />	
	
	<script type="text/javascript" src="Portal/includes/js/cookies.js"></script>	
	<script type="text/javascript" src="includes/js/server.js"></script>
	
</HEAD>
<BODY>
<?PHP
	$htmlApplication = '';
	$mobileApplications = '';
	
	getApplicationList( $htmlApplication,  $mobileApplications );
?>
<table width="100%">
	<TR>
		<TD colspan=2>
		<?PHP
			include_once('Portal/style/mobile/header.php');
		?>
		</TD>
	</TR>
	<?php
		if ( $mobileApplications != '' )
		{
			echo "<TR><TD align='top' height='20px' bgcolor='#DEE3F7'>" . HOME_INSTALL_APPLICATION . "</TD></TR>";
			echo "<TR><TD height='100%'>" . $mobileApplications . "</TD></TR>";
		}
	?>
	<TR>
		<TD align="top" height="20px" bgcolor="#DEE3F7">
			<?php
				echo HOME_HTML_APPLICATION;
			?>
        </TD>
	</TR>
	<TR>
		<TD height="100%">
		<?PHP
			echo $htmlApplication;
		?>
		</TD>
	</TR>
</table>

</BODY>
</HTML>
<SCRIPT type="text/javascript">
	
	phpSid ='<?php echo session_id();?>';	
	var size = getCookie('tabCount' + phpSid );
	
	if ( null != size )
	{ // register after a refresh		
		runServerScript('register.php');
	}
	
	if ( 0 != size )
	{		
		var expDays = 30;
		var exp = new Date();
		exp.setTime(exp.getTime() + (expDays*30*24*60*60*1000));
		sessionCount = 0;
		setCookie ('tabCount' + phpSid, 0, exp);		
	}
</SCRIPT>