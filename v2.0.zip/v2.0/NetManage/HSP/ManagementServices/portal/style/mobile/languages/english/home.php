<?PHP
define('HOME_STATUS','NetManage - Host Services Platform');
define('HOME_APPLICATION_TREE_TXT','Application Tree');
define('HOME_DB_FATAL_ERROR','Fatal error: Cannot connect to database.');
define('HOME_HTML_APPLICATION', "HTML applications");
define('HOME_INSTALL_APPLICATION', "Installable applications");
?>