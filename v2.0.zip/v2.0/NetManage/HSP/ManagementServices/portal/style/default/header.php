<!-- HEADER - START -->
<?php

$style = $userObj->getUserStyle();
$language = $_SESSION['language'];

if ( $userObj->isAnonymous())
{
	$fullName = 'Anonymous';
}
else
{
	$fullName = trim($userObj->getFullName());
	
	if ( $fullName == '' || empty($fullName) )
	{
		$fullName = $userObj->getUsername();
	}
}
include_once('Portal/style/' . $style . '/languages/'. $language .'/header.php');
?>

<TABLE border="0" width="100%" cellspacing="0" cellpadding="0" style="display:inline;" id=tblHeader  bgcolor="#FFFFFF" >
	<TR>
		<TD align=left>
			<img src = "Portal/style/<?PHP echo $style; ?>/images/img-logo-itau.jpg" border="0" alt="">
		</TD>
		<TD align=center class="HomeHeader">
		
			<?PHP echo '&nbsp;&nbsp;' . HEADER_WELCOME . $fullName ;?>
		</TD>
		<TD align=right>
			<?PHP 				
				echo "<a href=# onClick=logout(); onMouseOver=\"window.status='". HOME_STATUS ."'; return true;\" >". HOME_LOGOUT ."</a>";
			 ?>
		</TD>		
	</TR>	
</TABLE>

<script language="javascript">
var logoutPressed;

function logout()
{	
	logoutPressed = true;
	location.href = 'logout.php';
}
</script>

<!-- HEADER - END -->