<!-- FOOTER - START -->
<!--
<TABLE border="0" width="100%" cellspacing="0" cellpadding="0">
	<TR>
		<TD align="center">
			<B>Host Services Platform</B>
		</TD>
	</TR>
</TABLE>
-->
<!-- FOOTER - END -->