<?PHP
define('HEADER_WELCOME', 'Welcome ');
?>