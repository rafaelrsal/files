<?PHP
define('HEADER_WELCOME', 'Bem vindo, ');
?>