<?PHP
define('HOME_STATUS','NetManage - Host Services Platform');
define('HOME_NEW_WINDOW','Open in new window');
define('HOME_CLOSE_BTN','Close');
define('HOME_APPLICATION_TREE_TXT','Application Tree');
define('HOME_DB_FATAL_ERROR','Fatal error: Cannot connect to database.');

define('HOME_USERNAME_LABEL','User name:');
define('HOME_NEW_PASSWORD', 'New password');
define('HOME_CONFIRM_PASSWORD', 'Confirm password');
define('HOME_WRONG_PASSWORD', 'Wrong Password');
define('HOME_PASSWORD_REQ_MSG', 'Password  is required');
define('HOME_PASSWOR_DO_NOT_MATCH', 'Confirm password must match password');
define('HOME_CHANGE_PASS_LBL', 'Change password');
define('HOME_OLD_PASSWORD', 'Password');
define('HOME_OK_LBL', 'Ok');
define('HOME_CANCEL_LBL', 'Cancel');
define('HOME_REQUIRED_FIELD_TXT','denotes required field');

//*********define logout***********
define('HOME_LOGOUT','Logout');
?>