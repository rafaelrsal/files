<?PHP
define('HOME_STATUS','Micro Focus - Host Services Platform');
define('HOME_NEW_WINDOW','Abrir em nova janela');
define('HOME_CLOSE_BTN','Fechar');
define('HOME_APPLICATION_TREE_TXT','Menu de Aplica��es');
define('HOME_DB_FATAL_ERROR','Erro Fatal: N�o foi poss�vel conectar no database.');

define('HOME_USERNAME_LABEL','Usu�rio:');
define('HOME_NEW_PASSWORD', 'Nova senha');
define('HOME_CONFIRM_PASSWORD', 'Confirme senha');
define('HOME_WRONG_PASSWORD', 'Senha n�o confere');
define('HOME_PASSWORD_REQ_MSG', 'Senha � obrigat�ria');
define('HOME_PASSWOR_DO_NOT_MATCH', 'Confirma��o de senha deve corresponder a senha');
define('HOME_CHANGE_PASS_LBL', 'Altere a senha');
define('HOME_OLD_PASSWORD', 'Senha');
define('HOME_OK_LBL', 'Ok');
define('HOME_CANCEL_LBL', 'Cancelar');
define('HOME_REQUIRED_FIELD_TXT','verifique os campos obrigat�rios');

//*********define logout***********
define('HOME_LOGOUT','Sair');
?>