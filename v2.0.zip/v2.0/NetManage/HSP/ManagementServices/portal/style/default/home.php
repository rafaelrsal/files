	<script language="JavaScript" type="text/javascript">
	<!--
	<?php
	define('LMENU_PATH','includes/LMenu/');
	
	include (LMENU_PATH.'libjs/layersmenu-browser_detection.js'); 
	include (LMENU_PATH.'libjs/layerstreemenu-cookies.js'); 
	?>
	// -->
	</script>
	<?PHP
	
	$userObj1 = $userObj;
	include_once (LMENU_PATH.'lib/PHPLIB.php');
	include_once (LMENU_PATH.'lib/layersmenu-common.inc.php');
	include_once (LMENU_PATH.'lib/treemenu.inc.php');
	include_once('Portal/style/' .  $userObj->getUserStyle() . '/languages/'. $_SESSION['language'].'/home.php');

	require_once('Portal/includes/dbConnection.php');
	require_once('Portal/includes/applicationProcess.php');

	if ($_SERVER['REQUEST_METHOD'] == 'POST')
	{ // PROCESS POST REQUESTS
		if (isset($_POST['buttonClicked']) && 'ok' == $_POST['buttonClicked'])
		{ // returned from popup with 'ok' clicked
			unset($_POST['buttonClicked']);
			
			if(!extension_loaded('HSPSecurModule'))
			{
		        dl('php_HSPSecurModule.dll');
			}
			
			updatePassword( $userObj->getUsername(), encrypt_str($_POST['newPassword']), $userObj->getCustomDirId() );
		}
	}
	
	function updatePassword($name, $newPassword, $customDirID)
	{			
		$db = DBConnection();
		
		$fields_values = array( 'password' =>$newPassword);
		return $db->AutoExecute(TABLE_CUSTOM_USERS, $fields_values, DB_AUTOQUERY_UPDATE, "dirID=$customDirID AND name=\"$name\";");
	}
?>

<HTML>
<HEAD>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	
	<!-- PORTAL STYLESHEET - START -->
	<link rel="stylesheet" type="text/css" href="Portal/style/<?PHP echo $userObj->getUserStyle();?>/hsp.css">
	<!-- PORTAL STYLESHEET - END -->
	
	<!-- tab control - start -->	
	<link id="tabstyle" type="text/css" rel="stylesheet" href="Portal/includes/css/tab.style.css" />	
	<script type="text/javascript" src="Portal/includes/js/tabpane.js"></script>
	<script type="text/javascript" src="Portal/includes/js/tabcontrol.js"></script>
	<script type="text/javascript" src="Portal/includes/js/Languages/<?PHP echo $_SESSION['language']; ?>/tabcontrol.js"></script>	
	<!-- tab control  - end -->
	
	<script type="text/javascript" src="data/portalConfiguration.js"></script>
	<script type="text/javascript" src="Portal/includes/js/cookies.js"></script>	
	<script type="text/javascript" src="includes/js/server.js"></script>
	
</HEAD>
<BODY scroll=no>

<table width="100%" height="100%">

<!-- HEADER - START -->
<TR>
	<TD colspan=2>
	<?PHP
		include_once('Portal/style/' .  $userObj->getUserStyle() . '/header.php');
	?>
	</TD>
</TR>
<!-- HEADER - END -->

<TR>
<TD height="100%">
<TABLE border="0" width="100%" height="100%" cellspacing="0" cellpadding="0" class="PortalTable" >
	<TR>
		<!-- LEFT COLUMN - START -->
		<TD  height="100%" valign="top" width="20%" id=tdLeftTree style="display:inline;">
		<TABLE width="100%" height="100%" class="LeftTable" cellspacing="0" cellpadding="0">
            <TR>
                <TD align=center  height="20px" bgcolor="#F57921">
					<div class="app-menu">
					   <?php
							echo HOME_APPLICATION_TREE_TXT;
						?>
					</div>
                </TD>
            <TR>

			<TR>
				<TD height="100%">
					<DIV style="border:1px  solid; width:100%; height:100%;overflow-x:auto; overflow-y:auto;">
					<?PHP
					$nodeList = $_SESSION['megredList'];
					$db = new dbConnection();
					if ( isset($_SESSION['refresh_tree']) )
					{		
						$userObj->m_db = $db->getDb();
						$userObj->getUserInfoFromDB();// get user id and style from hsp_users table				
					}
					$appProc = new applicationProcess($db, &$userObj);
					
					if ( isset($_SESSION['refresh_tree']) )
					{						
						$nodes = $appProc->getMergedNodeList();
						if ( $nodes == HSP_ERR_DB_SQL_ERROR )
						{
							//return ERR_DB_ERROR;
						}
						
						$nodeList = $appProc->buildUserTree($nodes);
						$_SESSION['megredList'] = $nodeList;
					}
					
					$strTree = $appProc->buildLMenuTree($nodeList);
					echo $strTree;
					?>
					</DIV>
				</TD>
			</TR>
            <TR>
                <TD align=center bgcolor="#F57921">
	                <DIV id="openInNewWindow">
	                    <FORM>
	                    	<INPUT TYPE=CHECKBOX id="newWindow" onclick="toggleNew()" value="off"><?PHP echo HOME_NEW_WINDOW; ?></INPUT>                    
	                    </FORM>
	                </DIV>
	                </TD>
            </TR>
            <TR align=center bgcolor="#F57921">
            	<TD>
					<div class="app-menu">
						<?PHP 
						$br = false;            		
						if ( $userObj->isCustomUser() && !$userObj->getCannotChangePassword() )
						{
							$br = true;
							echo "<a href=\"#\" onMouseover=\"window.status='Micro Focus - Host Services Platform'; return true;\" onclick='openChangePasswordPopup();'>".HOME_CHANGE_PASS_LBL."</a>";
						}
						
						if ( $userObj->getLocalstartState() )
						{            			            			
							if ( $br )      			            			
							{
								echo "<br>";
							}
							
							echo "<a href=\"#\" onMouseover=\"window.status='Micro Focus - Host Services Platform'; return true;\" onClick=localstartTab(); id='enableLocalstartState'>Download Local Start</a>";
						}
						
						?>
					</div>
            	</TD>
            </TR>
		</TABLE>		      	
        </TD>
        <td width=2px class="CenterTable" id=tdCenterTree></td>
		<!-- LEFT COLUMN - END -->
		<!-- CENTER - START -->
		<TD valign="top" class="RightTable" id=TDContainer align=right class="tab-pane" bgcolor="#FFFFFF">
			<a id=ancRestore style='display:none;' href='#'><img border=0 src='Portal/includes/images/Restore.gif' onclick='RestoreTab();'></a>
        			<a id=ancMaximize href='#'><img border=0 src='Portal/includes/images/Maximize.gif' onclick='MaximizeTab();'></a>
                        		<a href='#'><img border=0 onclick=removeTab() src='Portal/includes/images/Close.gif' value='Close'></a>
			<div class="tab-pane" id="tabPane"  style="width:100%;height:100%" >
			<SCRIPT type="text/javascript">						
			globalTabPane = new WebFXTabPane( document.getElementById( "tabPane" ) , false );
			
				switch (screen.height)
				{
					case 1050:
						document.getElementById('tabPane').style.height="90%";
						break;
					case 1024:
						document.getElementById('tabPane').style.height="89%";
						break;
					case 768:
						document.getElementById('tabPane').style.height="88%";
						break;
					case 600:
						document.getElementById('tabPane').style.height="75%";
						break;
				}
							
 			</SCRIPT>
			</div>
		</TD>
		<!-- CENTER - END -->
		
		<!-- RIGHT COLUMN - START -->
		<!-- Right column is disabled
		<TD width="150" valign="top">
		</TD>		
		-->
		<!-- RIGHT COLUMN - END -->
		
	</TR>
</TABLE>
</TD>
</TR>

<!-- FOOTER - START -->
<TR>
	<TD colspan=2>
		<?PHP
		include_once('Portal/style/' .  $userObj->getUserStyle() . '/footer.php');	
		?>
	</TD>
</TR>
<!-- FOOTER - END -->

</table>

<FORM action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" name="homeForm" id="homeForm">
<input name="buttonClicked" type="hidden" value= />
<input name="username" type="hidden" value="<?PHP echo $userObj->getUsername(); ?>" />
<input name="newPassword" type="hidden" value= />
<input name="password" type="hidden" value="<?PHP echo $userObj->getPassword(); ?>" />
<input name="customDirID" type="hidden" value='<?PHP echo $userObj->getCustomDirId(); ?>' />
</FORM>

<DIV id="popupContent" style="display:none">
	<table height="100%" >
	<TR>
		<TD width="5px"></TD>
		<TD><font color="red"><div id="popupErrors"></div></font></TD>
	</TR>
	<TR>
		<TD width="0px"></TD>
		<TD height="99%" valign="top">
			<table>
    		<TR>
    			<TD width=390px>
			        <TABLE>
					<TR>
						<TD width=110px><?PHP echo HOME_USERNAME_LABEL;?></TD><TD><input class="FixedWidthObjects" size="20" maxlength="255" name="popupusername" type="text" /></TD>
					</TR>
					<TR>
						<TD width=110px><font color="red" size="1">*</font><?PHP echo HOME_OLD_PASSWORD;?></TD>
						<TD><input class="FixedWidthObjects" size="20" maxlength="255" name="oldPassword" type="password" /></TD>
					</TR>					
					<TR>
						<TD width=110px><font color="red" size="1">*</font><?PHP echo HOME_NEW_PASSWORD;?></TD>
						<TD><input class="FixedWidthObjects" size="20" maxlength="255" name="newPassword" type="password" /></TD>
					</TR>
					<TR>
						<TD width=110px><font color="red" size="1">*</font><?PHP echo HOME_CONFIRM_PASSWORD;?></TD>
						<TD><input class="FixedWidthObjects" size="20" maxlength="255" name="confirmPassword" type="password" /></TD>
					</TR>
			        </TABLE>
				</TD>
			</TR>
			<TR>		
				<TD height="99%" class="smallText">
					<hr>
					<TABLE>
					<TR>
	    				<TD class="smallText"><font color="red" size="1">*</font><?PHP echo HOME_REQUIRED_FIELD_TXT;?></TD>
	    			</TR>
					</TABLE>
				</TD>
			</TR>			
			<TR>
				<TD height="99%">
					<table border="0">
					<TR>
						<TD width=50%></TD>
						<TD width=50%  align=right>
							<INPUT class="NewButton" name="popupok" value="<?PHP echo HOME_OK_LBL;?>" type="submit" onclick="onOk()"/>			
						</TD>
						<TD>
							<INPUT class="NewButton" name="popupcancel" value="<?PHP echo HOME_CANCEL_LBL;?>" type="button" onclick="onCancel();"/>
						</TD>
					</TR>
					</table>
				</TD>
			</TR>
    		</table>
		</TD>	
	</TR>
	</table>
</DIV>	

<input name="password_req_msg" type="hidden" value='<?PHP echo HOME_PASSWORD_REQ_MSG; ?>' />
<input name="passwordMatch_req_msg" type="hidden" value='<?PHP echo HOME_PASSWOR_DO_NOT_MATCH ?>'/>
<input name="wrong_password_msg" type="hidden" value='<?PHP echo HOME_WRONG_PASSWORD; ?>' />

</BODY>
</HTML>
<SCRIPT type="text/javascript">
	
	phpSid ='<?php echo session_id();?>';	
	var size = getCookie('tabCount' + phpSid );
	
	if ( null != size )
	{ // register after a refresh		
		runServerScript('register.php');
	}
	
	if ( 0 != size )
	{		
		var expDays = 30;
		var exp = new Date();
		exp.setTime(exp.getTime() + (expDays*30*24*60*60*1000));
		sessionCount = 0;
		setCookie ('tabCount' + phpSid, 0, exp);		
	}
	
	if ( false == enableNewWindow )
	{
		document.all.openInNewWindow.style.display='none';
	}	
	
	if ( true == setOpenNewWindow )
	{
		document.all.newWindow.checked = 'on';	//dispaly
		toggleNew(); // state
	}

	if (enableLocalstart == false && document.all.enableLocalstartState != null )
	{
		document.all.enableLocalstartState.style.display='none';
	}

	function openChangePasswordPopup()
	{
		window.showModalDialog('portalPopup.php?Title=<?php echo HOME_CHANGE_PASS_LBL;?>&jsFileName=home.js',window,"dialogHeight:250px;dialogWidth:380px;status:no;center:yes;help:no;");
	}
</SCRIPT>