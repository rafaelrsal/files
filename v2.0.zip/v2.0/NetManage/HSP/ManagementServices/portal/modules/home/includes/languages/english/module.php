<?PHP
define('HOME_MAIN_TXT','<h1><center><marquee>HSP - RELOADED</marquee></center></h1>');
?>