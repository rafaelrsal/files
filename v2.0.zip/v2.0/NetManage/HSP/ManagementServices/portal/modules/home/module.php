<?PHP
require_once('includes/classes/boxes.php');

class home extends ModuleBase
{
	function home($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		$moduleName = 'home';		
		$session  = parent::GetSession();
		$session->set(SESSION_MODULE, $moduleName);
		
		$language = parent::GetLanguage();
		$language ->RequireLangFile( 'module.php' , $moduleName);		
		$boxContents = array();
	  	$boxContents[] = array('text' =>HOME_MAIN_TXT); 
	  	$box = new infoBox($boxContents);
	    $this->SetContent($box->getInfoBox());		
	}	
}
?>