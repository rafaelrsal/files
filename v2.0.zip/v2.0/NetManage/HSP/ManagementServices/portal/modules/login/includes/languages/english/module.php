<?PHP
define('LOGIN_HEADER_TXT' , 'Welcome to Host Access Platform User Login');
define('LOGIN_USERNAME_LBL', 'Username:');
define('LOGIN_PASSWORD_LBL', 'Password:');
define('LOGIN_DIRECTORIES_LBL', 'Directory:');
define('LOGIN_BTN','Login');
define('LOGIN_TXT_REQUIRED','denotes required field');
define('LOGIN_NAME_REQ_MSG','Please enter your user name');
define('LOGIN_PWD_REQ_MSG','Please enter your user password');
define('LOGIN_INITIAL_CONFIG_MSG','You are running HSP admin console for the first time. Please fill in your details.');
?>