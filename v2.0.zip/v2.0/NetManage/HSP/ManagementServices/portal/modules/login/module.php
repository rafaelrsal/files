<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Author:           	Hoter Mickey
  		Udi Zisser
  					
  Date Created:     Mars 2004

  Title:            module.php (login)
  Purpose:          Entry point for loging in to the HSP administration console.
  Limitations:		Requires PHP 4+

 ============================================================================*/

require_once 'HTML/QuickForm/Renderer/ITStatic.php';
require_once('HTML/QuickForm.php');
require_once 'HTML/Template/Sigma.php';
require_once('includes/classes/boxes.php');

define('TABLE_DIRECTORIES','directories');

class login extends ModuleBase
{
	var $m_DirArray;
	var $m_pearDB;
	
	function login($globalobjects)
	{
		parent::ModuleBase($globalobjects);
		
		$moduleName = 'login';		
		$session  = parent::GetSession();
		$session->set(SESSION_MODULE, $moduleName);
		
		$language = parent::GetLanguage();
		$language ->RequireLangFile( 'module.php' , $moduleName);
		
		$this->pearDBInit();
		
		
		$isErrorFound = false;

		// Instantiate the HTML_QuickForm object
		$form = new HTML_QuickForm('loginForm'); //default is post		
				
		// Build the login form:
		$form->addElement('header', 'header', LOGIN_HEADER_TXT);
		$form->addElement('text', 'name', LOGIN_USERNAME_LBL, array('size' => 20, 'maxlength' => 255));
		$form->addElement('password', 'password', LOGIN_PASSWORD_LBL, array('size' => 20, 'maxlength' => 255));
		$form->addElement('select', 'directories', LOGIN_DIRECTORIES_LBL,$this->GetDirectoriesNames(),'style="width:200"');
		$form->addElement('submit', 'submit', LOGIN_BTN);
		$form->setRequiredNote(LOGIN_TXT_REQUIRED);
		
		// Define filters and validation rules
		$form->applyFilter('name', 'trim');
		$form->addRule('name', LOGIN_NAME_REQ_MSG, 'required');
		$form->addRule('password', LOGIN_PWD_REQ_MSG, 'required');
		
		$this->validate($form);
		
		
		$tpl =& new HTML_Template_Sigma('.');
		$tpl->loadTemplateFile('portal/modules/login/includes/login.tpl');
			
		$renderer =& new HTML_QuickForm_Renderer_ITStatic($tpl);
		$renderer->setRequiredTemplate('<font color="red" size="1">*</font>{label}');
		$renderer->setErrorTemplate('<font color="red" size="">{error}</font><br />{html}');
				
		$form->accept($renderer);
		$tpl->parse();

		$contents = $tpl->get();		
		
		$boxContents = array();
	  	$boxContents[] = array('text' =>$contents); 		
	  	$box = new infoBox($boxContents);
	    $this->SetContent($box->getInfoBox());
	}
	
	function checkUserCredentials($username,$password)
	{		
		$db  = parent::GetDatabase();
		$dbAdminUsers = new adminUsersTbl($db);
		return $dbAdminUsers->validate($username,$password);		
	}
	
	function GetDirectoriesNames()
	{
		$this->m_DirArray = $this->m_pearDB->GetAll(TABLE_DIRECTORIES);
		// retun an array with all the directories names
		$list = array();
		//$list[-1] = GROUPS_CHOOSE_DIR_TXT;
		foreach ($this->m_DirArray as $dir)
		{
			$list[$dir[0]] = $dir[1]; // $dir[1] name , $dir[0] dir id
		}
		return $list;
	}
	
	function pearDBInit()
	{
		$this->m_pearDB = &parent::GetDatabase();	
		$this->m_pearDB->connect();
	}
	
	function autenticate($user , $pass, $directory)
	{
		if(!extension_loaded(PHP_AUTH_MODULE))
		{
			dl(PHP_AUTH_DLL);
		}
		
		if (1 == authenticateuser($user, $pass, $directory)) // authentication succeeded
		{
			//authentication succeeded
			return true;
		}
		else
		{
			// authentication failed
			$errorCode = array(HSP_ERR_AUTHENTICATION_ERROR);		
			$this->m_Session->set(SESSION_ERRORS, $errorCode);
			return false;
		}
	}
	
	function getDirectoryName($dirID)
	{
		foreach ($this->m_DirArray as $dir)
		{
			if ($dir[0] == $dirID)
			{
				return $dir[2]; //directory name
			}
		}
	}
	
	function validate(&$form)
	{
		if ($form->validate())
		{
			$username = htmlspecialchars($form->exportValue('name'));
			$password = htmlspecialchars($form->exportValue('password'));
			$directoryId = htmlspecialchars($form->exportValue('directories'));
			
			$directoyName = $this->getDirectoryName($directoryId);
			
			if ($this->autenticate($username , $password, $directoyName))
			{
					Header('Location: index.php?module=home');
			}
		}
	}
	
	
}
?>