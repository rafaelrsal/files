<?PHP
define('LOGIN_HEADER_TXT' , 'Bem vindo ao Portal de Login do Usu�rio para Acesso aos Hosts');
define('LOGIN_USERNAME_LBL', 'Usu�rio:');
define('LOGIN_PASSWORD_LBL', 'Senha:');
define('LOGIN_DIRECTORIES_LBL', 'Diret�rio:');
define('LOGIN_BTN','Login');
define('LOGIN_TXT_REQUIRED','verifique os campos obrigat�rios');
define('LOGIN_NAME_REQ_MSG','Por favor informe seu usu�rio');
define('LOGIN_PWD_REQ_MSG','Por favor informe sua senha');
define('LOGIN_INITIAL_CONFIG_MSG','Voc� est� executando a console de administra��o do HSP pela primeira vez. Por favor preencha os seus dados.');
?>