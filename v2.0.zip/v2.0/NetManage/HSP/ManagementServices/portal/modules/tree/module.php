
<script language="JavaScript" type="text/javascript">
<!--
<?php
define('LMENU_PATH','includes/LMenu/');

include (LMENU_PATH.'libjs/layersmenu-browser_detection.js'); 
include (LMENU_PATH.'libjs/layerstreemenu-cookies.js'); 
?>
// -->
</script>
<?PHP
include_once (LMENU_PATH.'lib/PHPLIB.php');
include_once (LMENU_PATH.'lib/layersmenu-common.inc.php');
include_once (LMENU_PATH.'lib/treemenu.inc.php');

class tree
{
	var $m_Content;
	function tree($str)
	{
		$mid = new TreeMenu();		
		$mid->setImgdir(LMENU_PATH.'images/');
		$mid->setImgwww(LMENU_PATH.'images/');
		$mid->setLibjsdir(LMENU_PATH.'libjs/');
		$mid->setMenuStructureString($str);
		$mid->parseStructureForMenu("treemenu1");
	    $this->m_Content = $mid->newTreeMenu("treemenu1");
		
		print_r($this);
	}
	
	function show()
	{
		echo $this->m_Content;
	}
}  
?>