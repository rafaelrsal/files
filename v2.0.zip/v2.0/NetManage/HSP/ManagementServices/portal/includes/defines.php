<?php
// Admin Global Defines
	define('LANG_DIR' , 'Portal/includes/languages/');	
	define('BOXES_DIR' , 'Portal/includes/boxes/');
	define('CLASSES_DIR' , 'Portal/includes/classes/');	
	define('IMAGES_DIR' , 'Portal/includes/images/');
	define('SESSION_DIR_AUTH_CACHE' , 'dirAuthCache' );
	
?>