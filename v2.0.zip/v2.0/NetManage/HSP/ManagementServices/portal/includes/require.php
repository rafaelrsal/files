<?php
	require_once('filenames.php');	
	require_once('defines.php');
?>