<?PHP
define('FILENAME_INDEX','index.php');
define('FILENAME_ADMIN','admin.php');
define('FILENAME_STYLESHEET','stylesheet.css');
define('FILENAME_DIRECTORYCFG','directorycfg.php');
define('FILENAME_DIRECTORIESBOX','directoriesBox.php');
define('FILENAME_LANGUAGEBOX','languageBox.php');
define('FILENAME_CLOCKBOX','clockBox.php');
define('FILENAME_LMENUTREEBOX','LMenuTreeBox.php');
define('FILENAME_PAGE_TPL','page_tpl.php');
define('FILENAME_FRAME_ELEMENTS','frameElements.php');

?>