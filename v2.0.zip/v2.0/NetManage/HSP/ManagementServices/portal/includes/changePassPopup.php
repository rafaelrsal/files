	
<DIV id="popupContent" style="display:none">
	<table height="100%" >
	<tr>
		<td width="5px"></td>
		<td><font color="red"><div id="popupErrors"></div></font></td>
	</tr>
	<tr>
		<td width="0px"></td>
		<td height="99%" valign="top">
			<table>
    		<tr>
    			<td width=390px>
			        <TABLE>
					<TR>
						<TD width=110px><?PHP echo USERNAME_LABEL;?></td>
						<td><input class="FixedWidthObjects" size="20" maxlength="255" name="popupUsername" type="text" /></TD>
					</TR>
					<TR>
						<TD width=110px><font color="red" size="1">*</font><?PHP echo OLD_PASSWORD;?></TD>
						<TD><input class="FixedWidthObjects" size="20" maxlength="255" name="oldPassword" type="password" /></TD>
					</TR>					
					<TR>
						<TD width=110px><font color="red" size="1">*</font><?PHP echo NEW_PASSWORD;?></TD>
						<TD><input class="FixedWidthObjects" size="20" maxlength="255" name="newPassword" type="password" /></TD>
					</TR>
					<TR>
						<TD width=110px><font color="red" size="1">*</font><?PHP echo CONFIRM_PASSWORD;?></TD>
						<TD><input class="FixedWidthObjects" size="20" maxlength="255" name="confirmPassword" type="password" /></TD>
					</TR>
			        </TABLE>
				</td>
			</tr>
			<tr>		
				<td height="99%" class="smallText">
					<hr>
					<TABLE>
					<tr>
	    				<td class="smallText"><font color="red" size="1">*</font><?PHP echo REQUIRED_FIELD_TXT;?></td>
	    			</tr>
					</TABLE>
				</td>
			</tr>			
			<tr>
				<td height="99%">
					<table border="0">
					<tr>
						<td width=50%></td>
						<td width=50%  align=right>
							<INPUT class="NewButton" name="popupok" value="<?PHP echo OK_LBL;?>" type="submit" onclick="onOk()"/>			
						</td>
						<td>
							<INPUT class="NewButton" name="popupcancel" value="<?PHP echo CANCEL_LBL;?>" type="button" onclick="onCancel();"/>
						</td>
					</tr>
					</table>
				</td>
			</tr>
    		</table>
		</td>	
	</tr>
	</table>
	</DIV>