<?PHP
define('IMAGE_NM_BANNER','logo_itau2.png');
?>