<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Jan 2005
  Title: loginProcess.php
  Purpose: user portal login functions and handling.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
if ( !isset($_SESSION) )
{
	ini_set("include_path", ".;includes/pear;includes/xmlparser" );

	require_once('includes/classes/whosOnline.php');
	require_once('Portal/includes/dbConnection.php');
	require_once('Portal/includes/applicationProcess.php');
	require_once('Portal/includes/portalUser.php');
	require_once('includes/classes/PearDB.php');
	require_once('includes/global_defines.php');
	require_once('includes/classes/global_objects.php');

	session_start();
}

if ( isset($_SESSION['adminAuthFlag']) )
{
	$_SESSION = array();
}


define('ANON_USER_NAME', 'anonymous');
$db = new dbConnection();
$whosOnlineObj = new whosOnline($db->getDb());
$globalobjects = new GlobalObjects();
$pearDB = $globalobjects->GetDatabase();
$pearDB->connect();
if ( is_null($db->getDb()) )
{		
	redirectToErrorPage( 7 );// General database error
}

// if we are authorized we only need to redirect.
// this is usually (100%) a refresh thing
if ( isset($_SESSION['authenticatedUserType']) )
{	
	$_SESSION['refresh'] = true;
	$_SESSION['refresh_tree'] = true;
	redirect( $db, $whosOnlineObj );
}

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{ //  POST REQUESTS
	if (isset($_POST['loginUsername']))
	{	
		$defaultUsername = stripslashes($_POST['loginUsername']);
	}
	
	if (isset($_POST['password']))
	{
		$defaultPassword = stripslashes($_POST['password']);
	}
	
	if (isset($_POST['directories']))
	{
		$defaultDirectory = $_POST['directories'];
	}
	
	if (isset($_POST['groups']))
	{
		$groups = $_POST['groups'];
	}
	
	if (isset($_POST['domain']))
	{
		$domain = $_POST['domain'];
	}
	
	if (isset($_POST['rememberPassword']) )
	{
		$rememberPassword = 'checked';
	}
	else
	{
		$rememberPassword = '0';
	}
	
	if ( isset($_POST['sso']) && $_POST['sso'] == true )
	{		
		if (isset($_POST['ssoParameters']) )
		{
			doSSO($db,$whosOnlineObj,$_POST['ssoParameters']);
		}
		else
		{
			redirectToErrorPage( 3 );// you are not authorized to view this page!
		}
	}	
	elseif ( isset($_SESSION['anonymous']) && $_SESSION['anonymous'] == true )
	{
		$wrapper = new xmlWrapper();
		$wrapper->initFromFile(CONFIG_XML_PATH . CONFIG_XML_NAME);
		$anonStatus = $wrapper->getAnonymousStatus();

		if ('enabled' == $anonStatus)
		{
			doAnonLogin($db,$whosOnlineObj);
		}
		else 
		{
			redirectToErrorPage( 1 );// Anonymous user login is disabled.
		}
	}
	else
	{
		$errorMsg = doLogin($db,$whosOnlineObj,$defaultDirectory,$defaultUsername,$defaultPassword, &$invokeChangePasswordPopup, $pearDB);
	}	
}
	function doLogin( $db, $whos, $defaultDirectory, $defaultUsername , $defaultPassword, &$changePass, $pearDB = null )
	{	
		$user = new portalUser( $db, USER_TYPE_USER, $defaultUsername, $defaultPassword, $defaultDirectory );
		// DB Call
		if ( $user->getDirDetailsFromDB() != HSP_SUCCESS ) // get dir details from the db and fill an array
		{
			return ERR_DB_ERROR; // test error msg
		}
		
		$dirDetails = $user->getDirectoryDetails(); // get the dir details array
		$dirDisplayName = $dirDetails['display_name'];
		
		// DB Call
		if ( GLOBAL_SESSION_LIMIT && $whos->checkUserLogged( $defaultUsername, $dirDisplayName ) )
		{
			return ERR_USER_ALREADY_LOGGEDIN;
		}
		// DB Call
		if ( $user->getUserInfoFromDB() != HSP_SUCCESS )// get user id and style from hsp_users table
		{
			return ERR_DB_ERROR;
		}		
		
		$fullName = $defaultUsername;
		$appProc = new applicationProcess( $db, &$user );
		// DB Call if custom
		$auth = $appProc->authenticate(); // also fills in custom user parameters ()
		//------------------------------------------------------------------------------------//
		if ( $auth == true )
		{
			$isMobile = strstr( $_SERVER['PHP_SELF'], 'mobileindex.php' );
			$style = $user->getUserStyle();
			if ( $isMobile )
			{
				$user->setUserStyle('mobile');
			}
			
			
			if ( $user->isCustomUser() )
			{
				$details = $user->getCustomUserDetails();
				
				if (isset($_POST['buttonClicked']) && 'ok' == $_POST['buttonClicked'])
				{
					unset($_POST['buttonClicked']);
					
					if(!extension_loaded('HSPSecurModule'))
					{
				        dl('php_HSPSecurModule.dll');
					}

					if ( $user->updatePassword( stripslashes($_POST['newPassword'])) != HSP_SUCCESS )
					{
						return ERR_DB_ERROR;
					}					
				}
				else
				{	
					if ($details['accountDisabled'])
					{
						return ACCOUNT_IS_DISABLED;
					}
								
					$changePass = $details['changePassword'];
					if ( $changePass )
					{
						return;
					}
				}
				
				
				if ( !empty($details['fullName']) )
				{
					$fullName = $details['fullName'];
				}
				
				$_SESSION['cannotChangePassword'] = $details['cannotChangePassword'];
			}
			
			// db call at getImportedGroups()
			$nodes = $appProc->getMergedNodeList();
			if ( $nodes == HSP_ERR_DB_SQL_ERROR )
			{
				return ERR_DB_ERROR;
			}
			$userTree = $appProc->buildUserTree($nodes);
			
			if ( empty($userTree) || !count($userTree) )
			{
				return ERR_NO_TREE_DEFINED;
			}
			
			$_SESSION['authenticatedUserType'] = 'user';
			
			
			RegLogin($defaultUsername, $pearDB);
			redirect( $db, $whos, $user, $userTree );
		}
		elseif( $auth == false )
		{
			return ERR_AUTH_FAILED;
		}
		else
		{
			return ERR_DB_ERROR;
		}
	}

	function doAnonLogin($db , $whos )
	{		
		$user = new portalUser( $db );		
		
		if ( GLOBAL_SESSION_LIMIT && $whos->checkUserLogged( ANON_USER_NAME ) )
		{
			redirectToErrorPage( 6 );// You are already logged on to this directory.
		}
		
		if ( $user->getUserInfoFromDB() != HSP_SUCCESS )// get user id and style from hsp_users table
		{
			redirectToErrorPage( 7 );// General database error
		}
		
		$appProc = new applicationProcess( $db, &$user );
		
		$style = $user->getUserStyle();		
		
		$userTree = $appProc->buildUserTree();
		if ( empty($userTree) || !count($userTree) )
		{
			redirectToErrorPage( 1 );// Anonymous user login is disabled.
		}
		
		$_SESSION['authenticatedUserType'] = 'anonymous';
		redirect( $db, $whos, $user, $userTree );

	}
	
	function doSSO( $db, $whos, $ssoParameters )
	{
		if(!extension_loaded('HSPSecurModule'))
		{
			dl('php_HSPSecurModule.dll');
		}
		
		$ssoParameters = decrypt_str($ssoParameters);
		$ssoParametersArr = explode('#' , $ssoParameters);
		if ( count($ssoParametersArr) < 2 )
		{
			redirectToErrorPage( 3 );// you are not authorized to view this page!
		}
		
		$username  = $ssoParametersArr[0];		
		$directory = $ssoParametersArr[1];
		
		$userGroups = array();
		for($i = 2 ; $i < count($ssoParametersArr) ; $i++)
		{
			$userGroups[] = $ssoParametersArr[$i];
		}
		
		$password = '';		
		
		$user = new portalUser( $db, 'sso', $username , $password, null, $directory );
		$dirDetailsRet = $user->getDirDetailsFromDB();
		if ( $dirDetailsRet == HSP_ERR_DB_SQL_ERROR ) // get dir details from the db and fill an array
		{
			redirectToErrorPage( 7 );// General database error
		}
		elseif( $dirDetailsRet == HSP_ERR_EMPTY_DIR_LIST)
		{
			redirectToErrorPage( 3 );// you are not authorized to view this page!
		}
		
		$dirDetails = $user->getDirectoryDetails();		
		
		if ( GLOBAL_SESSION_LIMIT && $whos->checkUserLogged( $username, $dirDetails['ssoname'] ) )
		{
			redirectToErrorPage( 6 );// You are already logged on to this directory.			
		}
		
		if ( $user->getUserInfoFromDB() != HSP_SUCCESS )// get user id and style from hsp_users table
		{
			redirectToErrorPage( 7 );// General database error
		}
		
		$appProc = new applicationProcess( $db, $user );		
		$nodes = $appProc->getMergedNodeList($userGroups);
		if ( $nodes == HSP_ERR_DB_ERROR )
		{
			redirectToErrorPage( 7 );// General database error
		}
		$userTree = $appProc->buildUserTree($nodes);
		if ( empty($userTree) || !count($userTree) )
		{
			redirectToErrorPage( 3 );// you are not authorized to view this page!
		}
		
		$_SESSION['authenticatedUserType'] = 'sso';
		redirect( $db, $whos, $user, $userTree );
	}	

	function redirect( $db, $whos, $userObj=null, $userTreeNodes=null )
	{		
		$_SESSION['language'] = CURRENT_LANG; // TODO: handle this elsewhere...	
		
		if ( !is_null($userObj) )
		{
			$_SESSION['userObject'] = $userObj;
		}
		
		if ( !is_null($userTreeNodes) )
		{
			$_SESSION['megredList'] = $userTreeNodes;
		}
				
		$whos->register();
		include_once('portalLoader.php');
		exit();		
	}	
	
	function redirectToErrorPage( $err )
	{
		$_SESSION['errorCode'] = $err;
		include_once('hspError.php');	
		exit();	
	}	
	
	/***********************************************
		Criador: Guilherme Lima
		Empresa: Slice-TI
		Data: June 2013
		Fun��o para cria��o de arquivo contendo
			Registros de Login
		Recebe --> $username - usu�rio que logou
	************************************************/
	function RegLogin($username, $pearDB)
	{
		$sql = 	"SELECT g.name from " .  TABLE_CUSTOM_USERS . " u inner join ". TABLE_CUSTOM_CROSS ." c on c.userId = u.id inner join ". TABLE_CUSTOM_GROUPS." g on g.id = c.groupId";
		$pearDB->GetOne($sql, $name);
		if ( DB::isError($name) )
		{
			$name = "";
		}
		$log = fopen("log/portal/".date('Ymd').".hsp", 'a');
		if($log == true)// criou ou abriu log?
		{
			$strTextoLog = date('d/m/Y H:i:s').";".$username.";".$name."\n"; // string contendo conteudo do arquivo
			fwrite($log, $strTextoLog);
			fclose($log);
		}
	}
?>