var MAXTAB_MSG = 'You have exceeded the maximum number of applications you are allowed to open.';
