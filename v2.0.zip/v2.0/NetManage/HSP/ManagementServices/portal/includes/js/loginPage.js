window.status = "NetManage - Host Services Platform";
window.onbeforeunload = disableFields;

function disableFields()
{
	for ( i = 0 ; i < document.forms[0].elements.length ; ++i )
	{
		document.forms[0].elements[i].disabled = true;
	}
}

function loginOnload(changePass)
{	
	selectDirectory();
	if (changePass)
	{
		// the jsFileName represents the java script file to be executed by the portaPopup.php (located @ Portal\includes\js)
		window.showModalDialog('portalPopup.php?Title=<?php echo CHANGE_PASS_LBL;?>&jsFileName=login.js',window,"dialogHeight:250px;dialogWidth:380px;status:no;center:yes;help:no;");	
	}

	if (document.getElementsByName('loginUsername').item(0).disabled == false)
	{
		document.getElementsByName('loginUsername').item(0).focus();	
	}
}

function DoDefaultEnterKey(e)
{
	if(CheckEnter(e))
	{
   		doLogon();
   	}
}

//e is event object passed from function invocation
function CheckEnter(e)
{ 
	var characterCode //literal character code will be stored in this variable

	//if which property of event object is supported (NN4)
	if(e && e.which)
	{
		e = e
		characterCode = e.which //character code is contained in NN4's which property
	}
	else
	{
		e = event
		characterCode = e.keyCode //character code is contained in IE's keyCode property
	}

	if(characterCode == 13) //if generated character code is equal to ascii 13 (if enter key)
	{ 
		return true 
	}
	else
	{
		return false 
	}

}


function doLogon()
{
	document.forms[0].submit();
}

function selectDirectory()
{
	for ( i=0; i<document.loginForm.directories.length; i++ )
	{
		if ( document.loginForm.directories[i].value == "<?php echo $defaultDirectory;?>")
		{
			document.loginForm.directories.selectedIndex = i;
			break;
		}
	}			
}