/* open all tabs after refresh
var nodeIdArray = new Array();
var nodeNameArray = new Array();
*/

var phpSid = null;
var expDays = 30;
var exp = new Date();
exp.setTime(exp.getTime() + (expDays*30*24*60*60*1000));
var bLoadingFlag = false;

var windowHandles = new Array(255);
var localstartTabIndex = -1;

function toggleNew()
{
	if (document.getElementById( "newWindow" ).value == "on")
	{
		document.getElementById( "newWindow" ).value = "off";
	}
	else
	{
		document.getElementById( "newWindow" ).value = "on";
	}
}
function addTab(nodeID, nodeName, newWindow )
{
	if( bLoadingFlag )
	{
		return;
	}
	
	if( nodeName == null )
	{
		return;
	}
	if ( newWindow == 'newWindow' || document.getElementById( "newWindow").value == "on" && !newWindow )
	{
		var openWindowCount = getCookie('windowCount' + phpSid); // open windows
		var openTabsCount = getCookie('tabCount' + phpSid); // open tabs
		
		if ( null == openWindowCount )
		{		
			openWindowCount = 0;
			setCookie ('windowCount' + phpSid, 0, exp);
		}
		
		if ( null == openTabsCount)
		{		
			openTabsCount = 0;
			setCookie ('tabCount' + phpSid, 0, exp);
		}
		
		if( (parseInt(openWindowCount) + parseInt(openTabsCount)) >= numberOfTabs && true == globalSessionLimit) //number open windows + tabs
		{			
			alert(MAXTAB_MSG);			
			return;
		}
	
		windowHandle = window.open('appWindow.php?nodeID=' + nodeID + '&sid='+phpSid, '_blank', "location=no, menubar=no, status=no, toolbar=no, scrollbars=yes, resizable=yes");
		for(i = 0 ; i < 255 ; i++)
		{
			if ( null == windowHandles[i] || windowHandles[i].closed )
			{
				windowHandles[i] = windowHandle;
            break;
			}
		}
	}
	else if(newWindow == 'newTab' || document.getElementById( "newWindow").value == "off" && !newWindow)
	{
		bLoadingFlag = true;
      	newTab(nodeID,nodeName);
	}
}

function onCloseAllOpenedWindows()
{
   for(i = 0 ; i < 5 ; i ++)
   {
      if(null != windowHandles[i] && !windowHandles[i].closed )
		{
			windowHandles[i].close();   
		}
   }   
}

function newTab(nodeID,nodeName)
{
		var openWindowCount = getCookie('windowCount' + phpSid); // open windows
		var openTabsCount = getCookie('tabCount' + phpSid);
		//alert('openTabsCount:'+openTabsCount+' openWindowCount:'+openWindowCount);
		if ( null == openTabsCount)
		{		
			openTabsCount = 0;
			setCookie ('tabCount' + phpSid, 0, exp);
		}
		
		if ( null == openWindowCount )
		{		
			openWindowCount = 0;
			setCookie ('windowCount' + phpSid, 0, exp);
		}		
		
		if( (parseInt(openWindowCount) + parseInt(openTabsCount)) >= numberOfTabs && true == globalSessionLimit ) //number of tabs+opne windows
		{			
			alert(MAXTAB_MSG);
			bLoadingFlag = false;
			return;
		}		

		setCookie ('tabCount' + phpSid, ++openTabsCount, exp); 		
		tabnum = globalTabPane.pages.length;
		
		/* open all tabs after refresh
		nodeIdArray[tabnum] = nodeID;
		deleteCookie('nodeidarray');
		setCookie ('nodeidarray', nodeIdArray, exp ); 
		nodeNameArray[tabnum] = nodeName;
		deleteCookie('nodenamearray');
		setCookie ('nodenamearray', nodeNameArray, exp ); 
		*/
		
		a1 = document.createElement('div');
		a1.className = "tab-page";
		a1.id = "tabid" + tabnum;
		a1.name = "tabname" + tabnum;

		a2 = document.createElement('h2');
		a2.className = "tab";
		a2.name = "tab_h2_" + tabnum;
		a2.id = "tab_h2_" + tabnum;

		a2.appendChild(document.createTextNode(nodeName));
		//a2.innerHTML=strTable;

		ifrm = document.createElement("IFRAME");
		ifrm.setAttribute("src", "appLoader.php?tab=true&nodeID=" + nodeID + "&nodeName=" + encodeURI(nodeName) + "&sid="+phpSid);
		ifrm.attachEvent('onload', unsetLoadingFlag);		
		ifrm.frameBorder=0;
		ifrm.style.width = "100%";
		ifrm.style.height = "100%";
		ifrm.name = "ifrm_" + tabnum;
		ifrm.id = "ifrm_" + tabnum;
		
		a1.appendChild(a2);
		a1.appendChild(ifrm);
		document.getElementById( "tabPane" ).appendChild(a1);
	   	page = globalTabPane.addTabPage(a1);
		globalTabPane.setSelectedIndex(page.index);
}

function unsetLoadingFlag()
{	
	bLoadingFlag = false;
}

function removeTab()
{
	for (i=0;i<globalTabPane.pages.length && globalTabPane.pages[i]==null ;i++);
	if (globalTabPane.pages[i]!=null)
	{
		selected = globalTabPane.getSelectedIndex();
		if ( localstartTabIndex == selected)
		{
			localstartTabIndex = -1;
		}
		closeTab(selected);
// handle tab cookies for refresh - start
/* open all tabs after refresh
		nodeIdArray.splice(selected,1);
		deleteCookie('nodeidarray');
		setCookie ('nodeidarray', nodeIdArray, exp ); 
		nodeNameArray.splice(selected,1);
		deleteCookie('nodenamearray');
		setCookie ('nodenamearray', nodeNameArray, exp ); 		
		*/
// handle tab cookies for refresh - end

		var sessionCount = getCookie('tabCount' + phpSid);
		if ( null != sessionCount && sessionCount > 0 )
		{
			setCookie ('tabCount' + phpSid, --sessionCount, exp);
		}

		/* open all tabs after refresh
		if (sessionCount == 0)
		{
			deleteCookie('nodeidarray');
			deleteCookie('nodenamearray');
		}
		*/
		
	}
}

function closeTab(tabIndex)
{
	thistab	= document.getElementById( "tabid" + tabIndex)
	h2 = document.getElementById( "tab_h2_" + tabIndex );

	globalTabPane.tabRow.removeChild(h2);
	ifrm = document.getElementById( "ifrm_" + tabIndex );
	ifrm.setAttribute("src", "" );
	thistab.removeChild(ifrm);
	
	tabpane = document.getElementById( "tabPane" );
	tabpane.removeChild(document.getElementById( "tabid" + tabIndex));


	globalTabPane.pages[tabIndex]=null;

	for (i=0;i<globalTabPane.pages.length && globalTabPane.pages[i]==null ;i++);

	if (globalTabPane.pages[i]!=null)
	{
		globalTabPane.setSelectedIndex(i);
	}
}

function closeAllTabs()
{
	for (i=0;i<globalTabPane.pages.length && globalTabPane.pages[i]==null ;i++)
	{
		closeTab(i);
	}
}

function MaximizeTab()
{
	document.getElementById("tdLeftTree").style.display="none";
	document.getElementById("tdCenterTree").style.display="none";
	document.getElementById("tblHeader").style.display="none";

	document.getElementById("ancMaximize").style.display="none";
	document.getElementById("ancRestore").style.display="inline";


}
function RestoreTab()
{
	document.getElementById("tdLeftTree").style.display="inline";
	document.getElementById("tdCenterTree").style.display="inline";
	document.getElementById("tblHeader").style.display="inline";
	
	document.getElementById("ancMaximize").style.display="inline";
	document.getElementById("ancRestore").style.display="none";
}

function openAllTabs()
{
	nodeIdArrayAsString = getCookie('nodeidarray');
	nodeNameArrayAsString = getCookie('nodenamearray');
	deleteCookie('nodeidarray');
	deleteCookie('nodenamearray');
	nodeIdArray = nodeIdArrayAsString.split(",");
	nodeNameArray = nodeNameArrayAsString.split(",");	
	
	for (i = 0 ; i < nodeIdArray.length ;i++ )
	{
		//window.setTimeout('doNothing()',2000);
		newTab(nodeIdArray[i],nodeNameArray[i]);
	}	
}
function doNothing()
{
}
function localstartTab()
{
	if ( localstartTabIndex == -1 )
	{
		tabnum = globalTabPane.pages.length;
		localstartTabIndex = tabnum;
		
		a1 = document.createElement('div');
		a1.className = "tab-page";
		a1.id = "tabid" + tabnum;
		a1.name = "localstartTab";

		a2 = document.createElement('h2');
		a2.className = "tab";
		a2.name = "localstartTab";
		a2.id = "tab_h2_" + tabnum;

		a2.appendChild(document.createTextNode('Local Start'));		

		ifrm = document.createElement("IFRAME");
		ifrm.setAttribute("src", "localstart.php?sid="+phpSid);
		ifrm.attachEvent('onload', unsetLoadingFlag);		
		ifrm.frameBorder=0;
		ifrm.style.width = "100%";
		ifrm.style.height = "100%";
		ifrm.name = "ifrm_" + tabnum;
		ifrm.id = "ifrm_" + tabnum;
		
		a1.appendChild(a2);
		a1.appendChild(ifrm);
		document.getElementById( "tabPane" ).appendChild(a1);
	   	page = globalTabPane.addTabPage(a1);
		globalTabPane.setSelectedIndex(page.index);
	}
}