function initPopup()
{
	document.getElementsByName('popupusername').item(0).value = win.document.getElementsByName('loginUsername').item(0).value; 
	document.getElementById('popupErrors').innerHTML = "&nbsp;";
	document.getElementsByName('popupUsername').item(0).disabled = true;
	document.getElementsByName('oldPassword').item(0).focus();
	
}

function finalizePopup()
{

}

function onOk()
{
  if ( validateForm() )			
  {
	  win.document.getElementsByName('buttonClicked').item(0).value = 'ok';
	  win.document.getElementsByName('newPassword').item(0).value = document.getElementsByName('newPassword').item(0).value;
	  //win.document.getElementsByName('password').item(0).value = document.getElementsByName('newPassword').item(0).value;
	  win.document.getElementById('loginForm').submit();
	  window.close();
  }
  else
  {
	  document.getElementsByName('newpassword').item(0).focus();
  }	
}

function onCancel()
{
	win.document.getElementById('loginUsername').focus();
	window.close();
}

function validateForm()
{
	if( win.document.getElementsByName('password').item(0).value != document.getElementsByName('oldPassword').item(0).value)
	{
		document.getElementById('popupErrors').innerHTML = win.document.getElementsByName('wrong_password_msg').item(0).value;
	   return false;
	}
	else if ( isEmpty ( 'newPassword' ) )
	{    
		document.getElementById('popupErrors').innerHTML = win.document.getElementsByName('password_req_msg').item(0).value;
		return false;
	} 
	else if (document.getElementsByName('confirmPassword').item(0).value != document.getElementsByName('newPassword').item(0).value )
	{
		document.getElementById('popupErrors').innerHTML = win.document.getElementsByName('passwordMatch_req_msg').item(0).value;
		return false;
	}
	return true;
}