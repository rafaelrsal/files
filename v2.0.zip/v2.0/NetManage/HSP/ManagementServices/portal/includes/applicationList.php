<?php
ini_set("include_path", ".;includes/pear;includes/xmlparser" );
require_once('Portal/includes/portalUser.php');
require_once('includes/classes/PearDB.php');
require_once('includes/global_require.php');
require_once('Portal/includes/dbConnection.php');

define("ONWEB_RULE", "?ONWEB_InfoRule=_HSP.LaunchApp(_ONWEB_CGIDATA_)&appName=");

	function getApplicationList( &$htmlApplication,  &$mobileApplications )
  	{
  		$db = new dbConnection();
  		
  		$appData = populateApplicationData( $db->getDb() , $_SESSION['megredList'] );
		createApplications( $db->getDb() , $appData, $htmlApplication,  $mobileApplications );
  	}
	
	function populateApplicationData( $db , $nodeIds )	
	{	
		$applicationTreeData = array();
		
		$sql = "SELECT * FROM " . TABLE_TREE .";";
		$tree = $db->GetAllEx( $sql, null, DB_FETCHMODE_ASSOC );
		if ( isset($tree[0]) )
		{	
			foreach ( $nodeIds as $nodeId )
			{
				foreach ( $tree as $treeNode )
				{
					if ( $treeNode['id'] == $nodeId )
					{
						$applicationTreeData[$nodeId] = $treeNode;
						break;						
					}
				}
			}
			
			$tmpArr = $nodeIds;							
			
			for ( $i = 0 ; $i < count($tmpArr) ; $i++ )
			{								
				foreach ( $tree as $treeNode )
				{
					if ( $treeNode['parent_id'] == $tmpArr[$i] )
					{
						$applicationTreeData[$treeNode['id']] = $treeNode;
						$tmpArr[] = $treeNode['id'];
					}
				}
			}
		}

		return $applicationTreeData;
	}

	function getApplicationData( $db , $applicationID, $applicationType )
	{
		$sql = null;
		$res = null;
		
		if ( 'url' == $applicationType )
		{
			$sql =   "SELECT * FROM " . TABLE_APPS_LINKS . " WHERE appID=$applicationID;";
		}
		elseif ( 'onWeb' == $applicationType )
		{
			$sql =   "SELECT * FROM " . TABLE_APPS_ONWEB . " WHERE appID=$applicationID;";
		}
		
		if ( !is_null( $sql ) )
		{
			$res = $db->GetAllEx( $sql, null, DB_FETCHMODE_ASSOC );
		}
		
		return $res;	
	}
	
	function createApplications( $db, $applicationTreeData, &$htmlApplication,  &$mobileApplications )
	{
		$userObj = $_SESSION['userObject'];	
		$app = null;
		
		foreach( $applicationTreeData as $appID=>$application )
		{
			if ( $application['mobile'] )
			{			
				if ( $application['application'] != null )
				{
					$result = getApplicationData( $db, $application['appID'] , $application['application'] );
					
					if ( 'url' == $application['application'] )
					{
						$app = $result[0]['url'];
				
						if(1 == $result[0]['parameterized'])
						{
							// Get user params and values:
							$userID = $userObj->getUserId();
							$sql = "SELECT paramName,paramValue FROM ".TABLE_USER_PARAMETER." WHERE userID=$userID;";
							$arrParamVal = $db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
							if(is_array($arrParamVal) && count($arrParamVal)>0)
							{
								// The URL expects paramters, parse according to user pramters:
				 				$app = parseParamters($app, $arrParamVal);			
							}
							else
							{
								// Cannot run the url: should we present a message or leave to the dogs?
							} 
						}
						
						if ( isset($result[0]['mobileApp']) && $result[0]['mobileApp'] == true )
						{
							$mobileApplications .= "&nbsp<a href='$app'>{$application['text']}</a><br>";
						}
						else
						{
							$htmlApplication .= "&nbsp<a href='$app'>{$application['text']}</a><br>";
						}
					}
					elseif( 'onWeb' == $application['application'] )	
					{
						$hostURL = $result[0]['hostURL'];
						$rule = ONWEB_RULE.$result[0]['name'];
						$userNameParm = "&HSPUser=".$userObj->getUsername();
						$appURLParm = $result[0]['appURL'].'&';
						
						// Should look like the following:
						// |---------------------------$hostURL----------------------------------------------|-$userNameParm-|----$appURLParm------|
						// http://OnWebIP:port/?ONWEB_InfoRule=_HSP.LaunchApp(_ONWEB_CGIDATA_)&appName=myHPApp&HSPUser=testusr&startPage=myHPApp.htm&
						$assembliedApp = $hostURL.$rule.$userNameParm.$appURLParm;
						
						$htmlApplication .= "&nbsp<a href='$assembliedApp'>{$application['text']}</a><br>";
						
					}		
				}
			}			
		}
	}
?>
