<?PHP
define('TXT_MAIN' , 'Bem vindo ao Portal de Acesso Externo aos Hosts');
?>