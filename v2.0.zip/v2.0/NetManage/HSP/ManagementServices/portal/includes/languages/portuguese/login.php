<?PHP
define('INDEX_TITLE' , 'Acesso aos Hosts - Portal do Usu�rio');
define('STATUS_BAR' , 'MicroFocus - Host Services Plataform' );
define('INDEX_HSP_CLOSE','Fechando Host Services Plataform');

define('WELCOME_TXT','Bem vindo ao Portal Corporativo de Acesso Externo aos Hosts');

define('LOGIN_INSTRUCTIONS_LABEL','Entre com seu usu�rio e senha');
define('USERNAME_LABEL','Usu�rio:');
define('PASSWORD_LABEL','Senha:');
define('DIRECTORY_LABEL','Autenticar em:');
define('LOGIN_LABEL_BTN','Logon');

define('ERR_NO_USER','N�o foi poss�vel encontrar o usu�rio no database do HSP.');
define('ERR_USER_NOT_DEFINED','Usu�rio n�o definido no database do HSP.');
define('ERR_NO_TREE_DEFINED','N�o existem aplica��es definidas para este usu�rio.');
define('ERR_USERNAME_REQ','Campo Usu�rio requerido!');
define('ERR_PASSWORD_REQ','Campo Senha requerido!');
define('ERR_AUTH_FAILED','Falha na autentica��o de diret�rio.');
define('ERR_DB_ERROR','Erro no Database.');
define('ERR_USER_ALREADY_LOGGEDIN','Voc� j� est� autenticado neste diret�rio.');

define('REMEMBER_PASSWORD_LBL', 'Relembre minha senha');
define('NEW_PASSWORD', 'Nova senha');
define('CONFIRM_PASSWORD', 'Confirme a senha');
define('PASSWORD_REQ_MSG', 'Senha requerida');
define('WRONG_PASSWORD', 'Senha errada');
define('PASSWOR_DO_NOT_MATCH', 'Confirma��o de senha deve corresponder a senha');
define('ACCOUNT_IS_DISABLED', 'Conta desabilitada');
define('CHANGE_PASS_LBL', 'Altere a senha');
define('OLD_PASSWORD', 'Senha');
define('OK_LBL', 'Ok');
define('CANCEL_LBL', 'Cancelar');
define('REQUIRED_FIELD_TXT','verifique os campos obrigat�rios');
define('LOGOUT_REFRESH_MESSAGE','Pressionando OK todas as suas sess�es ser�o fechadas.\n\nPara sair normalmente, pressione Cancel, ent�o efetue o logout e feche o browser.');
?>