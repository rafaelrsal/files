<?PHP
// Global entries for the <html> tag
define('HTML_PARAMS','dir="LTR" lang="pt"');
// charset for web pages and emails
define('CHARSET', 'ISO-8859-1');
define('PORTUGUESE','Portuguese');
?>