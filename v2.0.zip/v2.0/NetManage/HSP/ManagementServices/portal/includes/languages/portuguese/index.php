<?PHP
define('INDEX_TITLE' , 'Ita� Unibanco - Portal do Usu�rio');
define('STATUS_BAR' , 'Micro Focus - Host Services Platform' );
define('INDEX_HSP_CLOSE','Fechando HSP');
?>