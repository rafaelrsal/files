<?PHP
define('BOX_TITLE_TREEMENU','Main Menu');
define('MENUITEM_SETTINGS','Settings');
define('MENUITEM_DATABASE','Database');
define('MENUITEM_IMPORTEXPORT','Database Import/Export');
define('MENUITEM_SYSTEM_DIRECTORIES','System Directories');
define('MENUITEM_LDAP','LDAP');
define('MENUITEM_NT_DOMAIN','NT Domain');
define('MENUITEM_MONITORING','Monitoring and Logging');
define('MENUITEM_CONFIGURATION','Configuration');
define('MENUITEM_REPORTS','Reports');
define('MENUITEM_USER_MANAGE','User Management');
define('MENUITEM_GROUPS','Groups');
define('MENUITEM_USERS','Users');
define('MENUITEM_ASSOC_APPLICATIONS','Associate Applications');
define('MENUITEM_PORTAL','Portal');
define('MENUITEM_APPLICATION_MANAGMENT','Application Management');
define('MENUITEM_APPLICATIONS','Applications');
define('MENUITEM_APPLICATIONS_TREE','Application Tree');
define('MENUITEM_HELP','Help');
define('MENUITEM_HELP_TOC','Table of Contents');

define('BOX_TITLE_TREEMENU_TEXT','Main Menu');
define('MENUITEM_SETTINGS_TEXT','Settings');
define('MENUITEM_DATABASE_TEXT','Database');
define('MENUITEM_IMPORTEXPORT_TEXT','Database Import/Export');
define('MENUITEM_SYSTEM_DIRECTORIES_TEXT','System Directories');
define('MENUITEM_LDAP_TEXT','LDAP');
define('MENUITEM_NT_DOMAIN_TEXT','NT Domain');
define('MENUITEM_MONITORING_TEXT','Monitoring and Logging');
define('MENUITEM_CONFIGURATION_TEXT','Configuration');
define('MENUITEM_REPORTS_TEXT','Reports');
define('MENUITEM_USER_MANAGE_TEXT','User Management');
define('MENUITEM_GROUPS_TEXT','Groups');
define('MENUITEM_USERS_TEXT','Users');
define('MENUITEM_ASSOC_APPLICATIONS_TEXT','Associate Applications');
define('MENUITEM_PORTAL_TEXT','Portal');
define('MENUITEM_APPLICATION_MANAGMENT_TEXT','Application Management');
define('MENUITEM_APPLICATIONS_TEXT','Applications');
define('MENUITEM_APPLICATIONS_TREE_TEXT','Application Tree');
define('MENUITEM_HELP_TEXT','Help');
define('MENUITEM_HELP_TOC_TEXT','Table of Contents');

?>
