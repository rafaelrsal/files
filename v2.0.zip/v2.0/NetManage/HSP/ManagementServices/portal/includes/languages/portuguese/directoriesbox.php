<?PHP
define('BOX_TITLE_DIRECTORIES','Diret�rios');
define('LDAP_LINK','LDAP & AD')
?>