<?PHP
	define('TXT_FOOTER1' , 'HSP Project');
	define('TXT_FOOTER2' , 'Host Services Platform Administrator');
?>