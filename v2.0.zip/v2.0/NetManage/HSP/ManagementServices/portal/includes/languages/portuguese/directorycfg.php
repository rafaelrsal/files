<?PHP
define('TXT_MAIN' , 'P�gina de Configura��o de Diret�rio');
define('LBL_DIR_LIST' , 'Lista de Diret�rios');
define('LBL_NAME','Nome');
define('LBL_HOST','Host');
define('LBL_PORT','Porta');
define('LBL_USERNAME','Nome do Usu�rio');
define('LBL_PASSWORD','Senha');
define('LBL_USERS_DN','Usu�rio DN');
define('LBL_USER_OBJ_ATTR','Attributo OBJ do Usu�rio');
define('LBL_GROUPS_DN','Grupos DN');
define('LBL_GROUP_OBJ_ATTR','Attributo OBJ do Grupo');
define('BTN_ADD','Adicionar');
define('BTN_REMOVE','Remover');
define('BTN_EDIT','Editar');
define('BTN_NEW','Novo');
define('BTN_APPLY','Aplicar');
define('BTN_CANCEL','Cancelar');
define('BTN_TEST','Testar');
?>