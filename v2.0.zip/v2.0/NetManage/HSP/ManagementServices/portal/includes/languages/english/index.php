<?PHP
define('INDEX_TITLE' , 'HSP - User Portal');
define('STATUS_BAR' , 'NetManage - Host Services Platform' );
define('INDEX_HSP_CLOSE','Closing HSP');
?>