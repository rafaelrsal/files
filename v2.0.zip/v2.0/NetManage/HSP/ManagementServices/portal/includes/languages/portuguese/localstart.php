<?php
define('LOCALSTART_TXT','Precione Iniciar para baixar o portal para o seu computador.');
?>