<?PHP
	define('TXT_FOOTER1' , 'Projeto HSP');
	define('TXT_FOOTER2' , 'Plataforma de Administra��o de Acesso aos Hosts');
?>