<?PHP
define('TXT_MAIN' , 'Welcome to Host Services Platform Administrator');
?>