<?PHP

	//Header - start
	define('TXT_HEADER1' , 'HSP LAP Project');
	define('TXT_HEADER2' , 'Plataforma de Administra��o do Acesso aos Hosts');
	//Header - end

	//Footer - start
	define('TXT_FOOTER1' , 'HSP LAP Project');
	define('TXT_FOOTER2' , 'Plataforma de Administra��o do Acesso aos Hosts');
	//Footer - end
?>