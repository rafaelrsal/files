<?PHP
	define('TXT_HEADER1' , 'Projeto HSP');
	define('TXT_HEADER2' , 'Plataforma de Administra��o do Acesso aos Hosts');
?>