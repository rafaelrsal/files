<?PHP

	//Header - start
	define('TXT_HEADER1' , 'HSP LAP Project');
	define('TXT_HEADER2' , 'Host Services Platform Administrator');
	//Header - end

	//Footer - start
	define('TXT_FOOTER1' , 'HSP LAP Project');
	define('TXT_FOOTER2' , 'Host Services Platform Administrator');
	//Footer - end
?>