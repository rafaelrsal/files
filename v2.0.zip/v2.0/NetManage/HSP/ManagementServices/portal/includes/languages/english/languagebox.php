<?PHP
define('BOX_TITLE_LANGUAGES','Language');
define('GO_BTN','Go');
?>