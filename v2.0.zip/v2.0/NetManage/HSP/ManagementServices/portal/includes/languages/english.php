<?PHP
// Global entries for the <html> tag
define('HTML_PARAMS','dir="LTR" lang="en"');
// charset for web pages and emails
define('CHARSET', 'iso-8859-1');
define('ENGLISH','English');
?>