<?PHP
define('BOX_TITLE_TREEMENU','Menu Principal');
define('MENUITEM_SETTINGS','Configura��es');
define('MENUITEM_DATABASE','Database');
define('MENUITEM_IMPORTEXPORT','Importa��o/Exporta��o de Database');
define('MENUITEM_SYSTEM_DIRECTORIES','Sistema de Diret�rios');
define('MENUITEM_LDAP','LDAP');
define('MENUITEM_NT_DOMAIN','NT Domain');
define('MENUITEM_MONITORING','Monitoramento e Registro');
define('MENUITEM_CONFIGURATION','Configura��o');
define('MENUITEM_REPORTS','Relat�rios');
define('MENUITEM_USER_MANAGE','Gerenciamento de Usu�rio');
define('MENUITEM_GROUPS','Grupos');
define('MENUITEM_USERS','Usu�rios');
define('MENUITEM_ASSOC_APPLICATIONS','Aplica��es Associadas');
define('MENUITEM_PORTAL','Portal');
define('MENUITEM_APPLICATION_MANAGMENT','Gerenciamento de Aplica��es');
define('MENUITEM_APPLICATIONS','Aplica��es');
define('MENUITEM_APPLICATIONS_TREE','�rvore de Aplica��es');
define('MENUITEM_HELP','Ajuda');
define('MENUITEM_HELP_TOC','Tabela de Conte�do');

define('BOX_TITLE_TREEMENU_TEXT','Menu Principal');
define('MENUITEM_SETTINGS_TEXT','Configura��es');
define('MENUITEM_DATABASE_TEXT','Database');
define('MENUITEM_IMPORTEXPORT_TEXT','Importa��o/Exporta��o de Database');
define('MENUITEM_SYSTEM_DIRECTORIES_TEXT','Sistema de Diret�rios');
define('MENUITEM_LDAP_TEXT','LDAP');
define('MENUITEM_NT_DOMAIN_TEXT','NT Domain');
define('MENUITEM_MONITORING_TEXT','Monitoramento e Registro');
define('MENUITEM_CONFIGURATION_TEXT','Configura��o');
define('MENUITEM_REPORTS_TEXT','Relat�rios');
define('MENUITEM_USER_MANAGE_TEXT','Gerenciamento de Usu�rio');
define('MENUITEM_GROUPS_TEXT','Grupos');
define('MENUITEM_USERS_TEXT','Usu�rios');
define('MENUITEM_ASSOC_APPLICATIONS_TEXT','Aplica��es Associadas');
define('MENUITEM_PORTAL_TEXT','Portal');
define('MENUITEM_APPLICATION_MANAGMENT_TEXT','Gerenciamento de Aplica��es');
define('MENUITEM_APPLICATIONS_TEXT','Aplica��es');
define('MENUITEM_APPLICATIONS_TREE_TEXT','�rvore de Aplica��es');
define('MENUITEM_HELP_TEXT','Ajuda');
define('MENUITEM_HELP_TOC_TEXT','Tabela de Conte�do');

?>
