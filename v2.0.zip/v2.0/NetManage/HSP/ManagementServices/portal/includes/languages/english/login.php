<?PHP
define('INDEX_TITLE' , 'HSP - User Portal');
define('STATUS_BAR' , 'NetManage - Host Services Platform' );
define('INDEX_HSP_CLOSE','Closing HSP');

define('WELCOME_TXT','Welcome to Host Services Platform');

define('LOGIN_INSTRUCTIONS_LABEL','Enter your user name and password');
define('USERNAME_LABEL','User name:');
define('PASSWORD_LABEL','Password:');
define('DIRECTORY_LABEL','Log on to:');
define('LOGIN_LABEL_BTN','Logon');

define('ERR_NO_USER','Could not find user in HSP database.');
define('ERR_USER_NOT_DEFINED','User is not defined in HSP database.');
define('ERR_NO_TREE_DEFINED','No applications are defined for this user.');
define('ERR_USERNAME_REQ','Username field is required!');
define('ERR_PASSWORD_REQ','Password field is required!');
define('ERR_AUTH_FAILED','Directory authentication failed.');
define('ERR_DB_ERROR','Database Error.');
define('ERR_USER_ALREADY_LOGGEDIN','You are already logged on to this directory.');

define('REMEMBER_PASSWORD_LBL', 'Remember my password');
define('NEW_PASSWORD', 'New password');
define('CONFIRM_PASSWORD', 'Confirm password');
define('PASSWORD_REQ_MSG', 'Password  is required');
define('WRONG_PASSWORD', 'Wrong Password');
define('PASSWOR_DO_NOT_MATCH', 'Confirm password must match password');
define('ACCOUNT_IS_DISABLED', 'Account is disabled');
define('CHANGE_PASS_LBL', 'Change password');
define('OLD_PASSWORD', 'Password');
define('OK_LBL', 'Ok');
define('CANCEL_LBL', 'Cancel');
define('REQUIRED_FIELD_TXT','denotes required field');
define('LOGOUT_REFRESH_MESSAGE','Pressing OK will close all your sessions.\n\nTo log out normally, press Cancel, then logout and close the browser.');
?>