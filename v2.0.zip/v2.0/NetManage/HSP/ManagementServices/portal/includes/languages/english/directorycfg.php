<?PHP
define('TXT_MAIN' , 'Directory Configuration page');
define('LBL_DIR_LIST' , 'Directory List');
define('LBL_NAME','Name');
define('LBL_HOST','Host');
define('LBL_PORT','Port');
define('LBL_USERNAME','User name');
define('LBL_PASSWORD','Password');
define('LBL_USERS_DN','Users DN');
define('LBL_USER_OBJ_ATTR','User OBJ Attr');
define('LBL_GROUPS_DN','Groups DN');
define('LBL_GROUP_OBJ_ATTR','Group OBJ Attr');
define('BTN_ADD','Add');
define('BTN_REMOVE','Remove');
define('BTN_EDIT','Edit');
define('BTN_NEW','New');
define('BTN_APPLY','Apply');
define('BTN_CANCEL','Cancel');
define('BTN_TEST','Test');
?>