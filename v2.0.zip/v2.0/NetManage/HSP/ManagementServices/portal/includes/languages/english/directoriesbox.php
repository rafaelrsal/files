<?PHP
define('BOX_TITLE_DIRECTORIES','Directories');
define('LDAP_LINK','LDAP & AD')
?>