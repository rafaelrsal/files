<?php
define('LOCALSTART_TXT','Click Start to download the portal to your computer.');
?>