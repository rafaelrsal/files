<?PHP
define('BOX_TITLE_LANGUAGES','Languagem');
define('GO_BTN','Ir');
?>