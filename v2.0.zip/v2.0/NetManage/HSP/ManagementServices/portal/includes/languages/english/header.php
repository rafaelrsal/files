<?PHP
	define('TXT_HEADER1' , 'HSP Project');
	define('TXT_HEADER2' , 'Host Services Platform Administrator');
?>