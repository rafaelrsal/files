<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.  
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit  					
  Date Created: Mars 2004
  Title: global_defines.php
  Purpose: Responsible for building trees for HSP users.
  Limitations: Requires PHP 4.3.4 and up.
 
 ============================================================================*/

include_once ("includes/LMenu/lib/PHPLIB.php");
include_once ("includes/LMenu/lib/layersmenu-common.inc.php");
include_once ("includes/LMenu/lib/treemenu.inc.php");
require_once ("includes/classes/LMenu.php");

/**
* Creating a user applications tree.
* @param object $databse reference to PEARDB object.
* @param array $megredList Containing groups names and IDs
* @param int $userID The user ID for whom we build the tree
* @param int $userName The user name for whom we build the tree
* @param str $strTree In-Out string for containg the string that represents the tree
* @access public
* @return error code
*/
function buildMergedUserTree($megredList, $userID, $userName, &$strTree)
{
	$arrLists = array();
	$arrResultList = array();
	$strNames = "";
	$strIDs = "";
	
	$db = DBConnection();
	
	if (null == $db)
	{
		return HSP_ERR_DB_CONNECT_ERROR;			
	}
	
	// Get all groups names and ids:
	$arrEntries = array_values($megredList);
	
	foreach($megredList as $arrEntry)
	{
		$strNames .= ("\"".$arrEntry[0]."\",");
		$strIDs .= ($arrEntry[1].",");
	}

	if(null != $userID)
	{
		// Add the user entry to the list, we need to see if he has got a UAT:
		$strNames .= "\"".$userName."\"";
		$strIDs .= $userID;
	}
	else 
	{
		// Get rid of the last comma:
		$strNames = rtrim($strNames, ",");
		$strIDs = rtrim($strIDs, ",");
	}
		
	
	$arrLists = $db->GetAllEx("SELECT nodeList FROM ".TABLE_GAT_UAT." WHERE id IN ($strIDs) AND name IN ($strNames);");

	if($arrLists != null)
	{
		for($i=0; $i<count($arrLists); ++$i)
		{
			$arrList = explode(",", $arrLists[$i][0]);
			foreach($arrList as $node)
			{
				if(!array_key_exists($node, $arrResultList))
					$arrResultList[$node] = true;
			}
		}
	}
	else
		return HSP_ERR_DB_ERROR;
		
	$arrFinal = array_keys($arrResultList);
	
	// Build the menu:
	$mid = new TreeMenu();		
	$mid->setImgwww("includes/LMenu/images/"); // allowing different icons.
	$mid->setImgdir("includes/LMenu/images/");
	$mid->setLibjsdir("includes/LMenu/libjs/");
	$mid->setDBConnParms($db->getDSNasString());
	$mid->setTableName("hsp_tree");		
	$mid->scanTableForMenu("merged_tree","","cut", $arrFinal);

	// This is the final html of the user tree:
	$strTree = $mid->newTreeMenu("merged_tree");
	
	return HSP_SUCCESS;

} 
 
function DBConnection()
{
	$database = null;
	$dbconfig = new DBConfig();
	$dbconfig->init();
	$errCode = $dbconfig->DBDeserialize();
	
	if($errCode != 0)
	{
		return null;
	}			
	else
	{
		$database = new PearDB();
		$database->SetDSNArray($dbconfig->getDBData());			
		$ret = $database->Connect();
		if ( $ret != 0 )
		{ 
			return null;
		}			
	}
	
	return $database;
} 

function getMergedGroupList($userGroups, $hspGroups, &$megredList)
{
	$megredList = array();
	foreach($hspGroups as $group)
	{
		if (in_array($group[0], $userGroups))
		{
			$megredList[] = $group;
		}
	}
}
?>