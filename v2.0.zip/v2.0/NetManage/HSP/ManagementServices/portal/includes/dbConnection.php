<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Jan 2005
  Title: dbConnection.php
  Purpose: user portal login functions and handling.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
require_once('includes/global_require.php');
require_once('includes/classes/DBConfig.php');
require_once('includes/classes/PearDB.php');
 
class dbConnection
{
	var $m_db;
	
	function dbConnection()
	{		
		$dbconfig = new DBConfig();
		$dbconfig->init();
		$dbconfig->DBDeserialize();
	
		$this->m_db = new PearDB();
		$this->m_db->SetDSNArray($dbconfig->getDBData());
		//$this->m_db->SetDSN('mysql','root','root','localhost','hsp232',$port=false,$dbsyntax=false,$protocol=false,$socket=false);
		if ( $this->connect() != HSP_SUCCESS )
		{
			$this->m_db = null;
		}
	}

	function connect()
	{
		if ($this->m_db != null)
		{
			return $this->m_db->Connect();
		}
	}
	
	function getDb()
	{
		return $this->m_db;
	}
	
}
?>