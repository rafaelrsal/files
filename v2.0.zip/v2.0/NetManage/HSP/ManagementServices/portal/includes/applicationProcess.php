<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Jan 2005
  Title: applicationProcess.php
  Purpose: user portal login functions and handling.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/

class applicationProcess
{
	var $m_db;
	var $m_portalUserObj;
	
	function applicationProcess( $db , &$portalUserObj )
	{
		$this->m_db = $db->getDb();		
		$this->m_portalUserObj = &$portalUserObj;		
	} 
 
 	function authenticate()
	{
		if ( !$this->m_portalUserObj->isAnonymous() )
		{
			$dirDetails = $this->m_portalUserObj->getDirectoryDetails();		
			
			if ( !is_null( $dirDetails['customDirId'] ))
			{ // custom directory
				if(!extension_loaded('HSPSecurModule'))
				{
		            dl('php_HSPSecurModule.dll');
				}
		
				$sql = "SELECT * FROM ". TABLE_CUSTOM_USERS." WHERE dirId=". $dirDetails['customDirId'] ." AND name=\"".$this->m_portalUserObj->getUsername()."\";";
				$recSet = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC );
				if ( DB::isError($recSet) ) 
				{
					return HSP_ERR_DB_SQL_ERROR;
				}
				
				if ( is_array($recSet) && count($recSet) && decrypt_str($recSet[0]['password']) == $this->m_portalUserObj->getPassword() )
				{	
					$this->m_portalUserObj->setCustomUserDetails($recSet[0]['id'], 
																 $recSet[0]['fullName'],
																 $recSet[0]['changePassword'],
																 $recSet[0]['disabled'],
																 $recSet[0]['cannotChangePassword'],
																 $recSet[0]['dirID']
																 );
					
					$this->m_portalUserObj->setAuthenticatedStatus(true);
					return true;
				}
				$this->m_portalUserObj->setAuthenticatedStatus(false);
				return false;
				
			}
			else
			{ // domain
				if(!extension_loaded('PhPAuthModule'))
				{
					dl('php_PhPAuthModule.dll');
				}

				$auth = authenticateuser(	$this->m_portalUserObj->getUsername(),
											$this->m_portalUserObj->getPassword(),
											$dirDetails['host'],
											$dirDetails['host'],
											$dirDetails['type_dir'],
											$dirDetails['port'],
											$dirDetails['base_dn'],
											$dirDetails['group_dn'] ,
											$dirDetails['user_dn'],
											$dirDetails['ldap_user_identifier']);
				if ( $auth )
				{
					$this->m_portalUserObj->setAuthenticatedStatus(true);
					return true;
				}
				$this->m_portalUserObj->setAuthenticatedStatus(false);
				return false;
			}
		}
		
		return true; // anon user always authenticated
		
	}
	
	
	function getCustomUserGroups()
	{
		$userDetails = $this->m_portalUserObj->getCustomUserDetails();
		
		if (isset($userDetails['id']))
		{		
			$names = array();
			$sql = 	"SELECT " . TABLE_CUSTOM_GROUPS . ".name FROM " . TABLE_CUSTOM_GROUPS . ", " . TABLE_CUSTOM_CROSS . 
					" WHERE " . TABLE_CUSTOM_GROUPS . ".id = ".TABLE_CUSTOM_CROSS.".groupId and " . 
					TABLE_CUSTOM_CROSS . ".userId=" . $userDetails['id'];
				
			$recSet = $this->m_db->GetAllEx($sql,null,DB_FETCHMODE_ASSOC);
			
			if ( DB::isError($recSet) )
			{
				return HSP_ERR_DB_SQL_ERROR;				
			}
			
			if ( is_array($recSet) && count($recSet) )
			{				
				foreach ($recSet as $record )
				{
					$names[] = $record['name'];
				}
			}
			return $names;		
		}
		return false;
		
	}
		
		
	function getDirectoryGroups()
	{
		if(!extension_loaded('PhPAuthModule'))
		{
			dl('php_PhPAuthModule.dll');
		}

		$details = $this->m_portalUserObj->getDirectoryDetails();
		return getusergroups( 	$this->m_portalUserObj->getUsername(),
								$this->m_portalUserObj->getPassword(),
								$details['host'],
								$details['host'],
								$details['type_dir'],
								$details['port'],
								$details['base_dn'],
								$details['group_dn'] ,
								$details['user_dn'],
								$details['ldap_user_identifier']);

	}
		
	function getImportedGroups()
	{		
		$details = $this->m_portalUserObj->getDirectoryDetails();
		$hspGroups = $this->m_db->GetAllEx("SELECT name, id, style, localstart FROM ".TABLE_GROUPS." WHERE dirID=" . $details['id'], null,DB_FETCHMODE_ASSOC );
		if ( DB::isError($hspGroups) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		return $hspGroups;
	}
	
	function getMergedGroupList( $userGroups )
	{
		$megredList = null;
		$hspGroups = $this->getImportedGroups();
		if ( $hspGroups == HSP_ERR_DB_SQL_ERROR )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		if ( is_array($userGroups) && is_array($hspGroups) && count($userGroups) && count($hspGroups) )
		{
			$megredList = array();
			$localstartEnabled = 0;
			
			foreach($hspGroups as $group)
			{
			
				if (in_array($group['name'], $userGroups))
				{
					$megredList[] = $group;
					$localstartEnabled |= $group['localstart'];
				}
			}
			if ( is_null( $this->m_portalUserObj->getUserStyle()) && count($megredList))
			{
				$this->m_portalUserObj->setUserStyle($megredList[0]['style']);
			}
			
			if ( ( $this->m_portalUserObj->getLocalstartState() == 0 || is_null($this->m_portalUserObj->getLocalstartState())) && count($megredList))
			{
				$this->m_portalUserObj->setLocalstartState( $localstartEnabled );
			}
		}
		
		if ( is_null( $this->m_portalUserObj->getUserStyle() ) )
		{
			$this->m_portalUserObj->setUserStyle('default');
		}
		
		return $megredList;
	}
	
	function buildUserTree( $megredList=null )
	{		
		$arrLists = array();
		$arrResultList = array();
		$strNames = "";
		$strIDs = "";
		
		if ( !is_null($megredList) )
		{	
			$arrEntries = array_values($megredList);
			foreach($megredList as $arrEntry)
			{
				$strNames .= ("\"".$arrEntry['name']."\",");
				$strIDs .= ($arrEntry['id'].",");
			}
		}
				
		$userId = $this->m_portalUserObj->getUserId();
		if( !is_null($userId) )
		{
			// Add the user entry to the list, we need to see if he has got a UAT:
			$strNames .= "\"".$this->m_portalUserObj->getUsername()."\"";
			$strIDs .= $userId;
		}
		else 
		{
			// Get rid of the last comma:
			$strNames = rtrim($strNames, ",");
			$strIDs = rtrim($strIDs, ",");
		}
			
		if ( strlen($strNames) )
		{
			$arrLists = $this->m_db->GetAllEx("SELECT nodeList FROM ".TABLE_GAT_UAT." WHERE id IN ($strIDs) AND name IN ($strNames);");

			if ( DB::isError($arrLists) )
			{
				return HSP_ERR_DB_SQL_ERROR;
			}
		}
		
		if( is_array($arrLists) )
		{
			for($i=0; $i<count($arrLists); ++$i)
			{
				$arrList = explode(",", $arrLists[$i][0]);
				foreach($arrList as $node)
				{
					if(!array_key_exists($node, $arrResultList))
						$arrResultList[$node] = true;
				}
			}
		}				
			
		return array_keys($arrResultList);
	}
	
	
	function getMergedNodeList( $userGroups = null )
	{
		$megredList = null;
		if ( !$this->m_portalUserObj->isAnonymous() )
		{
			if ( $userGroups == null )
			{
				$details = $this->m_portalUserObj->getDirectoryDetails();
				$bCustomDir = $details['customDirId'];
				if ( !is_null($bCustomDir) )
				{
					$userGroups =  $this->getCustomUserGroups();
				}
				else
				{
					$userGroups =  $this->getDirectoryGroups();
				}
			}
			
			if ( is_array($userGroups) && count($userGroups) )
			{
				$megredList = $this->getMergedGroupList($userGroups);
			}
		}
		
		return $megredList;
		
	}
	
	function buildLMenuTree( $appTreeNodes )
	{
		$mid = new TreeMenu();		
		$mid->setImgwww("includes/LMenu/images/"); // allowing different icons.
		$mid->setImgdir("includes/LMenu/images/");
		$mid->setLibjsdir("includes/LMenu/libjs/");
		$mid->setDBConnParms($this->m_db->getDSNasString());
		$mid->setTableName("hsp_tree");		
		$mid->scanTableForMenu("merged_tree","","cut", $appTreeNodes);
		
		// This is the final html of the user tree:
		return $mid->newTreeMenu("merged_tree");
	}
}
 
 
?>