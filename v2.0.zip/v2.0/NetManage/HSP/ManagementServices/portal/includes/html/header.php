<!-- HEADER - START -->
<TABLE border="0" cellspacing="0" cellpadding="0" bgcolor="#f57921" width="100%" height="30px">
	<TR>
		<TD align="left">			
		</TD>
		<TD align="right">
			<div id="lang">
				<a href='/hsp/?l=portuguese'>
					<img src='admin/includes/images/ico-pt.jpg'>
					<span>Portugu&ecirc;s</span>
				</a>
				<a href='/hsp/?l=english'>
					<img src='admin/includes/images/ico-en.jpg'>
					<span>English</span>
				</a>
			</div>
		</TD>
	</TR>
</TABLE>
<!-- HEADER - END -->