<?php
define('ANONYMOUS_USERNAME','anonymous');
define('USER_TYPE_USER','user');
define('USER_TYPE_ANONYMOUS','anonymous');
define('USER_TYPE_SSO','sso');



class portalUser
{
	var $m_userId;
	var $m_username;
	var $m_password;	
	var $m_dirDetails;	
	var $m_style;
	var $m_bCustomUser;
	var $m_customUserDetails;	
	var $m_authenticated; 	
	var $m_db;
	var $m_userType;
	var $m_localstart;
	
	function portalUser( $db, $userType=ANONYMOUS_USERNAME, $username=null, $password=null, $directoryId=null, $directoryName=null )
	{
		$this->m_dirDetails = array();		
		$this->m_authenticated = false;
		$this->m_style = 'default';
		$this->m_db = $db->getDb();
		$this->m_userType = $userType;
		
		if ( $userType == USER_TYPE_ANONYMOUS )
		{	
			$this->m_username = ANONYMOUS_USERNAME;
			$this->m_dirDetails['id'] = 0;
			$this->m_authenticated = true;
		}
		elseif ( $userType == USER_TYPE_USER )
		{			
			$this->m_username = $username;
			$this->m_password = $password;
			$this->m_dirDetails['id'] = $directoryId;
		}
		elseif ( $userType == USER_TYPE_SSO )
		{
			$this->m_username = $username;
			$this->m_password = $password;
			$this->m_authenticated = true;
			if ( !is_null( $directoryName ) )
			{
				$this->m_dirDetails['ssoname'] = $directoryName;
			}
		}
	}
	
	function getUserType()
	{
		return $this->m_userType;
	}
	
	function getUserId()	
	{
		return $this->m_userId;
	}
	
	function isAnonymous()
	{
		if ( $this->m_userType == USER_TYPE_ANONYMOUS )
		{
			return true;
		}
		
		return false;
	}	
	
	function isCustomUser()
	{
		return $this->m_bCustomUser;
	}
		
	function getUsername()
	{
		return $this->m_username;			
	}
	
	function getPassword()
	{
		return $this->m_password;
	}
	
	function getDirectoryDetails()
	{		
		return $this->m_dirDetails;
	}	
	
	function getCustomUserDetails()
	{
		return $this->m_customUserDetails;
	}
	
	function getUserStyle()
	{	
		return $this->m_style;
	}
	
	function setUserStyle( $style )
	{
		$this->m_style = $style;
	}
	
	function getIsAccountDisabled()
	{		
		return $this->m_customUserDetails['accountDisabled'];
	}
	
	function getCannotChangePassword()
	{		
		return $this->m_customUserDetails['cannotChangePassword'];
	}
	
	function getChangePassword()
	{
		return $this->m_customUserDetails['changePassword'];
	}
	
	function getCustomDirId()
	{
		return $this->m_customUserDetails['customDirId'];
	}
	
	function getFullName()
	{
		return $this->m_customUserDetails['fullName'];
	}
	
	function getLocalstartState()
	{
		return $this->m_localstart;
	}

	function setCustomUserDetails( $userId, $fullName, $changePass, $accountDisabled, $cannotChangePassword, $customDirId )
	{
		$this->m_customUserDetails = array();
		$this->m_customUserDetails['id'] = $userId;		
		$this->m_customUserDetails['fullName'] = $fullName;
		$this->m_customUserDetails['customDirId'] = $customDirId;
		$this->m_customUserDetails['changePassword'] = $changePass;
		$this->m_customUserDetails['accountDisabled'] = $accountDisabled;
		$this->m_customUserDetails['cannotChangePassword'] = $cannotChangePassword;
	}
	
	
	function getDirDetailsFromDB()
	{	
		if ( $this->m_userType == USER_TYPE_USER )
		{
			$sql = "SELECT * FROM ". TABLE_DIRECTORIES." WHERE id=". $this->m_dirDetails['id'] .";";
		}
		elseif ( $this->m_userType == USER_TYPE_SSO )
		{
			$sql = "SELECT * FROM ". TABLE_DIRECTORIES." WHERE ssoname='". $this->m_dirDetails['ssoname'] ."';";
		}
				
		
		$recSet = $this->m_db->GetAllEx($sql,null,DB_FETCHMODE_ASSOC);
		
		if ( DB::isError($recSet) )		
		{
			return HSP_ERR_DB_SQL_ERROR;
		}		
		elseif ( !count($recSet) )
		{
			return HSP_ERR_EMPTY_DIR_LIST;
		}
		
		
		$this->m_dirDetails['id'] 					= $recSet[0]['id'];
		$this->m_dirDetails['ssoname'] 				= $recSet[0]['ssoname'];
		$this->m_dirDetails['host'] 				= $recSet[0]['host'];
		$this->m_dirDetails['type_dir'] 			= $recSet[0]['type_dir'];
		$this->m_dirDetails['port'] 				= $recSet[0]['port'];
		$this->m_dirDetails['base_dn'] 				= $recSet[0]['base_dn'];
		$this->m_dirDetails['group_dn'] 			= $recSet[0]['group_dn'];
		$this->m_dirDetails['user_dn'] 				= $recSet[0]['user_dn'];
		$this->m_dirDetails['ldap_user_identifier'] = $recSet[0]['ldap_user_identifier'];
		$this->m_dirDetails['customDirId'] 			= $recSet[0]['customDirId'];
		$this->m_dirDetails['display_name'] 		= $recSet[0]['display_name'];
		
		if ( !is_null($this->m_dirDetails['customDirId']))
		{
			$this->m_bCustomUser = true;
		}
		else 
		{
			$this->m_bCustomUser = false;
		}
		
		return HSP_SUCCESS;
	}	
	
	function updatePassword( $newPassword )
	{
		if(!extension_loaded('HSPSecurModule'))
		{
	        dl('php_HSPSecurModule.dll');
		}
		
		$dirId = $this->m_dirDetails['customDirId'];
		
		$fields_values = array( 'password' =>encrypt_str($newPassword),
								'changePassword' =>0);
								
		$ret = $this->m_db->AutoExecute(TABLE_CUSTOM_USERS, $fields_values, DB_AUTOQUERY_UPDATE, "dirID=$dirId AND name=\"$this->m_username\";");
		
		if ( HSP_SUCCESS != $ret)
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		$this->m_password = $newPassword;
		return HSP_SUCCESS;
		
	}
	
	function getUserInfoFromDB()
	{			
		$this->m_userId = null;
		$this->m_style = null;
		$this->m_localstart = null;
		$sql = "SELECT id,style, localstart FROM ".TABLE_USERS." WHERE dirID=".$this->m_dirDetails['id']." AND name=\"".$this->m_username."\";";
		$ret = $this->m_db->getAllEx( $sql,null, DB_FETCHMODE_ASSOC );
		
		if ( DB::isError($ret) )
		{
			return HSP_ERR_DB_SQL_ERROR;
		}
		
		if ( count($ret) )
		{
			$this->m_userId = $ret[0]['id'];
			$this->m_style = $ret[0]['style'];
			$this->m_localstart = $ret[0]['localstart'];
			/*if ( empty($this->m_style) )
			{
				$this->m_style = 'default';
			}	
			*/
		}
		
		return HSP_SUCCESS;
	
	}
	
	function isAuthenticated()
	{
		return $this->m_authenticated;
	}
	
	function setAuthenticatedStatus( $auth )
	{
		$this->m_authenticated = $auth;
	}
	
	function setLocalstartState( $state )
	{
		$this->m_localstart = $state;
	}
	
}
?>