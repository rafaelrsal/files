<?php

	//Connection test ...
	//página para verificação de connecção
	
	$server = '192.168.1.108,1433'; // servidor a ser testado a connexão com o banco
	$user = 'sa'; // usuário do banco
	$senha = 'Sa2012'; // senha do banco
	
	// connect
	$link = mssql_connect($server, $user, $senha);
	
	if (!$link) // conexão foi errada?
	{ // sim
		die ("Algo deu errado na conexão: " . mssql_get_last_message());
	}
	// else{
	// echo $user . "<br />" ;
	// $banco = "baselocal";
	// echo "<br />".$banco."<br />";
	// $retorno = mssql_select_db($banco, $link);
	// // if (!$retorno){
		// // die("não conectado: " . mssql_get_last_message());
		// // }
		// // die("conectado no banco");
	// }
	
	
	// $query = "INSERT INTO acesso (nome, sobrenome) values ('ze', 'jao')";
	
	// $ok = mssql_query($query, $link);
	
	// if($ok){
	 // die("ok");
	 // }else{
	 // die("erro");
	 // }
?>