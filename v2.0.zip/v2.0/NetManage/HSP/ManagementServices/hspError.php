<?PHP
//session_start();
$lang = 'english';
require_once('includes/classes/language.php' );
if ( isset( $_SESSION['language'] ) )
{
	if ( is_string($_SESSION['language']) )
	{	
		$lang = $_SESSION['language'];
	}	
}

$langInc = "includes/languages/$lang/hspError.php";
require_once('includes/classes/stringTranslation.php');
require_once($langInc);


$pageTitle = HSP_ERROR_PAGETITLE;

$errorCodeIndex = 8;

if ( isset($_SESSION['errorCode']) )
{
	$errorCodeIndex = $_SESSION['errorCode'];
}
elseif(isset($_GET['errorCode'])) 
{
	$errorCodeIndex = $_GET['errorCode'];
}

$stringTranslation = new stringTranslation();
$errorText = $stringTranslation->translate( $errorCodeIndex );

?>


<html>
<head>
<script type="text/javascript" src="includes/js/keyHandlers.js"></script>
<link rel="stylesheet" type="text/css" href="portal/style/default/hsp.css">
<META NAME="ROBOTS" CONTENT="NOINDEX">
<title><?php echo $pageTitle;?></title>
</head>

<body>
<table id="table1" cellpadding="3" cellspacing="5">
    <tr>    
        <td align="left" valign="middle">
	        <h1 style="COLOR:000000; FONT: 13pt/15pt verdana">
	        <?php echo $errorText; ?>
	        </h1>
        </td>
    </tr>
    <tr>
        <td colspan="2">
	        <font style="COLOR:000000; FONT: 8pt/11pt verdana">
	        <hr color="#C0C0C0" noshade>
        </td>
    </tr>
</body>
</html>
<script language="javascript" for="window" event="onload">
document.onkeydown = checkKP;
document.oncontextmenu=new Function("return false");
</script>