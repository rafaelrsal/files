<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Author:           Guy Schetrit, Hoter Mickey, Udi Zisser
  Date Created:     August 2004
  Title:            portalPopup.php
  Purpose:          A wrapper for popup windows
  Limitations:		Requires PHP 4.3.x and up (but not 5.x... yet)
 ============================================================================*/ 
 $popupDiv = '';
 if ( isset($_GET['popupDiv']))
 {
 	$popupDiv = $_GET['popupDiv'];
 }
 ?>
<script type="text/javascript" src="includes/js/server.js"></script>
<SCRIPT language="javascript">
var win = window.dialogArguments;
var popupDiv = '<?php echo $popupDiv; ?>';

function getContent()
{		
	if ( '' == popupDiv )
	{
		document.getElementById('popupContent').innerHTML = win.document.getElementById('popupContent').innerHTML;	
	}
	else
	{
		document.getElementById('popupContent').innerHTML = win.document.getElementById(popupDiv).innerHTML;	
	}
	
	initPopup();
}

function setContent()
{
	win.document.getElementById('popupContent').innerHTML = document.getElementById('popupContent').innerHTML;
	finalizePopup();
}

document.onkeydown = checkKP;
function checkKP(e) 
{			

	if (event.keyCode == 27)
	{
		window.close();
	}
}

</SCRIPT>
<html>
	<head>
		<title><?php echo $_GET['Title'] ?></title>
		
		<script language="JavaScript" src="Portal/includes/js/<?php echo $_GET['jsFileName']; ?>"></script>
		<script language="JavaScript" src="admin/includes/js/misc.js"></script>
		<link rel="stylesheet" type="text/css" href="includes/stylesheets/hsp.css">
	</head>
	<body onload='javascript:getContent();'>		
		<div id="popupContent"></div>	
	</body>
</html>