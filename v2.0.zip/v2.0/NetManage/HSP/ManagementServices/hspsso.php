<?php
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: Jan 2005
  Title: hspsso.php
  Purpose: user portal login page.
  Limitations: Requires PHP 4.3.4 and up.

 ============================================================================*/
ini_set("include_path", ".;includes/pear;includes/xmlparser" );
require_once('Portal/includes/portalUser.php');
require_once('includes/classes/PearDB.php');
session_start();
header("Cache-control: private"); // IE6 Fix
define('GLOBAL_CONTEXT','portal');
require_once('includes/global_require.php');
require_once('Portal/includes/Languages/'.CURRENT_LANG.'/index.php');
if ( isset($_SESSION['authenticatedUserType']) || isset($_SESSION['adminAuthFlag']) )
{
	$_SESSION = array();
} 

?>

<html>
<head>

	<OBJECT
			Name = "HSP_SSO"
			CLASSID="CLSID:FF3E22BE-4BB9-438B-95CB-134500153B79"
			Type="application/x-oleobject"
			codebase="HSP_SSO.cab#version=1,1,0,0"
			HEIGHT = "0"
			WIDTH = "0">
	</OBJECT>	

<script language="JavaScript" type="text/javascript">;

function DoSSO()
{
	var ssoInfo = document.HSP_SSO.UserInfo;
	if( typeof ssoInfo != "undefined" )  //check for existance of SSO ActiveX Object
	{
		document.getElementById('ssoParameters').value = ssoInfo;
		document.form1.submit();
	}
	else
	{
		location.href = 'hspError.php?errorCode=9'; //Could not complete Single Sign On execution
	}
}

</script>
<link rel="stylesheet" type="text/css" href="portal/style/default/hsp.css">
</head>
<body scroll="no" onload="setTimeout('DoSSO()',0);">
	<table align="center" border="0">
		<tr>
	    	<td height="10px"></td>
		</tr>
		<tr>			
			<td height="1%">
                <div id="titleBar" align="center">
                <h1 style="COLOR:000000; FONT: 13pt/15pt verdana">
                	Retrieving Data...
	        	</h1>
                </div>
            </td>
		</tr>
	</table>
	
	<form method="POST" action="index.php" id="form1" name="form1">
	<input type="hidden" id="loginUsername" name="loginUsername">
	<input type="hidden" id="domain" name="domain">
	<input type="hidden" id="groups" name="groups">
	<input type="hidden" id="sso" name="sso" value="true">
	<input type="hidden" id="ssoParameters" name="ssoParameters">
	</form>	
</body>
</html>