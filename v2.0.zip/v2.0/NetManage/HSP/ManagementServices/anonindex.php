<?PHP
/*===========================================================================

        Copyright (c) 2004, NetManage Incorporated.  All Rights Reserved.
 ============================================================================

  Authors: Hoter Mickey, Udi Zisser, Guy Schetrit
  Date Created: September 2004
  Title: anonindex.php
  Purpose: user portal anonymous login page.
  Limitations: Requires PHP 4.3.4 and up.
*/
// SESSION HANDLING SECTION - MUST COME BEFORE ANY CODE!!!
ini_set("include_path", ".;includes/pear;includes/xmlparser" );
require_once('Portal/includes/portalUser.php');
require_once('includes/classes/PearDB.php');
session_start();
header("Cache-control: private"); // IE6 Fix
if ( isset($_SESSION['authenticatedUserType']) || isset($_SESSION['adminAuthFlag']) )
{
	$_SESSION = array();
}

include_once('Portal/includes/languages/portuguese/index.php');
$_SESSION['anonymous'] = true;
?>

<script language="JavaScript" type="text/javascript">;
	window.history.forward();
</script>

<script type="text/javascript" src="Portal/includes/js/cookies.js"></script>
<script language="JavaScript">
<!--
window.status = "Micro Focus - Host Services Platform - Anonymous";
//-->
</script>
<HTML>
<TITLE>
<?PHP echo INDEX_TITLE;?>
</TITLE>
<body onload="document.form1.submit();">
	<form method="POST" action="index.php" id="form1" name="form1">	
	</form>
</body>
</HTML>