<?php
class Tmp1805301
{	
	var $m_log;
	var $m_db;
	
	function Tmp1805301( $log=null, $db=null )
	{
		$this->m_db = $db;
		$this->m_log = $log;
	}
	
	function run( $types = null )
	{		
		$ret1 = true;
		$ret2 = true;
		
		$sql = 'SELECT * FROM '. TABLE_VERSIONS. ';';
		$ret = $this->m_db->m_DB->query( $sql );
		$databaseType = $this->m_db->getDBSyntax();
		
		if ( DB::isError($ret) )
		{
			if ( 'mysql' == $databaseType )
			{
				$sql = "CREATE TABLE `" . TABLE_VERSIONS . "` (`version` varchar(255) NOT NULL default '') TYPE=MyISAM;";
			}
			elseif ( 'mssql' == $databaseType )
			{
				$sql = "CREATE TABLE [".TABLE_VERSIONS."] ( [version] VARCHAR(255) NOT NULL DEFAULT '');";
			}
			
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError($ret) )
			{
				$this->m_log->write( LOG_FAIL . "create version table (database type: $databaseType)" );
				$ret1 = false;
			}
			else
			{
				$this->m_log->write( LOG_SUCCESS . "version table created (database type: $databaseType)" );
				
				$ret1 =  true;
			}
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "create version table, table already exists (database type: $databaseType)" );
			$ret1 = true;
		}
				
		$sql = 'SELECT lastUpgrade FROM '. TABLE_GENERAL. ';';	
		$ret = $this->m_db->m_DB->query( $sql );
		if ( DB::isError($ret) )
		{
			$sql = 'ALTER TABLE '. TABLE_GENERAL. ' ADD lastUpgrade VARCHAR(255);';		
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError($ret) )
			{
				$this->m_log->write( LOG_FAIL . "alter hsp_general table (database type: $databaseType)" );
				$ret2 = false;
			}
			else
			{
				$this->m_log->write( LOG_SUCCESS . "hsp_general table altered (database type: $databaseType)" );
				$ret2 = true;
			}
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "alter hsp_general table, column already exists (database type: $databaseType)" );
			$ret2 = true;
		}
		
		return $ret1 && $ret2;
	}
}
?>