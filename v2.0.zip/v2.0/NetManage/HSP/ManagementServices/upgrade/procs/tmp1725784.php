<?php
require_once('upgrade/procBase.php');

class Tmp1725784 extends ProcBase
{		
	///////////////////////////////////////////////
	//	DB upgrade
	///////////////////////////////////////////////
	
	function upgradeDB()
	{
		$databaseType = $this->m_db->getDBSyntax();
		
		$sql = 'SELECT name FROM '. TABLE_DIRECTORIES. ';';	
		$ret = $this->m_db->m_DB->query( $sql );
		if ( !DB::isError($ret) )
		{
			$databaseType = $this->m_db->getDBSyntax();
			if ( 'mysql' == $databaseType )
			{
				$sql = 'ALTER TABLE '. TABLE_DIRECTORIES. ' DROP name;';
			}
			elseif ( 'mssql' == $databaseType )
			{
				$sql = "SELECT so.name FROM sysobjects so INNER JOIN 
						sysconstraints scon ON so.id = scon.constid INNER JOIN 
						syscolumns scol ON scon.id = scol.id AND scon.colid = scol.colid 
						WHERE (so.parent_obj = OBJECT_ID('" . TABLE_DIRECTORIES ."')) AND (so.xtype = 'D')";
				
				$ret = $this->m_db->GetAllEx( $sql , DB_FETCHMODE_ASSOC );
				if ( DB::isError($ret) )
				{
					$this->m_log->write( LOG_FAIL . "get constrains list of hsp_directories (database type: $databaseType)" );
				}
				else
				{
					$constraintName = null;
					foreach ($ret as $recSet) 
					{
						if ( false != strpos($recSet['name'], '__name__') )
						{
							$constraintName = $recSet['name'];
							break;
						}
					}
				}
				
				if ( null != $constraintName )
				{
					$sql = "ALTER TABLE " . TABLE_DIRECTORIES . " DROP CONSTRAINT " . $constraintName;
					$ret = $this->m_db->m_DB->query( $sql );
					if ( DB::isError($ret) )
					{
						$this->m_log->write( LOG_FAIL . "alter table drop default constraint from column name hsp_directories (database type: $databaseType)" );
					}
					else
					{
						$this->m_log->write( LOG_SUCCESS . "alter table drop default constraint from column name hsp_directories (database type: $databaseType)" );
					}
				}
				
				$sql = 'ALTER TABLE '. TABLE_DIRECTORIES. ' DROP COLUMN name;';
			}
			
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError($ret) )
			{
				$this->m_log->write( LOG_FAIL . "alter table drop name hsp_directories (database type: $databaseType)" );
			}
			
			$this->m_log->write( LOG_SUCCESS . "hsp_directories drop table drop name (database type: $databaseType)" );
		}
		
		$sql = 'SELECT ssoname FROM '. TABLE_DIRECTORIES. ';';	
		$ret = $this->m_db->m_DB->query( $sql );
		if ( DB::isError($ret) )
		{
			$sql = 'ALTER TABLE '. TABLE_DIRECTORIES. ' ADD ssoname VARCHAR(255);';		
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError($ret) )
			{
				$this->m_log->write( LOG_FAIL . "alter table add ssoname hsp_directories (database type: $databaseType)" );
				return false;
			}
			
			$this->m_log->write( LOG_SUCCESS . "hsp_directories altere table add ssoname (database type: $databaseType)" );
			return true;
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "alter hsp_directories table, column ssoname already exists (database type: $databaseType)" );
			return true;
		}
	}
	
	///////////////////////////////////////////////
	//	Configuration files upgrade
	///////////////////////////////////////////////
	
	function upgradeFiles()
	{		
		$fp = fopen('data/directoylist', 'w');
		
		$sql = 'select * from ' . TABLE_DIRECTORIES . ' order by display_name;';
		$directories = $this->m_db->GetAllEx( $sql , DB_FETCHMODE_ASSOC );
		
		if ( DB::isError($directories) ) 
		{
			$this->m_log->write( LOG_FAIL . "update directorylist" );
			return false;
		}
		else 
		{
			foreach ( $directories as $dir )
			{
				fwrite($fp, '<option value="' .  $dir['id'] . '">'.$dir['display_name'].'</option>');
			}
		}
		
		$this->m_log->write( LOG_SUCCESS . "update directorylist" );
		fclose($fp);
		
		return true;
	}

}



?>