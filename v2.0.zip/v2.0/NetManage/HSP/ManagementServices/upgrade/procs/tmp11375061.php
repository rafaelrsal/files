<?php
require_once('upgrade/procBase.php');

class Tmp11375061 extends ProcBase
{	
	///////////////////////////////////////////////
	//	DB upgrade
	///////////////////////////////////////////////
	function upgradeDB()
	{
		$databaseType = $this->m_db->getDBSyntax();
		
		$sql = 'SELECT mobile FROM '. TABLE_TREE. ';';	
		$ret = $this->m_db->m_DB->query( $sql );
		if ( DB::isError($ret) )
		{
			$sql = 'ALTER TABLE '. TABLE_TREE. ' ADD mobile INT;';		
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError($ret) )
			{
				$this->m_log->write( LOG_FAIL . "alter hsp_tree table (database type: $databaseType)" );
				return false;
			}
			
			$this->m_log->write( LOG_SUCCESS . "hsp_tree table altered (database type: $databaseType)" );
			
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "alter hsp_tree table, column already exists (database type: $databaseType)" );			
		}
		
		$sql = 'SELECT mobileApp FROM '. TABLE_TREE. ';';	
		$ret = $this->m_db->m_DB->query( $sql );
		if ( DB::isError($ret) )
		{
			$sql = 'ALTER TABLE '. TABLE_APPS_LINKS. ' ADD mobileApp INT;';		
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError($ret) )
			{
				$this->m_log->write( LOG_FAIL . "alter hsp_apps_links table (database type: $databaseType)" );
				return false;
			}
			
			$this->m_log->write( LOG_SUCCESS . "hsp_apps_links table altered (database type: $databaseType)" );
			return true;
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "alter hsp_apps_links table, column already exists (database type: $databaseType)" );
			return true;
		}
		
		
		
	}
}
?>