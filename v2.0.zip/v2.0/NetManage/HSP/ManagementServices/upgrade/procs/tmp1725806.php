<?php
require_once('upgrade/procBase.php');

class Tmp1725806 extends ProcBase
{
	// do nothing - supertemp wrapper
}

?>