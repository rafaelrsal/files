<?php
require_once('upgrade/procBase.php');

class Tmp1576083 extends ProcBase
{	
	///////////////////////////////////////////////
	//	DB upgrade
	///////////////////////////////////////////////
	function upgradeDB()
	{
		$databaseType = $this->m_db->getDBSyntax();
		
		$sql = 'SELECT newWindow FROM '. TABLE_TREE. ';';	
		$ret = $this->m_db->m_DB->query( $sql );
		if ( DB::isError($ret) )
		{
			$sql = 'ALTER TABLE '. TABLE_TREE. ' ADD newWindow VARCHAR(255);';		
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError($ret) )
			{
				$this->m_log->write( LOG_FAIL . "alter hsp_tree table (database type: $databaseType)" );
				return false;
			}
			
			$this->m_log->write( LOG_SUCCESS . "hsp_tree table altered (database type: $databaseType)" );
			return true;
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "alter hsp_tree table, column already exists (database type: $databaseType)" );
			return true;
		}
	}
	
	///////////////////////////////////////////////
	//	XML upgrade
	///////////////////////////////////////////////
	
	function upgradeConfigXML()
	{				
		$this->m_ezXml = new eZXML();
		
		if ( $this->loadConfigXML() )
		{
			
			$setOpenNewWindow = &$this->m_domTree->elementsByName('setOpenNewWindow');
			if ( $setOpenNewWindow == null )
			{
				$umConfig = &$this->m_domTree->elementsByName('um_config_info');
				
				$newElement =& $this->m_domTree->createElementNode( "setOpenNewWindow" );
				$newElement->appendChild( $this->m_domTree->createTextNode( "false" ) );
				
				$umConfig[0]->appendChild( $newElement );
				
				$fp = @fopen('includes/config/config.xml', "w");
				if(true == $fp)
				{
					if(fputs($fp,  $this->m_domTree->toString()))
					{					
						fclose($fp);
						$this->m_log->write( LOG_SUCCESS . "update config.xml" );
						return true;
					}
				}	
			}
			else
			{
				$this->m_log->write( LOG_FAIL . "config.xml already contains setOpenNewWindow element" );
				return true;
			}
		}
		
		$this->m_log->write( LOG_FAIL . "update config.xml" );
		return false;
	}
	
	function loadConfigXML()
	{
		$fd = @fopen( 'includes/config/config.xml', "r" );
		
		if ( $fd )
		{
			$xmlString = @fread($fd, filesize('includes/config/config.xml'));
			@fclose($fd);		
			$this->m_domTree = $this->m_ezXml->domTree( $xmlString );
			return true;
		}
		return false;	
	}
	
	///////////////////////////////////////////////
	//	Configuration files upgrade
	///////////////////////////////////////////////
	
	function upgradeFiles()
	{			
		$configFileString = file_get_contents('data/portalConfiguration.js');
		
		if ( false == strpos($configFileString, 'setOpenNewWindow') )
		{
			$fd = @fopen( 'data/portalConfiguration.js', "a" );
			
			if ( $fd )
			{
				@fwrite($fd, ' var setOpenNewWindow = false;');
				@fclose($fd);
				$this->m_log->write( LOG_SUCCESS . "update portalConfiguration.js" );
				return true;
			}
			
			$this->m_log->write( LOG_FAIL . "update portalConfiguration.js" );
			return false;	
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "setOpenNewWindow already defined in portalConfiguration.js" );
			return true;
		}		
	}

}



?>