<?php
require_once('upgrade/procBase.php');

class Tmp11117643 extends ProcBase
{	
	///////////////////////////////////////////////
	//	DB upgrade
	///////////////////////////////////////////////
	function upgradeDB()
	{
		$databaseType = $this->m_db->getDBSyntax();
		
		$sql = 'SELECT localstart FROM '. TABLE_USERS. ';';
		$ret = $this->m_db->m_DB->query( $sql );
		
		if ( DB::isError( $ret ) )
		{
			$sql = 'ALTER TABLE '. TABLE_USERS. ' ADD localstart INT;';		
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError( $ret ) )
			{
				$this->m_log->write( LOG_FAIL . "alter hsp_users table (database type: $databaseType)" );
				return false;
			}
			
			$this->m_log->write( LOG_SUCCESS . "hsp_users table altered (database type: $databaseType)" );
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "alter hsp_users table, column already exists (database type: $databaseType)" );
		}
		
		$sql = 'SELECT localstart FROM '. TABLE_GROUPS. ';';
		$ret = $this->m_db->m_DB->query( $sql );
		if ( DB::isError( $ret ) )
		{
			$sql = 'ALTER TABLE '. TABLE_GROUPS. ' ADD localstart INT;';		
			$ret = $this->m_db->m_DB->query( $sql );
			if ( DB::isError( $ret ) )
			{
				$this->m_log->write( LOG_FAIL . "alter hsp_groups table (database type: $databaseType)" );
				return false;
			}
			
			$this->m_log->write( LOG_SUCCESS . "hsp_groups table altered (database type: $databaseType)" );
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "alter hsp_groups table, column already exists (database type: $databaseType)" );			
		}
		return true;
	}
	
	///////////////////////////////////////////////
	//	XML upgrade
	///////////////////////////////////////////////
	
	function upgradeConfigXML()
	{				
		$this->m_ezXml = new eZXML();
		
		if ( $this->loadConfigXML() )
		{	
			$enableLocalstart = &$this->m_domTree->elementsByName('enableLocalstart');
			if ( $enableLocalstart == null )
			{
				$umConfig = &$this->m_domTree->elementsByName('um_config_info');
				
				$newElement =& $this->m_domTree->createElementNode( "enableLocalstart" );
				$newElement->appendChild( $this->m_domTree->createTextNode( "0" ) );
				
				$umConfig[0]->appendChild( $newElement );
				
				$fp = @fopen('includes/config/config.xml', "w");
				if(true == $fp)
				{
					if(fputs($fp,  $this->m_domTree->toString()))
					{					
						fclose($fp);
						$this->m_log->write( LOG_SUCCESS . "update config.xml" );
						return true;
					}
				}	
			}
			else
			{
				$this->m_log->write( LOG_FAIL . "config.xml already contains enableLocalstart element" );
				return true;
			}			
		}
		
		$this->m_log->write( LOG_FAIL . "update config.xml" );
		return false;
	}
	
	///////////////////////////////////////////////
	//	Configuration files upgrade
	///////////////////////////////////////////////
	
	function upgradeFiles()
	{			
		$configFileString = file_get_contents('data/portalConfiguration.js');
		
		if ( false == strpos($configFileString, 'enableLocalstart') )
		{
			$fd = @fopen( 'data/portalConfiguration.js', "a" );
			
			if ( $fd )
			{
				@fwrite($fd, ' var enableLocalstart = false;');
				@fclose($fd);
				$this->m_log->write( LOG_SUCCESS . "update portalConfiguration.js" );
				return true;
			}
			
			$this->m_log->write( LOG_FAIL . "update portalConfiguration.js" );
			return false;	
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "enableLocalstart already defined in portalConfiguration.js" );
			return true;
		}		
	}
	
	function loadConfigXML()
	{
		$fd = @fopen( 'includes/config/config.xml', "r" );
		
		if ( $fd )
		{
			$xmlString = @fread($fd, filesize('includes/config/config.xml'));
			@fclose($fd);		
			$this->m_domTree = $this->m_ezXml->domTree( $xmlString );
			return true;
		}
		return false;	
	}
}
?>