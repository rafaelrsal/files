<?php
class ProcBase
{	
	var $m_log;
	var $m_db;
	
	function ProcBase( $log=null, $db=null )
	{
		$this->m_db = $db;
		$this->m_log = $log;
	}
	
	function run( $types = null )
	{
		$ret1 = true;
		$ret2 = true;
		$ret3 = true;
		
		if ( is_array( $types ))
		{
			foreach ( $types as $operationType )
			{
				switch ( $operationType )
				{
					case OPERATION_TYPE_DB:
						$ret1 = $this->upgradeDB();
						break;
					case OPERATION_TYPE_XML:
						$ret2 = $this->upgradeConfigXML();
						break;
					case OPERATION_TYPE_FILE:
						$ret3 = $this->upgradeFiles();
						break;
					default:
						break;
				}
			}
		}
		else 
		{
			$ret1 = $this->upgradeDB();
			$ret2 = $this->upgradeConfigXML();
			$ret3 = $this->upgradeFiles();
		}
		
		// return global state of this temp
		return $ret1 && $ret2 && $ret3;
	}
	
	///////////////////////////////////////////////
	//	DB upgrade
	///////////////////////////////////////////////
	function upgradeDB()
	{
		return true;
	}
	
	///////////////////////////////////////////////
	//	XML upgrade
	///////////////////////////////////////////////
	
	function upgradeConfigXML()
	{
		return true;
	}
	
	///////////////////////////////////////////////
	//	Configuration files upgrade
	///////////////////////////////////////////////
	
	function upgradeFiles()
	{
		return true;
	}
}
?>