<?php
include_once( "lib/ezxml/classes/ezxml.php" );
require_once('includes/classes/logger.php');

define('UPGRADE_XML','upgrade/upgrade.xml');
define('OPERATION_TYPE_DB',0);
define('OPERATION_TYPE_XML',1);
define('OPERATION_TYPE_FILE',2);

define('SESSION_UPGRADE', 'upgrade');

class Upgrade
{
	var $m_fullTempList;
	var $m_upgradeTempList = array();
	var $m_ezXml;
	var $m_domTree;	
	var $m_db;
	var $m_log;

	var $m_bDoUpgrade;
	
	function Upgrade( $db = null )
	{
		$this->m_db = $db;
	}
	
	function init()
	{
		if ( !file_exists(UPGRADE_XML) )
		{
			// we would like to continue normally if no upgrade.xml exists
			// this means that there are no upgrade procs to execute.
			return true;
		}		
		
		$this->m_ezXml = new eZXML();
		
		if ( $this->loadUpgradeXML() )
		{
			$this->populateFullTempList();
			
			if ( $this->checkTimestamp() )
			{			
				$this->m_upgradeTempList = $this->m_fullTempList;
				$this->m_bDoUpgrade = true;
			}
			else
			{
				$this->performeUpgradeCheck();
			}
			
			return true;
		}

		return false;	
	}	
	
	function loadUpgradeXML()
	{
		$fd = @fopen( UPGRADE_XML, "r" );
		
		if ( $fd )
		{
			$xmlString = @fread($fd, filesize(UPGRADE_XML));
			@fclose($fd);		
			$this->m_domTree = $this->m_ezXml->domTree( $xmlString );
			return true;
		}
		return false;
	}	
	
	function run( $types = null )
	{
		$this->m_db->Connect();
		
		$this->m_log = new Logger();
		$this->m_log->open();
		
		if ( $this->m_bDoUpgrade )
		{
			$this->getVersionsFromDB( $versions );
			
			foreach ( $this->m_upgradeTempList as $proc )
			{
				$success = true;
				
				@include_once("upgrade/procs/{$proc['className']}.php");
				$procObj = new $proc['className']( $this->m_log, $this->m_db );
				
				if ( null != $procObj && !$procObj->run( $types ) )
				{
					$this->m_log->write( LOG_FAIL . "temp proccessed - " . $proc['className'] );
					$success = false;					
				}
				else
				{
					$this->m_log->write( LOG_SUCCESS . "temp proccessed - " . $proc['className'] );
				}
				
				if ( $success && ( null == $versions || !in_array( $proc['version'], $versions ) ) )
				{
					$fields_values = array(	'version' => $proc['version']);
					$this->m_db->AutoExecute(TABLE_VERSIONS, $fields_values);
				}
			}
			$this->writeTimestamp();
			$this->m_bDoUpgrade = false;
		}
		
		$this->m_log->close();
	}
	
	function getVersionsFromDB( &$versions )
	{			
		$sql = 'select * from hsp_versions;';
		$tmpVersions = $this->m_db->GetAllEx($sql, null, DB_FETCHMODE_ASSOC);
			
		//on error db_error object
		if ( DB::isError( $tmpVersions ) ) 
		{
			return false;
		}
		
		foreach ( $tmpVersions as $verItem )
		{
			$versions[] = $verItem['version'];
		}
		return true;		
	}
	
	function populateFullTempList()
	{		
		$this->m_fullTempList = array();
		$upgrade_procs = $this->m_domTree->elementsByName('upgrade_procs');
		$upgrade_procs_elements = $upgrade_procs[0]->elementsByName( 'upgrade_proc' );
				
		foreach ($upgrade_procs_elements as $element)
		{
			$ver = $element->elementTextContentByName('version');
			$names = $element->elementsTextContentByName( 'name' );
			foreach( $names as $procName )
			{
				$this->m_fullTempList[] = array('version'=>$ver, 'className'=>$procName);
			}
		}
	}
	
	function performeUpgradeCheck()
	{
		$versions = null;
		
		if ( is_array( $this->m_fullTempList ) )
		{
			$this->getVersionsFromDB( $versions );
						
			foreach ( $this->m_fullTempList as $proc )
			{
				if ( $versions != null && in_array( $proc['version'], $versions ) )
				{
					break;
				}
				else 
				{
					$this->m_upgradeTempList[] = array( 'version'=>$proc['version'], 'className'=>$proc['className'] );
				}
			}
		}
		
		if ( count( $this->m_upgradeTempList ) )
		{
			$this->m_bDoUpgrade = true;
		}
		else
		{
			$this->m_bDoUpgrade = false;
		}
	}
	
	function checkTimestamp()
	{
		$rootElement = $this->m_domTree->elementsByName('upgrade');
		$xmlTimestamp = $rootElement[0]->elementTextContentByName('timestamp');
		
		$sql = 'select lastUpgrade from ' . TABLE_GENERAL . ';';
		$this->m_db->GetOne($sql, $lastUpgrade);
		
		if ( DB::isError($lastUpgrade) || $lastUpgrade != $xmlTimestamp )
		{
			return true; // need to upgrade
		}
		else
		{
			return false; // no need to upgrade
		}
	}
	
	function writeTimestamp()
	{
		$rootElement = $this->m_domTree->elementsByName('upgrade');
		$timestamp = &$rootElement[0]->elementTextContentByName('timestamp');
		
		$timestamp = time();
		
		$fp = @fopen(UPGRADE_XML, "w");
		if(true == $fp)
		{
			if(fputs($fp,  $this->m_domTree->toString()))
			{					
				fclose($fp);
				$this->m_log->write( LOG_SUCCESS . "timestamp $timestamp update.xml" );
			}
			else
			{
				$this->m_log->write( LOG_FAIL . "timestamp $timestamp update.xml" );
			}
		}
		else
		{
			$this->m_log->write( LOG_FAIL . "timestamp $timestamp update.xml" );
		}
			
		$fields_values = array(	'lastUpgrade' => $timestamp );
		$this->m_db->AutoExecute(TABLE_GENERAL, $fields_values, DB_AUTOQUERY_UPDATE);
	}
	
	function getDoUpgrade()
	{
		return $this->m_bDoUpgrade;
	}
}
?>